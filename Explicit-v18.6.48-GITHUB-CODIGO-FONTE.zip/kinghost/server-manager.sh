#!/usr/bin/env bash
set -Eeuo pipefail
case "${1:-}" in
 status) systemctl --no-pager status explicit;;
 iniciar) sudo systemctl start explicit;;
 parar) sudo systemctl stop explicit;;
 reiniciar) sudo systemctl restart explicit;;
 logs) sudo journalctl -u explicit -n 120 --no-pager;;
 teste) curl -fsS http://127.0.0.1:8080/ >/dev/null && echo 'Backend HTTP respondendo (não valida login/voz/tela).';;
 backup)
   sudo install -d -m 700 /var/backups/explicit
   dest="/var/backups/explicit/explicit-$(date +%Y%m%d-%H%M%S).sql"
   sudo mysqldump --single-transaction --routines --triggers explicit | sudo tee "$dest" >/dev/null
   sudo chmod 600 "$dest"
   echo "Backup: $dest";;
 *) echo 'Uso: bash kinghost/server-manager.sh {status|iniciar|parar|reiniciar|logs|teste|backup}'; exit 2;;
esac
