#!/usr/bin/env bash
# OPTIONAL SECOND STEP, only AFTER the API installer has worked.
# Single-VPS pilot. TURN/UDP yes; TURN/TLS 443 no (requires extra routing/IP).
set -Eeuo pipefail
trap 'echo "ERRO na linha $LINENO: LiveKit pode estar parcialmente instalado. O Explicit só ativa LiveKit quando /etc/explicit/livekit.env existe e o serviço é reiniciado." >&2' ERR
[[ $EUID -eq 0 ]] || { echo 'Use sudo'; exit 1; }
[[ $# == 2 ]] || { echo 'Uso: sudo bash kinghost/instalar-livekit-ubuntu.sh media.seudominio.com email@dominio.com'; exit 2; }
MEDIA_DOMAIN=$1; EMAIL=$2
[[ $MEDIA_DOMAIN =~ ^([a-zA-Z0-9-]+\.)+[a-zA-Z]{2,}$ ]] || { echo 'Domínio da mídia inválido'; exit 2; }
[[ $EMAIL =~ ^[^[:space:]@]+@[^[:space:]@]+\.[^[:space:]@]+$ ]] || { echo 'Email inválido'; exit 2; }
BASE=$(cd "$(dirname "$0")/.." && pwd)
[[ -f /etc/systemd/system/explicit.service && -d /opt/explicit/server/web ]] || { echo 'Primeiro instale a API do Explicit (instalar-ubuntu.sh).'; exit 1; }
[[ ! -e /etc/explicit/livekit.env && ! -e /opt/explicit/livekit/livekit.yaml ]] || { echo 'LiveKit já configurado: não vou sobrescrever chaves nem dados. Consulte o manual.'; exit 1; }
. /etc/os-release
[[ $ID == ubuntu ]] || { echo 'Suportado somente Ubuntu'; exit 1; }
echo 'AVISO: este piloto exige liberar TCP 443 e 7881, UDP 3478 e 7882, e bloquear TCP 7880 externo.'
echo 'TURN/TLS na porta 443 não é configurado por este script. Algumas operadoras/firewalls podem continuar bloqueando mídia.'
export DEBIAN_FRONTEND=noninteractive
apt-get update
apt-get install -y docker.io nodejs npm certbot python3-certbot-nginx openssl
systemctl enable --now docker
# Supply an exact-version SDK from npm during installation, never load a CDN in the app.
temp=$(mktemp -d);trap 'rm -rf "$temp"' EXIT
printf '{"name":"explicit-livekit-vendor","private":true,"version":"1.0.0"}\n' > "$temp/package.json"
(cd "$temp" && npm install --no-audit --no-fund --save-exact livekit-client@2.23.0)
install -d -o explicit -g explicit -m 750 /opt/explicit/server/web/vendor
sdk=""
for candidate in "$temp/node_modules/livekit-client/dist/livekit-client.umd.js" "$temp/node_modules/livekit-client/dist/livekit-client.umd.min.js"; do
  if [[ -s "$candidate" && $(wc -c < "$candidate") -gt 100000 ]]; then sdk="$candidate"; break; fi
done
[[ -n "$sdk" ]] || { echo 'ERRO: bundle UMD oficial LiveKit nao encontrado'; exit 1; }
install -m 644 -o explicit -g explicit "$sdk" /opt/explicit/server/web/vendor/livekit-client.umd.min.js
install -d -m 700 /opt/explicit/livekit
API_KEY=$(openssl rand -hex 12)
API_SECRET=$(openssl rand -hex 32)
# Quoted YAML values, keys only contain hex digits.
cat > /opt/explicit/livekit/livekit.yaml <<YAML
port: 7880
log_level: info
rtc:
  tcp_port: 7881
  udp_port: 7882
  use_external_ip: true
keys:
  "$API_KEY": "$API_SECRET"
turn:
  enabled: true
  udp_port: 3478
YAML
chmod 600 /opt/explicit/livekit/livekit.yaml
# Docker host networking permits UDP media without NAT from a bridge.
docker run --detach --name explicit-livekit --restart unless-stopped --network host \
  --mount type=bind,source=/opt/explicit/livekit/livekit.yaml,target=/etc/livekit.yaml,readonly \
  livekit/livekit-server:v1.13.11 --config /etc/livekit.yaml
sleep 4
[[ $(docker inspect --format '{{.State.Running}}' explicit-livekit) == true ]] || { docker logs --tail 80 explicit-livekit; exit 1; }
sed "s/__MEDIA_DOMAIN__/$MEDIA_DOMAIN/g" "$BASE/kinghost/nginx-livekit.conf.template" > /etc/nginx/sites-available/explicit-livekit
ln -sfn /etc/nginx/sites-available/explicit-livekit /etc/nginx/sites-enabled/explicit-livekit
nginx -t
systemctl reload nginx
certbot --nginx -d "$MEDIA_DOMAIN" --non-interactive --agree-tos -m "$EMAIL" --redirect
# Activate only AFTER container, Nginx, TLS issuance and SDK installation succeed.
install -d -o root -g explicit -m 750 /etc/explicit
printf 'LIVEKIT_WS_URL=wss://%s\nLIVEKIT_API_KEY=%s\nLIVEKIT_API_SECRET=%s\n' "$MEDIA_DOMAIN" "$API_KEY" "$API_SECRET" > /etc/explicit/livekit.env
chown root:explicit /etc/explicit/livekit.env
chmod 640 /etc/explicit/livekit.env
# Guarantee the optional EnvironmentFile is available to systemd.
systemctl daemon-reload
systemctl restart explicit
unset API_KEY API_SECRET
printf '\nLiveKit opcional instalado. Teste TLS em https://%s; verifique portas/firewall e participe com 3 clientes atualizados.\n' "$MEDIA_DOMAIN"
echo 'IMPORTANTE: não funciona em todas as redes sem TURN/TLS em 443. Não exponha /etc/explicit/livekit.env.'
