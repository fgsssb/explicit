#!/usr/bin/env bash
set -Eeuo pipefail
trap 'echo "Falha na linha $LINENO. Consulte o erro acima; nenhum banco existente foi apagado." >&2' ERR
[[ $EUID -eq 0 ]] || { echo 'Execute com sudo.'; exit 1; }
[[ $# -eq 2 && $1 =~ ^[a-zA-Z0-9.-]+$ && $2 =~ ^[^[:space:]@]+@[^[:space:]@]+\.[^[:space:]@]+$ ]] || { echo 'Uso: sudo bash kinghost/instalar-ubuntu.sh api.exemplo.com email@exemplo.com'; exit 1; }
DOMAIN=$1; EMAIL=$2
BASE=$(cd "$(dirname "$0")/.." && pwd)
[[ -f "$BASE/Explicit_V16/server/Comunicador_Fase1/go.mod" ]] || { echo 'Arquivos do backend ausentes'; exit 1; }
. /etc/os-release
[[ "$ID" == ubuntu ]] || { echo 'Este instalador exige Ubuntu.'; exit 1; }
export DEBIAN_FRONTEND=noninteractive
apt-get update
apt-get install -y golang-go mysql-server mysql-client nginx certbot python3-certbot-nginx openssl ca-certificates curl
id explicit >/dev/null 2>&1 || useradd --system --home /opt/explicit --shell /usr/sbin/nologin explicit
install -d -o explicit -g explicit -m 750 /opt/explicit/server/data
install -d -o root -g explicit -m 750 /etc/explicit
systemctl enable --now mysql
mysql < "$BASE/kinghost/explicit_database.sql"
if [[ ! -f /etc/explicit/mysql.cnf ]]; then
  PASS=$(openssl rand -hex 32)
  mysql -e "CREATE USER IF NOT EXISTS 'explicit_app'@'localhost' IDENTIFIED BY '$PASS';"
  mysql -e "GRANT SELECT, INSERT, UPDATE, DELETE, CREATE ON explicit.* TO 'explicit_app'@'localhost';"
  printf '[client]\nuser=explicit_app\npassword=%s\nhost=localhost\n' "$PASS" > /etc/explicit/mysql.cnf
  chown root:explicit /etc/explicit/mysql.cnf
  chmod 640 /etc/explicit/mysql.cnf
  unset PASS
fi
(cd "$BASE/Explicit_V16/server/Comunicador_Fase1" && go build -trimpath -o /opt/explicit/server/explicit-server .)
cp -a "$BASE/Explicit_V16/server/Comunicador_Fase1/web" /opt/explicit/server/
chown -R explicit:explicit /opt/explicit/server
chmod 750 /opt/explicit/server/explicit-server
install -m 644 "$BASE/kinghost/explicit.service" /etc/systemd/system/explicit.service
sed "s/__DOMAIN__/$DOMAIN/g" "$BASE/kinghost/nginx-explicit.conf.template" > /etc/nginx/sites-available/explicit
ln -sfn /etc/nginx/sites-available/explicit /etc/nginx/sites-enabled/explicit
nginx -t
systemctl daemon-reload
systemctl enable --now nginx explicit
systemctl restart explicit
sleep 2
curl -fsS http://127.0.0.1:8080/api/ping >/dev/null || { journalctl -u explicit -n 60 --no-pager; exit 1; }
certbot --nginx -d "$DOMAIN" --non-interactive --agree-tos -m "$EMAIL" --redirect
printf '\nExplicit instalado. Teste: https://%s/api/ping\n' "$DOMAIN"
