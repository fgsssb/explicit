# Explicit — versão piloto com LiveKit opcional (v17.3)

**Comece por aqui.** Este ZIP foi preparado para ser enviado à VPS Linux. O código foi integrado e passou em testes locais, mas **não houve acesso a uma VPS KingHost nem chamada real entre 3 computadores**. Portanto o compartilhamento ainda NÃO está comprovado. Não convide público e não use dados importantes sem antes validar em ambiente de testes.

## 1. Em português simples: por que três pessoas falharam?

O Explicit anterior faz chamadas *mesh*: cada computador tenta trocar voz e vídeo diretamente com cada um dos demais. O cliente usa apenas um STUN público, HTTP para negociação e tem tratamento incompleto de alterações de participantes, ICE e renegociação. Isso **pode** explicar por que o segundo espectador não recebeu o vídeo e por que a transmissão caiu, mas não é possível afirmar uma causa única sem logs do momento da falha.

A novidade é **LiveKit SFU opcional**: o transmissor envia o vídeo uma vez ao servidor de mídia; ele distribui aos espectadores. O Go continua cuidando de login, comunidade, permissões, histórico, mensagens e presença. Electron, layout e ícone não foram trocados. Foi introduzido **TypeScript somente no adaptador de mídia**, já compilado para JavaScript, porque dá checagem de tipos sem refazer o aplicativo inteiro.

## 2. O que foi modificado (e por quê)

| Arquivo | Alteração | Motivo |
|---|---|---|
| `server/Comunicador_Fase1/livekit.go` | Novas rotas `/api/media-config` e `/api/livekit-token`, JWT HS256 de 5 minutos e autorização por canal/usuário/fonte | O cliente recebe um convite de mídia temporário, **não** as chaves mestras do servidor |
| `server/Comunicador_Fase1/main.go` | Registro das duas rotas | Disponibilizar configuração autenticada e token |
| `server/Comunicador_Fase1/web/media-src/livekit-adapter.ts` | Novo módulo TypeScript, eventos de áudio/vídeo, encerramento, reconexão básica, PTT e seleção de entrada | O SFU gerencia novos espectadores sem renegociações mesh |
| `server/Comunicador_Fase1/web/livekit-adapter.js` | JavaScript gerado do TypeScript | Executar no Electron sem exigir TypeScript no PC dos amigos |
| `server/Comunicador_Fase1/web/index.html` | Integração condicional de voz/tela com o novo módulo, mantendo o código mesh de retorno | Preservar a interface e permitir rollback |
| `server/Comunicador_Fase1/build-livekit-client.sh` | Compilação TS e instalação opcional de `livekit-client@2.23.0` local | Sem carregar SDK de CDN ao abrir o Explicit |
| `server/Comunicador_Fase1/livekit_test.go` | Testes de assinatura, escopo, permissões e controle de acesso | Reduzir falhas de segurança óbvias |
| `server/Comunicador_Fase1/web/media-src/livekit-adapter.test.js` | Testes simulados de publicação/assinatura e microfone | Verificar lógica JS, não substituir chamadas de verdade |
| `kinghost/explicit.service` | Carrega `/etc/explicit/livekit.env` **se existir** | LiveKit opt-in; padrão continua o antigo |
| `kinghost/nginx-livekit.conf.template` | Proxy WSS específico para subdomínio de mídia | Separar sinalização segura do tráfego UDP |
| `kinghost/instalar-livekit-ubuntu.sh` | Preparação experimental do LiveKit num único servidor: Docker, SDK, Nginx, certificado e chaves | Instalação opcional para piloto |
| `kinghost/server-manager.sh` | Corrige teste HTTP para não usar `/api/ping` sem credenciais | Antes o teste básico acusava erro 401 mesmo com o servidor ativo |

**O que não mudou:** arquivos de contas, schema do banco, mensagens, permissões existentes, canais, comunidades, Electron, ícone e layout. Também não foi acrescentado C++ nem Rust.

## 3. Antes de gastar dinheiro

O plano que aparece em certas ofertas de R$ 53,90/mês na KingHost tem **4 GB de RAM e 2 vCPU**, mas confira **o preço final e o período de compromisso** na página de contratação. Para um teste privado pode ser possível; não é garantia de vários streams. Instale **Ubuntu 24.04** e reserve espaço para backups. É necessário acesso root, Docker e liberação das portas abaixo.

Você precisa de **um domínio com dois subdomínios apontando para o mesmo IP da VPS**:

- `api.seudominio.com` — login, comunidades, mensagens e interface.
- `media.seudominio.com` — LiveKit (`wss://media.seudominio.com`).

Os dois nomes são **exemplos**, substitua pelos seus. Domínio/registrador pode ter custo adicional; o ZIP não inclui domínio.

**Portas necessárias para este piloto** (também no firewall da provedora, caso exista):

| Entrada | Porta | Ação |
|---|---|---|
| SSH | TCP 22 | Permitir, de preferência apenas seu IP |
| HTTPS/Certbot | TCP 80 e 443 | Permitir |
| WebRTC fallback | TCP 7881 | Permitir |
| WebRTC SFU (UDP multiplexado) | UDP 7882 | Permitir |
| TURN/UDP integrado | UDP 3478 | Permitir |
| LiveKit API interna | TCP 7880 | **BLOQUEAR acesso público** — só Nginx local deve alcançar |
| Go API e MySQL | TCP 8080 e 3306 | **BLOQUEAR acesso público** — serviços locais |

Esta configuração **não inclui TURN/TLS em TCP 443**. Parte das redes restritivas pode falhar. O TURN/TLS 443 precisa coexistir com o HTTPS 443 do Nginx no mesmo IP; a solução segura exige um roteador L4/SNI próprio, outro IP ou instalação gerada pela ferramenta oficial do LiveKit. **Não tente pôr o TURN TCP diretamente na 443 enquanto o Nginx a utiliza.**

Links de referência: https://docs.livekit.io/transport/self-hosting/ports-firewall/ e https://docs.livekit.io/transport/self-hosting/vm/.

## 4. Passo a passo em uma VPS nova

### Passo A — enviar e instalar o Explicit original

No PowerShell do Windows (na mesma pasta onde baixou o novo ZIP), com os seus dados reais:

```powershell
scp .\Explicit-KingHost-LiveKit-Piloto-v17.3.zip usuario@IP_DA_VPS:~/
ssh usuario@IP_DA_VPS
```

No Ubuntu:

```bash
sudo apt update
sudo apt install -y unzip
mkdir -p ~/explicit-piloto
unzip ~/Explicit-KingHost-LiveKit-Piloto-v17.3.zip -d ~/explicit-piloto
cd ~/explicit-piloto
sudo bash kinghost/instalar-ubuntu.sh api.seudominio.com email@seudominio.com
bash kinghost/server-manager.sh teste
sudo systemctl status explicit --no-pager
```

**Não rode o instalador em banco que já possui dados reais sem backup.** Esse instalador foi concebido para uma VPS nova e não migra PostgreSQL automaticamente.

### Passo B — instalar mídia (somente se o passo A funcionar)

Confirme primeiro que os dois subdomínios já apontam para a VPS. Execute:

```bash
cd ~/explicit-piloto
sudo bash kinghost/instalar-livekit-ubuntu.sh media.seudominio.com email@seudominio.com
sudo docker ps --filter name=explicit-livekit
sudo docker logs --tail 80 explicit-livekit
sudo systemctl status explicit --no-pager
```

O instalador de mídia é **opt-in** e usa Docker com imagem LiveKit travada na versão `v1.13.11` e SDK de navegador `2.23.0`. Precisa de internet na VPS na instalação para baixar dependências. Se uma etapa falhar, **não considere a mídia instalada**. O segredo principal fica em `/etc/explicit/livekit.env` e não deve ser copiado para o PC.

### Passo C — configurar o programa no Windows

No PC onde você compila o cliente, abra `Explicit_V16/desktop/config.json` e coloque:

```json
{"serverUrl":"https://api.seudominio.com"}
```

No Windows, na pasta `Explicit_V16/desktop`:

```powershell
npm install
npm run build:portable
```

O usuário final só precisa do executável distribuído **já com o endereço de produção**. O backend serve o novo JavaScript da interface e o SDK; para o piloto, **todos os amigos precisam abrir a versão atualizada do aplicativo**. Não compartilhe o arquivo com a senha do LiveKit; o cliente não precisa dele.

**Observação:** os scripts do Electron são para compilar no Windows; o ambiente de testes aqui não gerou um `.exe` portátil do Electron. Existe um `.exe` de **servidor Go** para Windows, que NÃO é o cliente Electron.

## 5. Teste obrigatório com três amigos (critérios de aprovação)

1. Crie três contas, uma comunidade e um canal de voz; entre com A e B, de preferência de redes/operadoras diferentes, **sem Radmin**. Confirme áudio nos dois sentidos, mute e saída/reentrada.
2. A compartilha **uma tela/janela com resolução e FPS modestos** (por exemplo, 720p / 15 FPS); B confirma imagem em movimento por pelo menos 5 minutos.
3. C entra **depois de A já estar transmitindo** e precisa enxergar a mesma tela. Depois C sai e reentra; depois inverter quem inicia a transmissão. Faça pelo menos 5 repetições.
4. Deixe a chamada ligada por **30 minutos**. Procure travamentos, áudio cortando e aumento contínuo de RAM. Teste também com uma conexão via 4G/5G e outra banda larga.
5. Simule uma queda breve de rede no cliente; verifique se LiveKit tenta reconectar e se é possível sair/entrar outra vez sem reiniciar o app. Depois reinicie a VPS e teste mensagens, login, voz e tela novamente.
6. No servidor monitore `sudo docker stats explicit-livekit`, `free -h`, `top`, `sudo docker logs --tail 100 explicit-livekit` e `sudo journalctl -u explicit -n 100 --no-pager`. **Não publique logs com tokens/credenciais.**

**Aprovação mínima para teste privado:** 3 pessoas, duas redes externas diferentes, imagem para B e C, voz utilizável, 30 minutos sem encerramento inesperado, reentrada funcionando e VPS sem swap constante/saturação. Só depois experimente 4+ participantes e mais transmissões.

Se falhar, salve apenas as mensagens de erro sem dados pessoais, horário aproximado, quantidade de usuários e observações CPU/RAM/rede para investigação. O código atual não tem observabilidade completa por fluxo nem garantia de recuperação automática em todo cenário.

## 6. Se LiveKit falhar: como voltar sem quebrar contas/mensagens

O software antigo **continua instalado**. Para desligar só a nova arquitetura de mídia:

```bash
sudo mv /etc/explicit/livekit.env /etc/explicit/livekit.env.desativado
sudo systemctl restart explicit
```

Depois disso, as novas sessões de voz voltam ao modo mesh original; isso **não torna o mesh confiável em redes externas**. Se você quiser reativar a configuração antiga:

```bash
sudo mv /etc/explicit/livekit.env.desativado /etc/explicit/livekit.env
sudo systemctl restart explicit
```

Para ver o estado: `sudo systemctl status explicit --no-pager` e `sudo docker ps --filter name=explicit-livekit`. Use o mesmo arquivo de chaves; **não regenere os segredos** enquanto houver um servidor LiveKit com segredos antigos.

## 7. O que ainda não foi resolvido

- **Sem teste real KingHost:** CPU, RAM, rede, qualidade e compatibilidade de operadoras dependem da VPS real.
- **Sem TURN/TLS na 443:** algumas redes restritivas podem não conectar; é uma pendência de conectividade para operação pública.
- **Moderação de voz ainda parcial:** o Go controla permissões e as ordens de mute, mas o bloqueio de microfone já conectado e a expulsão de participantes devem ser reforçados pelo lado do LiveKit para impedir clientes adulterados.
- **Revogação de tokens:** tokens são curtos (5 min), mas um já emitido não é revogado instantaneamente só porque o usuário sai/é banido; adicionar chamadas administrativas de remoção no SFU antes de abrir ao público.
- **Servidor de voz único:** queda do contêiner/VPS encerra a sessão; faltam testes mais fortes de recuperação e monitoramento/alertas.
- **Banco de dados antigo:** o MySQL ainda salva um estado JSON grande, não é uma migração relacional completa. A escrita usa o cliente de linha de comando MySQL; não é escalável para público.
- **VPS pequena:** Redis não foi incluído neste piloto de nó único. Para produção e escalabilidade, seguir a arquitetura oficial LiveKit e medir CPU/RAM/banda.
- **Conta/sessões:** o backend continua a perder sessões de login em memória depois de reiniciar, exigindo novo login. Isso não é perda das mensagens persistidas.
- **Cliente Windows não foi compilado e executado num PC real** nesta entrega; Electron necessita de teste final de seleção de monitor/janela e permissões.

## 8. Testes de código realmente executados

- `go test ./...` na pasta do backend — passou.
- `node --test web/media-src/livekit-adapter.test.js` — passou em SDK simulado, não em rede real.
- `tsc --target ES2020 --lib ES2020,DOM --skipLibCheck --strict ...` — passou.
- `node --check` nos scripts HTML — passou.
- `npm test` no cliente Electron — 23 testes existentes passaram.
- `bash -n` nos scripts da KingHost — passou.

**Sem garantias irreais:** este ZIP melhora o desenho e a testabilidade, mas não transforma sozinho uma configuração de R$ 53 em uma hospedagem comprovada nem um protótipo em serviço público auditado.
