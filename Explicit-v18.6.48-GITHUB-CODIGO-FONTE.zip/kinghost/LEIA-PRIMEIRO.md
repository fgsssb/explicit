# ATENÇÃO: NOVA ETAPA OPCIONAL LIVEKIT v17.3

**Leia primeiro `kinghost/GUIA-LIVEKIT-SEM-SURPRESAS.md`.** O instalador básico mantém o modo mesh anterior. Para ativar LiveKit de forma controlada depois da API funcionar, use `sudo bash kinghost/instalar-livekit-ubuntu.sh media.seudominio.com email@dominio.com`. Não foi testado na VPS real. TURN/TLS na TCP 443 ainda é pendência.

---

# Explicit v17.2 — Instalação na KingHost (implantação sob responsabilidade do operador)

## O que este pacote efetivamente entrega
Código original do Explicit com interface preservada; backend Go; armazenamento MySQL **compatível com o estado legado em JSON**; arquivo SQL; scripts de instalação e administração; configuração Nginx e systemd. Não é uma implementação relacional completa nem a reformulação integral do prompt mestre. O sistema usa cliente de linha de comando MySQL a cada gravação e não deve ser tratado como escalável ou auditado para exposição pública sem revisão.

## Antes de começar
1. Contrate VPS com Ubuntu (preferencialmente 24.04), acesso SSH e pelo menos 2 GB de RAM. Reserve disco para backups e anexos.
2. Registre um domínio e configure um registro DNS **A** para o IP público da VPS (por exemplo, `api.seudominio.com`).
3. No firewall da VPS/provedor, libere TCP 22 (restrito ao seu IP quando possível), TCP 80 e TCP 443. O tráfego WebRTC pode exigir TURN e portas UDP adicionais, ainda não configurados.
4. Não migre dados reais sem backup. O instalador cria uma base MySQL nova; **não migra automaticamente PostgreSQL**.

## No Windows: envio do ZIP
Abra PowerShell na pasta do ZIP e execute:

```powershell
scp .\Explicit-KingHost-Instalacao-v17.2.zip usuario@IP_DA_VPS:~/
ssh usuario@IP_DA_VPS
```

## No Ubuntu: instalar
```bash
sudo apt update
sudo apt install -y unzip
mkdir -p ~/explicit-v172
unzip ~/Explicit-KingHost-Instalacao-v17.2.zip -d ~/explicit-v172
cd ~/explicit-v172
sudo bash kinghost/instalar-ubuntu.sh api.seudominio.com seu@email.com
```
O script solicita privilégios sudo, instala Go, MySQL, Nginx e Certbot, cria banco e usuário dedicados, compila backend, instala serviço systemd e tenta emitir HTTPS. O domínio deve estar apontado para a VPS para o Certbot funcionar.

## Confirmar funcionamento
```bash
sudo systemctl status explicit --no-pager
sudo systemctl status mysql --no-pager
sudo nginx -t
bash kinghost/server-manager.sh teste
sudo journalctl -u explicit -n 100 --no-pager
```
A rota `/api/ping` exige autorização; abri-la diretamente no navegador retorna 401. Use `bash kinghost/server-manager.sh teste` para conferir HTTP básico. Isso não comprova autenticação, voz, tela ou estabilidade.

## Preparar o cliente Windows
Edite `Explicit_V16/desktop/config.json` substituindo a URL por `https://api.seudominio.com` conforme o formato existente. Dentro da pasta `Explicit_V16/desktop`, execute `npm install` e use os scripts de `package.json` para compilar. O aplicativo ainda utiliza interface servida pelo backend; não é possível prometer bloqueio absoluto de navegadores.

## MySQL e phpMyAdmin
O script importa `kinghost/explicit_database.sql`. Para acessar o MySQL localmente na VPS: `sudo mysql`. As credenciais do app estão protegidas em `/etc/explicit/mysql.cnf` (não as compartilhe). **phpMyAdmin não é instalado automaticamente**; não exponha painel de banco publicamente.

## Backup, logs e recuperação
```bash
bash kinghost/server-manager.sh backup
bash kinghost/server-manager.sh logs
bash kinghost/server-manager.sh reiniciar
```
Antes de atualizar, guarde ZIP anterior e backup SQL. Restaurar banco: `sudo mysql explicit < ARQUIVO.sql` (ação destrutiva: confirme arquivo e backup primeiro).

## Pendências que exigem desenvolvimento
- MySQL relacional normalizado e migração automática PostgreSQL → MySQL.
- Cache híbrido local com sincronização e ACK persistentes.
- Servidor TURN/SFU e testes de chamadas e compartilhamento em redes externas.
- Atualização automática assinada para cliente e servidor.
- phpMyAdmin protegido e gerenciador interativo completo.
- Auditoria de segurança e testes na KingHost real.

**Não use esta compilação com dados importantes ou usuários externos sem antes tratar as pendências de segurança e fazer testes reais.**
