# Estado da implementação — piloto LiveKit v17.3

## Implementado e testado localmente
- [x] API Go permanece com contas, chat, comunidades, permissões e banco anterior.
- [x] Rotas autenticadas `/api/media-config` e `/api/livekit-token` com escopo de usuário/canal e permissões de fontes; testes Go.
- [x] Novo adaptador opcional de mídia em TypeScript compilado para JS; SDK LiveKit local e fixado em 2.23.0 ao instalar.
- [x] Cliente usa SFU no lugar de conexões P2P quando LiveKit é configurado; mesh permanece como fallback de instalação (não fallback silencioso após falha).
- [x] Eventos de tela para quem já está e quem entra depois, áudio, PTT/mute e controle de desconexão; testes simulados.
- [x] Script opcional de implantação single-node Docker, TLS da sinalização Nginx e TURN/UDP.
- [x] Testes estáticos/compilação e suíte Go/Node/TS executados.

## NÃO comprovado / precisa de trabalho adicional
- [ ] 3 computadores reais, 2+ operadoras, pelo menos 30 minutos: não testado.
- [ ] TURN/TLS na TCP 443: não instalado; cobertura incompleta de firewalls restritivos.
- [ ] Proteção via API SFU para mute/ban imediato após emissão do token.
- [ ] Alta disponibilidade e garantia de estabilidade/performance para vários usuários.
- [ ] MySQL normalizado, migração PostgreSQL e testes de segurança pública.
- [ ] Compilar e testar cliente Electron portable em Windows real.
- [ ] Verificar todas as portas e regras de firewall de KingHost na VPS adquirida.

Leia `GUIA-LIVEKIT-SEM-SURPRESAS.md` antes de executar.
