@echo off
cd /d "%~dp0desktop"
if exist dist rmdir /s /q dist
echo Somente a pasta dist foi removida.
pause
