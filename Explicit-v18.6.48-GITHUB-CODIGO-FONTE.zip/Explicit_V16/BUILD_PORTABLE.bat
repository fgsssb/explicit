@echo off
setlocal EnableExtensions
cd /d "%~dp0desktop"
set "LOG=%~dp0BUILD_PORTABLE_LOG.txt"
echo ==============================================
echo EXPLICIT - BUILD PORTABLE WINDOWS x64
echo ==============================================
echo Pasta: %CD%
echo.
where node >nul 2>&1
if errorlevel 1 goto missing_node
where npm.cmd >nul 2>&1
if errorlevel 1 goto missing_npm
if not exist package.json goto missing_package
(
 echo Explicit portable build
 echo Diretório: %CD%
 echo.
) > "%LOG%"
echo Node e npm:
node --version
npm.cmd --version
if exist package-lock.json (
 echo [1/3] Instalando dependencias com npm ci...
 call npm.cmd ci >> "%LOG%" 2>&1
) else (
 echo [1/3] Sem lockfile. Instalando dependencias com npm install...
 call npm.cmd install >> "%LOG%" 2>&1
)
if errorlevel 1 goto failed
set "EXPLICIT_BUILD_VERSION="
for /f "delims=" %%V in ('node -p "require('./package.json').version"') do set "EXPLICIT_BUILD_VERSION=%%V"
if not defined EXPLICIT_BUILD_VERSION goto missing_package
echo [2/3] Validando e gerando executavel...
call npm.cmd run build:portable >> "%LOG%" 2>&1
if errorlevel 1 goto failed
echo [3/3] Verificando resultado...
if not exist "dist\Explicit-%EXPLICIT_BUILD_VERSION%-x64.exe" goto missing_exe
echo.
echo SUCESSO: %CD%\dist\Explicit-%EXPLICIT_BUILD_VERSION%-x64.exe
echo Log: %LOG%
echo.
pause
exit /b 0
:missing_node
echo ERRO: Node.js nao encontrado. Instale Node.js LTS.
goto end_fail
:missing_npm
echo ERRO: npm.cmd nao encontrado. Reinstale Node.js LTS.
goto end_fail
:missing_package
echo ERRO: package.json nao encontrado em %CD%.
goto end_fail
:missing_exe
echo ERRO: build terminou sem gerar o executavel esperado. Confira o log.
goto end_fail
:failed
echo.
echo ERRO: compilacao falhou. Ultimas linhas do log:
powershell -NoProfile -Command "Get-Content -LiteralPath '%LOG%' -Tail 35" 2>nul
:end_fail
echo.
echo LOG COMPLETO: %LOG%
echo Envie o log para identificar a causa exata.
pause
exit /b 1
