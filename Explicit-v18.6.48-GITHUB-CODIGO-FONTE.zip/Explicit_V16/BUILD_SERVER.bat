@echo off
setlocal EnableExtensions
cd /d "%~dp0server\Comunicador_Fase1"
where go >nul 2>&1
if errorlevel 1 (
 echo Instale Go 1.22 ou superior antes de compilar o servidor.
 pause
 exit /b 1
)
go build -trimpath -o ExplicitServer-Teste-Cloud.exe .
if errorlevel 1 (
 echo Falha ao compilar o servidor. Confira a mensagem acima.
 pause
 exit /b 1
)
copy /Y ExplicitServer-Teste-Cloud.exe ExplicitServer-Radmin-Postgres.exe >nul
if errorlevel 1 exit /b 1
echo Servidores Windows gerados. Binarios nao devem ser enviados ao Git.
pause
