@echo off
cd /d "%~dp0desktop"
call npm.cmd start
pause
