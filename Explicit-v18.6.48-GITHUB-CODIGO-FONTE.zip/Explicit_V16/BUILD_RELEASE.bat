@echo off
cd /d "%~dp0desktop"
call npm.cmd run check
if errorlevel 1 exit /b 1
call npm.cmd run pack:win
pause
