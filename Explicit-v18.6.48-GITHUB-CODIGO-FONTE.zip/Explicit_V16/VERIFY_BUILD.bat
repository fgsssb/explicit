@echo off
cd /d "%~dp0desktop"
call npm.cmd run verify
pause
