"use strict";
const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto');
const dir=path.resolve(__dirname,'..','dist');
if(!fs.existsSync(dir)){console.error('Pasta dist não encontrada.');process.exit(1);}
const version=require('../package.json').version;
const expected=`Explicit-${version}-x64.exe`;
const portable=fs.readdirSync(dir).filter(f=>f.toLowerCase()===expected.toLowerCase());
if(!portable.length){console.error('Executável esperado não encontrado:',path.join(dir,expected));process.exit(1);}
for(const file of portable){const full=path.join(dir,file);const stat=fs.statSync(full);if(stat.size<10*1024*1024){console.error('Arquivo inesperadamente pequeno:',file);process.exit(1);}const hash=crypto.createHash('sha256').update(fs.readFileSync(full)).digest('hex');console.log(`${file} | ${(stat.size/1048576).toFixed(1)} MiB | SHA256 ${hash}`);}
console.log('Artefato(s) verificados quanto à presença e tamanho; execução Windows ainda exige teste manual.');
