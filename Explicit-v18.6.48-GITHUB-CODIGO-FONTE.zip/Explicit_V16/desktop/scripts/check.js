"use strict";
const fs=require('node:fs');const path=require('node:path');const cp=require('node:child_process');
const root=path.resolve(__dirname,'..');
const pkg=require(path.join(root,'package.json'));
const required=['main.js','preload.js','picker.html','picker.js','picker-preload.js','picker.css','splash.html','security.js','config.json','ui-tokens.css','fonts/InterVariable.woff2','fonts/OFL.txt'];
for(const f of required){if(!fs.existsSync(path.join(root,f))){console.error('Arquivo obrigatório ausente:',f);process.exit(1);}}
if(!pkg.build?.asar||!pkg.build?.win?.target?.some(t=>t.target==='portable')){console.error('Configuração portátil/ASAR ausente');process.exit(1);}
for(const f of ['main.js','preload.js','picker.js','picker-preload.js','security.js']){
 const result=cp.spawnSync(process.execPath,['--check',path.join(root,f)],{stdio:'inherit'});if(result.status!==0)process.exit(1);
}
let r=cp.spawnSync(process.execPath,['--test',path.join(root,'tests','security.test.js')],{stdio:'inherit'});if(r.status!==0)process.exit(1);
console.log('Verificações de pré-build concluídas.');
