"use strict";
const {app,BrowserWindow,session,shell,dialog,desktopCapturer,Menu,ipcMain,safeStorage,nativeTheme,Notification,Tray,nativeImage}=require('electron');
nativeTheme.themeSource='dark';
// Keep Windows taskbar grouping tied to the Explicit application.
if(process.platform==='win32')app.setAppUserModelId('com.explicit.desktop');
// GPU setting is loaded before app readiness, as required by Electron.
const hardwareFile=()=>require('node:path').join(app.getPath('userData'),'hardware-acceleration.json');
let explicitHardwareEnabled=true;
try{explicitHardwareEnabled=JSON.parse(require('node:fs').readFileSync(hardwareFile(),'utf8')).enabled!==false}catch{}
if(!explicitHardwareEnabled)app.disableHardwareAcceleration();

const fs=require('node:fs');
const path=require('node:path');
const {createHash,randomUUID}=require('node:crypto');
const {getServerURL,isTrustedURL,externalURL}=require('./security');
const startupEpoch=process.hrtime.bigint();
const startupMarks=[];
function startupMark(stage){const ms=Number(process.hrtime.bigint()-startupEpoch)/1e6;startupMarks.push({stage,ms:+ms.toFixed(1)});console.info(`[Explicit startup] ${stage}: ${ms.toFixed(1)} ms`);}
startupMark('main-process-code-start');
let tray=null,quittingExplicit=false,gracefulExitInProgress=false,gracefulExitDone=false;
let win=null,splash=null,activePicker=null,pendingCapture=null,nextCaptureId=0,splashOpenedAt=0,splashReady=false,windowReady=false,splashTimeout=null,splashCreationFailed=false;
const SESSION_FILENAME='remembered-session.dat';
function sessionFile(){return path.join(app.getPath('userData'),SESSION_FILENAME)}
function validSessionSender(event){return !!win&&!win.isDestroyed()&&event.sender===win.webContents&&event.senderFrame===win.webContents.mainFrame&&isTrustedURL(event.sender.getURL(),getServerURL(path.dirname(process.execPath),__dirname,app.isPackaged));}
ipcMain.handle('explicit:session-load',event=>{if(!validSessionSender(event)||!safeStorage.isEncryptionAvailable())return null;try{return safeStorage.decryptString(fs.readFileSync(sessionFile()))}catch{return null}});
ipcMain.handle('explicit:session-save',(event,token)=>{if(!validSessionSender(event)||!safeStorage.isEncryptionAvailable()||typeof token!=='string'||token.length<12||token.length>1024)return false;try{fs.mkdirSync(path.dirname(sessionFile()),{recursive:true});fs.writeFileSync(sessionFile(),safeStorage.encryptString(token),{mode:0o600});return true}catch{return false}});
ipcMain.handle('explicit:device-id',event=>{
 if(!validSessionSender(event))return null;
 let raw='';
 if(process.platform==='win32')try{const {execFileSync}=require('node:child_process');const out=execFileSync('reg',['query','HKLM\\SOFTWARE\\Microsoft\\Cryptography','/v','MachineGuid'],{encoding:'utf8',timeout:1200,windowsHide:true});raw=out.match(/MachineGuid\s+REG_SZ\s+([A-Za-z0-9-]+)/i)?.[1]||''}catch{}
 if(!raw){const file=path.join(app.getPath('userData'),'device-token.txt');try{raw=fs.readFileSync(file,'utf8').trim()}catch{raw=randomUUID();fs.mkdirSync(path.dirname(file),{recursive:true});fs.writeFileSync(file,raw,{mode:0o600})}}
 return createHash('sha256').update('Explicit device v1|'+raw).digest('hex');
});
ipcMain.handle('explicit:session-clear',event=>{if(!validSessionSender(event))return false;try{fs.rmSync(sessionFile(),{force:true});return true}catch{return false}});

// Windows-specific settings; only trusted main-window renderer can call these.
function desktopSettingsAllowed(event){return validSessionSender(event)}
function desktopSettingsUnsupported(){return {supported:false,enabled:false}}
ipcMain.handle('explicit:settings-startup-get',event=>{
 if(!desktopSettingsAllowed(event))return desktopSettingsUnsupported();
 if(process.platform!=='win32')return desktopSettingsUnsupported();
 const state=app.getLoginItemSettings();return {supported:true,enabled:!!state.openAtLogin};
});
ipcMain.handle('explicit:settings-startup-set',(event,enabled)=>{
 if(!desktopSettingsAllowed(event)||typeof enabled!=='boolean'||process.platform!=='win32')return desktopSettingsUnsupported();
 try{
  const opts={openAtLogin:enabled};
  // Portable builds must use the executable actually launched on this computer.
  if(app.isPackaged)opts.path=process.execPath;
  app.setLoginItemSettings(opts);
  return {supported:true,enabled:!!app.getLoginItemSettings().openAtLogin};
 }catch(e){console.warn('Startup setting:',e.message);return desktopSettingsUnsupported()}
});
ipcMain.handle('explicit:settings-info',event=>{
 if(!desktopSettingsAllowed(event))return null;
 return {name:app.getName(),version:app.getVersion(),electron:process.versions.electron,chrome:process.versions.chrome,platform:process.platform,arch:process.arch};
});
ipcMain.handle('explicit:settings-data-folder',async event=>{
 if(!desktopSettingsAllowed(event))return {ok:false};
 try{const result=await shell.openPath(app.getPath('userData'));return {ok:!result,reason:result||''}}catch(e){return {ok:false,reason:e.message}}
});
ipcMain.handle('explicit:settings-logs-folder',async event=>{
 if(!desktopSettingsAllowed(event))return {ok:false};
 try{const logs=app.getPath('logs');fs.mkdirSync(logs,{recursive:true});const result=await shell.openPath(logs);return {ok:!result,reason:result||''}}catch(e){return {ok:false,reason:e.message}}
});
// The renderer can supply only an integer unread count. It cannot provide an
// icon path or HTML, so a compromised webpage cannot make the taskbar display
// arbitrary content. Only the trusted Explicit main window can update it.
let overlayUnread=0;
function updateTaskbarUnread(count){
 overlayUnread=count;
 if(process.platform==='darwin'&&app.dock?.setBadge){app.dock.setBadge(count?(count>=100?'99+':String(count)):'');return}
 if(process.platform!=='win32'||!win||win.isDestroyed())return;
 try{
  const image=count?nativeImage.createFromPath(path.join(__dirname,'unread-overlays',count>=100?'99plus.png':String(count)+'.png')):null;
  win.setOverlayIcon(image&&image.isEmpty()?null:image,count?((count>=100?'99+':String(count))+' notificações não lidas'):'Nenhuma notificação não lida');
 }catch(error){console.warn('Taskbar badge indisponível:',error.message)}
}
ipcMain.handle('explicit:notification-count',(event,count)=>{
 if(!desktopSettingsAllowed(event)||typeof count!=='number'||!Number.isInteger(count)||count<0||count>100)return {ok:false};
 updateTaskbarUnread(count);return {ok:true};
});
ipcMain.handle('explicit:notification-show',(event,payload)=>{
 if(!desktopSettingsAllowed(event)||!payload||typeof payload!=='object'||!Notification.isSupported())return {ok:false};
 const title=String(payload.title||'Explicit').slice(0,90).replace(/[\r\n]/g,' ');
 const body=String(payload.body||'').slice(0,250).replace(/[\r\n]/g,' ');
 try{const note=new Notification({title,body,silent:payload.silent===true});note.on('click',()=>{if(win&&!win.isDestroyed()){if(win.isMinimized())win.restore();win.show();win.focus()}});note.show();return {ok:true}}catch{return {ok:false}}
});
ipcMain.handle('explicit:settings-notification-test',event=>{
 if(!desktopSettingsAllowed(event))return {ok:false};
 if(!Notification.isSupported())return {ok:false,reason:'Notificações não são suportadas neste sistema.'};
 try{new Notification({title:'Explicit',body:'Notificações do Windows funcionando.'}).show();return {ok:true}}catch(e){return {ok:false,reason:e.message}}
});

ipcMain.handle('explicit:settings-hardware-get',event=>desktopSettingsAllowed(event)?{enabled:explicitHardwareEnabled}:{enabled:false});
ipcMain.handle('explicit:settings-hardware-set',(event,enabled)=>{
 if(!desktopSettingsAllowed(event)||typeof enabled!=='boolean')return {ok:false};
 try{fs.mkdirSync(path.dirname(hardwareFile()),{recursive:true});fs.writeFileSync(hardwareFile(),JSON.stringify({enabled}),{mode:0o600});explicitHardwareEnabled=enabled;return {ok:true,enabled}}catch(error){return {ok:false,reason:error.message}}
});
const PICKER_CHANNEL='explicit:capture-choice';
const hasLock=app.requestSingleInstanceLock();
if(!hasLock){app.quit();}else{
 app.on('second-instance',()=>{if(win&&!win.isDestroyed()){if(win.isMinimized())win.restore();win.show();win.focus();}});
 app.whenReady().then(()=>{
  startupMark('electron-ready');
  // Start splash and main window independently: a large splash must not block Chromium navigation.
  const splashPromise=createSplash().catch(e=>{splashCreationFailed=true;console.error('Splash unavailable:',e);});
  try{createWindow();startupMark('main-window-created');}catch(e){dialog.showErrorBox('Configuração do Explicit',e.message);app.quit();return;}
  // Tray is useful but not on the critical path to the first visible window.
  setImmediate(()=>{createExplicitTray();});
  splashPromise.then(()=>{finishSplash();});
 }).catch(e=>{dialog.showErrorBox('Configuração do Explicit',e.message);app.quit();});
 // Ao encerrar de verdade, dá uma curta oportunidade ao cliente de registrar
 // a saída na API antes de destruir a janela. Minimizar para a bandeja não passa aqui.
 app.on('before-quit',event=>{
  quittingExplicit=true;
  if(gracefulExitDone||!win||win.isDestroyed()||win.webContents.isDestroyed())return;
  event.preventDefault();
  if(gracefulExitInProgress)return;
  gracefulExitInProgress=true;
  const timeout=new Promise(resolve=>setTimeout(resolve,1800));
  Promise.race([win.webContents.executeJavaScript('window.explicitGracefulAppExit?.()',false).catch(error=>console.warn('Presence/voice leave on exit:',error.message)),timeout])
   .finally(()=>{gracefulExitDone=true;app.quit();});
 });
 app.on('window-all-closed',()=>{if(quittingExplicit&&process.platform!=='darwin')app.quit();});
 app.on('activate',()=>{if(!win||win.isDestroyed())createWindow();});
}
function showExplicitWindow(){
 if(!win||win.isDestroyed())return;
 if(win.isMinimized())win.restore();
 win.show();win.focus();
}
function createExplicitTray(){
 if(tray)return;
 try{
  const icon=nativeImage.createFromPath(path.join(__dirname,'tray-icon.png'));
  tray=new Tray(icon);
  tray.setToolTip('Explicit — em execução');
  tray.setContextMenu(Menu.buildFromTemplate([
   {label:'Abrir Explicit',click:showExplicitWindow},
   {type:'separator'},
   {label:'Fechar Explicit',click:()=>{quittingExplicit=true;app.quit();}}
  ]));
  tray.on('double-click',showExplicitWindow);
 }catch(error){console.error('Não foi possível criar ícone da bandeja:',error);}
}
function resolveCapture(id,source){
 const pending=pendingCapture;
 if(!pending||pending.id!==id||pending.finished)return;
 pending.finished=true;
 pendingCapture=null;
 const picker=activePicker;
 activePicker=null;
 // Clear state before invoking Chromium's callback to avoid stale close handlers.
 try{pending.callback(source?{video:source}:{});}catch(e){console.warn('Capture completion failed:',e.message);}
 if(picker&&!picker.isDestroyed())picker.close();
}
ipcMain.on(PICKER_CHANNEL,(event,choice)=>{
 const p=pendingCapture;
 if(!p||!activePicker||activePicker.isDestroyed()||event.sender!==activePicker.webContents||event.senderFrame!==activePicker.webContents.mainFrame)return;
 if(!choice||typeof choice!=='object'||choice.requestId!==p.id)return;
 if(choice.sourceId===null){resolveCapture(p.id,null);return;}
 if(typeof choice.sourceId!=='string'||choice.sourceId.length>200)return;
 const selected=p.sources.find(s=>s.id===choice.sourceId);
 if(selected)resolveCapture(p.id,selected);
});
async function showCapturePicker(_request,callback){
 if(pendingCapture)resolveCapture(pendingCapture.id,null);
 if(!win||win.isDestroyed()){callback({});return;}
 const id=++nextCaptureId;
 const p={id,callback,sources:[],finished:false};
 pendingCapture=p;
 try{
  const sources=await desktopCapturer.getSources({types:['screen','window'],thumbnailSize:{width:320,height:180},fetchWindowIcons:true});
  if(pendingCapture!==p||p.finished)return;
  if(!sources.length){resolveCapture(id,null);return;}
  p.sources=sources;
  const picker=new BrowserWindow({parent:win,modal:true,show:false,width:820,height:625,minWidth:600,minHeight:470,minimizable:false,maximizable:false,
   backgroundColor:'#0d1117',title:'Compartilhar tela — Explicit',icon:path.join(__dirname,process.platform==='win32'?'explicit.ico':'explicit-icon.png'),autoHideMenuBar:true,resizable:false,
   webPreferences:{preload:path.join(__dirname,'picker-preload.js'),contextIsolation:true,nodeIntegration:false,sandbox:true,webSecurity:true}});
  activePicker=picker;
  picker.setMenu(null);
  picker.on('closed',()=>{if(activePicker===picker)activePicker=null;resolveCapture(id,null);});
  picker.webContents.setWindowOpenHandler(()=>({action:'deny'}));
  picker.webContents.on('will-navigate',e=>e.preventDefault());
  await picker.loadFile(path.join(__dirname,'picker.html'));
  if(pendingCapture!==p||p.finished||picker.isDestroyed())return;
  picker.webContents.send('explicit:capture-sources',{requestId:id,sources:sources.map(s=>({id:s.id,name:s.name,kind:s.id.startsWith('screen:')?'screen':'window',thumbnail:s.thumbnail&&!s.thumbnail.isEmpty()?s.thumbnail.toDataURL():null,icon:s.appIcon&&!s.appIcon.isEmpty()?s.appIcon.toDataURL():null}))});
  picker.show();
 }catch(e){console.error('Capture picker error:',e.message);resolveCapture(id,null);}
}
const explicitClipboard=require('electron').clipboard;
ipcMain.handle('explicit:clipboard-write',(event,value)=>{if(!validSessionSender(event))throw Error('Janela não autorizada');if(typeof value!=='string'||value.length>4096)throw Error('Texto inválido');explicitClipboard.writeText(value);return true});
// Explicit titlebar actions are authorized only from the trusted main window.
ipcMain.handle('explicit:window-control',(event,action)=>{
 if(!validSessionSender(event)||typeof action!=='string'||!['minimize','maximize','close'].includes(action))return false;
 if(!win||win.isDestroyed())return false;
 if(action==='minimize')win.minimize();
 else if(action==='maximize'){if(win.isMaximized())win.unmaximize();else win.maximize()}
 else win.close(); // Keeps existing minimize-to-tray behavior on close.
 return true;
});
ipcMain.handle('explicit:window-state',event=>{
 if(!validSessionSender(event))return null;
 return {maximized:win.isMaximized(),fullscreen:win.isFullScreen()};
});
function createWindow(){
 const origin=getServerURL(path.dirname(process.execPath),__dirname,app.isPackaged);
 win=new BrowserWindow({show:false,width:1400,height:900,minWidth:900,minHeight:620,backgroundColor:'#090b0e',title:'Explicit 18.6.48',icon:path.join(__dirname,process.platform==='win32'?'explicit.ico':'explicit-icon.png'),autoHideMenuBar:true,...(process.platform==='win32'?{frame:false,roundedCorners:true}:{titleBarStyle:'hidden',titleBarOverlay:{color:'#0b1119',symbolColor:'#e9f4ff',height:34}}),
  webPreferences:{preload:path.join(__dirname,'preload.js'),nodeIntegration:false,contextIsolation:true,sandbox:true,webSecurity:true,backgroundThrottling:false}});
 const frameWindow=win;
 const publishWindowState=()=>{
  if(!frameWindow.isDestroyed())frameWindow.webContents.send('explicit:window-state',{
   maximized:frameWindow.isMaximized(),fullscreen:frameWindow.isFullScreen()
  });
 };
 for(const event of ['maximize','unmaximize','enter-full-screen','leave-full-screen'])frameWindow.on(event,publishWindowState);
 Menu.setApplicationMenu(null);
 // Do not allow an HTML page title (or a server response) to replace the product/version title.
 win.webContents.on('page-title-updated',event=>{event.preventDefault();if(win&&!win.isDestroyed())win.setTitle('Explicit 18.6.48')});
 win.setTitle('Explicit 18.6.48');
 const ses=win.webContents.session;
 const trusted=url=>isTrustedURL(url,origin);
 ses.setPermissionCheckHandler((_wc,permission,requestingOrigin,details)=>{
  if(!trusted(requestingOrigin))return false;
  if(permission==='media')return details?.mediaType!=='video';
  return ['fullscreen','notifications','speaker-selection','display-capture'].includes(permission);
 });
 ses.setPermissionRequestHandler((wc,permission,callback,details)=>{
  if(!wc||wc.isDestroyed()||wc!==win.webContents||!trusted(wc.getURL()))return callback(false);
  if(permission==='media')return callback(details?.mediaTypes?.includes('video')!==true);
  callback(['fullscreen','notifications','speaker-selection','display-capture'].includes(permission));
 });
 ses.setDisplayMediaRequestHandler((request,callback)=>{
  if(!win||win.isDestroyed()||!request.frame||request.frame!==win.webContents.mainFrame||!trusted(request.frame.url))return callback({});
  showCapturePicker(request,callback).catch(e=>console.error('Capture failure:',e.message));
 });
 win.webContents.setWindowOpenHandler(({url})=>{const safe=externalURL(url);if(safe)shell.openExternal(safe).catch(()=>{});return {action:'deny'};});
 win.webContents.on('will-navigate',(e,url)=>{if(!trusted(url))e.preventDefault();});
 win.webContents.on('will-redirect',(e,url)=>{if(!trusted(url))e.preventDefault();});
 win.webContents.on('render-process-gone',()=>{if(win&&!win.isDestroyed())dialog.showMessageBox(win,{type:'warning',message:'A interface do Explicit parou de responder. Reinicie o aplicativo.'});});
 win.on('close',event=>{if(!quittingExplicit&&tray){event.preventDefault();win.hide();}});
 win.on('closed',()=>{if(pendingCapture)resolveCapture(pendingCapture.id,null);win=null;if(splashTimeout)clearTimeout(splashTimeout);});
 setSplash(36,'Conectando ao servidor…');
 win.webContents.once('did-finish-load',()=>{
  startupMark('main-window-dom-loaded');
  setSplash(85,'Preparando a interface…');
  // A hidden Chromium window may throttle requestAnimationFrame indefinitely.
  // did-finish-load confirms the page loaded; a bounded fallback prevents a stuck splash.
  const loadedWindow=win;
  const revealTimer=setTimeout(()=>{if(win===loadedWindow)finishSplash();},800);
  loadedWindow.webContents.executeJavaScript(
   'new Promise(resolve => { requestAnimationFrame(() => requestAnimationFrame(resolve)); })',true)
   .then(()=>{clearTimeout(revealTimer);if(win===loadedWindow)finishSplash();})
   .catch(()=>{clearTimeout(revealTimer);if(win===loadedWindow)finishSplash();});
 });
 win.loadURL(origin).catch(e=>{console.error('Server load error:',e.message);splashError('Não foi possível acessar o servidor configurado. Confira o endereço HTTPS e se o túnel está aberto.');});
 win.webContents.on('did-fail-load',(_e,code,description,_url,isMainFrame)=>{
  if(isMainFrame&&win&&!win.isDestroyed())splashError(`Não foi possível acessar ${origin} (erro ${code}). Confirme o túnel e a configuração do cliente.`);
 });
}

async function createSplash(){
 splash=new BrowserWindow({width:380,height:265,show:false,frame:false,resizable:false,center:true,alwaysOnTop:true,skipTaskbar:true,icon:path.join(__dirname,process.platform==='win32'?'explicit.ico':'explicit-icon.png'),backgroundColor:'#0d141b',webPreferences:{nodeIntegration:false,contextIsolation:true,sandbox:true,webSecurity:true}});
 splash.setMenu(null);
 splash.on('closed',()=>{splash=null;});
 try{
  await splash.loadFile(path.join(__dirname,'splash.html'));
  if(splash&&!splash.isDestroyed()){
   splash.show();
   startupMark('splash-visible');
   splashOpenedAt=Date.now();
   splashReady=true;
   setSplash(12,'Iniciando Explicit…');
  }
 }catch(e){console.error('Splash:',e.message);throw e;}
}
function setSplash(percent,label){
 if(!splash||splash.isDestroyed())return;
 const data=JSON.stringify({percent,label});
 splash.webContents.executeJavaScript(`window.explicitSplashUpdate&&window.explicitSplashUpdate(${data})`,true).catch(()=>{});
}
function splashError(label){
 if(splash&& !splash.isDestroyed())setSplash(null,label);
 else dialog.showErrorBox('Explicit',label);
}
function finishSplash(){
 if(!win||win.isDestroyed()||windowReady)return;
 // The main renderer can finish before the splash loads. Do not show a blank window.
 if(!splashReady&&!splashCreationFailed)return;
 windowReady=true;
 setSplash(100,'Pronto!');
 // A short visual minimum avoids a flash, without imposing the old 1.7-second delay.
 const remaining=splashReady?Math.max(0,350-(Date.now()-splashOpenedAt)):0;
 splashTimeout=setTimeout(()=>{
  splashTimeout=null;
  if(!win||win.isDestroyed())return;
  win.maximize();
  win.show();
  startupMark('main-window-visible');
  if(splash&&!splash.isDestroyed())splash.close();
 },remaining);
}
