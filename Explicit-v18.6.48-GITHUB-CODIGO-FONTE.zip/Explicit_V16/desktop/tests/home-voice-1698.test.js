const test=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const root=path.join(__dirname,'../../server/Comunicador_Fase1');
const html=fs.readFileSync(path.join(root,'web/index.html'),'utf8');
const go=fs.readFileSync(path.join(root,'communities.go'),'utf8');
test('home headings and CTA copy updated',()=>{
 assert.match(html,/Anúncios e Divulgações/);
 const home=html.slice(html.indexOf('async function openHome(){'),html.indexOf("document.body.classList.remove('explicit-light-theme');",html.indexOf('async function openHome(){')));assert.doesNotMatch(home,/Bem-[Vv]indo ao/);assert.doesNotMatch(home,/explicitHomeDate/);
 assert.match(html,/Solicitar divulgação/);
 assert.doesNotMatch(html,/QR Code de exemplo<\/span>/);
});
test('home list scroll is scoped to the home page and both themes',()=>{
 for(const id of ['#homeFriends','#homeNotifications','#homeSpaces'])assert.ok(html.includes(id));
 assert.match(html,/overflow-x:auto!important/);
 assert.match(html,/explicit-light-theme\.explicit-session-ready\.explicit-home :is\(#homeFriends/);
});
test('channel voice permissions exposed and server validated',()=>{
 assert.match(html,/\['SPEAK','Falar'\]/);
 assert.match(html,/\['USE_PTT','Usar push-to-talk'\]/);
 assert.match(go,/validateOverrides\(/);
 assert.match(fs.readFileSync(path.join(root,"channel_permissions.go"),"utf8"),/"SPEAK"\s*:\s*true/);
});
test('login loading uses official icon',()=>{
 assert.match(html,/explicit-loading-logo"><img src="\/explicit-icon.png"/);
 assert.ok(fs.existsSync(path.join(root,'web/explicit-icon.png')));
});
