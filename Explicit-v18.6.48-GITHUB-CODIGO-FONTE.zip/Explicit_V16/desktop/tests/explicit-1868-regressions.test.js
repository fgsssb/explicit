'use strict';
const {test} = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const web = path.resolve(__dirname,'../../server/Comunicador_Fase1/web');
const html = fs.readFileSync(path.join(web,'index.html'),'utf8');
const nav = fs.readFileSync(path.join(web,'navigation-explicit.js'),'utf8');
const hub = fs.readFileSync(path.join(web,'community-hub.js'),'utf8');
const refinements = fs.readFileSync(path.join(web,'refinements.js'),'utf8');
test('login and registration labels are synchronized with the desktop bar',()=>{
 assert.match(nav,/explicitAuthMode==='register'\?'CADASTRO':'LOGIN'/);
 assert.match(html,/window\.explicitNavRender\?\.\(\)/);
});
test('DM title reads usernames from the actual chat participants',()=>{
 assert.match(html,/\(c\.users\|\|\[\]\)\.find\(name=>name!==myself\)/);
 assert.doesNotMatch(html,/Conversa privada com o usuário @'\+\(c\.display_name/);
});
test('profiles offer friend requests and real usernames for member and chat actions',()=>{
 assert.match(html,/function explicitFriendRequestAction\(/);
 assert.match(html,/explicitFriendRequestAction\(user,pop\)/);
 assert.match(html,/box\.dataset\.author=m\.author/);
 assert.match(html,/d\.dataset\.author=m\.author/);
});
test('community menus filter sensitive actions against server-issued permissions',()=>{
 assert.match(hub,/await fetchInfo\(c\)/);
 assert.match(hub,/if\(can\(info,'CREATE_CHANNEL'\)\)/);
 assert.match(hub,/if\(can\(info,'MANAGE_CHANNELS'\)\)/);
 assert.match(refinements,/adminState\?\.permissions/);
});
test('Home keeps unread notifications until user explicitly marks them read',()=>{
 const home=html.slice(html.indexOf('async function openHome(){'),html.indexOf("document.body.classList.remove('explicit-light-theme');",html.indexOf('async function openHome(){')));
 assert.doesNotMatch(home,/action:'read_misc'/);
 assert.match(home,/homeMarkNotificationsRead/);
 assert.match(home,/action:'read_all'/);
});
