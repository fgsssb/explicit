const test=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const html=fs.readFileSync(path.join(__dirname,'../../server/Comunicador_Fase1/web/index.html'),'utf8');
const media=fs.readFileSync(path.join(__dirname,'../../server/Comunicador_Fase1/web/livekit-adapter.js'),'utf8');
test('home 18.2 retains required layout, limits and palette',()=>{
 assert.match(html,/friends:5,communities:5,notifications:5/);
 for(const v of ['spot friends','communities communities','support support','grid-template-columns:repeat(5,minmax(0,1fr))','background:#030405','color:#6ca6df'])assert.ok(html.includes(v),v);
});
test('community chooser translucent with blur, black cards',()=>{
 assert.match(html,/\.obsidian-modal-backdrop\.explicit-community-choice-backdrop/);
 assert.match(html,/background:rgba\(2,4,8,\.43\)!important/);
 assert.match(html,/background:#10141a!important/);
});
test('screen stage removes channel search button and composer',()=>{
 assert.match(html,/body\.explicit-screen-view #explicitSearchButton/);
 assert.match(html,/body\.explicit-screen-view #form\{display:none!important\}/);
});
test('voice can be muted or deafened before joining, with microphone muted on deafen',()=>{
 assert.ok(!html.includes('id="voiceMute" class="icon-control" title="Mutar microfone" aria-label="Mutar microfone" disabled'));
 assert.match(html,/voiceCanSpeak&&!voiceMuted&&!voiceDeaf&&!adminMuted/);
 assert.match(html,/muted:voiceMuted\|\|voiceDeaf,deaf:voiceDeaf/);
 assert.match(html,/if\(voiceMuted\|\|voiceDeaf\)await voiceRequest/);
 assert.match(media,/if \(auth\.can_speak && !startMuted\)/);
 assert.match(html,/explicit-voice-user-state/);
});
