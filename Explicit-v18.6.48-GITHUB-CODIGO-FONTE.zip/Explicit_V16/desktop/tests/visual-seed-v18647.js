() => {
 session='qa-isolated-not-a-real-token';document.getElementById('auth').style.setProperty('display','none','important');document.getElementById('app').style.setProperty('display','block','important');document.getElementById('who').textContent='Jean';document.body.classList.add('explicit-session-ready');
 communities=[{id:'qa-community',name:'Explicit • Comunidade',owner:'Jean',channels:['geral','avisos','clipes','Lobby','Warface','Ausentes'],channel_meta:{geral:{type:'text'},avisos:{type:'text'},clipes:{type:'text'},Lobby:{type:'voice'},Warface:{type:'voice'},Ausentes:{type:'voice'}}}];activeCommunity='qa-community';activeChannel='geral';
 adminState={permissions:['MANAGE_CHANNELS','MANAGE_ROLES','MANAGE_MEMBERS'],roles:[],members:[]};
 memberPresence=[{user:'Jean',display_name:'Jean',online:true,status:'online',system_role:'owner'},{user:'Lucas',display_name:'Lucas',online:true,status:'online'},{user:'Marina',display_name:'Marina',online:true,status:'away'},{user:'Rafael',display_name:'Rafael',online:false,status:'offline'}];
 voicePresenceState={Warface:[{user:'Jean',display_name:'Jean',muted:false,deaf:false},{user:'Lucas',display_name:'Lucas',muted:false,deaf:false}]};
 openSpaces();renderCommunitiesRail();renderChannels();renderMembers();document.getElementById('channelTitle').textContent='# geral';
 document.getElementById('messages').replaceChildren();
 [{author:'Jean',text:'Boa tarde, pessoal! Já estão prontos para jogar hoje?'},{author:'Marina',text:'Estou terminando umas coisas e já entro no canal.'},{author:'Lucas',text:'Bora! Deixei o canal Warface aberto pra gente.'},{author:'Jean',text:'Fechado. Se alguém quiser entrar, é só chegar. ✌️'},{author:'Lucas',text:'A transmissão está com uma qualidade muito boa.'}].forEach((m,i)=>add({...m,id:'qa'+i,time:'2026-11-04T15:'+String(10+i).padStart(2,'0')+':00Z'}));
 explicitSetSpeaking('Lucas',true);
}
