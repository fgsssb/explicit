"use strict";
const test=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path');
const web=path.join(__dirname,'../../server/Comunicador_Fase1/web');
const html=fs.readFileSync(path.join(web,'index.html'),'utf8');
const js=fs.readFileSync(path.join(web,'direct-calls.js'),'utf8');
const css=fs.readFileSync(path.join(web,'direct-calls.css'),'utf8');
const server=fs.readFileSync(path.join(web,'../social.go'),'utf8');
test('group creation is in the DM header, not the narrow rail',()=>{
 assert.doesNotMatch(html,/const createGroup=document.createElement/);
 assert.match(js,/Adicionar pessoas/);assert.match(js,/config\.initial/);
});
test('call invitation, ring, and join require no pre-existing media connection',()=>{
 assert.match(js,/request\(id,'peek'\)/);
 assert.match(js,/Chamada recebida/);assert.match(js,/Participar da chamada/);
 assert.match(js,/function chime/);assert.match(js,/window\.explicitDirectCallRailUpdate/);
});
test('audio controls use headphones; screen video gets main stage',()=>{
 assert.match(js,/headphonesOff/);assert.match(js,/Desativar áudio/);
 assert.doesNotMatch(js,/Entrar na chamada e compartilhar tela/);
 assert.match(css,/\.explicit-private-call\.is-streaming/);
 assert.match(css,/\.explicit-private-call\.is-streaming \.explicit-private-participants\{display:none/);
 assert.match(js,/está transmitindo/);
});
test('group defaults to comma-separated people and max eight on server',()=>{
 assert.match(server,/group must have 3 to 8 members/);
 assert.match(server,/len\(c\.Users\)\+len\(q\.Targets\) > 8/);
 assert.match(server,/strings\.Join\(users\[1:\], ", "\)/);
 assert.match(js,/explicit-dm-title-editable/);
});
