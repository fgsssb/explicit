const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const base = path.join(__dirname, '../../server/Comunicador_Fase1/web');
const script = fs.readFileSync(path.join(base, 'name-presets.js'), 'utf8');
const css = fs.readFileSync(path.join(base, 'name-presets.css'), 'utf8');
const html = fs.readFileSync(path.join(base, 'index.html'), 'utf8');

test('personalization is embedded into Conta with five preset slots, not a separate inventory', () => {
  assert.match(script,/const presetLimit=5/);
  assert.match(script,/async function personalization\(host\)/);
  assert.match(css,/explicit-name-style-grid/);
  assert.match(html,/Conta · Personalização/);
  assert.doesNotMatch(html,/Conta · Inventário/);
});
test('presets only use the validated server style schema, and no arbitrary CSS/HTML', () => {
  assert.match(script, /const normalize=/);
  assert.match(script, /function paint\(elm,s\)/);
  assert.match(script, /const prepared=normalize\(state\)/);
  assert.doesNotMatch(script, /innerHTML\s*=/);
  assert.match(script, /for\(const n of \[bigName,chat,member,profile\]\)paint\(n,prepared\)/);
});
test('effects respect global chat colors, use ordered gradient stops, and support reduced motion', () => {
  assert.match(script, /style\.setProperty\('color',x\.color,'important'\)/);
  assert.match(script, /#ffffff 47%,\$\{a\} 53%/);
  assert.match(css, /@media\(prefers-reduced-motion:reduce\)/);
  assert.match(css, /explicit-name-anim-shine/);
});
test('editing uses tabs and live preview of chat, member list and profile', () => {
  for (const text of ['Cores', 'Fonte', 'Brilho', 'NO CHAT', 'NA LISTA DE MEMBROS', 'NO PERFIL']) {
    assert.ok(script.includes(text), `Missing ${text}`);
  }
  assert.match(script, /api\('name-presets','POST',\{action:'save'/);
  assert.match(script, /api\('name-presets','POST',\{action:'equip'/);
  assert.match(script, /api\('name-presets','POST',\{action:'delete'/);
});
test('asset loads use new versioned stylesheet and script', () => {
  assert.match(html, /name-presets\.css\?v=\d+/);
  assert.match(html, /name-presets\.js\?v=\d+/);
});
