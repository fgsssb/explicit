'use strict';
const {test}=require('node:test');const assert=require('node:assert/strict');
const fs=require('node:fs'),path=require('node:path'),vm=require('node:vm');
// DOM double for interaction regressions. Does not simulate visual layout.
class Element {
 constructor(doc){this.doc=doc;this.children=[];this.dataset={};this.attributes={};this.listeners={};this.className='';this.isConnected=true;this.disabled=false;this.classList={toggle:(name,on)=>{const names=new Set(this.className.split(' ').filter(Boolean));if(on)names.add(name);else names.delete(name);this.className=[...names].join(' ')}}}
 append(...nodes){for(const n of nodes){n.parent=this;this.children.push(n)}}
 replaceChildren(...nodes){for(const n of this.children)n.isConnected=false;this.children=[];this.append(...nodes)}
 setAttribute(k,v){this.attributes[k]=v}
 querySelectorAll(selector){return this.children.flatMap(c=>[...(selector==='.tile'&&c.className.split(' ').includes('tile')?[c]:[]),...c.querySelectorAll(selector)])}
 querySelector(s){return this.querySelectorAll(s)[0]||null}
 contains(node){return this===node||this.children.some(c=>c.contains(node))}
 focus(){this.doc.activeElement=this}
 addEventListener(k,fn){(this.listeners[k]??=[]).push(fn)}
 removeEventListener(k,fn){this.listeners[k]=(this.listeners[k]||[]).filter(f=>f!==fn)}
 remove(){this.isConnected=false;if(this.parent)this.parent.children=this.parent.children.filter(c=>c!==this)}
 fire(k,event){for(const fn of this.listeners[k]||[])fn(event)}
}
function fixture(){
 const doc={activeElement:null,createElement(){return new Element(this)},addEventListener(){}};
 const ids=Object.fromEntries(['grid','share','hint','cancel','obsidianModalRoot'].map(id=>[id,new Element(doc)]));ids.share.disabled=true;
 const tabs=['screen','window'].map(kind=>{const b=new Element(doc);b.dataset.kind=kind;return b});tabs[0].className='active';
 doc.getElementById=id=>ids[id];doc.querySelectorAll=()=>tabs;doc.querySelector=()=>tabs.find(t=>t.className==='active');
 const calls=[];let deliver;const ctx=vm.createContext({document:doc,window:{explicitPicker:{onSources:fn=>deliver=fn,choose:id=>calls.push(id),cancel(){}}}});
 vm.runInContext(fs.readFileSync(path.join(__dirname,'../picker.js'),'utf8'),ctx);
 return {doc,ids,tabs,calls,deliver:data=>deliver(data),ctx};
}
const sources=[{id:'screen:1',kind:'screen',name:'Tela principal'},{id:'window:2',kind:'window',name:'Uma janela'}];
test('trocar categoria limpa seleção e impede transmitir fonte oculta',()=>{
 const f=fixture();f.deliver(sources);f.ids.grid.children[0].onclick();assert.equal(f.ids.share.disabled,false);
 f.tabs[1].onclick();assert.equal(f.ids.share.disabled,true);f.ids.share.onclick();assert.deepEqual(f.calls,[]);
 assert.equal(f.tabs[1].attributes['aria-pressed'],'true');assert.equal(f.tabs[0].attributes['aria-pressed'],'false');
 f.ids.grid.children[0].onclick();f.ids.share.onclick();assert.deepEqual(f.calls,['window:2']);
});
test('selecionar mantém botão focado e permite duplo clique',()=>{
 const f=fixture();f.deliver(sources);const tile=f.ids.grid.children[0];tile.focus();tile.onclick();
 assert.equal(f.doc.activeElement,tile);assert.equal(f.ids.grid.children[0],tile);assert.equal(tile.attributes['aria-pressed'],'true');
 tile.ondblclick();assert.deepEqual(f.calls,['screen:1']);
});
test('fonte removida desabilita transmissão e limpa status',()=>{
 const f=fixture();f.deliver(sources);f.ids.grid.children[0].onclick();f.deliver([]);f.ids.share.onclick();
 assert.equal(f.ids.share.disabled,true);assert.deepEqual(f.calls,[]);assert.equal(f.ids.hint.textContent,'Selecione uma fonte para continuar');
});
test('atualização restaura foco pelo identificador da fonte',()=>{
 const f=fixture();f.deliver(sources);const before=f.ids.grid.children[0];before.focus();before.onclick();f.deliver(sources);
 assert.notEqual(f.doc.activeElement,before);assert.equal(f.doc.activeElement.dataset.sourceId,'screen:1');assert.equal(f.ids.share.disabled,false);
});
test('Escape da confirmação é consumido e retorna ao acionador',async()=>{
 const f=fixture();const html=fs.readFileSync(path.join(__dirname,'../../server/Comunicador_Fase1/web/index.html'),'utf8');
 const code=html.slice(html.indexOf('function nexoModal('),html.indexOf('function nexoPrompt('));
 let back;f.ctx.el=id=>f.ids[id];f.ctx.explicitMountModal=node=>{back=node};const opener=new Element(f.doc);opener.focus();
 vm.runInContext(code,f.ctx);const result=vm.runInContext("nexoModal('Confirmar','Texto')",f.ctx);
 let prevented=false,stopped=false;back.fire('keydown',{key:'Escape',preventDefault(){prevented=true},stopPropagation(){stopped=true}});
 assert.equal(await result,null);assert.equal(prevented,true);assert.equal(stopped,true);assert.equal(f.doc.activeElement,opener);
});
