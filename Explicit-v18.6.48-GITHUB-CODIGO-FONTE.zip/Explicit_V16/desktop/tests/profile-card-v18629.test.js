'use strict';
const test=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const web=path.join(__dirname,'../../server/Comunicador_Fase1/web');
const html=fs.readFileSync(path.join(web,'index.html'),'utf8');
const css=fs.readFileSync(path.join(web,'ux-v18627.css'),'utf8');
const ux=fs.readFileSync(path.join(web,'ux-v18627.js'),'utf8');

test('status action and settings gear share the account card but remain separate buttons',()=>{
 const markup=html.match(/<div class="explicit-account-line">(.+?)<\/div><div class="voice-status-line"/);
 assert.ok(markup,'account card markup must exist in the actual voice dock');
 assert.match(markup[1],/<button id="explicitMiniProfile"[^>]+onclick="toggleExplicitProfileMenu\(event\)"/);
 assert.match(markup[1],/<\/button><button id="explicitSettingsGear"[^>]+aria-label="Abrir configurações"/);
 assert.equal((markup[1].match(/<button\b/g)||[]).length,2);
 assert.match(css,/\.voice-dock \.explicit-account-line\{[\s\S]*?border:1px solid #273849!important/);
 assert.match(css,/\.voice-dock \.explicit-account-line \.explicit-mini-profile\{[\s\S]*?border:0!important/);
 assert.match(css,/\.voice-dock \.explicit-account-line \.explicit-profile-gear\{[\s\S]*?border:0!important/);
});
test('the same card contains both actions and keeps the settings click independent',()=>{
 assert.match(ux,/getElementById\('explicitSettingsGear'\)/);
 assert.match(ux,/gear\.onclick=ev=>\{ev\.stopPropagation\(\)/);
 assert.match(css,/\.voice-dock \.explicit-account-line \.explicit-profile-gear:focus-visible/);
 assert.match(css,/body\.explicit-light-theme \.voice-dock \.explicit-account-line/);
});
