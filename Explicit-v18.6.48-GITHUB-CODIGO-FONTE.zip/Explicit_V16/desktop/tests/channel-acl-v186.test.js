const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const root = path.join(__dirname,'../../server/Comunicador_Fase1');
const ui = fs.readFileSync(path.join(root,'web/channel-acl.js'),'utf8');
const html = fs.readFileSync(path.join(root,'web/index.html'),'utf8');
const css = fs.readFileSync(path.join(root,'web/channel-acl.css'),'utf8');
test('channel ACL UI is loaded by real desktop HTML',()=>{
 assert.match(html, /channel-acl\.js\?v=186\d+/);
 assert.match(html, /channel-acl\.css\?v=186\d+/);
 assert.ok(fs.statSync(path.join(root,'web/channel-acl.js')).size>1000);
});
test('tri-state role/user editor has synchronized category and private channel controls',()=>{
 for(const value of ['deny','inherit','allow']) assert.ok(ui.includes(value));
 for(const key of ['VIEW_CHANNEL','SEND_MESSAGES','CONNECT_VOICE','SPEAK','SCREEN_SHARE','USE_STICKERS','ATTACH_FILES'])assert.ok(ui.includes(key));
 assert.match(ui, /category_create/);
 assert.match(ui, /channel_sync/);
 assert.match(ui, /member_permissions/);
 assert.match(ui, /private:privateCheck\.checked/);
});
test('new permission UI respects existing Explicit colors and blur',()=>{
 for(const c of ['#6ca6df','#0b1118'])assert.ok(css.includes(c));
 assert.match(css,/backdrop-filter:blur/);
});
