'use strict';
const test=require('node:test');const assert=require('node:assert/strict');const fs=require('node:fs');const path=require('node:path');
const web=path.join(__dirname,'../../server/Comunicador_Fase1/web');
const server=path.join(__dirname,'../../server/Comunicador_Fase1');
const source=fs.readFileSync(path.join(web,'direct-calls.js'),'utf8');
const css=fs.readFileSync(path.join(web,'direct-calls.css'),'utf8');
const html=fs.readFileSync(path.join(web,'index.html'),'utf8');
const backend=fs.readFileSync(path.join(server,'direct_calls.go'),'utf8');
test('DM controls include call, screen share, member picker, and group management',()=>{
 assert.match(source,/Iniciar chamada de voz/);assert.match(source,/Compartilhar tela/);assert.match(source,/Adicionar pessoas/);assert.match(source,/Renomear grupo/);assert.match(source,/leave_group/);
 assert.match(source,/create_group/);assert.match(source,/add_members/);assert.match(source,/8 participantes/);
 assert.match(html,/direct-calls\.js\?v=18623/);assert.match(html,/direct-calls\.css\?v=18622/);
 assert.match(css,/\.explicit-dm-call-actions/);assert.match(css,/\.explicit-private-call/);assert.match(css,/is-streaming/);
});
test('private call grants are issued by authenticated backend with current membership',()=>{
 assert.match(backend,/s\.auth\(r\)/);assert.match(backend,/contains\(chat\.Users, user\)/);
 assert.match(backend,/signedLiveKitToken/);assert.match(backend,/directCallNewRoomName\(q\.ID\)/);
 assert.doesNotMatch(source,/LIVEKIT_API_SECRET|LIVEKIT_API_KEY/);
});
