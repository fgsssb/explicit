const test=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const vm=require('node:vm');
const root=path.join(__dirname,'..');
const html=fs.readFileSync(path.join(root,'../server/Comunicador_Fase1/web/index.html'),'utf8');
const navSource=fs.readFileSync(path.join(root,'../server/Comunicador_Fase1/web/navigation-explicit.js'),'utf8');
const preload=fs.readFileSync(path.join(root,'preload.js'),'utf8');
const main=fs.readFileSync(path.join(root,'main.js'),'utf8');

test('each major screen records the actual navigation event',()=>{
 assert.match(html,/async function openHome\(\)\{\s*window\.explicitNavRecord\?\.\(\{kind:'home'\}\)/);
 assert.match(html,/async function selectCommunity\(id\)\{window\.explicitNavRecord\?\.\(\{kind:'community',id\}\)/);
 assert.match(html,/async function openDirect\(id\)\{window\.explicitNavRecord\?\.\(\{kind:'direct',id\}\)/);
});

test('Windows caption buttons use restricted IPC and frame is custom',()=>{
 for(const action of ['minimize','maximize','close'])assert.match(preload,new RegExp(`'${action}'`));
 assert.match(main,/ipcMain\.handle\('explicit:window-control'/);
 assert.match(main,/validSessionSender\(event\)/);
 assert.match(main,/process\.platform==='win32'\?\{frame:false,roundedCorners:true\}/);
});

test('navigation title, disabled state and back/forward reflect actual app routing',async()=>{
 const listeners={};const nodes={};
 for(const id of ['explicitNavLabel','explicitNavBack','explicitNavForward'])nodes[id]={id,disabled:false,textContent:''};
 const document={readyState:'complete',body:{classList:{contains:()=>false}},getElementById:id=>nodes[id]||null,addEventListener:(name,fn)=>listeners[name]=fn};
 let current='',toast=[];
 const context={window:{addEventListener(){}},document,session:'signed-in',activeCommunity:'',activeDirect:'',communities:[{id:'123',name:'Minha sala'}],MutationObserver:class{observe(){}disconnect(){}},console,
  openHome:async()=>{current='home';context.window.explicitNavRecord({kind:'home'})},
  selectCommunity:async id=>{current=id;context.window.explicitNavRecord({kind:'community',id})},
  openDirect:async id=>{current=id;context.window.explicitNavRecord({kind:'direct',id})},
  nexoToast:(msg)=>toast.push(msg)};
 vm.runInNewContext(navSource,context);
 const push=context.window.explicitNavRecord;
 push({kind:'home'});push({kind:'community',id:'123'});push({kind:'direct',id:'dm-8'});
 assert.equal(nodes.explicitNavLabel.textContent,'MENSAGENS DIRETAS');
 assert.equal(nodes.explicitNavBack.disabled,false);
 assert.equal(nodes.explicitNavForward.disabled,true);
 async function click(id){listeners.click({target:{closest:selector=>selector===`#${id}`?{id}:null},preventDefault(){}});await new Promise(resolve=>setImmediate(resolve))}
 await click('explicitNavBack');assert.equal(current,'123');assert.equal(nodes.explicitNavLabel.textContent,'MINHA SALA');
 await click('explicitNavBack');assert.equal(current,'home');assert.equal(nodes.explicitNavLabel.textContent,'INICIO');assert.equal(nodes.explicitNavBack.disabled,true);
 await click('explicitNavForward');assert.equal(current,'123');assert.equal(nodes.explicitNavForward.disabled,false);
 assert.deepEqual(toast,[]);
});
