"use strict";
const test=require('node:test'), assert=require('node:assert/strict'), fs=require('node:fs'), path=require('node:path');
const server=fs.readFileSync(path.resolve(__dirname,'../../server/Comunicador_Fase1/admin.go'),'utf8');
const html=fs.readFileSync(path.resolve(__dirname,'../../server/Comunicador_Fase1/web/index.html'),'utf8');
const main=fs.readFileSync(path.resolve(__dirname,'../main.js'),'utf8');
test('presence does not expire clients based on a 30-minute timeout',()=>{
 assert.doesNotMatch(server,/elapsed > 30\s*\*\s*time\.Minute/);
 assert.match(server,/if elapsed <= 16\*time\.Second/);
 assert.match(server,/away = true/);
});
test('hidden tab and actual exit have different presence paths',()=>{
 assert.match(html,/visibilitychange.*explicitHeartbeat/);
 assert.match(html,/addEventListener\('pagehide'.*explicitGracefulAppExit/);
 assert.match(html,/keepalive:true/);
 assert.match(html,/leaving:true/);
});
test('actual Electron Quit reports the account leaving, tray minimization does not',()=>{
 assert.match(main,/app\.on\('before-quit'/);
 assert.match(main,/executeJavaScript\('window\.explicitGracefulAppExit/);
 assert.match(main,/event\.preventDefault\(\);win\.hide\(\)/);
});
