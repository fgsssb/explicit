'use strict';
const test=require('node:test'), assert=require('node:assert/strict'), fs=require('node:fs'), path=require('node:path'),vm=require('node:vm');
const web=path.resolve(__dirname,'../../server/Comunicador_Fase1/web');
const script=fs.readFileSync(path.join(web,'audio-profiles.js'),'utf8');
const scope={};vm.runInNewContext(script,scope);const audio=scope.ExplicitAudioProfiles;
const plain=value=>JSON.parse(JSON.stringify(value));
test('Perfil recomendado é seguro para jogos sem amplificar automaticamente o ambiente',()=>{
 const settings=plain(audio.build({},{}));
 assert.deepEqual(settings,{echoCancellation:true,noiseSuppression:false,autoGainControl:false});
});
test('Perfis são distintos, com estúdio puro e equilibrado com ganho',()=>{
 assert.deepEqual(plain(audio.build({audioInputProfile:'studio'},{})),{echoCancellation:false,noiseSuppression:false,autoGainControl:false});
 assert.deepEqual(plain(audio.build({audioInputProfile:'balanced'},{})),{echoCancellation:true,noiseSuppression:true,autoGainControl:true});
});
test('Isolamento experimental não é aplicado ao perfil recomendado; apenas ao personalizado quando solicitado',()=>{
 assert.equal(audio.build({audioInputProfile:'clean'}, {getSupportedConstraints:()=>({voiceIsolation:true})}).voiceIsolation,undefined);
 assert.equal(audio.build({audioInputProfile:'custom',audioCustomVoiceIsolation:true}, {getSupportedConstraints:()=>({voiceIsolation:true})}).voiceIsolation,true);
 assert.equal(audio.build({audioInputProfile:'studio'}, {getSupportedConstraints:()=>({voiceIsolation:true})}).voiceIsolation,undefined);
 assert.equal(plain(audio.withoutExperimental(audio.build({audioInputProfile:'clean'}, {getSupportedConstraints:()=>({voiceIsolation:true})}))).voiceIsolation,undefined);
});
test('Configurações customizadas são persistíveis e não sobrescrevem os dispositivos',()=>{
 const pref={audioInputProfile:'custom',audioInputId:'headset-01',audioCustomEchoCancellation:false,audioCustomNoiseSuppression:true,audioCustomAutoGainControl:true};
 assert.deepEqual(plain(audio.build(pref,{})),{echoCancellation:false,noiseSuppression:true,autoGainControl:true,deviceId:{exact:'headset-01'}});
});
test('Perfil inválido retorna padrão seguro sem habilitar experimentos',()=>{
 assert.equal(audio.normalize('suspicious'),'clean');
 assert.equal(audio.build({audioInputProfile:'unknown'},{}).noiseSuppression,false);
});
test('Configurações de áudio integram voz em comunidade e chamada privada',()=>{
 const html=fs.readFileSync(path.join(web,'index.html'),'utf8');
 const adapter=fs.readFileSync(path.join(web,'livekit-adapter.js'),'utf8');
 const direct=fs.readFileSync(path.join(web,'direct-calls.js'),'utf8');
 assert.match(html,/changeActiveVoiceProcessing\(/);
 assert.match(html,/explicitUpdateDirectCallAudioProfile/);
 assert.match(html,/Voz limpa \(recomendado\)/);
 assert.match(html,/voiceInputConstraints\(\)/);
 assert.match(adapter,/async updateInputProfile\(options\)/);
 assert.match(direct,/window\.explicitUpdateDirectCallAudioProfile/);
});
