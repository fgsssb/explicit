'use strict';
const test=require('node:test');const assert=require('node:assert/strict');const fs=require('node:fs');const path=require('node:path');
const web=path.resolve(__dirname,'../../server/Comunicador_Fase1/web');const go=path.resolve(__dirname,'../../server/Comunicador_Fase1');
const html=fs.readFileSync(path.join(web,'index.html'),'utf8');
const admin=fs.readFileSync(path.join(web,'admin-console.js'),'utf8');
const owner=fs.readFileSync(path.join(go,'owner.go'),'utf8');
test('Owner has only Owner badge in gold and legacy staff is Admin in red',()=>{
 assert.match(html,/badge\.textContent=owner\?'Owner':'Admin'/);
 assert.match(html,/\.explicit-owner-badge\{[^}]*background:#583513/);
 assert.match(html,/\.explicit-staff-badge\{[^}]*background:#431b22/);
 assert.match(admin,/\['staff','Admin'/);
});
test('No HTTP Owner self-assignment and management UI excludes Owner target',()=>{
 assert.match(owner,/func \(s \*Server\) bootstrapOwner/);
 assert.match(owner,/OwnerAccountID != ""/);
 assert.match(admin,/u\.role!=='owner'/);
});
