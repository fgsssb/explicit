const test=require('node:test');
const assert=require('node:assert/strict');
const {validateServerURL,isTrustedURL,externalURL}=require('../security');
test('development loopback works without HTTPS',()=>assert.equal(validateServerURL('http://127.0.0.1:8080',false),'http://127.0.0.1:8080'));
test('packaged localhost works for local testing',()=>assert.equal(validateServerURL('http://127.0.0.1:8080',true),'http://127.0.0.1:8080'));
test('remote HTTP is rejected',()=>assert.throws(()=>validateServerURL('http://example.com',false)));
test('remote HTTPS works',()=>assert.equal(validateServerURL('https://chat.example.com/',true),'https://chat.example.com'));
test('embedded credentials and URL paths are rejected',()=>{assert.throws(()=>validateServerURL('https://user:pass@chat.example.com/',false));assert.throws(()=>validateServerURL('https://chat.example.com/other',false));});
test('trusted origin matching does not accept lookalike domains',()=>{assert.equal(isTrustedURL('https://chat.example.com/api','https://chat.example.com'),true);assert.equal(isTrustedURL('https://chat.example.com.evil.test','https://chat.example.com'),false);});
test('external links only allow HTTPS',()=>{assert.equal(externalURL('javascript:alert(1)'),null);assert.equal(externalURL('file:///etc/passwd'),null);assert.equal(externalURL('http://example.com'),null);assert.equal(externalURL('https://example.com/a'),'https://example.com/a');});

test('packaged localhost may be enabled explicitly for testing',()=>{const old=process.env.EXPLICIT_ALLOW_LOCAL_HTTP;try{process.env.EXPLICIT_ALLOW_LOCAL_HTTP='1';assert.equal(validateServerURL('http://localhost:8080',true),'http://localhost:8080');}finally{if(old===undefined)delete process.env.EXPLICIT_ALLOW_LOCAL_HTTP;else process.env.EXPLICIT_ALLOW_LOCAL_HTTP=old;}});

// Regression: Electron portable extracts itself into %%TEMP%%, while the config
// travels next to the outer portable executable shared with friends.
test('portable uses endpoint next to outer executable rather than temporary unpack location',()=>{
 const fs=require('node:fs');
 const os=require('node:os');
 const path=require('node:path');
 const {getServerURL}=require('../security');
 const root=fs.mkdtempSync(path.join(os.tmpdir(),'explicit-endpoint-test-'));
 const outer=path.join(root,'portable');const unpack=path.join(root,'extracted');
 fs.mkdirSync(outer);fs.mkdirSync(unpack);
 fs.writeFileSync(path.join(outer,'explicit-endpoint.json'),JSON.stringify({serverUrl:'https://test.trycloudflare.com'}));
 fs.writeFileSync(path.join(unpack,'config.json'),JSON.stringify({serverUrl:'https://api.SEUDOMINIO.com'}));
 const beforeFile=process.env.PORTABLE_EXECUTABLE_FILE;
 const beforeDir=process.env.PORTABLE_EXECUTABLE_DIR;
 try{
  process.env.PORTABLE_EXECUTABLE_FILE=path.join(outer,'Explicit-16.9.8-x64.exe');
  process.env.PORTABLE_EXECUTABLE_DIR=outer;
  assert.equal(getServerURL(unpack,unpack,true),'https://test.trycloudflare.com');
  fs.rmSync(path.join(outer,'explicit-endpoint.json'));
  assert.throws(()=>getServerURL(unpack,unpack,true),/explicit-endpoint\.json não encontrado/);
 }finally{
  if(beforeFile===undefined)delete process.env.PORTABLE_EXECUTABLE_FILE;else process.env.PORTABLE_EXECUTABLE_FILE=beforeFile;
  if(beforeDir===undefined)delete process.env.PORTABLE_EXECUTABLE_DIR;else process.env.PORTABLE_EXECUTABLE_DIR=beforeDir;
  fs.rmSync(root,{recursive:true,force:true});
 }
});
