const test=require('node:test');
const assert=require('node:assert/strict');
const vm=require('node:vm');
const fs=require('node:fs');
const path=require('node:path');
async function drag(permissions){
 const callbacks={},sent=[];
 const list={addEventListener:(name,fn)=>{callbacks[name]=fn},querySelectorAll:()=>[]};
 const item={dataset:{explicitChannel:'geral'},classList:{add(){}}};
 const destination={dataset:{explicitCategory:'cat'},classList:{contains:()=>false}};
 const context={document:{getElementById:()=>list},communities:[{id:'c',channel_meta:{geral:{}}}],activeCommunity:'c',adminState:{permissions},
  api:async(...args)=>{sent.push(args)},refreshCommunities:async()=>{},nexoToast:()=>{}};
 let source=fs.readFileSync(path.join(__dirname,'../../server/Comunicador_Fase1/web/refinements.js'),'utf8');
 source=source.slice(0,source.indexOf(' // Context menu'))+'})();';
 vm.runInNewContext(source,context);
 callbacks.dragstart({target:{closest:()=>item},dataTransfer:{setData(){}}});
 await callbacks.drop({target:{closest:()=>destination},preventDefault(){},stopPropagation(){}});
 return sent[0][2];
}
test('channel manager can drag without silently changing category permissions',async()=>{
 const request=await drag(['MANAGE_CHANNELS']);assert.equal(request.action,'channel_reorder');assert.equal(request.category,'cat');assert.equal(request.sync,false);
});
test('authorized role manager retains category sync when dragging',async()=>{
 assert.equal((await drag(['MANAGE_CHANNELS','MANAGE_ROLES'])).sync,true);
});
