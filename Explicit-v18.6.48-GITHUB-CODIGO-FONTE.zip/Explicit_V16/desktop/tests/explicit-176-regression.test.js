'use strict';
const test=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const root=path.resolve(__dirname,'../../server/Comunicador_Fase1/web');
const html=fs.readFileSync(path.join(root,'index.html'),'utf8');
const admin=fs.readFileSync(path.join(root,'admin-console.js'),'utf8');
test('spectator joins the broadcaster voice channel before opening the stage',()=>{
 assert.match(html,/async function explicitJoinTransmission\(user,channel\)/);
 const join=html.indexOf('await joinVoiceChannel(channel)',html.indexOf('async function explicitJoinTransmission'));
 const show=html.indexOf('showScreenStage()',html.indexOf('async function explicitJoinTransmission'));
 assert.ok(join>0&&show>join);
 assert.match(html,/if\(voiceRoom!==desired\|\|\(livekitMode&&!livekitClient\)\)/);
});
test('Owner and Admin badges have distinct styles and compact profile sizing',()=>{
 assert.match(html,/badge\.textContent=owner\?'Owner':'Admin'/);
 assert.match(html,/\.explicit-owner-badge\{/);
 assert.match(html,/\.explicit-staff-badge\{/);
 assert.match(html,/#memberPopover \.explicit-staff-badge\{align-self:flex-start/);
});
test('admin console is a proper full-size workspace with real routes',()=>{
 assert.match(html,/<script src="\/admin-console\.js\?v=1800"><\/script>/);
 assert.match(html,/\.explicit-admin-console\{[^}]*width:min\(1150px/);
 assert.match(admin,/\{action:'add',title:v\.title\.trim\(\)/);
 assert.match(admin,/action:'approve_request'/);
 assert.match(admin,/['set_role','Alterar cargo']/);
 assert.match(admin,/action:'resolve_report'/);
 assert.doesNotMatch(admin,/confirmou o pagamento\?/);
});
test('short original sounds respect the user volume preference',()=>{
 assert.match(html,/const motifs=\{/);
 assert.match(html,/prefs\.voiceSounds===false/);
 assert.match(html,/ctx\.createBiquadFilter\(\)/);
});
