const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const html = fs.readFileSync(path.resolve(__dirname, '../../server/Comunicador_Fase1/web/index.html'), 'utf8');
test('logout preserves the member profile DOM container across account switches', () => {
  assert.match(html, /id="memberPopover"/);
  assert.doesNotMatch(html, /querySelectorAll\([^)]*#memberPopover[^)]*\)\.forEach\(x=>x\.remove\(\)\)/);
  // Logout compartilhado deve manter o nó de perfil para a próxima sessão.
  assert.match(html, /async function logout\(\)\{[^\n]*closeMemberPopover\(\)/);
  assert.match(html, /button\(exit,'Sair da conta'[^\n]*async\(\)=>\{/);
  assert.match(html, /await logout\(\)/);
  assert.doesNotMatch(html, /const logout=document\.createElement\('button'\)/);
});
