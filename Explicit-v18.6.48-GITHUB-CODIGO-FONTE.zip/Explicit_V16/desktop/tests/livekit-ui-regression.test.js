'use strict';
const test=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const html=fs.readFileSync(path.join(__dirname,'../../server/Comunicador_Fase1/web/index.html'),'utf8');
test('old screen track ending cannot erase a replacement after reconnection',()=>{
 assert.match(html,/video\.srcObject\?\.getTracks\(\)\.includes\(track\)/);
});
test('media disconnect is reported to the user instead of being silent',()=>{
 assert.match(html,/LiveKit desconectou\. Verifique a internet/);
});
