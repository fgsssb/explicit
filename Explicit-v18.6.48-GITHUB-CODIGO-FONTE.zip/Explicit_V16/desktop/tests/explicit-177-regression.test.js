'use strict';
const test=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path');
const web=path.resolve(__dirname,'../../server/Comunicador_Fase1/web');
const html=fs.readFileSync(path.join(web,'index.html'),'utf8');
const desktop=fs.readFileSync(path.resolve(__dirname,'../main.js'),'utf8');
test('admin entrypoint loads dedicated global console rather than legacy panel',()=>{
 assert.doesNotMatch(html,/modalWorkspace\('Painel Admin'\)/);
 assert.match(html,/b\.onclick=\(\)=>window\.explicitOpenAdmin/);
 assert.match(html,/admin-console\.js\?v=1800/);
});
test('screen watcher finds channel key from voice presence map',()=>{
 assert.match(html,/Object\.entries\(voicePresenceState\|\|\{\}\)\.flatMap\(\(\[channel,users\]\)/);
 assert.match(html,/explicitJoinTransmission\(user,voice\.channel\)/);
});
test('single community plus button presents two choices',()=>{
 assert.match(html,/add\.onclick=openCommunityChoice/);
 assert.doesNotMatch(html,/join\.className='rail-join'/);
 assert.match(html,/action:createCommunity/);assert.match(html,/action:joinCommunity/);
});
test('graceful application quit informs server, not minimized tray close',()=>{
 assert.match(desktop,/app\.on\('before-quit',event=>/);
 assert.match(desktop,/executeJavaScript\('window\.explicitGracefulAppExit/);
 assert.match(html,/window\.explicitGracefulAppExit=\(\)=>Promise\.allSettled/);
 assert.match(html,/keepalive:true/);
});
test('status icon uses inline monitor not Unicode square',()=>{
 assert.match(html,/className='explicit-sharing-glyph'/);
 assert.doesNotMatch(html,/person\.screen\?'▣/);
});
test('original audio synthesis defines distinct enter leave share exit motifs',()=>{
 for(const kind of ['self','leave','share','unshare'])assert.match(html,new RegExp(kind+':\\[\\['));
 assert.match(html,/level\.gain\.value=gainValue/);
});
