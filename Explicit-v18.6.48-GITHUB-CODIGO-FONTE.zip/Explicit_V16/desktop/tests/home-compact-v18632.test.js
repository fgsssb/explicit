const test=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');const path=require('node:path');
const web=path.join(__dirname,'../../server/Comunicador_Fase1/web');
const html=fs.readFileSync(path.join(web,'index.html'),'utf8');
const css=fs.readFileSync(path.join(web,'home-v18632.css'),'utf8');
const home=html.slice(html.indexOf('async function openHome(){'),html.indexOf("document.body.classList.remove('explicit-light-theme');",html.indexOf('async function openHome(){')));
test('compact dashboard removes greeting and standalone notifications card',()=>{
 assert.doesNotMatch(home,/explicit-hero|explicitHomeDate|explicit-notifications-section/);
 assert.match(home,/id="explicitSpotlight"/);assert.match(home,/id="homeNotificationBell"/);assert.match(home,/id="homeNotificationCount"/);
 assert.match(home,/id="homeSpaces"/);assert.match(home,/id="explicitSupportTitle"/);
});
test('three friend tabs use actual social lists and server actions',()=>{
 for(const name of ['all','online','pending'])assert.match(home,new RegExp('data-friend-tab="'+name+'"'));
 assert.match(home,/Array\.isArray\(social\.incoming\)/);assert.match(home,/Array\.isArray\(social\.outgoing\)/);
 assert.match(home,/friendList\.filter\(isOnline\)/);
 assert.match(home,/await api\('social','POST',\{action,id:n\.id\}\)/);
 assert.match(home,/openDirectWith\(f\.username\)/);
});
test('notification bell is user-controlled and does not implicitly clear unread',()=>{
 assert.match(home,/api\('notifications'\)\.then/);
 assert.match(home,/id="homeNotificationPanel"[^>]*hidden/);
 assert.match(home,/homeMarkNotificationsRead/);
 assert.doesNotMatch(home,/read_misc/);
 assert.match(css,/\.explicit-home-bell-count\[hidden\]/);
 assert.match(css,/\.explicit-home-notification-panel\[hidden\]/);
});
test('compact community list keeps create, join, selection, and release notes',()=>{
 assert.match(home,/root\.querySelector\('#homeCreateCommunity'\)\.onclick=createCommunity/);
 assert.match(home,/root\.querySelector\('#homeJoinCommunity'\)\.onclick=joinCommunity/);
 assert.match(home,/selectCommunity\(c\.id\)/);
 assert.match(home,/explicitLoadSpotlight\(root\)/);
 assert.match(css,/grid-template-areas:"spot friends" "communities communities" "support support"/);
});
