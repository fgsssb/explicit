'use strict';
const {test}=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs'),path=require('node:path');
const web=path.resolve(__dirname,'../../server/Comunicador_Fase1/web');
const html=fs.readFileSync(path.join(web,'index.html'),'utf8');
const ui=fs.readFileSync(path.join(web,'explicit-v18637.js'),'utf8');
const css=fs.readFileSync(path.join(web,'explicit-v18642-polish.css'),'utf8');
test('cabeçalho: seta adjacente ao nome e convite no fim',()=>{
 assert.match(ui,/row\.append\(heading\)/);assert.match(ui,/row\.append\(arrow\)/);assert.match(ui,/row\.append\(invite\)/);
 assert.match(ui,/arrow\.onpointerdown=e=>e\.stopPropagation\(\)/);
 assert.match(ui,/visibleMenu\.explicitClose\?\.\(\)/);
 assert.match(css,/\.explicit-community-invite-button \{[\s\S]*?margin-left:auto!important/);
 assert.match(css,/\.explicit-community-chevron\.is-open svg[\s\S]*?transform:rotate\(180deg\)/);
});
test('popover centraliza avatar e identidade',()=>{
 assert.match(css,/#memberPopover>\.explicit-popover-cover \{[\s\S]*?align-items:center!important/);
 assert.match(css,/\.explicit-popover-identity\{[\s\S]*?text-align:center!important/);
});
test('menus do áudio alternam sem fechar antes da hora e são compactos',()=>{
 assert.match(ui,/existing&&existing\.dataset\.for===id/);
 assert.match(ui,/const controller=new AbortController/);
 assert.match(ui,/menu\.explicitClose=close/);
 assert.match(css,/\.explicit-audio-quick \{[\s\S]*?width:252px!important/);
 assert.match(css,/\.explicit-audio-device-select\{/);
});
test('configurações abrem na conta, com logout fora do status',()=>{
 assert.match(html,/function openSettings\(category='Conta · Informações'\)/);
 assert.match(html,/heading\.textContent='Configurações'/);
 assert.match(html,/button\(exit,'Sair da conta'/);
 assert.doesNotMatch(html,/menu\.append\(settings,status,logout\)/);
 assert.match(css,/\.explicit-settings-account-submenu\{/);
});
test('ping não é consultado sem voz, visível somente durante voz e faixas claras',()=>{
 assert.match(html,/if\(!session\|\|!voiceRoom\|\|!explicitVoiceEstablished\)\{explicitConnectionVisibility\(\);return;\}/);
 assert.match(html,/explicitConnectionRow\.append\(voicePanel\.querySelector\('\.voice-status-line'\)\)/);
 assert.match(html,/explicitConnectionRow\.hidden=!connected/);assert.match(html,/explicitVoiceEstablished=true;updateVoiceStatus\(\)/);
 assert.match(html,/ms>90\?'critical':ms>50\?'warning':'good'/);
 for(const key of ['good','warning','critical'])assert.match(css,new RegExp('ice-ping\\[data-latency="'+key+'"\\]'));
 assert.match(css,/\.ice-ping\[hidden\]/);
});
