const test=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const app=fs.readFileSync(path.resolve(__dirname,'../../server/Comunicador_Fase1/web/index.html'),'utf8');
test('local diagnostics is available from Explicit settings',()=>{
 assert.match(app,/settingsCategories=\[[^\]]*'Diagnóstico'/);
 assert.match(app,/livekitClient\?\.supportReport/);
 assert.match(app,/navigator\.clipboard\.writeText/);
 assert.match(app,/window\.explicitMediaLastReport/);
});
