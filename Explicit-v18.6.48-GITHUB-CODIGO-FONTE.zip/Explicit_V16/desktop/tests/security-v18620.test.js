const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const web = path.join(__dirname, '../../server/Comunicador_Fase1/web');
const html = fs.readFileSync(path.join(web, 'index.html'), 'utf8');
const css = fs.readFileSync(path.join(web, 'security-ui.css'), 'utf8');
const main = fs.readFileSync(path.join(__dirname, '../main.js'), 'utf8');
test('interface keeps non-chat chrome unselectable, but chat and editing remain selectable', () => {
 assert.match(html, /security-ui\.css\?v=18620/);
 assert.match(css, /user-select:none/);
 assert.match(css, /#messages,#messages \*/);
 assert.match(css, /\.explicit-dm-messages/);
 assert.match(css, /input,textarea,\[contenteditable\]/);
});
test('electron retains isolated, sandboxed renderer and fixed application title', () => {
 assert.match(main, /nodeIntegration:false,contextIsolation:true,sandbox:true,webSecurity:true/);
 const version=require('../package.json').version;
 assert.ok(main.includes('Explicit '+version));
 assert.match(main, /setPermissionRequestHandler/);
 assert.match(main, /setWindowOpenHandler/);
});
