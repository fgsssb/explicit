'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const desktop = path.join(__dirname, '..');
const project = path.join(desktop, '..');
const web = path.join(project, 'server', 'Comunicador_Fase1', 'web');
const raw = file => fs.readFileSync(file);
const hash = file => crypto.createHash('sha256').update(raw(file)).digest('hex');
const pngSize = data => ({width:data.readUInt32BE(16),height:data.readUInt32BE(20)});
test('the same official icon is used in desktop splash and browser login loading', () => {
  const desktopIcon=path.join(desktop,'explicit-icon.png');
  const webIcon=path.join(web,'explicit-icon.png');
  assert.equal(hash(desktopIcon), hash(webIcon));
  const bytes=raw(desktopIcon);
  assert.equal(bytes.subarray(0,8).toString('hex'), '89504e470d0a1a0a');
  assert.deepEqual(pngSize(bytes), {width:1024,height:1024});
  const splash=fs.readFileSync(path.join(desktop,'splash.html'),'utf8');
  const html=fs.readFileSync(path.join(web,'index.html'),'utf8');
  assert.match(splash,/src="explicit-icon\.png"/);
  assert.match(html,/explicit-loading-logo"><img src="\/explicit-icon\.png"/);
});
test('multi-resolution Windows executable icon and tray icon are bundled',()=>{
  const ico=raw(path.join(desktop,'explicit.ico'));
  assert.equal(ico.readUInt16LE(0),0);
  assert.equal(ico.readUInt16LE(2),1);
  const count=ico.readUInt16LE(4);
  assert.ok(count>=7);
  const sizes=new Set();
  for(let i=0;i<count;i++){
    const at=6+i*16;
    sizes.add(ico[at] || 256);
    assert.equal(ico[at+1] || 256,ico[at] || 256);
  }
  for(const s of [16,24,32,48,64,128,256])assert.ok(sizes.has(s),String(s));
  const tray=raw(path.join(desktop,'tray-icon.png'));
  assert.deepEqual(pngSize(tray),{width:64,height:64});
  const pack=require(path.join(desktop,'package.json'));
  assert.equal(pack.build.win.icon,'explicit.ico');
  for(const name of ['explicit.ico','explicit-icon.png','splash.html','tray-icon.png'])assert.ok(pack.build.files.includes(name));
});
