'use strict';
const test=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const html=fs.readFileSync(path.join(__dirname,'../../server/Comunicador_Fase1/web/index.html'),'utf8');
const backend=fs.readFileSync(path.join(__dirname,'../../server/Comunicador_Fase1/main.go'),'utf8');
const images=fs.readFileSync(path.join(__dirname,'../../server/Comunicador_Fase1/images.go'),'utf8');
test('screen is separate view, text-channel selection exits screen view',()=>{
 assert.match(html,/function showScreenStage\(\)\{document\.body\.classList\.add\('explicit-screen-view'\)/);
 assert.match(html,/async function selectChannel\(ch\)\{if\(document\.body\.classList\.contains\('explicit-screen-view'\)\)/);
 assert.match(html,/body\.explicit-screen-view #channelTitle,body\.explicit-screen-view #messages,body\.explicit-screen-view #form\{display:none!important\}/);
});
test('public member popover does not inject account email',()=>{
 const start=html.indexOf('async function openMember('),end=html.indexOf('const chips=document.createElement',start);
 assert.ok(start>0 && end>start);
 assert.ok(!html.slice(start,end).includes('my.email'));
});
test('home keeps intended layout, limits, black and blue palette',()=>{
 for(const id of ['explicit-spotlight','explicit-friends-section','homeNotificationBell','explicit-communities-section','explicit-support-card'])assert.ok(html.includes(id));
 assert.match(html,/friends:5,communities:5,notifications:5/);
 assert.match(html,/#030405!important/);
 assert.match(html,/#6ca6df!important/);
 assert.match(html,/backdrop-filter:blur\(7px\)!important/);
});
test('settings render useful categories and correctly shaped toggles',()=>{
 assert.match(html,/settingsCategories=\['Conta','Geral','Aparência','Desempenho','Voz e áudio','Diagnóstico','Atalhos','Notificações','Armazenamento','Sobre'\]/);
 assert.match(html,/input\.explicit-settings-toggle:before/);
 assert.match(html,/input\.explicit-settings-toggle:checked/);
});
test('staff shortcuts invoke server-side authorized API, not local role change',()=>{
 assert.match(html,/async function explicitHandleStaffCommand\(text\)/);
 for(const cmd of ['/mutartodos','/entrar','/desconectar','/apagarcanal','/limparcanal'])assert.ok(html.includes(cmd));
 assert.match(html,/api\('staff-control','POST',payload\)/);
});
test('persisted local DB has corruption protection and storage diagnostics',()=>{
 assert.match(backend,/invalid database.*database not overwritten/);
 assert.match(backend,/persistLocalStore/);
 assert.match(backend,/STORAGE ERROR saving/);
 assert.match(images,/STORAGE ERROR image file/);
});
