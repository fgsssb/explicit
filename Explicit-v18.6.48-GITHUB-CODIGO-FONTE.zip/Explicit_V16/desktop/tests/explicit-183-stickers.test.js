'use strict';
const test=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path');
const server=path.resolve(__dirname,'../../server/Comunicador_Fase1');
const read=p=>fs.readFileSync(path.join(server,p),'utf8');
const html=read('web/index.html'),ui=read('web/stickers.js'),api=read('stickers.go'),admin=read('web/admin-console.js');
test('emoji picker offers a separate sticker tab without replacing emoji UI',()=>{
 assert.match(html,/stickers\.js\?v=1830/);
 assert.match(ui,/explicit-sticker-switch/);assert.match(ui,/Figurinhas/);assert.match(ui,/Emojis/);
 assert.match(html,/explicit-emoji-grid/);
});
test('users without permission see a neutral blue locked panel',()=>{
 assert.match(ui,/can_send/);assert.match(ui,/explicit-sticker-locked/);
 assert.match(html,/backdrop-filter:blur\(6px\)/);
 assert.match(html,/stroke:#91b7d8/);
});
test('chat renders sticker media as a compact image and supports context actions',()=>{
 assert.match(html,/if\(m\.sticker&&window\.explicitRenderSticker\)/);
 assert.match(html,/max-width:168px;max-height:168px/);
 assert.match(ui,/Salvar nos favoritos/);assert.match(ui,/Excluir minha figurinha/);assert.match(ui,/Remover dos favoritos/);
});
test('permissions enforced server side and beta controlled by superadmin',()=>{
 assert.match(api,/maySendStickersLocked/);assert.match(api,/stickerChannelAllowedLocked/);
 assert.match(api,/"favorite"/);assert.match(api,/"send"/);assert.match(api,/"delete"/);
 assert.match(admin,/set_beta/);assert.match(read('system_admin.go'),/level < 3 \|\| q\.Beta == nil/);
});
