'use strict';
const test=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path');
const server=path.join(__dirname,'../../server/Comunicador_Fase1');
const read=p=>fs.readFileSync(path.join(server,p),'utf8');
test('Explicit+ duration modal requires a nonzero duration before first grant',()=>{
 const js=read('web/admin-console.js');
 assert.match(js,/async function explicitPlusPeriodDialog\(edit=false\)/);
 for(const name of ['days','hours','minutes','seconds'])assert.match(js,new RegExp("name:'"+name+"'"));
 assert.match(js,/const shouldGrant=selected\.has\('explicit_plus'\)&&!u\.explicit_plus/);
 assert.match(js,/if\(shouldGrant&&!duration\)return/);
 assert.match(js,/action:'set_explicit_plus_duration'/);
});
test('Expiry is server-enforced for stickers and name styles, not client-only',()=>{
 assert.match(read('badges.go'),/explicitPlusActive\(u\)/);
 assert.match(read('stickers.go'),/explicitPlusActive\(u\)/);
 assert.match(read('name_presets.go'),/explicitPlusActive\(u\)/);
 assert.match(read('system_admin.go'),/validExplicitPlusDuration\(q\.DurationSeconds\)/);
});
test('Expiry countdown is exposed to account owner in profile',()=>{
 assert.match(read('web/refinements.js'),/explicit-plus-countdown/);
 assert.match(read('web/refinements.js'),/explicit_plus_expires_at/);
 assert.match(read('explicit.go'),/explicit_plus_expires_at/);
});
test('Homepage spotlight artwork and header use the official bundled icon',()=>{
 const html=read('web/index.html');
 assert.match(html,/explicit-brand-card-icon/);
 assert.match(html,/explicit-preview-badge"><img src="\/explicit-icon\.png"/);
 assert.match(html,/explicit-announcement-art-mark"><img src="\/explicit-icon\.png"/);
 assert.ok(fs.existsSync(path.join(server,'web/explicit-icon.png')));
});
