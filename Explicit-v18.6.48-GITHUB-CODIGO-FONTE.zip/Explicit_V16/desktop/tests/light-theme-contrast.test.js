const test=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const html=fs.readFileSync(path.join(__dirname,'../../server/Comunicador_Fase1/web/index.html'),'utf8');
test('tema único preto + azul médio mantém paleta no CSS',()=>{
 assert.match(html,/--explicit-bg:#030405/);
 assert.match(html,/--explicit-blue:#6ca6df/);
 assert.match(html,/--accent:#6ca6df!important/);
});
test('seleção de tema é removida dos ajustes, outros controles permanecem',()=>{
 assert.doesNotMatch(html,/group\('Tema do Explicit'/);
 assert.doesNotMatch(html,/next\.theme=value/);
 for(const item of ['Escala da interface','Interface compacta','Reduzir movimento','Volume dos participantes'])assert.ok(html.includes(item));
});
test('configuração antiga de tema claro é ignorada sem alterar outras preferências',()=>{
 assert.match(html,/const \{theme:_obsoleteTheme,\.\.\.saved\}/);
 assert.match(html,/document\.body\.classList\.remove\('explicit-light-theme'\)/);
 assert.doesNotMatch(html,/getPrefs\(\)\.theme==='light'/);
});
