'use strict';
// Optional isolated Electron renderer test. Requires playwright + Electron 43.
// The QA host replaces the server and native shell, never the production files.
const { _electron }=require('playwright');const fs=require('node:fs'),path=require('node:path'),os=require('node:os'),http=require('node:http');const assert=require('node:assert/strict');
const desktop=path.resolve(__dirname,'..'),web=path.resolve(desktop,'../server/Comunicador_Fase1/web');
const out=path.resolve(process.env.EXPLICIT_QA_OUTPUT||path.join(desktop,'qa-v18647'));
fs.mkdirSync(out,{recursive:true});
const members=[{user:'Jean',display_name:'Jean',online:true,status:'online',system_role:'owner'},{user:'Lucas',display_name:'Lucas',online:true,status:'online'},{user:'Marina',display_name:'Marina',online:true,status:'away'},{user:'Rafael',display_name:'Rafael',online:false,status:'offline'}];
const messages=[{id:'dm1',author:'Lucas',text:'Vamos jogar hoje?',time:'2026-11-04T15:10:00Z'},{id:'dm2',author:'Jean',text:'Sim! Podemos conversar por aqui enquanto organizamos a partida.',time:'2026-11-04T15:11:00Z'}];
const mime={'.html':'text/html','.js':'text/javascript','.css':'text/css','.woff2':'font/woff2','.png':'image/png','.svg':'image/svg+xml'};
let app,server,temp;const checks=[],errors=[],failedAssets=[];const check=(name,condition)=>{assert.ok(condition,name);checks.push(name)};
(async()=>{
 server=http.createServer((req,res)=>{
  const u=new URL(req.url,'http://127.0.0.1');
  if(u.pathname.startsWith('/api/')){
   let data=[];const p=u.pathname.slice(5);
   if(p==='captcha')data={id:'qa',image:'data:image/svg+xml,%3Csvg xmlns="http://www.w3.org/2000/svg" width="186" height="58"%3E%3C/svg%3E'};
   else if(p==='social')data={friends:members.slice(1,3).map(x=>({...x,username:x.user})),incoming:[],outgoing:[]};
   else if(p==='presence')data={members};
   else if(p==='community-admin')data={permissions:['MANAGE_CHANNELS','MANAGE_ROLES'],roles:[],members:[]};
   else if(p==='channel-permissions')data={roles:[],members:['Jean','Lucas'],categories:[],channel_meta:{geral:{type:'text'}}};
   else if(p==='voice-presence')data={};
   else if(p==='direct')data=u.search?{id:'qa-dm',users:['Jean','Lucas'],messages}:{length:1};
   if(p==='direct'&&!u.search)data=[{id:'qa-dm',other:'Lucas',users:['Jean','Lucas'],group:false,name:'Lucas'}];
   else if(p==='home-mode')data={mode:'announcements'};
   else if(p==='me'||p==='profile')data=members[0];
   else if(p==='notifications')data={items:[],unread:0};
   else if(p==='name-presets')data={styles:{}};
   if(p==='events'||p==='stream'){res.writeHead(204);res.end();return}
   res.writeHead(200,{'Content-Type':'application/json'});res.end(JSON.stringify(data));return;
  }
  // Mirror production's publicWebPath: flat assets or vendor/, no arbitrary directories.
  const relative=u.pathname==='/'?'index.html':u.pathname.slice(1);
  if(!/^(?:vendor\/)?[^/.][^/]*\.(?:html|js|css|png|jpg|jpeg|gif|webp|svg|ico|woff2?)$/.test(relative)||relative.includes('..')){res.writeHead(404);res.end();return}
  const file=path.join(web,relative);if(!fs.existsSync(file)){res.writeHead(404);res.end();return}
  res.writeHead(200,{'Content-Type':mime[path.extname(file)]||'application/octet-stream'});fs.createReadStream(file).pipe(res);
 });
 await new Promise(resolve=>server.listen(0,'127.0.0.1',resolve));
 const origin='http://127.0.0.1:'+server.address().port;
 temp=fs.mkdtempSync(path.join(os.tmpdir(),'explicit-ui-qa-'));
 const host=path.join(temp,'host.cjs');
 // Offscreen rendering avoids unavailable AF_UNIX locking, native trays and GTK display.
 fs.writeFileSync(host,`const {app,BrowserWindow,ipcMain}=require('electron');app.setPath('userData',${JSON.stringify(path.join(temp,'profile'))});const pkg=require(${JSON.stringify(path.join(desktop,'package.json'))});ipcMain.handle('explicit:settings-info',()=>({name:'Explicit',version:pkg.version,electron:process.versions.electron,platform:process.platform}));ipcMain.on('explicit:capture-choice',(_event,payload)=>{global.explicitQAChoice=payload});ipcMain.handle('explicit:session-load',()=>null);ipcMain.handle('explicit:settings-startup-get',()=>({supported:false,enabled:false}));ipcMain.handle('explicit:settings-hardware-get',()=>({enabled:true}));ipcMain.handle('explicit:notification-count',()=>({ok:true}));app.whenReady().then(async()=>{const w=new BrowserWindow({width:1440,height:900,show:false,backgroundColor:'#08090b',webPreferences:{preload:${JSON.stringify(path.join(desktop,'preload.js'))},offscreen:true,nodeIntegration:false,contextIsolation:true,sandbox:true,webSecurity:true}});await w.loadURL(${JSON.stringify(origin)})});app.on('window-all-closed',()=>app.quit());`);
 const executablePath=process.env.EXPLICIT_ELECTRON_PATH||require('electron');
 app=await _electron.launch({executablePath,args:[...(process.platform==='linux'?['--no-sandbox','--ozone-platform=headless','--disable-gpu']:[]),host],timeout:30000});
 let page;for(let i=0;i<150;i++){page=app.windows().find(p=>p.url().startsWith(origin));if(page)break;await new Promise(r=>setTimeout(r,50))}assert.ok(page,'renderer started');
 page.on('pageerror',e=>errors.push(e.message));page.on('response',r=>{if(r.status()>=400&&/\.(?:css|woff2)(?:\?|$)/.test(r.url()))failedAssets.push(r.url())});
 await page.waitForLoadState('load');await page.waitForFunction(()=>typeof openSettings==='function'&&document.body.id==='explicitApp');
 await page.evaluate(()=>document.fonts.load('400 14px Inter'));
 check('fonte Inter local carregada',await page.evaluate(()=>[...document.fonts].some(f=>f.family==='Inter'&&f.status==='loaded')));
 check('CSS final é a última folha',await page.evaluate(()=>[...document.querySelectorAll('link[rel=stylesheet]')].at(-1).href.includes('explicit-v18648-community-modal.css')));
 await page.evaluate('('+fs.readFileSync(path.join(__dirname,'visual-seed-v18647.js'),'utf8')+')()');
 await page.setViewportSize({width:1440,height:900});
 const screenshot=async name=>page.screenshot({path:path.join(out,name+'.png')});
 await screenshot('chat');
 check('Enviar usa azul-bebê',await page.locator('#sendMessage').evaluate(e=>getComputedStyle(e).backgroundColor==='rgb(168, 213, 247)'));
 const contrast=await page.evaluate(()=>{
  const rgb=s=>s.match(/[\d.]+/g).slice(0,3).map(Number);
  const luminance=c=>c.map(v=>{v/=255;return v<=.04045?v/12.92:((v+.055)/1.055)**2.4}).reduce((s,v,i)=>s+v*[.2126,.7152,.0722][i],0);
  return ['#sendMessage','.explicit-message-author','.explicit-chat-meta small','#message'].map(selector=>{const e=document.querySelector(selector),cs=getComputedStyle(e);let p=e,bg=cs.backgroundColor;while(bg==='rgba(0, 0, 0, 0)'&&p.parentElement){p=p.parentElement;bg=getComputedStyle(p).backgroundColor}const a=luminance(rgb(cs.color)),b=luminance(rgb(bg));return {selector,ratio:(Math.max(a,b)+.05)/(Math.min(a,b)+.05)}});
 });
 check('contraste dos quatro elementos de conversa >= 4.5:1',contrast.every(x=>x.ratio>=4.5));
 await page.locator('#sendMessage').focus();
 await page.evaluate(()=>{void nexoForm('Criar um canal',[{name:'name',label:'Nome do canal',value:'conversa',required:true}])});
 check('formulário recebe foco',await page.evaluate(()=>document.activeElement.closest('[role=dialog]')!==null));
 check('cancelar e confirmar têm estilos distintos',await page.evaluate(()=>{const b=document.querySelectorAll('.obsidian-modal-actions button');return getComputedStyle(b[0]).backgroundColor!==getComputedStyle(b[1]).backgroundColor}));
 await page.keyboard.press('Shift+Tab');check('Shift+Tab circula até Confirmar',await page.evaluate(()=>document.activeElement.textContent==='Confirmar'));
 await screenshot('modal');await page.keyboard.press('Escape');
 check('Escape fecha e restaura foco',await page.evaluate(()=>!document.querySelector('.obsidian-modal-backdrop')&&document.activeElement.id==='sendMessage'));
 await page.evaluate(()=>contextMenu({clientX:1425,clientY:888,type:'keydown'},[['Convidar amigos',()=>{}],['Configurações da comunidade',()=>{}],['Editar canais',()=>{}]]));
 const rect=await page.locator('.nexo-context').boundingBox();check('menu permanece na janela',rect.x>=0&&rect.y>=0&&rect.x+rect.width<=1440&&rect.y+rect.height<=900);
 await page.keyboard.press('ArrowDown');check('setas navegam no menu',await page.evaluate(()=>document.activeElement.textContent==='Configurações da comunidade'));
 await screenshot('menu');await page.keyboard.press('Escape');
 await page.evaluate(()=>openSettings('Voz e áudio'));await screenshot('configuracoes');
 check('ícones de configurações são SVG',await page.locator('.explicit-settings-nav-item svg').count()>5);
 for(const size of [{width:900,height:620},{width:1100,height:720},{width:1920,height:1080}]){
  await page.setViewportSize(size);const r=await page.locator('.explicit-settings-window').boundingBox();check('configurações cabem em '+size.width+'x'+size.height,r.x>=0&&r.y>=0&&r.x+r.width<=size.width+1&&r.y+r.height<=size.height+1);
  check('fechar acessível em '+size.width,await page.locator('.explicit-settings-window>.modal-close').isVisible());
 }
 await page.setViewportSize({width:1440,height:900});await page.locator('.explicit-settings-window>.modal-close').click();
 // Open the community configuration using the real menu action (private implementation).
 const openCommunity=async()=>{await page.evaluate(()=>openCommunityMenu({type:'keydown',clientX:100,clientY:70,preventDefault(){},stopPropagation(){}},communities[0]));await page.locator('.nexo-context button').filter({hasText:'Configurações da comunidade'}).click();await page.locator('.explicit-server-settings-screen').waitFor()};
 await page.locator('#sendMessage').focus();await openCommunity();
 const communityModal=page.locator('.explicit-server-settings-screen');
 check('comunidade abre em modal central com fundo visível',await communityModal.evaluate(e=>{const r=e.getBoundingClientRect();return r.width<innerWidth-40&&r.height<innerHeight-40&&r.x>20&&r.y>20}));
 check('comunidade usa superfície compartilhada',await communityModal.evaluate(e=>getComputedStyle(e).backgroundColor==='rgb(18, 21, 25)'));
 check('todas as cinco seções continuam disponíveis',await page.locator('.explicit-server-settings-side button').count()===5);
 await screenshot('comunidade-visao-geral');
 await page.locator('.explicit-server-settings-side button').filter({hasText:'Canais',exact:true}).click();await page.waitForSelector('.explicit-server-settings-channel');
 check('criar canal usa a cor primária compartilhada',await page.locator('.explicit-server-settings-action').evaluate(e=>getComputedStyle(e).backgroundColor==='rgb(168, 213, 247)'));
 await page.waitForFunction(()=>getComputedStyle(document.querySelector('.explicit-server-settings-side button.selected')).backgroundColor==='rgb(25, 46, 64)');
 check('seleção da comunidade usa azul discreto',await page.locator('.explicit-server-settings-side button.selected').evaluate(e=>getComputedStyle(e).backgroundColor==='rgb(25, 46, 64)'));
 check('lista de canais preservada',await page.locator('.explicit-server-settings-channel').count()===6);
 await screenshot('comunidade-canais');
 await page.locator('.explicit-server-settings-channel button').first().click();await page.waitForSelector('.explicit-acl-backdrop');
 check('permissões do canal abrem acima da comunidade',await page.evaluate(()=>Number(getComputedStyle(document.querySelector('.explicit-acl-backdrop')).zIndex)>Number(getComputedStyle(document.querySelector('.explicit-server-settings-backdrop')).zIndex)));
 await page.locator('.explicit-acl-close').click();check('fechar permissões mantém configurações abertas',await communityModal.isVisible());
 await page.locator('.explicit-server-settings-side button').filter({hasText:'Cargos',exact:true}).click();await page.waitForSelector('.explicit-inline-roles-list');
 await page.locator('.explicit-role-primary').click();await page.waitForSelector('.explicit-inline-role-editor');
 check('editor de cargo permanece dentro do modal',await page.locator('.explicit-server-settings-screen .explicit-inline-role-editor').count()===1);
 check('editor de cargo não ultrapassa conteúdo',await page.locator('.explicit-inline-role-editor').evaluate(e=>e.getBoundingClientRect().width<=e.parentElement.clientWidth+1));
 await screenshot('comunidade-editor-cargo');
 await page.locator('.explicit-inline-role-editor .explicit-role-editor-footer button').last().scrollIntoViewIfNeeded();
 check('ações finais do cargo são alcançáveis pela rolagem',await page.locator('.explicit-inline-role-editor .explicit-role-editor-footer').evaluate(e=>{const a=e.getBoundingClientRect(),b=e.closest('.explicit-server-settings-content').getBoundingClientRect();return a.bottom<=b.bottom+1}));
 await page.locator('.explicit-inline-role-editor .cancel').click();await page.waitForSelector('.explicit-inline-roles-list');
 await screenshot('comunidade-cargos');
 for(const size of [{width:900,height:620},{width:1100,height:720},{width:1920,height:1080}]){await page.setViewportSize(size);const r=await communityModal.boundingBox();check('modal comunidade cabe em '+size.width+'x'+size.height,r.x>=10&&r.y>=10&&r.x+r.width<=size.width-10&&r.y+r.height<=size.height-10)}
 await page.setViewportSize({width:1440,height:900});await page.keyboard.press('Escape');
 check('Escape limpa a referência de cargos da comunidade',await page.evaluate(()=>!document.querySelector('.explicit-server-settings-screen')&&window.explicitRolesInlineHost===null));
 await openCommunity();await page.locator('.explicit-server-settings-side button').filter({hasText:'Convites',exact:true}).click();await page.waitForSelector('.explicit-invite-friends');
 check('Convites continua abrindo o diálogo de convite',await page.locator('.explicit-invite-friends').count()===1);await page.keyboard.press('Escape');
 await openCommunity();await page.locator('.explicit-server-settings-side button').filter({hasText:'Notificações',exact:true}).click();await page.waitForSelector('.explicit-settings-heading h3');
 check('Notificações mantém a navegação aos ajustes',await page.locator('.explicit-settings-heading h3').textContent()==='Notificações');await page.keyboard.press('Escape');
 await page.evaluate(()=>openHome());await screenshot('inicio');
 await page.evaluate(()=>openDirect('qa-dm'));await page.waitForSelector('.explicit-dm-message');await screenshot('dm');
 check('DM mantém lista e conversa lado a lado',await page.locator('.explicit-dm-split').evaluate(e=>getComputedStyle(e).display==='grid'));
 check('Enviar da DM usa azul-bebê',await page.locator('#directComposer>button[type=submit]').evaluate(e=>getComputedStyle(e).backgroundColor==='rgb(168, 213, 247)'));
 check('DM usa a mesma fonte',await page.locator('.explicit-dm-text').first().evaluate(e=>getComputedStyle(e).fontFamily.includes('Inter')));
 check('DM usa o mesmo corpo de texto',await page.locator('.explicit-dm-text').first().evaluate(e=>getComputedStyle(e).fontSize==='15px'));
 await page.emulateMedia({reducedMotion:'reduce'});await page.evaluate(()=>{void nexoForm('Ajustar perfil',[{name:'name',label:'Nome',value:'Nome comprido de demonstração para verificar campos'}])});
 check('movimento reduzido respeitado',await page.locator('.obsidian-modal').evaluate(e=>getComputedStyle(e).animationName==='none'));
 for(const size of [{width:768,height:900},{width:390,height:844}]){await page.setViewportSize(size);const r=await page.locator('.obsidian-modal').boundingBox();check('modal cabe em '+size.width+'px',r.x>=0&&r.x+r.width<=size.width+1);await screenshot('modal-'+size.width)}
 await page.keyboard.press('Escape');
 // Exercise the shipped picker HTML/CSS/JS and isolated preload, with synthetic sources.
 const pickerId=await app.evaluate(async({BrowserWindow},config)=>{const w=new BrowserWindow({width:820,height:625,show:false,webPreferences:{offscreen:true,preload:config.preload,contextIsolation:true,nodeIntegration:false,sandbox:true,webSecurity:true}});await w.loadFile(config.html);return w.id},{preload:path.join(desktop,'picker-preload.js'),html:path.join(desktop,'picker.html')});
 let picker;for(let i=0;i<100;i++){picker=app.windows().find(p=>p.url().endsWith('/picker.html'));if(picker)break;await new Promise(r=>setTimeout(r,30))}assert.ok(picker);
 await picker.waitForLoadState('load');await picker.setViewportSize({width:820,height:625});await picker.evaluate(()=>document.fonts.load('400 14px Inter'));
 const sample=[{id:'screen:qa',kind:'screen',name:'Tela de demonstração',thumbnail:'data:image/png;base64,'+fs.readFileSync(path.join(out,'chat.png')).toString('base64')},{id:'window:qa',kind:'window',name:'Janela de demonstração com nome extenso para conferir seleção e rodapé sem ocultar as ações',thumbnail:null}];
 await app.evaluate(({BrowserWindow},data)=>BrowserWindow.fromId(data.id).webContents.send('explicit:capture-sources',{requestId:1,sources:data.sources}),{id:pickerId,sources:sample});
 await picker.locator('.tile').waitFor();await picker.screenshot({path:path.join(out,'seletor-inicial.png')});await picker.locator('.tile').click();
 check('picker habilita transmitir ao selecionar',await picker.locator('#share').isEnabled());
 await picker.locator('[data-kind=window]').click();check('picker invalida fonte da outra categoria',await picker.locator('#share').isDisabled());
 await picker.locator('.tile').focus();await picker.keyboard.press('Space');check('picker preserva foco ao selecionar',await picker.locator('.tile').evaluate(e=>e===document.activeElement));
 await picker.screenshot({path:path.join(out,'seletor-transmissao.png')});
 await picker.locator('#share').click();check('picker envia escolha pelo preload restrito',await app.evaluate(()=>global.explicitQAChoice?.sourceId)==='window:qa');
 await app.evaluate(({BrowserWindow},id)=>BrowserWindow.fromId(id).webContents.setZoomFactor(1.5),pickerId);
 check('rodapé do picker permanece acessível com zoom 150%',await picker.locator('.footer').evaluate(e=>{const r=e.getBoundingClientRect();return r.y>=0&&r.bottom<=innerHeight+1}));
 await picker.screenshot({path:path.join(out,'seletor-zoom150.png')});
 await app.evaluate(({BrowserWindow},id)=>BrowserWindow.fromId(id).close(),pickerId);
 const version=await app.evaluate(()=>process.versions.electron);
 check('nenhum erro JavaScript não tratado',errors.length===0);check('CSS e fonte sem erro HTTP',failedAssets.length===0);
 const report={electron:version,scope:'renderer/preload isolados com dados fictícios; sem shell nativo, backend Go ou LiveKit real',checks,contrast,errors,failedAssets};
 fs.writeFileSync(path.join(out,'resultado.json'),JSON.stringify(report,null,2));console.log(JSON.stringify(report,null,2));
})().catch(e=>{console.error(e);process.exitCode=1}).finally(async()=>{if(app)await app.close().catch(()=>{});if(server)server.close();if(temp)fs.rmSync(temp,{recursive:true,force:true})});
