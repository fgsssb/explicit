const test=require('node:test');
const assert=require('node:assert/strict');
const {validateServerURL}=require('../security');
test('Radmin requires explicit opt-in and exact host/port',()=>{
 const prev=process.env.EXPLICIT_RADMIN_TEST;
 try{
  delete process.env.EXPLICIT_RADMIN_TEST;
  assert.throws(()=>validateServerURL('http://26.61.221.56:8080',true));
  process.env.EXPLICIT_RADMIN_TEST='1';
  assert.equal(validateServerURL('http://26.61.221.56:8080',true),'http://26.61.221.56:8080');
  for(const bad of ['http://26.61.221.57:8080','http://26.61.221.56:8081','http://evil.example:8080'])assert.throws(()=>validateServerURL(bad,true));
 }finally{if(prev===undefined)delete process.env.EXPLICIT_RADMIN_TEST;else process.env.EXPLICIT_RADMIN_TEST=prev;}
});
