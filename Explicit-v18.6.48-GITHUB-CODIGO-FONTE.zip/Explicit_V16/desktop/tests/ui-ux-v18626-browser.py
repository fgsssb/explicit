"""Optional browser UX regression smoke for Explicit v18.6.26.
Run: python tests/ui-ux-v18626-browser.py (requires playwright + Chromium).
This is an ISOLATED renderer test, not a Windows/Electron or LiveKit end-to-end test.
"""
from pathlib import Path
import sys
from playwright.sync_api import sync_playwright

root = Path(__file__).resolve().parents[2] / 'server' / 'Comunicador_Fase1' / 'web'
index = (root / 'index.html').read_text(encoding='utf-8')
ctx = index[index.index('function contextMenu(e,items)'):index.index('function openCommunityMenu(', index.index('function contextMenu(e,items)'))]
modals = index[index.index('function explicitBindModalFocus('):index.index('// Ao assistir fora da sala', index.index('function explicitBindModalFocus('))]
form = index[index.index('function nexoForm(title,fields)'):index.index("\n\tel('nexoSidebar')", index.index('function nexoForm(title,fields)'))] if "\n\tel('nexoSidebar')" in index else index[index.index('function nexoForm(title,fields)'):index.index("\nel('nexoSidebar')", index.index('function nexoForm(title,fields)'))]

with sync_playwright() as p:
    browser = p.chromium.launch(executable_path='/usr/bin/chromium' if Path('/usr/bin/chromium').exists() else None, headless=True, args=['--no-sandbox'] if sys.platform.startswith('linux') else [])
    page = browser.new_page(viewport={'width': 320, 'height': 480})
    page.set_default_timeout(3000)
    errors = []
    page.on('pageerror', lambda error: errors.append(str(error)))
    html = """<html><head><style>
    body{font:14px Arial;background:#0b111a;color:#edf7ff;margin:0}
    button,input{font:inherit}button{cursor:pointer}
    .nexo-context{position:fixed;z-index:100;background:#1b2d41;border:1px solid #6591b1;padding:6px;display:flex;flex-direction:column;min-width:190px}
    .nexo-context button{padding:9px;background:transparent;color:white;border:0;text-align:left}
    .obsidian-modal-backdrop{position:fixed;inset:0;display:grid;place-items:center;background:#000b}
    .obsidian-modal{position:relative;background:#16243b;padding:20px;border:1px solid #476483;min-width:200px}
    .obsidian-modal .modal-close{position:absolute;right:12px;top:10px}
    .explicit-dm-header{background:#101c29;height:54px}
    #directMessages{height:320px;overflow:auto}
    </style></head><body>
    <button id="opener" type="button">Abrir modal</button>
    <div class="explicit-dm-header"><strong id="directTitle">Alice</strong></div>
    <div id="directMessages"></div>
    <div id="who">me</div>
    </body></html>"""
    page.set_content(html)
    page.add_style_tag(path=str(root/'direct-calls.css'))
    page.add_style_tag(path=str(root/'ux-polish-v18626.css'))
    page.add_script_tag(content="""
        function nexoToast(message){window.__lastToast=message}
        var activeDirect='dm1', session='dev-session', voiceRoom='', startVoice=async()=>{}, stopVoice=async()=>{};
        var getPrefs=()=>({volume:100,screenFPS:20,audioOutputId:''});
        var voiceInputConstraints=()=>({});
        var explicitConfirmFirstVoiceUse=async()=>true;
        var explicitVisualURL=()=>'/missing-avatar.png';
        var refreshDirectRail=async()=>{};
        var openHome=()=>{};
        var nexoDialog=async()=>true;
        var openDirect=async id=>{activeDirect=id;};
        var api=async(path,method,body)=>{
            if(path==='social')return {friends:[{username:'alice',display_name:'Alice'},{username:'bob',display_name:'Bob'},{username:'carol',display_name:'Carol'}]};
            if(path.startsWith('direct?id='))return {users:path.includes('group1')?['me','alice','bob']:['me','alice'],name:path.includes('group1')?'Equipe':''};
            if(path==='direct'&&body?.action==='create_group')return {id:'group1'};
            if(path==='direct')return {id:'dm1'};
            if(path==='direct-call'){
                if(body?.action==='peek')return {active:true,participants:[{user:'alice'}]};
                if(body?.action==='join')return {participants:[{user:'alice'},{user:'me'}]};
                if(body?.action==='poll')return {participants:[{user:'alice'},{user:'me'}],solo_remaining_seconds:null};
                return {ok:true};
            }
            return {};
        };
        window.ExplicitLiveKitMedia=class{
          async connect(){} async disconnect(){} async setMicActive(){} syncAudio(){} async stopScreen(){};
        };
    """)
    page.add_script_tag(content=ctx+'\n'+modals+'\n'+form)

    # Menu must stay inside a narrow window and be keyboard dismissible.
    page.evaluate("contextMenu({clientX:312,clientY:478,type:'contextmenu'},[['Primeira',()=>{}],['Segunda',()=>{}]])")
    rect=page.locator('.nexo-context').bounding_box()
    assert rect and rect['x']>=7 and rect['y']>=7 and rect['x']+rect['width']<=321 and rect['y']+rect['height']<=481, rect
    page.keyboard.press('Escape')
    assert page.locator('.nexo-context').count()==0

    # Shared workspace modal respects Escape, role, focus restore.
    page.locator('#opener').focus()
    page.evaluate("window.__modal=modalWorkspace('Perfil de teste');window.__modal.append(Object.assign(document.createElement('button'),{textContent:'Ação'}))")
    assert page.locator('.obsidian-modal[role=dialog][aria-modal=true]').count()==1
    assert page.evaluate('document.activeElement.classList.contains("modal-close")')
    page.keyboard.press('Shift+Tab')
    assert page.evaluate('document.activeElement.textContent==="Ação"')
    page.keyboard.press('Escape')
    assert page.locator('.obsidian-modal-backdrop').count()==0
    assert page.evaluate('document.activeElement.id==="opener"')

    # Form required validation, submit, focus restoration.
    page.locator('#opener').focus()
    page.evaluate("() => {window.__form=nexoForm('Alterar nome',[{name:'name',label:'Nome',required:true}]);window.__form.then(result=>window.__formResult=result)}")
    assert page.locator('.obsidian-modal[role=dialog]').count()==1
    page.locator('.obsidian-modal button').last.click()
    assert page.locator('.obsidian-modal-backdrop').count()==1
    page.locator('.obsidian-modal input').fill('Explicit')
    page.locator('.obsidian-modal button').last.click()
    page.wait_for_timeout(30)
    assert page.evaluate('window.__formResult?.name')=='Explicit'
    assert page.evaluate('document.activeElement.id==="opener"')

    # Group selection: Escape, focus restoration, disabled/enabled submit.
    page.add_script_tag(path=str(root/'direct-calls.js'))
    page.locator('#opener').focus()
    page.evaluate('window.explicitCreateGroupDM()')
    page.locator('.explicit-dm-friend').first.wait_for()
    assert page.locator('.explicit-dm-group-submit').is_disabled()
    page.keyboard.press('Escape')
    assert page.locator('.explicit-dm-group-backdrop').count()==0
    assert page.evaluate('document.activeElement.id==="opener"')
    page.evaluate('window.explicitCreateGroupDM()')
    page.locator('.explicit-dm-friend').first.wait_for()
    page.locator('.explicit-dm-friend input').nth(0).check()
    page.locator('.explicit-dm-friend input').nth(1).check()
    assert page.locator('.explicit-dm-group-submit').is_enabled()
    page.locator('.explicit-dm-group-submit').click()
    page.wait_for_timeout(150)
    assert page.locator('.explicit-dm-group-backdrop').count()==0

    # Call controls must survive polls without DOM replacement, unlike v18.6.25.
    page.evaluate("document.body.classList.add('explicit-direct-mode');activeDirect='dm1';openDirect('dm1')")
    page.locator('.explicit-private-join').wait_for(timeout=3000)
    page.locator('.explicit-private-join').click()
    page.locator('.explicit-private-call-toolbar .explicit-private-hang').wait_for(timeout=3000)
    page.evaluate("document.querySelector('.explicit-private-call-toolbar button').dataset.stable='yes'")
    page.wait_for_timeout(4250)
    assert page.evaluate("document.querySelector('.explicit-private-call-toolbar button').dataset.stable==='yes'")
    assert page.locator('.explicit-private-call').bounding_box()['width'] <= 320
    # Synthetic share stream only (not LiveKit): stage must give video the main area.
    page.evaluate("""() => {
      const panel=document.querySelector('.explicit-private-call-body .explicit-private-videos');
      const tile=document.createElement('div');tile.className='explicit-private-video';
      const label=document.createElement('span');label.className='explicit-private-video-label';label.textContent='Alice está transmitindo';
      const video=document.createElement('video');video.setAttribute('aria-label','Transmissão de Alice');
      tile.append(label,video);panel.append(tile);
      document.querySelector('.explicit-private-call').classList.add('is-streaming');
    }""")
    for width,height in [(1280,720),(1366,768),(1600,900),(1920,1080),(2560,1440)]:
        page.set_viewport_size({'width':width,'height':height})
        dims=page.evaluate("""() => {
          const stage=document.querySelector('.explicit-private-call'), box=stage.getBoundingClientRect(),
                tile=stage.querySelector('.explicit-private-video').getBoundingClientRect();
          return {x:box.x,right:box.right,stageWidth:box.width,stageHeight:box.height,
                  tileWidth:tile.width,overflow:document.documentElement.scrollWidth-window.innerWidth};
        }""")
        assert dims['x']>=-1 and dims['right']<=width+1 and dims['overflow']<=1, (width,height,dims)
        assert dims['tileWidth']>=320, (width,height,dims)
    page.set_viewport_size({'width':1280,'height':720})
    shot=root.parent.parent.parent.parent/'QA-Explicit-v18.6.26-chamada-isolada.png'
    page.screenshot(path=str(shot),full_page=False)
    assert not errors, errors
    print('PASS Chromium: menus, Escape/focus, forms, group modal, call toolbar and synthetic video stage at six viewport sizes.')
    browser.close()
