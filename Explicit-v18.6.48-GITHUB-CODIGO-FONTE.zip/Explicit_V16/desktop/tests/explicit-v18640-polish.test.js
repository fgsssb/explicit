
'use strict';
const test=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path');
const root=path.resolve(__dirname,'../../server/Comunicador_Fase1/web');
const html=fs.readFileSync(path.join(root,'index.html'),'utf8');
const css=fs.readFileSync(path.join(root,'explicit-v18640-fixes.css'),'utf8');
test('tela carrega os ajustes de tema por último e mantém controles existentes',()=>{
 assert.ok(html.lastIndexOf('explicit-v18640-fixes.css')>html.lastIndexOf('explicit-v18639-palette.css'));
 for(const id of ['attachImage','explicitEmojiButton','explicitEmojiPicker','message','screenVideos'])assert.match(html,new RegExp('id="'+id+'"'));
});
test('compositor e ambos os seletores usam a mesma superfície neutra e altura',()=>{
 assert.match(css,/#form\.composer/);assert.match(css,/#explicitEmojiPicker\.explicit-sticker-mode/);
 assert.match(css,/height:395px!important/);assert.match(css,/background:#0c0e12!important/);
});
test('Home não tem faixas internas e apoio é inteiramente visível',()=>{
 assert.match(css,/#spotlightContent,#homeFriends,#homeSpaces/);
 assert.match(css,/grid-template-rows:minmax\(0,1fr\) 176px 168px!important/);
 assert.match(css,/\.explicit-support-card \{/);
 assert.match(css,/overflow:visible!important/);
});
test('nome de exibição permite edição inline e confirmação com rollback',()=>{
 assert.match(html,/startDisplayNameEdit/);assert.match(html,/explicit-display-name-save/);
 assert.match(html,/displayName\.replaceWith\(editor\)/);assert.match(html,/editor\.replaceWith\(displayName\)/);
 assert.match(html,/api\('profile','POST',\{action:'display_name'/);
});
test('menu da transmissão oferece volume local e seleção 30-60 FPS',()=>{
 assert.match(html,/explicitScreenContextMenu/);assert.match(html,/for\(const fps of \[30,45,60\]\)/);
 assert.match(html,/setRemoteScreenFPS/);assert.match(html,/setScreenAudioVolume/);
});
test('setinhas de áudio permanecem transparentes no hover e clicáveis',()=>{
 assert.match(css,/\.explicit-audio-arrow:hover/);assert.match(css,/background:transparent!important/);
 assert.match(fs.readFileSync(path.join(root,'explicit-v18637.js'),'utf8'),/explicit-audio-arrow/);
});
