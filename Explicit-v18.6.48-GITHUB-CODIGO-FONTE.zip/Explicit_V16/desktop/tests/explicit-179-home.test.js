const test=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');const path=require('node:path');
const server=path.join(__dirname,'../../server/Comunicador_Fase1');
const html=fs.readFileSync(path.join(server,'web/index.html'),'utf8');
const admin=fs.readFileSync(path.join(server,'web/admin-console.js'),'utf8');
const backend=fs.readFileSync(path.join(server,'announcements.go'),'utf8');
test('dashboard keeps spotlight, friends, communities and support with compact limits',()=>{
 for(const section of ['explicit-spotlight','explicit-friends-section','explicit-communities-section','explicit-support-card']) assert.ok(html.includes(section));
 assert.match(html,/friends:5,communities:5,notifications:5/);
 assert.match(html,/data-friend-tab="all"/);assert.match(html,/data-friend-tab="online"/);assert.match(html,/data-friend-tab="pending"/);
});
test('approved video thumbnails are derived from constrained YouTube ids',()=>{
 assert.match(html,/function explicitYouTubeThumbnail/);
 assert.match(html,/i\.ytimg\.com\/vi\//);
 assert.match(html,/explicit-spotlight-thumb/);
});
test('announcements are real server-side staff-only actions and safely rendered',()=>{
 assert.match(admin,/Comunicados/);assert.match(admin,/action:'add'.*title:title\.value/);
 assert.match(backend,/systemLevel\(systemRole\(s\.db\.Users\[user\]\)\)\s*<\s*1/);
 assert.match(html,/explicitInlineMarkdown/);assert.match(html,/document\.createTextNode/);
});
