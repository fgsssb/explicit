const test=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const vm=require('node:vm');
const web=path.resolve(__dirname,'../../server/Comunicador_Fase1/web');
const index=fs.readFileSync(path.join(web,'index.html'),'utf8');
const adapter=fs.readFileSync(path.join(web,'livekit-adapter.js'),'utf8');
test('vendored open-source libraries load before the chat and LiveKit adapters',()=>{
 const files=['eventemitter3-4.0.7.min.js','pako-1.0.11.min.js'];
 for(const file of files)assert.ok(fs.statSync(path.join(web,'vendor',file)).size>1000);
 for(const file of ['LICENSE.eventemitter3','LICENSE.pako'])assert.match(fs.readFileSync(path.join(web,'vendor',file),'utf8'),/MIT License/i);
 assert.ok(index.indexOf('eventemitter3-4.0.7.min.js')<index.indexOf('livekit-adapter.js'));
 assert.ok(index.indexOf('realtime-events.js')<index.indexOf('livekit-adapter.js'));
 assert.ok(index.indexOf('pako-1.0.11.min.js')<index.indexOf('livekit-adapter.js'));
});
test('authenticated polling and SSE share one EventEmitter3 message bus',()=>{
 assert.match(index,/const explicitChatBus=new window\.EventEmitter3/);
 assert.match(index,/explicitChatBus\.on\('chat:message'/);
 assert.match(index,/explicitChatBus\.emit\('chat:message',\{\.\.\.m,channel:/);
 assert.match(index,/new window\.ExplicitRealtimeEvents/);
 assert.match(index,/transport\.stop\(\)/);
 assert.match(index,/explicitChatReconcileTimer=setInterval/);
});
test('diagnostics are opt-in and compressed locally, not posted to an external service',()=>{
 assert.match(index,/window\.pako\.gzip\(JSON\.stringify\(current\)\)/);
 assert.match(index,/\.json\.gz/);
 assert.match(index,/URL\.createObjectURL\(blob\)/);
 assert.doesNotMatch(index,/sentry\.io|telemetry\.discord\.com/);
});
test('video track interruption and local capture report avoid device identifiers',()=>{
 assert.match(adapter,/screen_track_muted/);
 assert.match(adapter,/screen_track_unmuted/);
 assert.match(adapter,/getSettings/);
 assert.match(adapter,/this\.supportBus\?\.emit\('media:event'/);
 assert.doesNotMatch(adapter,/deviceId:\s*settings\.deviceId/);
});
test('inline application scripts remain valid JavaScript after integration',()=>{
 let n=0;
 for(const [,attributes,source] of index.matchAll(/<script([^>]*)>([\s\S]*?)<\/script>/g)){
  if(attributes.includes('src='))continue;
  assert.doesNotThrow(()=>new vm.Script(source));n++;
 }
 assert.ok(n>=4);
});
