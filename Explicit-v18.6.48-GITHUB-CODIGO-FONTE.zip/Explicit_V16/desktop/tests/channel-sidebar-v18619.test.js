const test=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const web=path.join(__dirname,'../../server/Comunicador_Fase1/web');
const js=fs.readFileSync(path.join(web,'channel-sidebar.js'),'utf8');
const css=fs.readFileSync(path.join(web,'channel-sidebar.css'),'utf8');
const html=fs.readFileSync(path.join(web,'index.html'),'utf8');
test('channel sidebar retains original click, voice & ACL behavior',()=>{
 assert.match(js,/const original=renderChannels/);
 assert.match(js,/original\.apply\(this,arguments\)/);
 assert.match(js,/\.replaceChildren\(iconWrap\('voice',restricted\)/);
 assert.match(js,/\.replaceChildren\(iconWrap\('text',restricted\)/);
 assert.match(js,/community\.channel_meta\?\.\[name\]\?\.private===true/);
 assert.match(js,/\.voice-heading button\.toggle/);
 assert.match(css,/voice-members/);
});
test('channel icons and locks are semantic SVGs with named accessibility labels',()=>{
 assert.match(js,/lockIcon/);
 assert.match(js,/aria-label/);
 assert.match(js,/Canal privado de voz/);
 assert.match(js,/Canal privado de texto/);
 assert.match(html,/channel-sidebar\.css\?v=18619/);
 assert.match(html,/channel-sidebar\.js\?v=18619/);
});
