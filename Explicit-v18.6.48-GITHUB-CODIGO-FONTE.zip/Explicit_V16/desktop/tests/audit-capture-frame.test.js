const test=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const vm=require('node:vm');
// Exercise the actual registered callback without starting Chromium or capturing a screen.
function fixture(){
 const source=fs.readFileSync(require.resolve('../main.js'),'utf8');
 const start=source.indexOf(' ses.setDisplayMediaRequestHandler(');
 const end=source.indexOf('\n win.webContents.setWindowOpenHandler',start);
 const frame={url:'https://explicit.test/'};frame.top=frame;
 const context={win:{isDestroyed:()=>false,webContents:{mainFrame:frame}},trusted:url=>url==='https://explicit.test/',console,
  showCapturePicker:()=>{context.picks++;return Promise.resolve()},picks:0,
  ses:{setDisplayMediaRequestHandler:fn=>{context.handler=fn}}};
 vm.runInNewContext(source.slice(start,end),context);
 return {context,frame};
}
test('screen capture accepts only the trusted main frame and fails closed',()=>{
 const {context:c,frame}=fixture();
 const rejected=[{}, {frame:null}, {frame:{url:'https://foreign.test/',top:frame}}, {frame:{url:frame.url,top:frame}}];
 for(const request of rejected){let denied=false;c.handler(request,()=>{denied=true});assert.equal(denied,true);assert.equal(c.picks,0)}
 c.handler({frame},()=>assert.fail('trusted main frame rejected'));assert.equal(c.picks,1);
 frame.url='https://foreign.test/';let denied=false;c.handler({frame},()=>{denied=true});assert.equal(denied,true);assert.equal(c.picks,1);
});
