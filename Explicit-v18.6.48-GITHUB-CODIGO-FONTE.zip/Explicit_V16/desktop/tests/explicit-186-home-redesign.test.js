const test=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const html=fs.readFileSync(path.join(__dirname,'../../server/Comunicador_Fase1/web/index.html'),'utf8');
const home=html.slice(html.indexOf('async function openHome(){'),html.indexOf("document.body.classList.remove('explicit-light-theme');",html.indexOf('async function openHome(){')));
test('home redesign retains all real data regions and existing user actions',()=>{
 for(const id of ['spotlightContent','spotlightRequestBtn','spotlightPrev','spotlightNext','spotlightCount','homeFriends','homeNotificationBell','homeNotificationPanel','addFriendBtn','homeNotifications','homeSpaces','homeAllCommunities','homeCreateCommunity']){
  assert.ok(home.includes(id),`missing home element ${id}`);
 }
 for(const action of ['explicitLoadSpotlight(root)','api(\'social\')','openDirectWith(f.username)','createCommunity','joinCommunity','selectCommunity(c.id)','refreshDirectRail()']){
  assert.ok(home.includes(action),`missing action ${action}`);
 }
});
test('home styles are restricted to dedicated class and preserve original sidebar',()=>{
 assert.match(home,/classList\.add\('explicit-home','explicit-home-v179','explicit-home-refresh','explicit-home-v18632'\)/);
 assert.match(html,/\.explicit-home-refresh:not\(\.explicit-direct-mode\) #nexoOverlay/);
 assert.match(html,/home-v18632\.css/);assert.doesNotMatch(home,/id=\"explicitHomeDate\"/);
 assert.ok(!home.includes('document.getElementById(\'nexoRail\').innerHTML'));
});
test('compact community layout has a dedicated join action beside create and no fake cards',()=>{
 assert.match(home, /id=\"homeJoinCommunity\"[^>]*class=\"explicit-secondary-action\"/);
 assert.match(home, /root\.querySelector\('#homeJoinCommunity'\)\.onclick=joinCommunity/);
 assert.doesNotMatch(home, /explicit-home-join-card/);
 assert.match(home,/dest\.dataset\.count/);
 assert.match(home,/for\(const \[i,c\] of shown\.entries\(\)\)/);
 assert.doesNotMatch(home,/Espaço disponível/);
 assert.match(html,/justify-content:flex-start!important;align-items:stretch!important/);
});
test('friends and notifications are built with safe text nodes rather than interpolating user HTML',()=>{
 assert.match(home,/label\.textContent=f\.display_name\|\|f\.username/);
 assert.match(home,/subtitle\.textContent='@'\+n\.from/);
 assert.match(home,/b\.onclick=\(\)=>openDirectWith\(f\.username\)/);
 assert.match(home,/await api\('social','POST',\{action,id:n\.id\}\)/);
});
