'use strict';
const test=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const base=path.resolve(__dirname,'../../server/Comunicador_Fase1/web');
const html=fs.readFileSync(path.join(base,'index.html'),'utf8');
const admin=fs.readFileSync(path.join(base,'admin-console.js'),'utf8');

test('Badge label is the positioned click surface, not the entire admin modal',()=>{
 assert.match(html,/\.explicit-admin-console label\.explicit-admin-badge-choice\{[^}]*display:flex!important;[^}]*position:relative!important;/);
 const css=html.match(/\.explicit-admin-console \.explicit-admin-badge-choice input\[type=checkbox\]\{([^}]*)\}/);
 assert.ok(css,'badge checkbox-specific CSS rule missing');
 for(const rule of ['width:1px!important','height:1px!important','pointer-events:none!important','clip-path:inset(50%)!important'])assert.ok(css[1].includes(rule),`missing ${rule}`);
 assert.doesNotMatch(css[1],/width:100%/);
 assert.match(admin,/wrap\.className='explicit-admin-badge-choice'/);
 assert.match(admin,/wrap\.append\(input,indicator,heading\)/);
});

test('Admin content scrolls and reset password checkbox is only visible for password resets',()=>{
 assert.match(html,/\.explicit-admin-content\{[^}]*overflow-y:auto!important/);
 assert.match(html,/\.explicit-admin-console label\.explicit-admin-force\[hidden\]\{display:none!important\}/);
 assert.match(admin,/forceWrap\.hidden=action\.value!=='reset_password'/);
});
