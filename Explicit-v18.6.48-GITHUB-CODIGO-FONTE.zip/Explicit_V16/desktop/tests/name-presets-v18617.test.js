const test=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const base=path.join(__dirname,'../../server/Comunicador_Fase1/web');
const js=fs.readFileSync(path.join(base,'name-presets.js'),'utf8');
const css=fs.readFileSync(path.join(base,'name-presets.css'),'utf8');
test('delete action is a trash SVG and has its accessible label',()=>{
 assert.match(js,/createElementNS\('http:\/\/www\.w3\.org\/2000\/svg','svg'\)/);
 assert.match(js,/explicit-preset-delete/);
 assert.match(js,/del\.setAttribute\('aria-label','Excluir '/);
 assert.doesNotMatch(js,/explicit-preset-more/);
});
test('confirmation lives above inventory in same stacking context, not global nexoDialog',()=>{
 assert.match(js,/function confirmPresetDelete\(/);
 assert.match(js,/workspace\.append\(layer\)/);
 assert.match(css,/\.explicit-preset-confirm-layer\{position:fixed;inset:0;z-index:30/);
 assert.match(js,/if\(!await confirmPresetDelete\(preset,event\.currentTarget\)\)return/);
});
test('removes GIF/flare effects from name renderer while preserving basic customization',()=>{
 assert.match(js,/const effectModes=\['none'\]/);
 assert.match(js,/const animations=\['none'\]/);
 assert.match(js,/gradient/);
 assert.match(js,/shadow_color/);
 assert.match(js,/glow/);
 assert.doesNotMatch(css,/name-effect-ipb\.gif/);
 assert.doesNotMatch(css,/explicit-name-effect-ipb_particles/);
 assert.doesNotMatch(js,/Flare luminoso/);
});
