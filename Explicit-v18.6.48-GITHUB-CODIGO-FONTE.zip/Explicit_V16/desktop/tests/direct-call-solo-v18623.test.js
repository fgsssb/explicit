'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const server=fs.readFileSync(path.join(__dirname,'../../server/Comunicador_Fase1/direct_calls.go'),'utf8');
const client=fs.readFileSync(path.join(__dirname,'../../server/Comunicador_Fase1/web/direct-calls.js'),'utf8');
test('server times out solitary DM calls after two minutes and sweeps even without requests',()=>{
 assert.match(server,/directCallAloneTimeout\s*=\s*2 \* time\.Minute/);
 assert.match(server,/startDirectCallSweeper\(\)/);
 assert.match(server,/time\.NewTicker\(directCallSweepInterval\)/);
 assert.match(server,/cleanDirectCallRoomsLocked/);
 assert.match(server,/terminateDirectCallMedia\(ended\)/);
});
test('call countdown is shown in client, automatic shutdown releases LiveKit',()=>{
 assert.match(client,/solo_remaining_seconds/);
 assert.match(client,/Aguardando participantes · encerra em/);
 assert.match(client,/Chamada encerrada: você ficou sozinho por 2 minutos/);
 assert.match(server,/livekitRoomAction\(room, user, true\)/);
 assert.match(server,/directCallNewRoomName/);
});
