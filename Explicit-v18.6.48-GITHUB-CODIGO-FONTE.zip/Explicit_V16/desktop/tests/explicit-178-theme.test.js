const test=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const root=path.resolve(__dirname,'../..');
const html=fs.readFileSync(path.join(root,'server/Comunicador_Fase1/web/index.html'),'utf8');
const picker=fs.readFileSync(path.join(root,'desktop/picker.css'),'utf8');
const splash=fs.readFileSync(path.join(root,'desktop/splash.html'),'utf8');
test('interface fixa preta com azul equilibrado, sem opções de tema na UI',()=>{
 assert.ok(html.includes('--explicit-bg:#030405'));
 assert.ok(html.includes('--explicit-blue:#6ca6df'));
 assert.ok(html.includes("document.body.classList.remove('explicit-light-theme')"));
 assert.ok(!html.includes("group('Tema do Explicit'"));
 assert.ok(!html.includes("next.theme=value"));
});
test('destaques principais e ping usam a identidade de azul médio',()=>{
 for(const cls of ['.ice-ping strong','.explicit-settings-nav-item.selected','.explicit-admin-nav-item.active','.explicit-auth-card .explicit-auth-submit']) assert.ok(html.includes(cls));
 assert.ok(html.includes('var(--explicit-blue)'));
});
test('janelas nativas seguem o mesmo tom sem alterar os fluxos',()=>{
 assert.ok(picker.includes('#6ca6df'));
 assert.ok(splash.includes('#6ca6df'));
 assert.ok(splash.includes('explicit-icon.png'));
});
