'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const root = path.join(__dirname, '..');
const web = path.join(root, '../server/Comunicador_Fase1/web');
const read = file => fs.readFileSync(file,'utf8');
test('admin badges are independently selected and sent to authorized server route',()=>{
 const js = read(path.join(web,'admin-console.js'));
 assert.match(js,/if\(canManage\)\s*\{\s*const badgeBox/);
 assert.match(js,/Somente Owner pode conceder ou remover Admin/);
 assert.match(js,/\['staff','Admin'/);
 assert.match(js,/\['beta','Beta'/);
 assert.match(js,/\['explicit_plus','Explicit\+'/);
 assert.match(js,/action:'set_badges'/);
 assert.ok(js.indexOf('A maximum of two badges') > js.indexOf("tab==='users'"),'badge controls must only be inside user manager');
});
test('locked sticker area covers all controls but not the emoji/sticker tabs',()=>{
 const stickers=read(path.join(web,'stickers.js'));
 const html=read(path.join(web,'index.html'));
 assert.match(stickers,/pane\.classList\.toggle\('is-sticker-locked',!state\.can_send\)/);
 assert.match(stickers,/upload\.disabled=!state\.can_upload/);
 assert.match(stickers,/if\(!state\.can_upload\|\|!state\.can_send\)return/);
 assert.match(html,/\.explicit-sticker-pane\.is-sticker-locked \.explicit-sticker-locked \{inset:0;z-index:30/);
 assert.match(html,/\.explicit-sticker-switch button/);
});
test('taskbar badge uses authenticated IPC with count only and bundled static icons',()=>{
 const main=read(path.join(root,'main.js'));
 const pre=read(path.join(root,'preload.js'));
 const notify=read(path.join(web,'notifications.js'));
 const pkg=read(path.join(root,'package.json'));
 assert.match(main,/desktopSettingsAllowed\(event\).*Number\.isInteger\(count\)/);
 assert.match(main,/win\.setOverlayIcon\(/);
 assert.match(pre,/setNotificationCount:/);
 assert.match(notify,/"unread_count"|result\.unread_count/);
 assert.match(pkg,/unread-overlays\/\*\*/);
 for(const name of ['1.png','9.png','99.png','99plus.png'])assert.ok(fs.existsSync(path.join(root,'unread-overlays',name)));
});
