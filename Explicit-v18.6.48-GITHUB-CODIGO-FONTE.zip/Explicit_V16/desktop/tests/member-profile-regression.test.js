const test=require('node:test');const assert=require('node:assert/strict');const fs=require('node:fs');const path=require('node:path');
const html=fs.readFileSync(path.join(__dirname,'../../server/Comunicador_Fase1/web/index.html'),'utf8');
test('o perfil e posicionado dentro da funcao openMember',()=>{
 const start=html.indexOf('async function openMember(');const end=html.indexOf('const explicitRolePermissions=',start);assert.ok(start>=0&&end>start);
 const fn=html.slice(start,end);assert.ok(/identity\.append\(title,(sub|handle,stateLine)\);cover\.append\(portrait,fallback,identity\);pop\.append\(cover\);/.test(fn),'perfil preserva o bloco de identidade com nome, usuário e status');assert.match(fn,/pop\.hidden=false;/);assert.match(fn,/pop\.style\.left=/);
 assert.ok(fn.includes('async function openMember('),'funcao do perfil preservada');
});
