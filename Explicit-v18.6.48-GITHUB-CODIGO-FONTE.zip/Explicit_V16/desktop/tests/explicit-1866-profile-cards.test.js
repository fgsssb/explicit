const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const html = fs.readFileSync(path.join(__dirname, '../../server/Comunicador_Fase1/web/index.html'), 'utf8');
function part(start, end){ const a=html.indexOf(start);assert.ok(a >= 0, start);const b=html.indexOf(end,a+start.length);assert.ok(b>a,end);return html.slice(a,b); }
test('only Staff Explicit badge appears in community member list', ()=> {
 const source=part('function renderMembers(){','function contextMenu(');
 assert.match(source,/explicitStaffBadge\(m\.system_role\)/);
 assert.doesNotMatch(source,/explicitExtraBadges\(/);
 assert.match(source,/explicitAvatarBadge\(m\.user,m\.display_name\|\|m\.user/);
});
test('member avatars use initials with status overlay',()=>{
 const helper=part('function explicitAvatarBadge(', 'function explicitAvatarImg(');
 assert.match(helper,/explicitInitials\(displayName\|\|user\)/);
 assert.match(helper,/explicit-avatar-status/);
 assert.match(html,/\.explicit-avatar-status\.explicit-status-online/);
});
test('chat and direct messages use avatar fallbacks',()=>{
 const message=part('function add(m){','// A single authenticated event bus');
 assert.match(message,/explicitAvatarBadge\(m\.author/);
 assert.match(html,/explicit-dm-avatar-image/);
});
test('community images are rendered as photos, not CSS background-image',()=>{
 const rail=part('function renderCommunitiesRail(){','function renderChannels(){');
 assert.match(rail,/explicit-rail-community-photo/);
 const home=part('const fillSpaces=()=>{', 'allCommunities.onclick');
 assert.match(home,/explicit-community-cover-photo/);
 assert.doesNotMatch(home,/image\.style\.backgroundImage/);
});
test('register layout uses two columns and mobile fallback',()=>{
 assert.match(html,/#auth\.explicit-auth-register\{max-width:780px/);
 assert.match(html,/grid-template-columns:repeat\(2,minmax\(0,1fr\)\)/);
 assert.match(html,/@media\(max-width:650px\)\{#auth\.explicit-auth-register\{grid-template-columns:minmax\(0,1fr\)/);
 assert.match(html,/class="explicit-auth-field explicit-auth-password-field"/);
});
