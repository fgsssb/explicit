const test=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const vm=require('node:vm');
const path=require('node:path');
const html=fs.readFileSync(path.join(__dirname,'../../server/Comunicador_Fase1/web/index.html'),'utf8');
const code=fs.readFileSync(path.join(__dirname,'../../server/Comunicador_Fase1/web/notifications.js'),'utf8');
function harness(){
 const nodes=[];const document={getElementById:id=>id==='who'?{textContent:'ana'}:null,createTextNode:text=>({text}),createElement:tag=>({tag,className:'',textContent:''})};
 const window={};
 const vmctx={window,document,setInterval(){},setTimeout(){},console,session:'',api:async()=>({})};
 vm.runInNewContext(code,vmctx);return {window,nodes,document};
}
test('notification status policy respects online/busy/away/offline',()=>{
 const {window}=harness(),mode=window.explicitNotificationPolicy.notificationMode;
 assert.equal(mode('online'),'all');assert.equal(mode('busy'),'none');
 assert.equal(mode('away'),'sound');assert.equal(mode('offline'),'sound');
});
test('message filters differentiate normal chat from mentions',()=>{
 const {window}=harness(),allowed=window.explicitNotificationPolicy.channelMode;
 const prefs={message_mode:'mentions',messages:true,mentions:true,direct:false,voice_join:false};
 assert.equal(allowed(prefs,'message'),false);assert.equal(allowed(prefs,'mention'),true);
 assert.equal(allowed(prefs,'direct'),false);assert.equal(allowed(prefs,'voice_join'),false);
});
test('mention highlight is rendered using safe text nodes',()=>{
 const {window}=harness();const children=[];
 window.explicitRenderMentions({append:item=>children.push(item)},'Oi @ana @{Equipe Azul} <script>');
 assert.equal(children.map(n=>n.text||n.textContent).join(''),'Oi @ana @{Equipe Azul} <script>');
 assert.equal(children.filter(n=>n.className==='explicit-mention-highlight').length,2);
});
test('UI integrates settings, status and native bridge without altering LiveKit adapter',()=>{
 for(const token of ['explicitBuildNotificationSettings','explicitNotifyLocal','explicitRenderMentions','/notifications.js?v=1862','explicitSetNotificationStatus'])assert.ok(html.includes(token),token);
 const preload=fs.readFileSync(path.join(__dirname,'../preload.js'),'utf8');
 const main=fs.readFileSync(path.join(__dirname,'../main.js'),'utf8');
 assert.ok(preload.includes('explicit:notification-show'));
 assert.ok(main.includes('desktopSettingsAllowed(event)'));
 assert.ok(main.includes("ipcMain.handle('explicit:notification-show'"));
});
