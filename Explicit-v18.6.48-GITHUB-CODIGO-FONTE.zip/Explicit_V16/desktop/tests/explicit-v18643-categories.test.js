'use strict';
const {test}=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const web=path.resolve(__dirname,'../../server/Comunicador_Fase1/web');
const html=fs.readFileSync(path.join(web,'index.html'),'utf8');
const acl=fs.readFileSync(path.join(web,'channel-acl.js'),'utf8');

test('channel rendering keeps nodes flat until the single ACL grouping pass',()=>{
 assert.match(html,/for\(const ch of textChannels\)list\.append\(createTextButton\(ch\)\)/);
 assert.match(html,/for\(const ch of voiceChannels\)list\.append\(createVoiceGroup\(ch\)\)/);
 assert.match(acl,/const previous=renderChannels;/);
 assert.match(acl,/const map=new Map\(\)/);
 assert.match(acl,/list\.replaceChildren\(\.\.\.sections\)/);
 assert.doesNotMatch(html,/const appendCategory=/);
});
test('real categories and safe legacy headings use the same visual components',()=>{
 assert.match(acl,/addCategory\(cat\.name,cat\.id,members\)/);
 assert.match(acl,/addCategory\('TEXTO','',texts,true\)/);
 assert.match(acl,/addCategory\('VOZ','',voices,true\)/);
 assert.match(acl,/if\(!virtual\)group\.dataset\.explicitCategory=id/);
 assert.match(acl,/group\.append\(item\)/);
 assert.match(acl,/title\.setAttribute\('aria-expanded',String\(!closed\)\)/);
 assert.doesNotMatch(html,/label\.className='voice-label';label\.textContent='TEXTO'/);
});
