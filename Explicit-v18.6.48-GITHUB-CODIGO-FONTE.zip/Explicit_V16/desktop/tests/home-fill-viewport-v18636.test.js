const test=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const web=path.join(__dirname,'../../server/Comunicador_Fase1/web');
const html=fs.readFileSync(path.join(web,'index.html'),'utf8');
const css=fs.readFileSync(path.join(web,'home-v18636.css'),'utf8');

test('home uses latest stylesheet after compact v18.6.32 and not on direct messages',()=>{
 const previous=html.indexOf('/home-v18632.css?v=18632');
 const current=html.indexOf('/home-v18636.css?v=18636');
 assert.ok(previous>=0 && current>previous);
 assert.match(css,/\.explicit-home-v18632:not\(\.explicit-direct-mode\)/);
 assert.match(css,/@media\s*\(min-width:931px\)/);
});
test('desktop grid grows top panels instead of reserving a fixed 590px row',()=>{
 assert.match(css,/grid-template-rows:minmax\(0,1fr\) minmax\(0,172px\) minmax\(0,148px\)!important/);
 assert.match(css,/grid-template-areas:'spot friends' 'communities communities' 'support support'!important/);
 assert.match(css,/height:100%!important/);
 assert.match(css,/max-height:none!important/);
 assert.match(css,/#nexoOverlay :is\(\.explicit-spotlight,\.explicit-friends-section\)/);
});
test('whole page does not scroll while friends and changelog stay independently scrollable',()=>{
 assert.match(css,/#nexoOverlay\s*\{[^}]*overflow:hidden!important/s);
 assert.match(css,/#spotlightContent\s*\{[^}]*overflow-y:auto!important/s);
 assert.match(css,/#homeFriends\s*\{[^}]*overflow-y:auto!important/s);
 assert.match(css,/\.explicit-friends-section\s*\{[^}]*overflow:visible!important/s);
 assert.match(css,/\.explicit-support-card\s*\{[^}]*height:100%!important/s);
});
test('small screen height adapts without hiding support, and narrow screens retain safe scroll',()=>{
 assert.match(css,/@media\s*\(min-width:931px\) and \(max-height:720px\)/);
 assert.match(css,/grid-template-rows:minmax\(0,1fr\) minmax\(0,145px\) minmax\(0,118px\)!important/);
 assert.ok(!css.includes('@media (max-width:930px) {\n  body.explicit-home.explicit-home-v179.explicit-home-refresh.explicit-home-v18632:not(.explicit-direct-mode) #nexoOverlay {\n    overflow:hidden'));
});
