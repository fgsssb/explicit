const test=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const main=fs.readFileSync(path.join(__dirname,'../main.js'),'utf8');
const splash=fs.readFileSync(path.join(__dirname,'../splash.html'),'utf8');
test('splash and main window initialize concurrently',()=>{
 assert.match(main,/const splashPromise=createSplash\(\)\.catch/);
 assert.match(main,/createWindow\(\);startupMark/);
 assert.doesNotMatch(main,/await createSplash\(\);createWindow\(\)/);
});
test('splash is small and references a bundled image',()=>{
 assert.ok(Buffer.byteLength(splash)<20000);
 assert.match(splash,/src="explicit-icon\.png"/);
 assert.doesNotMatch(splash,/data:image\//);
});
test('main window waits for splash readiness without artificial 1.7s delay',()=>{
 assert.match(main,/if\(!splashReady&&!splashCreationFailed\)return/);
 assert.match(main,/splashPromise\.then\(\(\)=>\{finishSplash\(\);\}\)/);
 assert.doesNotMatch(main,/1700-\(Date\.now\(\)-splashOpenedAt\)/);
});
test('startup stages have monotonic instrumentation',()=>{
 assert.match(main,/process\.hrtime\.bigint\(\)/);
 for(const stage of ['electron-ready','splash-visible','main-window-dom-loaded','main-window-visible'])assert.ok(main.includes(stage));
});
