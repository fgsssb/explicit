'use strict';
const test=require('node:test'), assert=require('node:assert/strict'), fs=require('node:fs'), path=require('node:path');
const web=path.resolve(__dirname,'../../server/Comunicador_Fase1/web');
const html=fs.readFileSync(path.join(web,'index.html'),'utf8');
const go=fs.readFileSync(path.resolve(web,'../voice.go'),'utf8');
const adapter=fs.readFileSync(path.join(web,'livekit-adapter.js'),'utf8');
const permissions=fs.readFileSync(path.resolve(web,'../admin.go'),'utf8');
test('avatares de voz usam foto existente e fallback com iniciais',()=>{
 assert.match(html,/explicitAvatarBadge\(person\.user,member\?\.display_name\|\|person\.user,!!member\?\.avatar,null,'explicit-voice-avatar'\)/);
 assert.match(html,/\.voice-person\.is-speaking \.explicit-voice-avatar/);
 assert.match(html,/explicitActiveSpeakers/);
});
test('LiveKit usa evento de falante real e mesh tem medição não intrusiva',()=>{
 assert.match(adapter,/ActiveSpeakersChanged/);
 assert.match(html,/onSpeakers:participants/);
 assert.match(html,/createMediaStreamSource/);
 assert.match(html,/explicitStopMeters\(\)/);
});
test('poke mostra estado efetivo do canal e servidor confirma autorização',()=>{
 assert.match(go,/"can_actions": actions/);
 assert.match(html,/voiceChannelActions\[ch\]\?\.poke/);
 assert.match(permissions,/"POKE_MEMBERS": true/);
});
test('camadas de confirmação ganham z-index a cada modal novo',()=>{
 assert.match(html,/function explicitElevateModal\(node\)/);
 assert.match(html,/explicitModalObserver\.observe\(document\.body/);
 assert.match(html,/function explicitMountModal\(back\)\{document\.body\.append\(back\)/);
});
test('painel de cargos usa seções recolhíveis e lista em cartões',()=>{
 assert.match(html,/explicit-role-perm-section/);
 assert.match(html,/explicit-role-card/);
 assert.match(html,/explicit-role-editor-footer/);
 assert.match(html,/Enviar poke em membros/);
});
