'use strict';
const test=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const web=path.join(__dirname,'../../server/Comunicador_Fase1/web');
const root=path.join(__dirname,'../../server/Comunicador_Fase1');
const hub=fs.readFileSync(path.join(web,'community-hub.js'),'utf8');
const style=fs.readFileSync(path.join(web,'community-hub.css'),'utf8');
const index=fs.readFileSync(path.join(web,'index.html'),'utf8');
const go=fs.readFileSync(path.join(root,'community_hub.go'),'utf8');
test('menu de comunidade contem todas as acoes pedidas',()=>{
 for(const name of ['Marcar como lida','Convidar para a comunidade','Silenciar comunidade','Config. de notificações','Configurações da comunidade','Criar canal','Criar categoria'])assert.ok(hub.includes(name),name);
});
test('notificacoes e quantidades tem limite 99+ e indicador vermelho',()=>{
 assert.match(hub,/unread>=100\?'99\+'/);
 assert.match(style,/\.explicit-unread-badge/);
 assert.match(style,/#d83e52/);
});
test('modos de mute e preferencia individual disponiveis',()=>{
 for(const t of ['24h','48h','7d','30d','forever','off','mentions','all','none'])assert.ok(hub.includes(t),t);
 assert.match(go,/communityUnreadLocked/);
 assert.match(go,/communityIsMuted/);
});
test('configuracao e nova folha de estilos sao carregadas pela Home',()=>{
 assert.match(index,/community-hub\.js\?v=1863/);
 assert.match(index,/community-hub\.css\?v=1863/);
 assert.doesNotThrow(()=>new Function(hub));
});
test('som e popup respeitam silenciamento de comunidades',()=>{
 const notify=fs.readFileSync(path.join(web,'notifications.js'),'utf8');
 assert.match(notify,/community_prefs/);
 assert.match(notify,/own\.muted_until===-1/);
});
