'use strict';
const test=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const root=path.join(__dirname,'../../server/Comunicador_Fase1/web');
const html=fs.readFileSync(path.join(root,'index.html'),'utf8');
const ux=fs.readFileSync(path.join(root,'ux-v18627.js'),'utf8');
const css=fs.readFileSync(path.join(root,'ux-v18627.css'),'utf8');
test('Conta is a nested category in the existing settings window',()=>{
 assert.match(html,/settingsCategories=\['Conta','Geral'/);
 for(const page of ['Conta · Informações','Conta · Perfil','Conta · Segurança','Conta · Personalização'])assert.ok(html.includes(page));
 assert.match(html,/window\.explicitRenderNamePersonalization/);
 assert.match(html,/action:'password'/);
 assert.match(html,/action:'display_name'/);
});
test('account gear uses a flex row with the status card instead of a fixed top offset',()=>{
 assert.match(html,/class="explicit-account-line"/);
 assert.match(css,/\.explicit-account-line\{order:1;display:flex;align-items:center/);
 assert.match(css,/\.explicit-account-line \.explicit-profile-gear\{position:static!important/);
});
test('registration displays invite field only when public API requires it',()=>{
 assert.match(ux,/fetch\('\/api\/register-config'/);
 assert.match(ux,/cache:'no-store'/);
 assert.match(ux,/line\.hidden=!inviteRequired/);
 assert.match(ux,/inviteRequestSerial/);
 assert.match(css,/\.explicit-register-field\[hidden\]\{display:none!important\}/);
});
test('Explicit+ expiration dialog has distinct backdrop above admin panel',()=>{
 assert.match(html,/back\.classList\.add\('explicit-plus-period-backdrop'\)/);
 assert.match(css,/\.explicit-plus-period-backdrop\{position:fixed!important;inset:0!important;z-index:3200!important/);
 assert.match(html,/\.explicit-admin-backdrop\{position:fixed!important;inset:0!important;z-index:2600!important/);
});
