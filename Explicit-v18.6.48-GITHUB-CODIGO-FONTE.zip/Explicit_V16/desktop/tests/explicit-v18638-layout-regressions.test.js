'use strict';
const test=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path');
const web=path.resolve(__dirname,'../../server/Comunicador_Fase1/web');
const html=fs.readFileSync(path.join(web,'index.html'),'utf8');
const css=fs.readFileSync(path.join(web,'explicit-v18638.css'),'utf8');
const ui=fs.readFileSync(path.join(web,'explicit-v18637.js'),'utf8');
test('folha final vem por ultimo e padroniza fundos de membros/canais',()=>{
 assert.ok(html.indexOf('explicit-v18638.css')>html.indexOf('explicit-v18637.css'));
 assert.match(css,/#nexoSidebar,#membersPanel,#nexoPane/);
 assert.match(css,/#080a0e/);assert.match(css,/#6ca6df/);
});
test('home possui cards dimensionados sem cortar imagem ou dados',()=>{
 assert.match(css,/#homeSpaces>\.explicit-community-card/);
 assert.match(css,/min-height:76px!important;max-height:76px!important/);
 assert.match(css,/\.explicit-community-image\{/);
});
test('perfil remove barra horizontal e reposiciona apos carregar acoes',()=>{
 assert.match(css,/#memberPopover:not\(\[hidden\]\)/);
 assert.match(css,/overflow-x:hidden!important;overflow-y:auto!important;scrollbar-width:none!important/);
 assert.match(css,/\.explicit-profile-edit-self\{/);
 assert.match(ui,/const originalOpenMember=openMember/);
});
test('cabecalho alinha comunidade, seta e convite no mesmo elemento flexivel',()=>{
 assert.match(ui,/explicitCommunityHeaderRow/);
 assert.match(ui,/explicitCommunityChevron/);
 assert.match(css,/\.explicit-community-header-row\{display:flex!important/);
 assert.match(css,/\.explicit-community-chevron\.is-open/);
});
test('cargos e editor permanecem dentro da tela de configuracoes sem segundo modal',()=>{
 assert.match(ui,/\['Cargos',async\(\)=>\{/);
 assert.doesNotMatch(ui,/\['Cargos',\(\)=>\{frame\.remove\(\);showRoles\(\)\}\]/);
 assert.match(html,/window\.explicitRolesInlineHost\?\.isConnected/);
 assert.match(html,/inlineHost\.replaceChildren\(modal\)/);
 assert.match(html,/inlineHost\.replaceChildren\(box\)/);
 assert.match(css,/\.explicit-inline-role-editor/);
 assert.match(css,/\.obsidian-modal-backdrop\{z-index:8500!important/);
});
test('voz padrao Geral mantem identificador voz e metadados de audio',()=>{
 assert.match(html,/ch==='voz'\?'Geral':ch/);
 assert.match(html,/group\.dataset\.explicitChannel=ch/);
 const acl=fs.readFileSync(path.join(web,'channel-acl.js'),'utf8');
 assert.match(acl,/item\.dataset\.explicitChannel/);
 const server=fs.readFileSync(path.join(web,'../communities.go'),'utf8');
 assert.match(server,/Channels: \[\]string\{"geral", "voz"\}/);
 assert.match(server,/"voz":\s*\{Type: "voice", Category: "voz"\}/);
});
