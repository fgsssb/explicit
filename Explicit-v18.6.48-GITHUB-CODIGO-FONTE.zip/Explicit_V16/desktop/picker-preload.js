"use strict";
const {contextBridge,ipcRenderer}=require('electron');
let requestId=null;
contextBridge.exposeInMainWorld('explicitPicker',Object.freeze({
 onSources:callback=>ipcRenderer.on('explicit:capture-sources',(_event,payload)=>{if(payload&&Number.isSafeInteger(payload.requestId)&&Array.isArray(payload.sources)){requestId=payload.requestId;callback(payload.sources);}}),
 choose:id=>{if(requestId!==null&&typeof id==='string')ipcRenderer.send('explicit:capture-choice',{requestId,sourceId:id});},
 cancel:()=>{if(requestId!==null)ipcRenderer.send('explicit:capture-choice',{requestId,sourceId:null});}
}));
