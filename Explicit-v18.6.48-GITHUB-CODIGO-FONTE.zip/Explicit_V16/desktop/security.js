"use strict";
const fs=require('node:fs');
const path=require('node:path');
function validateServerURL(value,packaged){
 if(typeof value!=='string'||value.length>2048)throw Error('Endereço do servidor inválido');
 const u=new URL(value);
 if(u.username||u.password||u.search||u.hash||u.pathname!=='/'||!['http:','https:'].includes(u.protocol))throw Error('Endereço do servidor inválido');
 const loopback=['127.0.0.1','localhost','[::1]'].includes(u.hostname);
 if(u.protocol==='http:'&&!loopback && !(process.env.EXPLICIT_RADMIN_TEST==='1' && u.hostname==='26.61.221.56' && u.port==='8080'))throw Error('HTTPS obrigatório para servidores remotos; HTTP permitido apenas em localhost');
 return u.origin;
}
function getServerURL(exeDir,projectDir,packaged){
 // Electron-builder portable launches the real Electron process from a temporary
 // extraction directory. process.execPath therefore DOES NOT point at the .exe
 // that the user actually double-clicked. The portable launcher provides the
 // outer executable location through these documented environment variables.
 const portableFile=packaged?process.env.PORTABLE_EXECUTABLE_FILE:null;
 const portableDir=packaged?process.env.PORTABLE_EXECUTABLE_DIR:null;
 const externalDirs=[];
 if(portableFile&&path.isAbsolute(portableFile))externalDirs.push(path.dirname(portableFile));
 if(portableDir&&path.isAbsolute(portableDir))externalDirs.push(portableDir);
 if(externalDirs.length){
  for(const dir of new Set(externalDirs)){
   const file=path.join(dir,'explicit-endpoint.json');
   if(!fs.existsSync(file))continue;
   const config=JSON.parse(fs.readFileSync(file,'utf8'));
   return validateServerURL(config.serverUrl,packaged);
  }
  // Fail closed rather than silently loading the bundled placeholder domain.
  throw Error('Arquivo explicit-endpoint.json não encontrado ao lado do Explicit portátil. Execute 04_CONFIGURAR_CLIENTE.cmd.');
 }
 // Normal installation or local npm development mode.
 const files=[path.join(exeDir,'explicit-endpoint.json'),path.join(projectDir,'config.json')];
 for(const file of files){
  if(!fs.existsSync(file))continue;
  const config=JSON.parse(fs.readFileSync(file,'utf8'));
  return validateServerURL(config.serverUrl,packaged);
 }
 throw Error('Configuração de servidor não encontrada');
}
function isTrustedURL(value,origin){try{return new URL(value).origin===origin}catch{return false}}
function externalURL(value){try{const u=new URL(value);if(u.protocol!=='https:'||u.username||u.password||value.length>2048)return null;return u.href;}catch{return null}}
module.exports={validateServerURL,getServerURL,isTrustedURL,externalURL};
