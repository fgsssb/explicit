@echo off
setlocal EnableExtensions EnableDelayedExpansion
set "EXPLICIT_RADMIN_TEST=1"
set "EXPLICIT_EXE="
set /a EXPLICIT_EXE_COUNT=0
for %%F in ("%~dp0Explicit-*-x64.exe") do if exist "%%~fF" (
 set /a EXPLICIT_EXE_COUNT+=1
 set "EXPLICIT_EXE=%%~fF"
)
if not !EXPLICIT_EXE_COUNT!==1 (
 echo Coloque este .cmd ao lado de UM executavel portatil Explicit-*-x64.exe.
 pause
 exit /b 1
)
start "" "!EXPLICIT_EXE!"
