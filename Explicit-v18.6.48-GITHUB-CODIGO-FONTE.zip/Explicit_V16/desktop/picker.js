"use strict";
let sources=[];let kind='screen';let selected=null;
const grid=document.getElementById('grid');const share=document.getElementById('share');const hint=document.getElementById('hint');
function selectedSource(){return sources.find(s=>s.id===selected&&s.kind===kind)}
function syncSelection(){
 const source=selectedSource();
 if(!source)selected=null;
 share.disabled=!source;
 hint.textContent=source?'Selecionado: '+source.name:'Selecione uma fonte para continuar';
 for(const tile of grid.querySelectorAll('.tile')){
  const active=tile.dataset.sourceId===selected;
  tile.classList.toggle('selected',active);tile.setAttribute('aria-pressed',String(active));
 }
}
function render(){
 const focused=document.activeElement;
 const focusId=grid.contains(focused)?focused.dataset.sourceId:null;
 grid.replaceChildren();
 const items=sources.filter(s=>s.kind===kind);
 if(!items.length){const p=document.createElement('p');p.className='empty';p.textContent='Nenhuma fonte disponível nesta categoria.';grid.append(p)}
 for(const s of items){
  const btn=document.createElement('button');btn.type='button';btn.className='tile';btn.dataset.sourceId=s.id;btn.setAttribute('aria-label',s.name);btn.title=s.name;
  const img=document.createElement('img');img.className='thumb';img.alt='';if(s.thumbnail)img.src=s.thumbnail;else img.src='data:image/svg+xml,'+encodeURIComponent('<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 320 180"><g fill="none" stroke="#9da8b5" stroke-width="3"><rect x="132" y="64" width="56" height="40" rx="4"/><path d="M160 104v12m-14 0h28"/></g></svg>');
  const label=document.createElement('div');label.className='label';if(s.icon){const icon=document.createElement('img');icon.src=s.icon;icon.alt='';label.append(icon)}
  const name=document.createElement('span');name.textContent=s.name;label.append(name);btn.append(img,label);
  btn.onclick=()=>{selected=s.id;syncSelection()};
  btn.ondblclick=()=>{if(selectedSource()?.id===s.id)window.explicitPicker.choose(s.id)};
  grid.append(btn);
 }
 syncSelection();
 if(focusId){const tile=[...grid.querySelectorAll('.tile')].find(b=>b.dataset.sourceId===focusId);(tile||grid.querySelector('.tile')||document.querySelector('.tabs button.active')).focus()}
}
document.querySelectorAll('.tabs button').forEach(b=>b.onclick=()=>{
 if(kind!==b.dataset.kind)selected=null;
 kind=b.dataset.kind;
 document.querySelectorAll('.tabs button').forEach(t=>{t.classList.toggle('active',t===b);t.setAttribute('aria-pressed',String(t===b))});
 grid.setAttribute('aria-label',kind==='screen'?'Telas disponíveis':'Janelas disponíveis');render();
});
window.explicitPicker.onSources(data=>{sources=data;render()});
share.onclick=()=>{const source=selectedSource();if(source)window.explicitPicker.choose(source.id)};
document.getElementById('cancel').onclick=()=>window.explicitPicker.cancel();
document.addEventListener('keydown',e=>{if(e.key==='Escape')window.explicitPicker.cancel()});
