'use strict';
const {contextBridge,ipcRenderer}=require('electron');
contextBridge.exposeInMainWorld('explicitDesktopClipboard',Object.freeze({writeText:(value)=>ipcRenderer.invoke('explicit:clipboard-write',String(value).slice(0,4096))}));
contextBridge.exposeInMainWorld('explicitDesktopDevice',Object.freeze({get:()=>ipcRenderer.invoke('explicit:device-id')}));
contextBridge.exposeInMainWorld('explicitDesktopSession',Object.freeze({load:()=>ipcRenderer.invoke('explicit:session-load'),save:(token)=>ipcRenderer.invoke('explicit:session-save',token),clear:()=>ipcRenderer.invoke('explicit:session-clear')}));

// Frameless Windows titlebar, isolated renderer-to-main controls and themed navigation.
contextBridge.exposeInMainWorld('explicitDesktopWindow',Object.freeze({
 control:(action)=>ipcRenderer.invoke('explicit:window-control',action)
}));
window.addEventListener('DOMContentLoaded',()=>{
 if(process.platform!=='win32'||process.isMainFrame===false||document.getElementById('explicitDesktopTitlebar'))return;
 const style=document.createElement('style');
 style.textContent=`html{--explicit-titlebar-height:34px}body{padding-top:34px!important}#app{height:calc(100dvh - 34px)!important}main{height:calc(100dvh - 34px)!important}#nexoRail{top:34px!important}
 #explicitDesktopTitlebar{position:fixed;left:0;right:0;top:0;height:34px;z-index:5000;background:#090b0e;border-bottom:1px solid #1b2936;display:flex;align-items:center;justify-content:center;user-select:none;-webkit-app-region:drag;color:#d9e9fc;font:12px var(--ex-font,'Segoe UI',Arial,sans-serif)}
 #explicitDesktopTitlebar :is(button,.explicit-nav-buttons,.explicit-window-buttons){-webkit-app-region:no-drag}
 #explicitDesktopTitlebar .explicit-nav-buttons{position:absolute;left:9px;top:0;display:flex;align-items:center;gap:3px;height:100%}
 #explicitDesktopTitlebar .explicit-nav-buttons button{display:grid;place-items:center;width:30px;height:28px;border:0;background:transparent!important;color:#b9d2e8!important;border-radius:7px;padding:0!important;cursor:pointer}
 #explicitDesktopTitlebar .explicit-nav-buttons button:disabled{opacity:.33!important;cursor:default}
 #explicitDesktopTitlebar .explicit-nav-buttons button:hover:not(:disabled){background:#243b55!important;color:white!important}
 #explicitDesktopTitlebar .explicit-nav-product{position:absolute;left:84px;color:#a9c7e3;font-size:11px;pointer-events:none;display:flex;align-items:center;gap:8px}
 #explicitDesktopTitlebar .explicit-nav-label{font-size:11px;font-weight:750;letter-spacing:.10em;max-width:45vw;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;padding:0 4px}
 #explicitDesktopTitlebar .explicit-window-buttons{position:absolute;right:0;top:0;display:flex;height:33px}
 #explicitDesktopTitlebar .explicit-window-buttons button{display:grid;place-items:center;width:46px;height:33px;background:transparent!important;border:0!important;color:#bfdaee!important;padding:0!important;border-radius:0!important}
 #explicitDesktopTitlebar .explicit-window-buttons button:hover{background:#22394f!important;color:white!important}
 #explicitDesktopTitlebar .explicit-window-buttons button[data-action=close]:hover{background:#c42b3c!important;color:white!important}
 #explicitDesktopTitlebar button:focus-visible{outline:2px solid #83b5e8;outline-offset:-3px}
 @media(max-width:840px){#explicitDesktopTitlebar .explicit-nav-product{display:none}#explicitDesktopTitlebar .explicit-nav-label{max-width:35vw}}
 `;
 document.head.append(style);
 const svg=(path)=>`<svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${path}</svg>`;
 const bar=document.createElement('div');bar.id='explicitDesktopTitlebar';
 const nav=document.createElement('div');nav.className='explicit-nav-buttons';
 for(const [id,title,icon] of [['explicitNavBack','Voltar','<path d="m15 18-6-6 6-6"/>'],['explicitNavForward','Avançar','<path d="m9 18 6-6-6-6"/>']]){
  const button=document.createElement('button');button.type='button';button.id=id;button.title=title;button.setAttribute('aria-label',title);button.innerHTML=svg(icon);button.disabled=true;nav.append(button);
 }
 const label=document.createElement('span');label.className='explicit-nav-label';label.id='explicitNavLabel';label.textContent='INICIO';
 const product=document.createElement('span');product.className='explicit-nav-product';product.textContent='Explicit';
 const brandIcon=document.createElement('img');brandIcon.width=18;brandIcon.height=18;brandIcon.alt='';brandIcon.src='data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACQAAAAkCAYAAADhAJiYAAAGNElEQVR4nLWYfWzV1RnHP8+5L30DWpG+MlOUl9FSujImyIpigNXoJg4JS1qWwSIsgxGZW8QFFN+yJSZLpmDiWIJZUBOzdbzMppbZFV3U4BYJUAalAdq1HQWxb1J6X3/n2R/3tr1tL6X3wp7kJje/c873fM5znvOc5/cTRtuk2UXGmMcVFgLTABnT59ZMgS8FjlvrHKD//JnYxpjJ8tMlM+tXoD8Fyb7NEDeyq2B/r6m9r3DlyvVhoKmzpkjY/SZi1kQWoEloS8y4WKeOpyUgAjgH1MUGus5dMwASdj2PMWvAJggTmVitRa3D2N29mZaCWsD1uIR4MaI4ZfYiwfwdkUkJkAxLWktuzjRC4TDd3X2ISTbkdECx5UYwlYhJCgaAUIgFpUWsWVUBwWD0YRJQ4kpHZZUhcpqSN4WpUzNZt/Z7GK8H1XhxNBEdRZAyA5KV2MixExXk53LfogWUlMyFUJjhg5GopyTTJDgijobwzdJiUlK8rK98DBw7ukNCYBMEii+qjsO0vGzuW1QGQNXaRymcPQMNhQd7TBgkQaDR4lG4YIhHHnqQuwu/Bgp5edn8fMt6sM7IfrcHaHRyGymujkNW9p38cuuPAbDWAZRN63/A/cu+jfoD3DzJjgWOAzTYKY5HhhKhA47lxZ1PUlrydQ7XfEB3bx8gZGSk8dorO8gtyI1uXTwvxZvjhkDjmwZDuEV46YVf8OTmH/G3hk/Y9Zs9hMNOFFZZ8I1i9u55mclTJqHB0CiI0WAjFxsHKJ5nFA2H0FCIsrJiDr77Bs9t30L1oTp+uPFpGk8309LaMTREVXnsuyt5e99vyZ+eg/p8qI4+fYNzacx/cN/EH6i1iDHML5mra1c/LMuXLaan9xqr122lpvYo4VAYrMOrb+xn8b1lGCOoVVSVVY+sYNY9hbzw6938tbaBQP91cLnA7UJM/M0RmTL3FCLzBwkFsKrgOCBCxqQM7rgji/lFM9Xj8ciFi+38u7EJ/H7ISEfcbkARq+zcvplnt2/G6/UOLzrq5M/+dZK/HD7Cx8eO0/KfDq529WBtrNcEVBtigCyqSvGcmTz4wGIWLyxl3tzZZGZOJjU1JaKvit8f4PIXX1J75CP2v3uIS+2diNcbuTKsw8rl5WzZWMXCsnnk5UzDmxJpcxyHgQEfbR2dnDzdxIlTZ6mp+5BzzS1gJB7QcOxkZU5mel4OxUWzqFi+lBXLljCjcPoY9zafb2Xztl00NHyKpHpRBQIBsJY783MpyM/hroJcXG43HZc66e3tp39gAJ/Pj8/vxzo2Wg/F9dAwkFobuQKsAwrZeTms+f5DPPPUT5hROH3oAhUR/nvpCt9ZtYGzTRfAGHDCzCspYvWjK1lybxlnms5TfaiOzz4/FQkDY0BMTJkyWNiNAzQmtB0HAkFmzLmbva+9TMWKpREoBTHCvv3VbNz0NBlZmezasZWtm9ZxsbWd5156lbr6j/H7/YjbdQP1kUATykPiciHpabRebKNyw1PUffAPRIbzygPl3yLnrgJe/93zbN+2kerDR7i/oopDB+vwh4LRwJ+YJZQYxeulu6uHJ7bs4GRj05DbJ2dk8My2J9hQtZo/H3yfTT/bSW9vH5KWGgUf7/oY2TahLRuFhfr8LFtRTm31H0hPTyMcdhCBto5OllZUDp28eBOOpzvhLRtpiqSl8NHRT/jjOwcAcBmDy+Viz963uNTSjng9ictGLfkCzRh2732b7p5exAhfXO3iwHv14ImF+b/WQyNNPB7OnWmmpu5DAE42nqW9tR2GTlNytfWtlbCqvPOn9wA4ffY8NhgacfqSMZP4y2GMeTwc++cJWlrbaevojMm6MF7NM46JQeSr5GhAjOGrrh7qj37K5ctXR+1OEosUe81g9fgtfeAwwsGaelrbOkBuIQIEFDkhTJ65RIy7HiQ9KSFVUlK8KBAMBONs20Q8JYAGlFC54dqFY1jeTDq+RfAHggQCoVEwTBAmoqHoPvoufG4AVePbBU5doi91w3oSPV0Jv6kCgqp9H3zPwqBb+tp6FH8lqrtR7UcGv9vcjp8Z+0wkEm9q+1Wd3eCroq+tZxBxpGXMKcXNw2KZH/1Ek2ROYDgKRtb3gup1FRox1NLbfCq28X8Fy30zGYw+ngAAAABJRU5ErkJggg==';product.prepend(brandIcon);
 ipcRenderer.invoke('explicit:settings-info').then(info=>{if(info&&typeof info.version==='string')product.replaceChildren(brandIcon,document.createTextNode('Explicit '+info.version))}).catch(()=>{});
 const controls=document.createElement('div');controls.className='explicit-window-buttons';
 for(const [action,title,icon] of [['minimize','Minimizar','<path d="M5 12h14"/>'],['maximize','Maximizar ou restaurar','<rect x="5" y="5" width="14" height="14" rx="1"/>'],['close','Fechar','<path d="M5 5l14 14M19 5 5 19"/>']]){
  const b=document.createElement('button');b.type='button';b.dataset.action=action;b.title=title;b.setAttribute('aria-label',title);b.innerHTML=svg(icon);
  b.addEventListener('click',()=>ipcRenderer.invoke('explicit:window-control',action).catch(e=>console.warn('Controle da janela:',e.message)));
  controls.append(b);
 }
 const maximizeButton=controls.querySelector('[data-action=maximize]');
 const applyWindowState=state=>{
  if(!state)return;
  const restored=state.maximized||state.fullscreen;
  maximizeButton.title=restored?'Restaurar':'Maximizar';
  maximizeButton.setAttribute('aria-label',maximizeButton.title);
  maximizeButton.innerHTML=svg(restored?'<path d="M9 5h10v10M5 9h10v10H5z"/>':'<rect x="5" y="5" width="14" height="14" rx="1"/>');
 };
 const stateListener=(_event,state)=>applyWindowState(state);
 ipcRenderer.on('explicit:window-state',stateListener);
 window.addEventListener('pagehide',()=>ipcRenderer.removeListener('explicit:window-state',stateListener),{once:true});
 ipcRenderer.invoke('explicit:window-state').then(applyWindowState).catch(()=>{});
 bar.append(nav,label,product,controls);document.body.prepend(bar);
});

// Restricted desktop settings bridge: no generic IPC or filesystem access.
contextBridge.exposeInMainWorld('explicitDesktopSettings',Object.freeze({
 getStartup:()=>ipcRenderer.invoke('explicit:settings-startup-get'),
 setStartup:(enabled)=>ipcRenderer.invoke('explicit:settings-startup-set',enabled===true),
 getInfo:()=>ipcRenderer.invoke('explicit:settings-info'),
 openDataFolder:()=>ipcRenderer.invoke('explicit:settings-data-folder'),
 openLogsFolder:()=>ipcRenderer.invoke('explicit:settings-logs-folder'),
 testNotification:()=>ipcRenderer.invoke('explicit:settings-notification-test'),
 showNotification:(payload)=>ipcRenderer.invoke('explicit:notification-show',payload),
 setNotificationCount:(count)=>ipcRenderer.invoke('explicit:notification-count',count),
 getHardwareAcceleration:()=>ipcRenderer.invoke('explicit:settings-hardware-get'),
 setHardwareAcceleration:(enabled)=>ipcRenderer.invoke('explicit:settings-hardware-set',enabled===true)
}));
