package main

import (
	"bytes"
	"encoding/json"
	"net/http"
	"net/http/httptest"
	"os"
	"path/filepath"
	"strings"
	"testing"
)

func TestV1862StaffResetRequiresTemporaryPasswordAndRevokesSession(t *testing.T) {
	s := newServer(filepath.Join(t.TempDir(), "db.json"))
	salt := token()
	s.db.Users["root"] = User{Name: "root", SystemRole: "superadmin"}
	s.db.Users["ana"] = User{Name: "ana", Salt: salt, Hash: secureHash(salt, "SenhaOriginal123")}
	s.db.Users["bob"] = User{Name: "bob"}
	s.sessions["root-token"] = "root"
	s.sessions["ana-token"] = "ana"
	s.sessions["bob-token"] = "bob"
	call := func(path, auth string, data any) *httptest.ResponseRecorder {
		body, _ := json.Marshal(data)
		request := httptest.NewRequest(http.MethodPost, path, bytes.NewReader(body))
		if auth != "" {
			request.Header.Set("Authorization", "Bearer "+auth)
		}
		response := httptest.NewRecorder()
		s.routes().ServeHTTP(response, request)
		return response
	}
	reset := map[string]any{"action": "reset_password", "target": "ana", "new_password": "TempV1862secure!", "force_change": true}
	if w := call("/api/system-admin", "bob-token", reset); w.Code != 403 {
		t.Fatalf("regular user reset accepted: %d", w.Code)
	}
	if w := call("/api/system-admin", "root-token", reset); w.Code != 200 {
		t.Fatalf("staff reset failed %d: %s", w.Code, w.Body.String())
	}
	if _, ok := s.sessions["ana-token"]; ok {
		t.Fatal("existing session survived password reset")
	}
	if !s.db.Users["ana"].RequirePasswordChange {
		t.Fatal("password change must be forced")
	}
	if w := call("/api/login", "", map[string]string{"name": "ana", "password": "SenhaOriginal123"}); w.Code != 401 {
		t.Fatalf("old password works: %d", w.Code)
	}
	w := call("/api/login", "", map[string]string{"name": "ana", "password": "TempV1862secure!"})
	if w.Code != 200 || !strings.Contains(w.Body.String(), "password_reset_required") || strings.Contains(w.Body.String(), "\"token\"") {
		t.Fatalf("temp password must not issue session: %d %s", w.Code, w.Body.String())
	}
	if w := call("/api/password-reset/complete", "", map[string]string{"name": "ana", "temporary_password": "wrong", "new_password": "OutraSenha123!", "confirm_password": "OutraSenha123!"}); w.Code != 401 {
		t.Fatalf("wrong temp password accepted: %d", w.Code)
	}
	if w := call("/api/password-reset/complete", "", map[string]string{"name": "ana", "temporary_password": "TempV1862secure!", "new_password": "OutraSenha123!", "confirm_password": "OutraSenha123!"}); w.Code != 200 {
		t.Fatalf("password reset complete: %d %s", w.Code, w.Body.String())
	}
	if s.db.Users["ana"].RequirePasswordChange {
		t.Fatal("forced reset flag not cleared")
	}
	if w := call("/api/login", "", map[string]string{"name": "ana", "password": "OutraSenha123!"}); w.Code != 200 || !strings.Contains(w.Body.String(), "\"token\"") {
		t.Fatalf("new password failed login: %d", w.Code)
	}
}
func TestV1862CaptchaIsImageNotPlaintext(t *testing.T) {
	s := newServer(filepath.Join(t.TempDir(), "db.json"))
	prior := os.Getenv("EXPLICIT_TEST_SKIP_ANTIBOT")
	os.Unsetenv("EXPLICIT_TEST_SKIP_ANTIBOT")
	defer os.Setenv("EXPLICIT_TEST_SKIP_ANTIBOT", prior)
	first := httptest.NewRecorder()
	s.routes().ServeHTTP(first, httptest.NewRequest(http.MethodGet, "/api/captcha", nil))
	if first.Code != 200 {
		t.Fatalf("captcha issue failed: %d", first.Code)
	}
	var issued struct {
		ID    string `json:"id"`
		Image string `json:"image"`
	}
	if err := json.Unmarshal(first.Body.Bytes(), &issued); err != nil || issued.ID == "" {
		t.Fatal("invalid captcha challenge")
	}
	imageResult := httptest.NewRecorder()
	s.routes().ServeHTTP(imageResult, httptest.NewRequest(http.MethodGet, issued.Image, nil))
	if imageResult.Code != 200 || !strings.HasPrefix(imageResult.Header().Get("Content-Type"), "image/png") || !bytes.HasPrefix(imageResult.Body.Bytes(), []byte("\x89PNG")) {
		t.Fatal("captcha must use rasterized PNG")
	}
	if bytes.Contains(imageResult.Body.Bytes(), []byte(s.captchas[issued.ID].glyphs)) {
		t.Fatal("plaintext answer leaked in image bytes")
	}
	if s.verifyCaptcha(issued.ID, "AAAAA") {
		t.Fatal("incorrect captcha accepted")
	}
	if s.verifyCaptcha(issued.ID, s.captchas[issued.ID].glyphs) {
		t.Fatal("captcha reused")
	}
}
func TestV1862HomeModeAndUnauthorizedVideo(t *testing.T) {
	s := newServer(filepath.Join(t.TempDir(), "db.json"))
	s.db.Users["admin"] = User{Name: "admin", SystemRole: "superadmin"}
	s.sessions["token"] = "admin"
	body := bytes.NewBufferString(`{"action":"set_home_mode","role":"changelog","reason":"Incluído: avatares. Corrigido: permissões."}`)
	request := httptest.NewRequest("POST", "/api/system-admin", body)
	request.Header.Set("Authorization", "Bearer token")
	response := httptest.NewRecorder()
	s.routes().ServeHTTP(response, request)
	if response.Code != 200 {
		t.Fatalf("home mode save: %d %s", response.Code, response.Body.String())
	}
	get := httptest.NewRecorder()
	s.routes().ServeHTTP(get, httptest.NewRequest("GET", "/api/home-mode", nil))
	if get.Code != 200 || !strings.Contains(get.Body.String(), "changelog") {
		t.Fatal("changelog mode was not persisted")
	}
	unauth := httptest.NewRecorder()
	s.routes().ServeHTTP(unauth, httptest.NewRequest("GET", "/api/video?id=00000000000000000000000000000000.mp4", nil))
	if unauth.Code != 401 {
		t.Fatalf("video may not be public: %d", unauth.Code)
	}
}

func TestV1862RegistrationLimitsByIPAndDevice(t *testing.T) {
	s := newServer(filepath.Join(t.TempDir(), "db.json"))
	s.db.RequireInvite = false
	register := func(name, ip, device string) int {
		b, _ := json.Marshal(map[string]string{"name": name, "display_name": name, "password": "StrongPassword1862!", "device_id": device})
		r := httptest.NewRequest(http.MethodPost, "/api/register", bytes.NewReader(b))
		r.RemoteAddr = ip + ":4499"
		w := httptest.NewRecorder()
		s.routes().ServeHTTP(w, r)
		return w.Code
	}
	device := "A1B2C3D4E5F6G7H8I9J0KLMNOPQRSTUVWXYZ"
	if got := register("usuario1", "192.0.2.8", device); got != 201 {
		t.Fatalf("first registration: %d", got)
	}
	if got := register("usuario2", "192.0.2.8", device); got != 201 {
		t.Fatalf("second registration: %d", got)
	}
	if got := register("usuario3", "192.0.2.8", "Z9Y8X7W6V5U4T3S2R1Q0PONMLKJIHGFE"); got != 429 {
		t.Fatalf("third same-IP account: %d", got)
	}
	if got := register("usuario4", "192.0.2.9", device); got != 429 {
		t.Fatalf("third same-device account: %d", got)
	}
}
