package main

import (
	"net/http"
	"net/http/httptest"
	"strings"
	"testing"
)

func TestV18637LeaveCommunityAndChannelNotificationSettings(t *testing.T) {
	s := newServer(t.TempDir() + "/store.json")
	s.mu.Lock()
	s.db.Users["founder"] = User{Name: "founder", DisplayName: "Founder"}
	s.db.Users["member"] = User{Name: "member", DisplayName: "Member"}
	s.sessions["founder-token"] = "founder"
	s.sessions["member-token"] = "member"
	s.db.Communities = []Community{{ID: "lobby", Name: "Lobby", Owner: "founder", Members: []string{"founder", "member"}, Channels: []string{"geral", "voz"}, MemberRoles: map[string][]string{"member": {"vip"}}, ChannelMeta: map[string]ChannelMeta{"geral": {Type: "text", MemberPermissions: map[string]map[string]bool{"member": {"VIEW_CHANNEL": true}}}, "voz": {Type: "voice"}}}}
	s.mu.Unlock()
	call := func(token, path, body string) *httptest.ResponseRecorder {
		r := httptest.NewRequest(http.MethodPost, path, strings.NewReader(body))
		r.Header.Set("Authorization", "Bearer "+token+"-token")
		w := httptest.NewRecorder()
		s.routes().ServeHTTP(w, r)
		return w
	}
	if w := call("member", "/api/community-hub", `{"action":"channel_preferences","community":"lobby","channel":"geral","mode":"none"}`); w.Code != http.StatusOK {
		t.Fatalf("channel preferences: %d %s", w.Code, w.Body.String())
	}
	s.mu.Lock()
	prefs := s.db.CommunityPrefs[communityPrefKey("member", "lobby")]
	s.mu.Unlock()
	if prefs.ChannelModes["geral"] != "none" {
		t.Fatal("channel notification mode not persisted")
	}
	if w := call("member", "/api/community-hub", `{"action":"channel_preferences","community":"lobby","channel":"fake","mode":"none"}`); w.Code != http.StatusForbidden {
		t.Fatalf("invalid channel allowed: %d", w.Code)
	}
	if w := call("founder", "/api/communities", `{"leave":"lobby"}`); w.Code != http.StatusForbidden {
		t.Fatalf("owner left community: %d", w.Code)
	}
	if w := call("member", "/api/communities", `{"leave":"lobby"}`); w.Code != http.StatusOK {
		t.Fatalf("member leave: %d %s", w.Code, w.Body.String())
	}
	s.mu.Lock()
	c := s.db.Communities[0]
	s.mu.Unlock()
	if contains(c.Members, "member") || len(c.MemberRoles["member"]) > 0 || c.ChannelMeta["geral"].MemberPermissions["member"] != nil {
		t.Fatalf("residual access after leave: %+v", c)
	}
	if w := call("member", "/api/community-hub", `{"action":"channel_preferences","community":"lobby","channel":"geral","mode":"all"}`); w.Code != http.StatusForbidden {
		t.Fatalf("ex-member can update prefs: %d", w.Code)
	}
}
