package main

import (
	"net/http"
	"net/url"
	"path"
	"strings"
)

// Strictly serve only front-end assets. No directory listing or test fixtures,
// even if a future build accidentally copies private files into web/.
func publicWebPath(raw string) bool {
	if raw == "/" || raw == "/index.html" {
		return true
	}
	if !strings.HasPrefix(raw, "/") || strings.Contains(raw, "\\") || strings.Contains(raw, "\x00") {
		return false
	}
	clean := path.Clean(raw)
	if clean != raw {
		return false
	}
	pieces := strings.Split(strings.TrimPrefix(clean, "/"), "/")
	if len(pieces) > 2 || len(pieces) == 0 {
		return false
	}
	for _, p := range pieces {
		if p == "" || strings.HasPrefix(p, ".") {
			return false
		}
	}
	if len(pieces) == 2 && pieces[0] != "vendor" {
		return false
	}
	ext := strings.ToLower(path.Ext(clean))
	switch ext {
	case ".js", ".css", ".png", ".jpg", ".jpeg", ".gif", ".webp", ".svg", ".ico", ".woff", ".woff2":
		return true
	default:
		return false
	}
}
func secureWebAssets(dir string) http.Handler {
	files := http.FileServer(http.Dir(dir))
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		if r.Method != http.MethodGet && r.Method != http.MethodHead {
			http.Error(w, "method not allowed", http.StatusMethodNotAllowed)
			return
		}
		if !publicWebPath(r.URL.Path) {
			http.NotFound(w, r)
			return
		}
		files.ServeHTTP(w, r)
	})
}

// A browser may omit Origin on same-origin GET/HEAD. If it is present,
// reject foreign / opaque origins, regardless of credentials.
// Reverse-proxy deployment retains the original public Host header.
func sameOriginRequest(r *http.Request) bool {
	origin := r.Header.Get("Origin")
	if origin == "" {
		return true
	}
	u, err := url.Parse(origin)
	if err != nil || (u.Scheme != "https" && u.Scheme != "http") || u.User != nil || u.Host == "" || u.Path != "" || u.RawQuery != "" || u.Fragment != "" {
		return false
	}
	return strings.EqualFold(u.Host, r.Host)
}
