package main

import (
	"bytes"
	"encoding/json"
	"net/http/httptest"
	"path/filepath"
	"testing"
)

func TestExplicitStatusAndAFKAuthorization(t *testing.T) {
	s := newServer(filepath.Join(t.TempDir(), "store.json"))
	s.db.Users["ana"] = User{Name: "ana", DisplayName: "Ana"}
	s.db.Users["bia"] = User{Name: "bia", DisplayName: "Bia"}
	s.db.Communities = []Community{{ID: "c", Owner: "ana", Members: []string{"ana", "bia"}, Channels: []string{"geral", "ausentes"}, ChannelMeta: map[string]ChannelMeta{"ausentes": {Type: "voice"}}}}

	s.db.Users["ana"] = User{Name: "ana"}
	s.db.Users["bia"] = User{Name: "bia"}
	s.sessions["a"] = "ana"
	s.sessions["b"] = "bia"
	call := func(path, token string, body any) int {
		b, _ := json.Marshal(body)
		r := httptest.NewRequest("POST", path, bytes.NewReader(b))
		r.Header.Set("Authorization", "Bearer "+token)
		w := httptest.NewRecorder()
		s.routes().ServeHTTP(w, r)
		return w.Code
	}
	if code := call("/api/status", "a", map[string]any{"status": "busy"}); code != 200 {
		t.Fatalf("status %d", code)
	}
	if s.db.Users["ana"].PreferredStatus != "busy" {
		t.Fatal("status not saved")
	}
	if code := call("/api/status", "a", map[string]any{"status": "unknown"}); code != 400 {
		t.Fatalf("invalid status %d", code)
	}
	config := map[string]any{"community": "c", "channel": "ausentes", "timeout_seconds": 60, "enabled": true}
	if code := call("/api/afk", "b", config); code != 403 {
		t.Fatalf("unauthorized afk %d", code)
	}
	if code := call("/api/afk", "a", config); code != 200 {
		t.Fatalf("authorized afk %d", code)
	}
	if !s.db.Communities[0].AFKEnabled || s.db.Communities[0].AFKTimeout != 60 {
		t.Fatal("afk not persisted")
	}
	config["channel"] = "geral"
	if code := call("/api/afk", "a", config); code != 400 {
		t.Fatalf("text channel %d", code)
	}
}
