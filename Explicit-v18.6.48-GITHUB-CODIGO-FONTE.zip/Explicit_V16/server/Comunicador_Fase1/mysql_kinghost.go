package main

import (
	"bytes"
	"encoding/hex"
	"encoding/json"
	"errors"
	"fmt"
	"os"
	"os/exec"
	"strings"
)

// MySQL adapter for the legacy state model. This is an intermediate compatibility
// layer, NOT the final normalized relational schema.
func mysqlRun(sql string) ([]byte, error) {
	config := strings.TrimSpace(os.Getenv("EXPLICIT_MYSQL_CONFIG"))
	if config == "" {
		return nil, errors.New("EXPLICIT_MYSQL_CONFIG not configured")
	}
	cmd := exec.Command("mysql", "--defaults-extra-file="+config, "--batch", "--raw", "--skip-column-names", "--database=explicit")
	cmd.Stdin = strings.NewReader(sql)
	out, err := cmd.CombinedOutput()
	if err != nil {
		return nil, fmt.Errorf("mysql command failed: %w: %s", err, strings.TrimSpace(string(out)))
	}
	return bytes.TrimSpace(out), nil
}
func mysqlInit() error {
	_, err := mysqlRun(`CREATE TABLE IF NOT EXISTS explicit_state (id TINYINT UNSIGNED NOT NULL PRIMARY KEY, payload JSON NOT NULL, updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;`)
	return err
}
func mysqlLoad() ([]byte, error) {
	if err := mysqlInit(); err != nil {
		return nil, err
	}
	out, err := mysqlRun("SELECT HEX(CAST(payload AS CHAR CHARACTER SET utf8mb4)) FROM explicit_state WHERE id=1;")
	if err != nil {
		return nil, err
	}
	if len(out) == 0 {
		return nil, nil
	}
	decoded, err := hex.DecodeString(string(out))
	if err != nil {
		return nil, err
	}
	if !json.Valid(decoded) {
		return nil, errors.New("MySQL returned invalid JSON state")
	}
	return decoded, nil
}
func mysqlSave(b []byte) error {
	if !json.Valid(b) {
		return errors.New("invalid JSON state")
	}
	sql := "INSERT INTO explicit_state (id,payload) VALUES (1,CONVERT(UNHEX('" + hex.EncodeToString(b) + "') USING utf8mb4)) ON DUPLICATE KEY UPDATE payload=VALUES(payload), updated_at=CURRENT_TIMESTAMP;"
	_, err := mysqlRun(sql)
	return err
}
