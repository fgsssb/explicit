package main

import (
	"bytes"
	"encoding/json"
	"net/http/httptest"
	"path/filepath"
	"strings"
	"testing"
)

func TestChannelACLPrecedencePrivateAndStickers(t *testing.T) {
	s := newServer(filepath.Join(t.TempDir(), "store.json"))
	s.db.Users["owner"] = User{Name: "owner"}
	s.db.Users["ana"] = User{Name: "ana", Beta: true}
	s.db.Users["bia"] = User{Name: "bia"}
	s.db.Users["carol"] = User{Name: "carol"}
	c := Community{ID: "c", Owner: "owner", Members: []string{"owner", "ana", "bia", "carol"}, Channels: []string{"geral", "privado"}, Roles: []Role{{ID: "r1", Name: "Amigos", Priority: 10}, {ID: "r2", Name: "Outros", Priority: 2}}, MemberRoles: map[string][]string{"ana": {"r1", "r2"}}, ChannelMeta: map[string]ChannelMeta{"geral": {Type: "text"}, "privado": {Type: "text", RolePermissions: map[string]map[string]bool{"everyone": {"VIEW_CHANNEL": false}, "r1": {"VIEW_CHANNEL": true}, "r2": {"VIEW_CHANNEL": false}}, MemberPermissions: map[string]map[string]bool{"bia": {"VIEW_CHANNEL": true}, "ana": {"USE_STICKERS": false}}}}}
	s.db.Communities = []Community{c}
	if !s.channelPermission(c, "ana", "privado", "VIEW_CHANNEL") {
		t.Fatal("allow from one role should beat conflicting deny from another role")
	}
	if !s.channelPermission(c, "bia", "privado", "VIEW_CHANNEL") {
		t.Fatal("explicit member allow must win")
	}
	if s.channelPermission(c, "carol", "privado", "VIEW_CHANNEL") {
		t.Fatal("private channel exposed to everyone")
	}
	if s.channelPermission(c, "ana", "privado", "USE_STICKERS") {
		t.Fatal("per-member sticker deny missing")
	}
	if !s.maySendStickersLocked("ana") {
		t.Fatal("beta should own stickers independently of channel rule")
	}
	if s.maySendStickersLocked("bia") {
		t.Fatal("channel override must not grant account sticker entitlement")
	}
	if !s.channelPermission(c, "owner", "privado", "USE_STICKERS") {
		t.Fatal("owner must bypass")
	}
	if s.channelPermission(c, "nonmember", "geral", "VIEW_CHANNEL") {
		t.Fatal("outsider")
	}
	visible := s.visibleCommunity(c, "carol")
	if contains(visible.Channels, "privado") || visible.ChannelMeta["privado"].Type != "" {
		t.Fatal("private channel leaked in community list")
	}
}
func TestChannelACLCreateCategorySyncAndHTTPPrivacy(t *testing.T) {
	s := newServer(filepath.Join(t.TempDir(), "store.json"))
	s.db.Users["owner"] = User{Name: "owner"}
	s.db.Users["ana"] = User{Name: "ana"}
	s.db.Users["bia"] = User{Name: "bia"}
	s.sessions["owner-token"] = "owner"
	s.sessions["ana-token"] = "ana"
	s.sessions["bia-token"] = "bia"
	s.db.Communities = []Community{{ID: "c", Name: "Teste", Owner: "owner", Members: []string{"owner", "ana", "bia"}, Channels: []string{"geral"}, ChannelMeta: map[string]ChannelMeta{"geral": {Type: "text"}}}}
	call := func(path, session, method string, data any) *httptest.ResponseRecorder {
		t.Helper()
		b, _ := json.Marshal(data)
		r := httptest.NewRequest(method, path, bytes.NewReader(b))
		r.Header.Set("Authorization", "Bearer "+session)
		w := httptest.NewRecorder()
		s.routes().ServeHTTP(w, r)
		return w
	}
	if w := call("/api/channel-permissions", "ana-token", "POST", map[string]any{"community": "c", "action": "category_create", "name": "Segredo"}); w.Code != 403 {
		t.Fatalf("ordinary member created category: %d", w.Code)
	}
	if w := call("/api/channel-permissions", "owner-token", "POST", map[string]any{"community": "c", "action": "category_create", "name": "Segredo"}); w.Code != 200 {
		t.Fatal(w.Body.String())
	}
	catID := s.db.Communities[0].Categories[0].ID
	if w := call("/api/channel-permissions", "owner-token", "POST", map[string]any{"community": "c", "action": "category_update", "category": catID, "role_permissions": map[string]map[string]bool{"everyone": {"VIEW_CHANNEL": false}}, "member_permissions": map[string]map[string]bool{"ana": {"VIEW_CHANNEL": true}}}); w.Code != 200 {
		t.Fatal(w.Body.String())
	}
	if w := call("/api/communities", "owner-token", "POST", map[string]any{"community": "c", "channel": "segredo", "type": "text", "category": catID, "sync": true}); w.Code != 200 {
		t.Fatal(w.Body.String())
	}
	if !s.db.Communities[0].ChannelMeta["segredo"].Synced {
		t.Fatal("channel should inherit category")
	}
	if w := call("/api/communities", "bia-token", "GET", nil); w.Code != 200 || strings.Contains(w.Body.String(), "segredo") {
		t.Fatalf("private channel enumeration leak: %d %s", w.Code, w.Body.String())
	}
	if w := call("/api/community-admin?community=c", "bia-token", "GET", nil); w.Code != 200 || strings.Contains(w.Body.String(), "segredo") {
		t.Fatalf("admin info leaked private metadata: %d %s", w.Code, w.Body.String())
	}
	if w := call("/api/channel-messages?community=c&channel=segredo", "bia-token", "GET", nil); w.Code != 403 {
		t.Fatalf("private messages readable %d", w.Code)
	}
	if w := call("/api/channel-messages?community=c&channel=segredo", "ana-token", "GET", nil); w.Code != 200 {
		t.Fatalf("authorized member denied %d", w.Code)
	}
	if w := call("/api/channel-permissions", "owner-token", "POST", map[string]any{"community": "c", "action": "category_update", "category": catID, "role_permissions": map[string]map[string]bool{"everyone": {"VIEW_CHANNEL": true}}}); w.Code != 200 {
		t.Fatal(w.Body.String())
	}
	if !s.channelPermission(s.db.Communities[0], "bia", "segredo", "VIEW_CHANNEL") {
		t.Fatal("synced channel did not receive category update")
	}
	if w := call("/api/channel-permissions", "owner-token", "POST", map[string]any{"community": "c", "action": "channel_update", "channel": "segredo", "role_permissions": map[string]map[string]bool{"everyone": {"VIEW_CHANNEL": false}}}); w.Code != 200 {
		t.Fatal(w.Body.String())
	}
	if s.db.Communities[0].ChannelMeta["segredo"].Synced {
		t.Fatal("editing individual channel must break sync")
	}
	if w := call("/api/channel-permissions", "owner-token", "POST", map[string]any{"community": "c", "action": "category_update", "category": catID, "role_permissions": map[string]map[string]bool{"everyone": {"VIEW_CHANNEL": true}}}); w.Code != 200 {
		t.Fatal(w.Body.String())
	}
	if s.channelPermission(s.db.Communities[0], "bia", "segredo", "VIEW_CHANNEL") {
		t.Fatal("unsynced channel changed due to category")
	}
	if w := call("/api/channel-permissions", "owner-token", "POST", map[string]any{"community": "c", "action": "channel_sync", "channel": "segredo"}); w.Code != 200 {
		t.Fatal(w.Body.String())
	}
	if !s.channelPermission(s.db.Communities[0], "bia", "segredo", "VIEW_CHANNEL") {
		t.Fatal("resync failed")
	}
	if w := call("/api/channel-permissions", "owner-token", "POST", map[string]any{"community": "c", "action": "category_sync_all", "category": catID}); w.Code != 200 {
		t.Fatal("category sync all: ", w.Body.String())
	}
	if !s.db.Communities[0].ChannelMeta["segredo"].Synced {
		t.Fatal("category-wide sync did not mark channel synced")
	}
	if w := call("/api/channel-permissions", "owner-token", "POST", map[string]any{"community": "c", "action": "category_delete", "category": catID}); w.Code != 200 {
		t.Fatal(w.Body.String())
	}
	if !contains(s.db.Communities[0].Channels, "segredo") || s.db.Communities[0].ChannelMeta["segredo"].Synced {
		t.Fatal("removing category should preserve channels and unsync")
	}
	if !contains(newServer(s.file).db.Communities[0].Channels, "segredo") {
		t.Fatal("category changes not persisted")
	}
}

func TestCreatePrivateVoiceWithRoleAndMember(t *testing.T) {
	s := newServer(filepath.Join(t.TempDir(), "store.json"))
	for _, u := range []string{"owner", "ana", "bia", "carol"} {
		s.db.Users[u] = User{Name: u}
		s.sessions[u+"-token"] = u
	}
	s.db.Communities = []Community{{ID: "c", Owner: "owner", Members: []string{"owner", "ana", "bia", "carol"}, Channels: []string{"geral"}, Roles: []Role{{ID: "friends", Name: "Amigos", Priority: 1}}, MemberRoles: map[string][]string{"ana": {"friends"}}, ChannelMeta: map[string]ChannelMeta{"geral": {Type: "text"}}}}
	b, _ := json.Marshal(map[string]any{"community": "c", "channel": "sala-privada", "type": "voice", "private": true, "role_permissions": map[string]map[string]bool{"friends": {"VIEW_CHANNEL": true, "CONNECT_VOICE": true}}, "member_permissions": map[string]map[string]bool{"bia": {"VIEW_CHANNEL": true, "CONNECT_VOICE": true}}})
	r := httptest.NewRequest("POST", "/api/communities", bytes.NewReader(b))
	r.Header.Set("Authorization", "Bearer owner-token")
	w := httptest.NewRecorder()
	s.routes().ServeHTTP(w, r)
	if w.Code != 200 {
		t.Fatalf("create private channel: %s", w.Body.String())
	}
	c := s.db.Communities[0]
	if !s.channelPermission(c, "ana", "sala-privada", "CONNECT_VOICE") || !s.channelPermission(c, "bia", "sala-privada", "CONNECT_VOICE") {
		t.Fatal("authorized role/member cannot connect")
	}
	if s.channelPermission(c, "carol", "sala-privada", "VIEW_CHANNEL") {
		t.Fatal("unauthorized account sees private voice")
	}
	for _, tc := range []struct {
		user string
		code int
	}{{"ana", 200}, {"bia", 200}, {"carol", 403}} {
		b, _ := json.Marshal(map[string]string{"community": "c", "channel": "sala-privada", "action": "join"})
		r := httptest.NewRequest("POST", "/api/voice", bytes.NewReader(b))
		r.Header.Set("Authorization", "Bearer "+tc.user+"-token")
		w := httptest.NewRecorder()
		s.routes().ServeHTTP(w, r)
		if w.Code != tc.code {
			t.Fatalf("%s voice join: wanted %d got %d %s", tc.user, tc.code, w.Code, w.Body.String())
		}
	}
	for _, u := range []string{"ana", "bia"} {
		r := httptest.NewRequest("POST", "/api/voice", strings.NewReader(`{"community":"c","channel":"sala-privada","action":"leave"}`))
		r.Header.Set("Authorization", "Bearer "+u+"-token")
		w := httptest.NewRecorder()
		s.routes().ServeHTTP(w, r)
	}
}
