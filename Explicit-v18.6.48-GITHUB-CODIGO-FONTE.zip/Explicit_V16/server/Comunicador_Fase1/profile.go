package main

import (
	"log/slog"
	"net/http"
	"strings"
)

func (s *Server) profileAPI(w http.ResponseWriter, r *http.Request) {
	user, err := s.auth(r)
	if err != nil {
		reply(w, 401, map[string]string{"error": "Não autorizado"})
		return
	}
	if r.Method != "POST" {
		reply(w, 405, map[string]string{"error": "Método inválido"})
		return
	}
	var q struct {
		Action          string `json:"action"`
		DisplayName     string `json:"display_name"`
		CurrentPassword string `json:"current_password"`
		NewPassword     string `json:"new_password"`
		ConfirmPassword string `json:"confirm_password"`
	}
	if parse(r, &q) != nil {
		reply(w, 400, map[string]string{"error": "Dados inválidos"})
		return
	}
	s.mu.Lock()
	defer s.mu.Unlock()
	u, ok := s.db.Users[user]
	if !ok {
		reply(w, 404, map[string]string{"error": "Conta não encontrada"})
		return
	}
	switch q.Action {
	case "display_name":
		name := strings.TrimSpace(q.DisplayName)
		if !validDisplayName(name) {
			reply(w, 400, map[string]string{"error": "Nome deve ter de 2 a 40 caracteres"})
			return
		}
		u.DisplayName = name
	case "password":
		if !checkPassword(u, q.CurrentPassword) {
			reply(w, 403, map[string]string{"error": "Senha atual incorreta"})
			return
		}
		if len(q.NewPassword) < 8 || len(q.NewPassword) > 256 || q.NewPassword != q.ConfirmPassword {
			reply(w, 400, map[string]string{"error": "Nova senha inválida ou confirmação diferente"})
			return
		}
		u.Salt = token()
		u.Hash = secureHash(u.Salt, q.NewPassword)
	default:
		reply(w, 400, map[string]string{"error": "Ação inválida"})
		return
	}
	old := s.db.Users[user]
	s.db.Users[user] = u
	if err := s.save(); err != nil {
		s.db.Users[user] = old
		reply(w, 500, map[string]string{"error": "Falha ao salvar"})
		return
	}
	slog.Info("profile.updated", "user", user, "action", q.Action)
	reply(w, 200, map[string]any{"ok": true, "display_name": s.displayName(user)})
}
