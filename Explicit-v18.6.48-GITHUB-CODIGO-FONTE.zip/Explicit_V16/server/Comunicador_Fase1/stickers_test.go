package main

import (
	"bytes"
	"encoding/json"
	"image"
	"image/color"
	"image/jpeg"
	"image/png"
	"mime/multipart"
	"net/http/httptest"
	"os"
	"path/filepath"
	"strings"
	"testing"
)

func fixtureStickerPNG(t *testing.T) []byte {
	t.Helper()
	im := image.NewNRGBA(image.Rect(0, 0, 800, 550))
	for y := 0; y < 550; y++ {
		for x := 0; x < 800; x++ {
			im.SetNRGBA(x, y, color.NRGBA{R: uint8(x % 256), G: uint8(y % 256), B: 190, A: 200})
		}
	}
	var b bytes.Buffer
	if err := png.Encode(&b, im); err != nil {
		t.Fatal(err)
	}
	return b.Bytes()
}
func stickerRequest(s *Server, method, path, user string, body any) *httptest.ResponseRecorder {
	data, _ := json.Marshal(body)
	r := httptest.NewRequest(method, path, bytes.NewReader(data))
	r.Header.Set("Authorization", "Bearer "+user+"-token")
	w := httptest.NewRecorder()
	s.routes().ServeHTTP(w, r)
	return w
}
func stickerUpload(t *testing.T, s *Server, username string, raw []byte) *httptest.ResponseRecorder {
	t.Helper()
	var b bytes.Buffer
	writer := multipart.NewWriter(&b)
	part, err := writer.CreateFormFile("image", "sticker.png")
	if err != nil {
		t.Fatal(err)
	}
	_, _ = part.Write(raw)
	_ = writer.Close()
	req := httptest.NewRequest("POST", "/api/stickers", &b)
	req.Header.Set("Authorization", "Bearer "+username+"-token")
	req.Header.Set("Content-Type", writer.FormDataContentType())
	w := httptest.NewRecorder()
	s.routes().ServeHTTP(w, req)
	return w
}
func TestStickerPermissionOptimizationFavoriteSendAndDeletion(t *testing.T) {
	s := staffFixture(t)
	s.db.Users["member"] = User{Name: "member", Beta: true}
	picture := fixtureStickerPNG(t)
	if w := stickerUpload(t, s, "owner", picture); w.Code != 403 {
		t.Fatalf("unauthorized upload %d", w.Code)
	}
	w := stickerUpload(t, s, "member", picture)
	if w.Code != 201 {
		t.Fatalf("beta upload failed: %d %s", w.Code, w.Body.String())
	}
	var sticker Sticker
	if err := json.Unmarshal(w.Body.Bytes(), &sticker); err != nil {
		t.Fatal(err)
	}
	if sticker.Width > 256 || sticker.Height > 256 || !strings.HasSuffix(sticker.ID, ".png") {
		t.Fatalf("invalid output: %+v", sticker)
	}
	saved, err := os.ReadFile(filepath.Join(filepath.Dir(s.file), "stickers", sticker.ID))
	if err != nil {
		t.Fatal(err)
	}
	if len(saved) >= len(picture) {
		t.Fatalf("sticker not optimized: %d >= %d", len(saved), len(picture))
	}
	decoded, err := png.Decode(bytes.NewReader(saved))
	if err != nil || decoded.Bounds().Dx() != sticker.Width {
		t.Fatalf("invalid stored image: %v", err)
	}
	if w = stickerRequest(s, "POST", "/api/stickers", "owner", map[string]any{"action": "send", "id": sticker.ID, "community": "c1", "channel": "geral"}); w.Code != 403 {
		t.Fatalf("user sent sticker %d", w.Code)
	}
	if w = stickerRequest(s, "POST", "/api/stickers", "member", map[string]any{"action": "send", "id": sticker.ID, "community": "c1", "channel": "geral"}); w.Code != 201 {
		t.Fatalf("beta cannot send %d %s", w.Code, w.Body)
	}
	if len(s.db.Messages) != 1 || s.db.Messages[0].Sticker != sticker.ID {
		t.Fatal("message not stored as sticker")
	}
	if w = stickerRequest(s, "POST", "/api/stickers", "owner", map[string]any{"action": "favorite", "id": sticker.ID}); w.Code != 200 {
		t.Fatalf("favorite %d %s", w.Code, w.Body)
	}
	if !contains(s.db.StickerFavorites["owner"], sticker.ID) {
		t.Fatal("favorite not saved")
	}
	if w = stickerRequest(s, "GET", "/api/stickers?id="+sticker.ID, "owner", nil); w.Code != 200 {
		t.Fatalf("saved image unavailable %d", w.Code)
	}
	if w = stickerRequest(s, "POST", "/api/stickers", "owner", map[string]any{"action": "delete", "id": sticker.ID}); w.Code != 403 {
		t.Fatalf("not owner deleted %d", w.Code)
	}
	if w = stickerRequest(s, "POST", "/api/stickers", "member", map[string]any{"action": "delete", "id": sticker.ID}); w.Code != 200 {
		t.Fatalf("owner delete failed %d", w.Code)
	}
	if w = stickerRequest(s, "POST", "/api/stickers", "member", map[string]any{"action": "send", "id": sticker.ID, "community": "c1", "channel": "geral"}); w.Code != 403 {
		t.Fatalf("removed sticker sent %d", w.Code)
	}
	if w = stickerRequest(s, "GET", "/api/stickers?id="+sticker.ID, "owner", nil); w.Code != 200 {
		t.Fatalf("historic message no longer renders %d", w.Code)
	}
	reloaded := newServer(s.file)
	if len(reloaded.db.Messages) != 1 || len(reloaded.db.Stickers) != 1 || !reloaded.db.Stickers[0].Removed {
		t.Fatal("sticker state lost")
	}
}
func TestStickerRejectsAnimatedAndInvalidImages(t *testing.T) {
	if _, _, _, _, err := makeSticker([]byte("GIF89a")); err == nil {
		t.Fatal("GIF accepted")
	}
	if _, _, _, _, err := makeSticker([]byte("not image")); err == nil {
		t.Fatal("invalid accepted")
	}
	im := image.NewRGBA(image.Rect(0, 0, 640, 380))
	var b bytes.Buffer
	if err := jpeg.Encode(&b, im, &jpeg.Options{Quality: 95}); err != nil {
		t.Fatal(err)
	}
	data, ext, w, h, err := makeSticker(b.Bytes())
	if err != nil || ext != "jpg" || w > 256 || h > 256 || len(data) > 512<<10 {
		t.Fatalf("jpeg optimize %v %s %dx%d", err, ext, w, h)
	}
}
func TestStickerBetaGrantOnlySuperadmin(t *testing.T) {
	s := staffFixture(t)
	s.db.Users["owner"] = User{Name: "owner", SystemRole: "user"}
	w := staffReq(s, "POST", "/api/system-admin", "member", map[string]any{"action": "set_beta", "target": "owner", "beta": true})
	if w.Code != 403 {
		t.Fatalf("non staff grant %d", w.Code)
	}
	w = staffReq(s, "POST", "/api/system-admin", "root", map[string]any{"action": "set_beta", "target": "owner", "beta": true})
	if w.Code != 200 || !s.db.Users["owner"].Beta {
		t.Fatalf("grant failed %d %s", w.Code, w.Body)
	}
	w = staffReq(s, "POST", "/api/system-admin", "root", map[string]any{"action": "set_beta", "target": "owner", "beta": false})
	if w.Code != 200 || s.db.Users["owner"].Beta {
		t.Fatalf("revoke failed %d %s", w.Code, w.Body)
	}
}
