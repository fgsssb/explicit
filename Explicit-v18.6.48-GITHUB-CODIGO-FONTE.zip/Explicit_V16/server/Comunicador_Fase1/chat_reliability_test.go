package main

import (
	"encoding/json"
	"net/http"
	"net/http/httptest"
	"strings"
	"testing"
	"time"
)

func TestChatRetryPersistsAcrossRestartAndDoesNotDuplicate(t *testing.T) {
	t.Setenv("EXPLICIT_INITIAL_INVITE_KEY", "TEST-BOOTSTRAP")
	path := t.TempDir() + "/store.json"
	s := newServer(path)
	call := func(server *Server, method, endpoint, body, auth string) *httptest.ResponseRecorder {
		r := httptest.NewRequest(method, endpoint, strings.NewReader(body))
		if auth != "" {
			r.Header.Set("Authorization", "Bearer "+auth)
		}
		w := httptest.NewRecorder()
		server.routes().ServeHTTP(w, r)
		return w
	}
	if w := call(s, "POST", "/api/register", `{"name":"alice","display_name":"Alice Example","password":"password123","invite_key":"TEST-BOOTSTRAP"}`, ""); w.Code != 201 {
		t.Fatalf("register %d %s", w.Code, w.Body.String())
	}
	login := func(s *Server) string {
		w := call(s, "POST", "/api/login", `{"name":"alice","password":"password123"}`, "")
		if w.Code != 200 {
			t.Fatalf("login: %d %s", w.Code, w.Body.String())
		}
		var v map[string]string
		_ = json.Unmarshal(w.Body.Bytes(), &v)
		if w := call(s, "POST", "/api/terms", `{"accept":true,"version":"`+currentTermsVersion+`"}`, v["token"]); w.Code != 200 {
			t.Fatal(w.Body)
		}
		return v["token"]
	}
	auth := login(s)
	communityResult := call(s, "POST", "/api/communities", `{"name":"General"}`, auth)
	var comm Community
	_ = json.Unmarshal(communityResult.Body.Bytes(), &comm)
	if communityResult.Code != 201 {
		t.Fatalf("community %d %s", communityResult.Code, communityResult.Body.String())
	}
	endpoints := []string{"/api/messages", "/api/channel-messages?community=" + comm.ID + "&channel=geral"}
	for index, endpoint := range endpoints {
		id := "11111111-1111-4111-8111-" + []string{"000000000001", "000000000002"}[index]
		body := `{"text":"Mensagem apenas uma vez","client_id":"` + id + `"}`
		first := call(s, "POST", endpoint, body, auth)
		if first.Code != 201 {
			t.Fatalf("first %d %s", first.Code, first.Body.String())
		}
		var saved Message
		_ = json.Unmarshal(first.Body.Bytes(), &saved)
		again := call(s, "POST", endpoint, body, auth)
		if again.Code != 200 {
			t.Fatalf("replay %d %s", again.Code, again.Body.String())
		}
		var replay Message
		_ = json.Unmarshal(again.Body.Bytes(), &replay)
		if saved.ID != replay.ID || saved.ClientID != id {
			t.Fatalf("duplicate message id: %#v %#v", saved, replay)
		}
		conflict := call(s, "POST", endpoint, `{"text":"different","client_id":"`+id+`"}`, auth)
		if conflict.Code != http.StatusConflict {
			t.Fatalf("id conflict accepted: %d", conflict.Code)
		}
		invalid := call(s, "POST", endpoint, `{"text":"hi","client_id":"bad"}`, auth)
		if invalid.Code != http.StatusBadRequest {
			t.Fatalf("invalid nonce accepted: %d", invalid.Code)
		}
		s = newServer(path)
		auth = login(s)
		postRestart := call(s, "POST", endpoint, body, auth)
		if postRestart.Code != 200 {
			t.Fatalf("replay after restart %d %s", postRestart.Code, postRestart.Body.String())
		}
		var after Message
		_ = json.Unmarshal(postRestart.Body.Bytes(), &after)
		if after.ID != saved.ID {
			t.Fatalf("restart replay created duplicate %q vs %q", after.ID, saved.ID)
		}
	}
	if len(s.db.Messages) != 2 {
		t.Fatalf("expected exactly 2 messages, got %d", len(s.db.Messages))
	}
}

func TestClientIDsDistinctUsersAndChannels(t *testing.T) {
	id := "11111111-1111-4111-8111-000000000001"
	now := time.Now()
	messages := []Message{{ID: "a", Author: "a", Channel: "x", ClientID: id, Time: now}, {ID: "b", Author: "b", Channel: "x", ClientID: id, Time: now}, {ID: "c", Author: "a", Channel: "y", ClientID: id, Time: now}}
	for _, tc := range []struct{ user, channel, want string }{{"a", "x", "a"}, {"b", "x", "b"}, {"a", "y", "c"}} {
		result := findChatRetry(messages, tc.user, tc.channel, id)
		if result == nil || result.ID != tc.want {
			t.Fatalf("wrong replay for %#v: %#v", tc, result)
		}
	}
	if findChatRetry(messages, "other", "x", id) != nil {
		t.Fatal("user isolation failed")
	}
	if findChatRetry(messages, "a", "x", "") != nil {
		t.Fatal("legacy message incorrectly deduplicated")
	}
}
