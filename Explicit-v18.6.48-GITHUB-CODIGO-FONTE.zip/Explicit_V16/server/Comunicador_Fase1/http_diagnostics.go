package main

import (
	"crypto/rand"
	"encoding/hex"
	"fmt"
	"log/slog"
	"net/http"
	"strings"
	"time"
)

// HTTP diagnostics use only route names and anonymous request IDs. Authentication
// headers, tokens, query parameters, message bodies and IP addresses are never logged.
type diagnosticResponse struct {
	http.ResponseWriter
	status int
	wrote  bool
}

func (w *diagnosticResponse) WriteHeader(status int) {
	if !w.wrote {
		w.wrote = true
		w.status = status
		w.ResponseWriter.WriteHeader(status)
	}
}
func (w *diagnosticResponse) Write(b []byte) (int, error) {
	if !w.wrote {
		w.WriteHeader(http.StatusOK)
	}
	return w.ResponseWriter.Write(b)
}
func (w *diagnosticResponse) Flush() {
	if f, ok := w.ResponseWriter.(http.Flusher); ok {
		f.Flush()
	}
}
func (w *diagnosticResponse) Unwrap() http.ResponseWriter { return w.ResponseWriter }
func newDiagnosticID() string {
	var b [8]byte
	if _, err := rand.Read(b[:]); err != nil {
		return "unavailable"
	}
	return hex.EncodeToString(b[:])
}
func withHTTPDiagnostics(next http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		start := time.Now()
		id := newDiagnosticID()
		w.Header().Set("X-Explicit-Request-ID", id)
		out := &diagnosticResponse{ResponseWriter: w, status: http.StatusOK}
		route := r.URL.Path
		// Only fixed API route names are retained in server logs.
		if !strings.HasPrefix(route, "/api/") || strings.ContainsAny(route, "\\:?") {
			route = "(other)"
		}
		defer func() {
			if recovered := recover(); recovered != nil {
				// Do not leak panic values or stack details to remote clients.
				if !out.wrote {
					http.Error(out, "Internal server error. Reference: "+id, http.StatusInternalServerError)
				}
				slog.Error("explicit.http.panic", "request_id", id, "route", route, "panic_type", fmt.Sprintf("%T", recovered))
			}
			if out.status >= 500 {
				slog.Error("explicit.http.error", "request_id", id, "method", r.Method, "route", route, "status", out.status, "elapsed_ms", time.Since(start).Milliseconds())
			}
		}()
		next.ServeHTTP(out, r)
	})
}
