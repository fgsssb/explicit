package main

import (
	"encoding/json"
	"net/http"
	"regexp"
	"strings"
	"time"
)

// Per-account/per-community settings. A zero value preserves the legacy behavior:
// messages enabled, not muted, and new arrivals accepted.
type CommunityUserPrefs struct {
	MessageMode  string            `json:"message_mode"`            // all | mentions | none
	MutedUntil   int64             `json:"muted_until"`             // -1 forever, otherwise UTC Unix seconds
	ReadThrough  int64             `json:"read_through"`            // UTC Unix nanoseconds
	ChannelModes map[string]string `json:"channel_modes,omitempty"` // all | mentions | none
}

func communityInviteCode(c Community) string {
	if c.InviteCode != "" {
		return c.InviteCode
	}
	return c.ID
}
func communityPrefKey(user, community string) string { return user + ":" + community }
func normalizedCommunityPrefs(p CommunityUserPrefs) CommunityUserPrefs {
	if p.MessageMode != "mentions" && p.MessageMode != "none" {
		p.MessageMode = "all"
	}
	return p
}
func communityIsMuted(p CommunityUserPrefs, now time.Time) bool {
	return p.MutedUntil == -1 || p.MutedUntil > now.Unix()
}
func (s *Server) communityUnreadLocked(user string, c Community, p CommunityUserPrefs) int {
	// Server-side filtering avoids disclosing private-channel activity via badge counts.
	if communityIsMuted(p, time.Now()) || p.MessageMode == "none" {
		return 0
	}
	global := userNotifyPrefs(s.db.Users[user])
	count := 0
	for _, item := range s.db.Notifications {
		if item.User != user || item.Community != c.ID || item.At.UnixNano() <= p.ReadThrough {
			continue
		}
		if item.Kind != "message" && item.Kind != "mention" {
			continue
		}
		if mode := p.ChannelModes[item.Channel]; mode == "none" || (mode == "mentions" && item.Kind == "message") {
			continue
		}
		if item.Kind == "message" && (p.MessageMode == "mentions" || global.MessageMode == "mentions" || !global.Messages) {
			continue
		}
		if item.Kind == "mention" && !global.Mentions {
			continue
		}
		if !contains(c.Channels, item.Channel) || !s.channelPermission(c, user, item.Channel, "VIEW_CHANNEL") {
			continue
		}
		if s.activeSanction(c, user, item.Channel) != nil {
			continue
		}
		count++
		if count >= 100 {
			return 100
		}
	}
	return count
}

func (s *Server) communityHubAPI(w http.ResponseWriter, r *http.Request) {
	actor, err := s.auth(r)
	if err != nil {
		http.Error(w, "unauthorized", 401)
		return
	}
	var q struct {
		Action     string `json:"action"`
		Community  string `json:"community"`
		Mode       string `json:"mode"`
		Mute       string `json:"mute"`
		Channel    string `json:"channel"`
		Name       string `json:"name"`
		Invite     string `json:"invite"`
		JoinClosed *bool  `json:"join_closed"`
		Confirm    bool   `json:"confirm"`
	}
	if r.Method == http.MethodGet {
		q.Community = r.URL.Query().Get("community")
	} else if r.Method == http.MethodPost {
		if parse(r, &q) != nil {
			http.Error(w, "invalid request", 400)
			return
		}
	} else {
		http.Error(w, "method", 405)
		return
	}
	if q.Action == "delete_community" {
		mediaControlMu.Lock()
		defer mediaControlMu.Unlock()
	}
	s.mu.Lock()
	locked := true
	defer func() {
		if locked {
			s.mu.Unlock()
		}
	}()
	if q.Community == "" && r.Method == http.MethodGet {
		result := map[string]any{}
		for _, c := range s.db.Communities {
			if !contains(c.Members, actor) && !s.isSuperadmin(actor) {
				continue
			}
			p := normalizedCommunityPrefs(s.db.CommunityPrefs[communityPrefKey(actor, c.ID)])
			result[c.ID] = map[string]any{"unread": s.communityUnreadLocked(actor, c, p), "prefs": p}
		}
		reply(w, 200, result)
		return
	}
	var c *Community
	for i := range s.db.Communities {
		if s.db.Communities[i].ID == q.Community {
			c = &s.db.Communities[i]
			break
		}
	}
	if c == nil {
		http.Error(w, "not found", 404)
		return
	}
	if !contains(c.Members, actor) && !s.isSuperadmin(actor) {
		http.Error(w, "forbidden", 403)
		return
	}
	key := communityPrefKey(actor, c.ID)
	p := normalizedCommunityPrefs(s.db.CommunityPrefs[key])
	if r.Method == http.MethodGet {
		info := map[string]any{"id": c.ID, "name": c.Name, "card_image": c.CardImage, "owner": c.Owner, "join_closed": c.JoinClosed, "prefs": p, "unread": s.communityUnreadLocked(actor, *c, p), "permissions": s.userPermissions(*c, actor), "can_delete": c.Owner == actor || s.isSuperadmin(actor)}
		if s.hasPermission(*c, actor, "CREATE_INVITES") {
			info["invite_code"] = communityInviteCode(*c)
		}
		if s.hasPermission(*c, actor, "MANAGE_MEMBERS") || s.hasPermission(*c, actor, "ASSIGN_ROLES") {
			info["members"] = c.Members
			info["member_roles"] = c.MemberRoles
		}
		if s.hasPermission(*c, actor, "MANAGE_ROLES") {
			info["roles"] = c.Roles
		}
		reply(w, 200, info)
		return
	}
	switch q.Action {
	case "channel_preferences":
		if !contains(c.Channels, q.Channel) || !s.channelPermission(*c, actor, q.Channel, "VIEW_CHANNEL") {
			http.Error(w, "channel not accessible", 403)
			return
		}
		if q.Mode != "all" && q.Mode != "mentions" && q.Mode != "none" {
			http.Error(w, "invalid notification mode", 400)
			return
		}
		old := p
		copyModes := make(map[string]string, len(p.ChannelModes)+1)
		for name, mode := range p.ChannelModes {
			copyModes[name] = mode
		}
		if q.Mode == "all" {
			delete(copyModes, q.Channel)
		} else {
			copyModes[q.Channel] = q.Mode
		}
		p.ChannelModes = copyModes
		if s.db.CommunityPrefs == nil {
			s.db.CommunityPrefs = map[string]CommunityUserPrefs{}
		}
		s.db.CommunityPrefs[key] = p
		if err := s.save(); err != nil {
			s.db.CommunityPrefs[key] = old
			http.Error(w, "storage error", 500)
			return
		}
		reply(w, 200, map[string]any{"prefs": p, "unread": s.communityUnreadLocked(actor, *c, p)})
		return
	case "delete_community":
		if c.Owner != actor && !s.isSuperadmin(actor) {
			http.Error(w, "only founder or superadmin may delete a community", 403)
			return
		}
		if !q.Confirm || q.Name != c.Name || strings.TrimSpace(q.Name) == "" {
			http.Error(w, "exact community name and confirmation required", 400)
			return
		}
		// Preserve the complete previous store for rollback on persistence errors.
		previous, err := json.Marshal(s.db)
		if err != nil {
			http.Error(w, "storage error", 500)
			return
		}
		removedID := c.ID
		newCommunities := make([]Community, 0, len(s.db.Communities)-1)
		for _, item := range s.db.Communities {
			if item.ID != removedID {
				newCommunities = append(newCommunities, item)
			}
		}
		s.db.Communities = newCommunities
		newMessages := make([]Message, 0, len(s.db.Messages))
		for _, item := range s.db.Messages {
			if !strings.HasPrefix(item.Channel, removedID+":") {
				newMessages = append(newMessages, item)
			}
		}
		s.db.Messages = newMessages
		newNotifications := make([]AppNotification, 0, len(s.db.Notifications))
		for _, item := range s.db.Notifications {
			if item.Community != removedID {
				newNotifications = append(newNotifications, item)
			}
		}
		s.db.Notifications = newNotifications
		for key := range s.db.CommunityPrefs {
			if strings.HasSuffix(key, ":"+removedID) {
				delete(s.db.CommunityPrefs, key)
			}
		}
		newMutes := make([]StaffMute, 0, len(s.db.StaffMutes))
		for _, item := range s.db.StaffMutes {
			if item.Community != removedID {
				newMutes = append(newMutes, item)
			}
		}
		s.db.StaffMutes = newMutes
		newSanctions := make([]Sanction, 0, len(s.db.Sanctions))
		for _, item := range s.db.Sanctions {
			if item.Community != removedID {
				newSanctions = append(newSanctions, item)
			}
		}
		s.db.Sanctions = newSanctions
		if err := s.save(); err != nil {
			_ = json.Unmarshal(previous, &s.db)
			http.Error(w, "storage error", 500)
			return
		}
		removals := removeCommunityVoicePresence(removedID, "")
		// Keep the deletion audit outside the deleted community data.
		s.appendAudit(removedID, actor, "Comunidade excluída", q.Name)
		s.mu.Unlock()
		locked = false
		if err := revokeCommunityMedia(removals); err != nil {
			reply(w, 502, map[string]any{"error": "Comunidade excluída, mas a desconexão de mídia falhou", "community_deleted": true, "community": removedID})
			return
		}
		reply(w, 200, map[string]any{"deleted": true, "community": removedID})
		return
	case "read":
		old := p
		p.ReadThrough = time.Now().UTC().UnixNano()
		if s.db.CommunityPrefs == nil {
			s.db.CommunityPrefs = map[string]CommunityUserPrefs{}
		}
		s.db.CommunityPrefs[key] = p
		if err := s.save(); err != nil {
			s.db.CommunityPrefs[key] = old
			http.Error(w, "storage error", 500)
			return
		}
		reply(w, 200, map[string]any{"prefs": p, "unread": 0})
		return
	case "preferences":
		if q.Mode != "all" && q.Mode != "mentions" && q.Mode != "none" {
			http.Error(w, "invalid notification mode", 400)
			return
		}
		old := p
		p.MessageMode = q.Mode
		if s.db.CommunityPrefs == nil {
			s.db.CommunityPrefs = map[string]CommunityUserPrefs{}
		}
		s.db.CommunityPrefs[key] = p
		if err := s.save(); err != nil {
			s.db.CommunityPrefs[key] = old
			http.Error(w, "storage error", 500)
			return
		}
		reply(w, 200, map[string]any{"prefs": p, "unread": s.communityUnreadLocked(actor, *c, p)})
		return
	case "mute":
		old := p
		switch q.Mute {
		case "off":
			p.MutedUntil = 0
		case "forever":
			p.MutedUntil = -1
		case "24h":
			p.MutedUntil = time.Now().Add(24 * time.Hour).Unix()
		case "48h":
			p.MutedUntil = time.Now().Add(48 * time.Hour).Unix()
		case "7d":
			p.MutedUntil = time.Now().Add(7 * 24 * time.Hour).Unix()
		case "30d":
			p.MutedUntil = time.Now().Add(30 * 24 * time.Hour).Unix()
		default:
			http.Error(w, "invalid mute duration", 400)
			return
		}
		if s.db.CommunityPrefs == nil {
			s.db.CommunityPrefs = map[string]CommunityUserPrefs{}
		}
		s.db.CommunityPrefs[key] = p
		if err := s.save(); err != nil {
			s.db.CommunityPrefs[key] = old
			http.Error(w, "storage error", 500)
			return
		}
		reply(w, 200, map[string]any{"prefs": p, "unread": s.communityUnreadLocked(actor, *c, p)})
		return
	case "rename", "invite", "rotate_invite", "toggle_join":
		if !s.hasPermission(*c, actor, "MANAGE_COMMUNITY") {
			http.Error(w, "forbidden", 403)
			return
		}
		before, _ := json.Marshal(*c)
		switch q.Action {
		case "rename":
			q.Name = strings.TrimSpace(q.Name)
			if len([]rune(q.Name)) < 3 || len([]rune(q.Name)) > 60 {
				http.Error(w, "invalid name", 400)
				return
			}
			c.Name = q.Name
		case "invite", "rotate_invite":
			code := strings.TrimSpace(strings.ToLower(q.Invite))
			if q.Action == "rotate_invite" {
				code = token()[:20]
			}
			if !regexp.MustCompile(`^[a-z0-9_-]{4,32}$`).MatchString(code) {
				http.Error(w, "invalid invite code", 400)
				return
			}
			if code == "api" || code == "admin" {
				http.Error(w, "reserved invite code", 400)
				return
			}
			for _, other := range s.db.Communities {
				if other.ID != c.ID && (strings.EqualFold(communityInviteCode(other), code) || strings.EqualFold(other.ID, code)) {
					http.Error(w, "invite code already in use", 409)
					return
				}
			}
			c.InviteCode = code
		case "toggle_join":
			if q.JoinClosed == nil {
				http.Error(w, "missing value", 400)
				return
			}
			c.JoinClosed = *q.JoinClosed
		}
		if err := s.save(); err != nil {
			_ = json.Unmarshal(before, c)
			http.Error(w, "storage error", 500)
			return
		}
		s.appendAudit(c.ID, actor, "Configuração da comunidade", q.Action)
		reply(w, 200, map[string]any{"ok": true, "name": c.Name, "invite_code": communityInviteCode(*c), "join_closed": c.JoinClosed})
		return
	default:
		http.Error(w, "invalid action", 400)
	}
}
