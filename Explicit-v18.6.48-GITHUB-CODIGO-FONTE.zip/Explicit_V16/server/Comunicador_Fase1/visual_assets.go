package main

import (
	"bytes"
	"image"
	"image/color"
	"image/draw"
	_ "image/gif"
	"image/jpeg"
	_ "image/png"
	"io"
	"log"
	"net/http"
	"os"
	"path/filepath"
	"strings"
)

// Server-mediated images: decode and re-encode uploads so their content type,
// size and dimensions are always known. Original files are never served.
func resizeExplicit(src image.Image, maxSize int, square bool) image.Image {
	b := src.Bounds()
	w, h := b.Dx(), b.Dy()
	if square {
		crop := w
		if h < crop {
			crop = h
		}
		x := (w - crop) / 2
		y := (h - crop) / 2
		b = image.Rect(b.Min.X+x, b.Min.Y+y, b.Min.X+x+crop, b.Min.Y+y+crop)
		w, h = crop, crop
	}
	if w <= 0 || h <= 0 {
		return image.NewRGBA(image.Rect(0, 0, 1, 1))
	}
	ratio := float64(maxSize) / float64(w)
	if float64(h) > float64(w) {
		ratio = float64(maxSize) / float64(h)
	}
	if ratio > 1 {
		ratio = 1
	}
	outW, outH := int(float64(w)*ratio), int(float64(h)*ratio)
	if outW < 1 {
		outW = 1
	}
	if outH < 1 {
		outH = 1
	}
	dst := image.NewRGBA(image.Rect(0, 0, outW, outH))
	draw.Draw(dst, dst.Bounds(), &image.Uniform{C: color.White}, image.Point{}, draw.Src)
	for y := 0; y < outH; y++ {
		for x := 0; x < outW; x++ {
			sx := b.Min.X + x*w/outW
			sy := b.Min.Y + y*h/outH
			dst.Set(x, y, src.At(sx, sy))
		}
	}
	return dst
}
func (s *Server) visualAPI(w http.ResponseWriter, r *http.Request) {
	kind := r.URL.Query().Get("type")
	id := r.URL.Query().Get("id")
	if kind != "avatar" && kind != "community" {
		http.Error(w, "invalid type", 400)
		return
	}
	if r.Method == http.MethodGet {
		if kind == "avatar" {
			if !validVisualID(id, false) {
				http.Error(w, "invalid id", 400)
				return
			}
		} else if !validVisualID(id, true) {
			http.Error(w, "invalid id", 400)
			return
		}
		s.mu.Lock()
		allowed := false
		if kind == "avatar" {
			u, ok := s.db.Users[id]
			allowed = ok && u.Avatar != ""
		} else {
			for _, c := range s.db.Communities {
				if c.ID == id && c.CardImage != "" {
					allowed = true
					break
				}
			}
		}
		s.mu.Unlock()
		if !allowed {
			http.NotFound(w, r)
			return
		}
		w.Header().Set("Content-Type", "image/jpeg")
		w.Header().Set("X-Content-Type-Options", "nosniff")
		w.Header().Set("Cache-Control", "public, max-age=120")
		http.ServeFile(w, r, filepath.Join(filepath.Dir(s.file), "visual", kind, id+".jpg"))
		return
	}
	if r.Method != http.MethodPost {
		http.Error(w, "method", 405)
		return
	}
	actor, err := s.auth(r)
	if err != nil {
		http.Error(w, "unauthorized", 401)
		return
	}
	if kind == "avatar" {
		id = actor
	} else if !validVisualID(id, true) {
		http.Error(w, "invalid community", 400)
		return
	}
	r.Body = http.MaxBytesReader(w, r.Body, 5<<20)
	if err := r.ParseMultipartForm(4 << 20); err != nil {
		http.Error(w, "file too large", 413)
		return
	}
	if r.MultipartForm != nil {
		defer r.MultipartForm.RemoveAll()
	}
	file, _, err := r.FormFile("image")
	if err != nil {
		http.Error(w, "image required", 400)
		return
	}
	defer file.Close()
	raw, err := io.ReadAll(io.LimitReader(file, (4<<20)+1))
	if err != nil || len(raw) == 0 || len(raw) > 4<<20 {
		http.Error(w, "file too large", 413)
		return
	}
	t := http.DetectContentType(raw)
	if t != "image/png" && t != "image/jpeg" && t != "image/gif" {
		http.Error(w, "use PNG, JPEG or GIF", 415)
		return
	}
	config, _, err := image.DecodeConfig(bytes.NewReader(raw))
	if err != nil || config.Width < 1 || config.Height < 1 || config.Width > 4096 || config.Height > 4096 || int64(config.Width)*int64(config.Height) > 12000000 {
		http.Error(w, "invalid dimensions", 400)
		return
	}
	src, _, err := image.Decode(bytes.NewReader(raw))
	if err != nil {
		http.Error(w, "invalid image", 400)
		return
	}
	result := resizeExplicit(src, map[bool]int{true: 256, false: 640}[kind == "avatar"], kind == "avatar")
	var encoded bytes.Buffer
	if err := jpeg.Encode(&encoded, result, &jpeg.Options{Quality: 84}); err != nil {
		http.Error(w, "encode failure", 500)
		return
	}
	s.mu.Lock()
	defer s.mu.Unlock()
	permitted := false
	if kind == "avatar" {
		_, permitted = s.db.Users[actor]
	} else {
		for _, c := range s.db.Communities {
			if c.ID == id && s.hasPermission(c, actor, "MANAGE_COMMUNITY") {
				permitted = true
				break
			}
		}
	}
	if !permitted {
		http.Error(w, "forbidden", 403)
		return
	}
	storageOwner := actor
	if kind == "community" {
		for _, c := range s.db.Communities {
			if c.ID == id {
				storageOwner = c.Owner
				break
			}
		}
	}
	if !s.storageAllowedLocked(storageOwner, int64(encoded.Len()), mediaKey("visual/"+kind, id+".jpg")) {
		http.Error(w, "Limite de armazenamento atingido. Entre em contato com a equipe do Explicit.", http.StatusRequestEntityTooLarge)
		return
	}
	folder := filepath.Join(filepath.Dir(s.file), "visual", kind)
	if err := os.MkdirAll(folder, 0700); err != nil {
		http.Error(w, "storage", 500)
		return
	}
	if !trustedStorageDirectory(filepath.Dir(s.file), "visual/"+kind) {
		http.Error(w, "invalid storage directory", 500)
		return
	}
	name := filepath.Join(folder, id+".jpg")
	previous, readErr := os.ReadFile(name)
	existed := readErr == nil
	if readErr != nil && !os.IsNotExist(readErr) {
		http.Error(w, "storage backup failed", 500)
		return
	}
	oldUser := s.db.Users[actor]
	oldCard := ""
	if kind == "community" {
		for _, c := range s.db.Communities {
			if c.ID == id {
				oldCard = c.CardImage
				break
			}
		}
	}
	temp := name + ".tmp"
	if err := os.WriteFile(temp, encoded.Bytes(), 0600); err != nil {
		http.Error(w, "storage", 500)
		return
	}
	if err := os.Rename(temp, name); err != nil {
		_ = os.Remove(temp)
		http.Error(w, "storage", 500)
		return
	}
	if kind == "avatar" {
		u := s.db.Users[actor]
		u.Avatar = "1"
		s.db.Users[actor] = u
	} else {
		for i := range s.db.Communities {
			if s.db.Communities[i].ID == id {
				s.db.Communities[i].CardImage = "1"
				break
			}
		}
	}
	if err := s.save(); err != nil {
		// Roll back both metadata and the overwritten file. Quotas remain
		// attributable to the previous persisted version after a failed save.
		if kind == "avatar" {
			s.db.Users[actor] = oldUser
		} else {
			for i := range s.db.Communities {
				if s.db.Communities[i].ID == id {
					s.db.Communities[i].CardImage = oldCard
					break
				}
			}
		}
		if existed {
			e := os.WriteFile(temp, previous, 0600)
			if e == nil {
				e = os.Rename(temp, name)
			}
			if e != nil {
				log.Printf("STORAGE ERROR restoring visual %s: %v", name, e)
			}
		} else {
			_ = os.Remove(name)
		}
		http.Error(w, "storage metadata failure", 500)
		return
	}
	reply(w, 200, map[string]bool{"ok": true})
}
func validVisualID(id string, community bool) bool {
	if id == "" || len(id) > 96 || strings.Contains(id, "..") {
		return false
	}
	for _, c := range id {
		if c >= 'a' && c <= 'z' || c >= 'A' && c <= 'Z' || c >= '0' && c <= '9' || c == '_' || c == '-' {
			continue
		}
		return false
	}
	return true
}
