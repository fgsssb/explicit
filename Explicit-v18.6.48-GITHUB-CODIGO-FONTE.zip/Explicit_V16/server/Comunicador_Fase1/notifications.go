package main

import (
	"crypto/sha256"
	"encoding/hex"
	"net/http"
	"regexp"
	"strconv"
	"strings"
	"time"
)

// The session identifier is never stored in the online presence map.
func notificationPresenceKey(authorization string) string {
	digest := sha256.Sum256([]byte(authorization))
	return "notifications:" + hex.EncodeToString(digest[:16])
}

// Preferences are private account settings; absent fields keep safe, usable defaults.
type NotifyPreferences struct {
	MessageMode string `json:"message_mode"` // all | mentions
	Messages    bool   `json:"messages"`
	Mentions    bool   `json:"mentions"`
	Direct      bool   `json:"direct"`
	Friends     bool   `json:"friends"`
	VoiceJoin   bool   `json:"voice_join"`
	VoiceLeave  bool   `json:"voice_leave"`
	Screen      bool   `json:"screen"`
	Sound       bool   `json:"sound"`
	Desktop     bool   `json:"desktop"`
}

func defaultNotifyPrefs() NotifyPreferences {
	return NotifyPreferences{
		MessageMode: "all", Messages: true, Mentions: true, Direct: true, Friends: true,
		VoiceJoin: true, VoiceLeave: true, Screen: true, Sound: true, Desktop: true,
	}
}
func userNotifyPrefs(u User) NotifyPreferences {
	if u.NotificationPrefs == nil {
		return defaultNotifyPrefs()
	}
	return *u.NotificationPrefs
}
func validNotifyPrefs(p NotifyPreferences) bool {
	return p.MessageMode == "all" || p.MessageMode == "mentions"
}

type AppNotification struct {
	ID        string    `json:"id"`
	User      string    `json:"user"`
	Kind      string    `json:"kind"`
	Author    string    `json:"author,omitempty"`
	Community string    `json:"community,omitempty"`
	Channel   string    `json:"channel,omitempty"`
	Text      string    `json:"text,omitempty"`
	At        time.Time `json:"at"`
}

// Caller holds the store mutex. Events are bounded and persisted with the
// business operation, allowing reconnecting clients to fetch missed activity.
func (s *Server) enqueueNotificationLocked(user, kind, author, community, channel, text string) {
	if user == "" || user == author {
		return
	}
	if _, ok := s.db.Users[user]; !ok {
		return
	}
	if len([]rune(text)) > 110 {
		text = string([]rune(text)[:110])
	}
	// Only suppress duplicate transient presence events; never suppress DMs,
	// mentions, friend requests or other user-facing messages.
	if kind == "voice_join" || kind == "voice_leave" || kind == "screen" {
		for i := len(s.db.Notifications) - 1; i >= 0; i-- {
			prev := s.db.Notifications[i]
			if prev.User != user {
				continue
			}
			if time.Since(prev.At) > 5*time.Second {
				break
			}
			if prev.Kind == kind && prev.Author == author && prev.Community == community && prev.Channel == channel && prev.Text == text {
				return
			}
		}
	}
	s.db.Notifications = append(s.db.Notifications, AppNotification{
		ID: token()[:22], User: user, Kind: kind, Author: author, Community: community,
		Channel: channel, Text: text, At: time.Now().UTC(),
	})
	s.compactUserNotificationsLocked(user, time.Now().UTC())
}

// Retain notifications independently for each recipient. A burst from one
// account must never evict another person's unread events. Important unread
// events survive longer than read/low-priority events, with a hard per-account
// upper bound so unattended accounts cannot grow storage indefinitely.
const maxNotificationsPerUser = 1000
const maxReadNotificationsPerUser = 240

func (s *Server) notificationWasReadLocked(n AppNotification) bool {
	u := s.db.Users[n.User]
	if n.Community != "" { // Community unread counts are derived from message cursors.
		for _, c := range s.db.Communities {
			if c.ID == n.Community {
				p := normalizedCommunityPrefs(s.db.CommunityPrefs[communityPrefKey(n.User, c.ID)])
				return n.At.UnixNano() <= p.ReadThrough
			}
		}
		return false
	}
	switch n.Kind {
	case "direct":
		return n.At.UnixNano() <= u.DirectNoticesRead[directNoticeKey(n)]
	case "friend":
		return n.At.UnixNano() <= u.OtherNoticesRead
	default:
		return n.At.UnixNano() <= u.OtherNoticesRead
	}
}
func (s *Server) compactUserNotificationsLocked(user string, now time.Time) {
	all := s.db.Notifications
	if len(all) == 0 {
		return
	}
	own := make([]int, 0)
	for i, n := range all {
		if n.User == user {
			own = append(own, i)
		}
	}
	if len(own) == 0 {
		return
	}
	keep := make([]bool, len(all))
	for i := range keep {
		keep[i] = true
	}
	readCount := 0
	// Newest notifications take priority. Expired read entries are removed
	// first; old unread entries are kept for up to 120 days where capacity allows.
	for i := len(own) - 1; i >= 0; i-- {
		index := own[i]
		n := all[index]
		read := s.notificationWasReadLocked(n)
		if read && (now.Sub(n.At) > 30*24*time.Hour || readCount >= maxReadNotificationsPerUser) {
			keep[index] = false
			continue
		}
		if read {
			readCount++
		}
		if now.Sub(n.At) > 120*24*time.Hour {
			keep[index] = false
		}
	}
	remaining := 0
	for i := len(own) - 1; i >= 0; i-- {
		index := own[i]
		if !keep[index] {
			continue
		}
		remaining++
		if remaining > maxNotificationsPerUser {
			keep[index] = false
		}
	}
	compact := make([]AppNotification, 0, len(all))
	for i, n := range all {
		if keep[i] {
			compact = append(compact, n)
		}
	}
	s.db.Notifications = compact
}

var mentionPattern = regexp.MustCompile(`@\{([^}\n]{1,64})\}|@([\pL\pN_.-]{1,64})`)

func (s *Server) channelMentionTargets(c Community, author, text string) map[string]bool {
	targets := map[string]bool{}
	for _, match := range mentionPattern.FindAllStringSubmatch(text, -1) {
		key := match[2]
		if match[1] != "" {
			key = match[1]
		}
		if strings.EqualFold(key, "everyone") {
			for _, u := range c.Members {
				targets[u] = true
			}
			continue
		}
		// Usernames are exact identifiers (not display names).
		if contains(c.Members, key) {
			targets[key] = true
		}
		// @role-id, @{Role Name}, or @RoleName.
		for _, role := range c.Roles {
			if role.ID == "everyone" {
				continue
			}
			if strings.EqualFold(role.ID, key) || strings.EqualFold(role.Name, key) {
				for _, u := range c.Members {
					if contains(c.MemberRoles[u], role.ID) {
						targets[u] = true
					}
				}
			}
		}
	}
	delete(targets, author)
	return targets
}
func (s *Server) notifyChannelMessageLocked(c Community, channel, author, body string) {
	targets := s.channelMentionTargets(c, author, body)
	for _, u := range c.Members {
		if u == author || s.activeSanction(c, u, channel) != nil || !s.channelPermission(c, u, channel, "VIEW_CHANNEL") {
			continue
		}
		if targets[u] {
			s.enqueueNotificationLocked(u, "mention", author, c.ID, channel, body)
		} else {
			s.enqueueNotificationLocked(u, "message", author, c.ID, channel, body)
		}
	}
}

// Unread taskbar badge: all readable community notifications plus DMs and
// friend requests. A badge is not a desktop alert, so offline/busy status does
// not erase pending unread activity. Per-account preferences still apply.
func (s *Server) unreadNotificationsLocked(user string) int {
	total := 0
	for _, c := range s.db.Communities {
		if !contains(c.Members, user) && !s.isSuperadmin(user) {
			continue
		}
		p := normalizedCommunityPrefs(s.db.CommunityPrefs[communityPrefKey(user, c.ID)])
		total += s.communityUnreadLocked(user, c, p)
		if total >= 100 {
			return 100
		}
	}
	u := s.db.Users[user]
	prefs := userNotifyPrefs(u)
	for _, item := range s.db.Notifications {
		if item.User != user || item.Community != "" {
			continue
		}
		switch item.Kind {
		case "direct":
			if !prefs.Direct || item.At.UnixNano() <= u.DirectNoticesRead[directNoticeKey(item)] {
				continue
			}
		case "friend":
			if !prefs.Friends || item.At.UnixNano() <= u.OtherNoticesRead {
				continue
			}
		default:
			continue
		}
		total++
		if total >= 100 {
			return 100
		}
	}
	return total
}

// Polling requires an authenticated session. Per-user filtering is done on
// the server; query params can never be used to read another user's events.
func (s *Server) notificationsAPI(w http.ResponseWriter, r *http.Request) {
	user, err := s.auth(r)
	if err != nil {
		http.Error(w, "unauthorized", 401)
		return
	}
	s.mu.Lock()
	defer s.mu.Unlock()
	u := s.db.Users[user]
	switch r.Method {
	case "GET":
		// Any authenticated notification poll is a client activity signal;
		// account presence does not depend on the community being displayed.
		if online.entries[user] == nil {
			online.entries[user] = map[string]time.Time{}
		}
		online.entries[user][notificationPresenceKey(r.Header.Get("Authorization"))] = time.Now()
		cursor := r.URL.Query().Get("after")
		items := make([]AppNotification, 0, 60)
		if cursor != "" {
			// IDs are generated random identifiers, so use a stable cursor timestamp and ID.
			stamp, err := strconv.ParseInt(cursor, 10, 64)
			if err != nil || stamp < 0 {
				http.Error(w, "invalid cursor", 400)
				return
			}
			for _, item := range s.db.Notifications {
				if item.User != user || item.At.UnixNano() <= stamp {
					continue
				}
				// Permissions are checked again in case a channel was made private.
				if item.Community != "" && item.Channel != "" {
					allowed := false
					for _, c := range s.db.Communities {
						if c.ID == item.Community && (contains(c.Members, user) || s.isSuperadmin(user)) && s.channelPermission(c, user, item.Channel, "VIEW_CHANNEL") {
							allowed = true
							break
						}
					}
					if !allowed {
						continue
					}
				}
				items = append(items, item)
			}
		}
		// Cursor moves across all events, even when their type is muted.
		next := int64(0)
		for _, item := range s.db.Notifications {
			if item.User == user && item.At.UnixNano() > next {
				next = item.At.UnixNano()
			}
		}
		communitySettings := map[string]CommunityUserPrefs{}
		for _, c := range s.db.Communities {
			if contains(c.Members, user) || s.isSuperadmin(user) {
				communitySettings[c.ID] = normalizedCommunityPrefs(s.db.CommunityPrefs[communityPrefKey(user, c.ID)])
			}
		}
		reply(w, 200, map[string]any{"items": items, "cursor": strconv.FormatInt(next, 10), "preferences": userNotifyPrefs(u), "status": u.PreferredStatus, "community_prefs": communitySettings, "unread_count": s.unreadNotificationsLocked(user)})
	case "POST":
		var q struct {
			Action string `json:"action"`
			Author string `json:"author"`
			ID     string `json:"id"`
		}
		if parse(r, &q) != nil {
			http.Error(w, "invalid request", 400)
			return
		}
		now := time.Now().UTC().UnixNano()
		previous := u
		oldPrefs := map[string]CommunityUserPrefs{}
		switch q.Action {
		case "read_direct":
			if q.Author == "" || len(q.Author) > 64 {
				http.Error(w, "invalid user", 400)
				return
			}
			if _, exists := s.db.Users[q.Author]; !exists {
				http.Error(w, "unknown user", 404)
				return
			}
			if u.DirectNoticesRead == nil {
				u.DirectNoticesRead = map[string]int64{}
			}
			// Copy-on-write so storage rollback preserves the old map.
			fresh := make(map[string]int64, len(u.DirectNoticesRead)+1)
			for k, v := range u.DirectNoticesRead {
				fresh[k] = v
			}
			fresh[q.Author] = now
			u.DirectNoticesRead = fresh
		case "read_group":
			authorized := false
			for _, c := range s.db.DirectChats {
				if c.ID == q.ID && contains(c.Users, user) && (len(c.Users) > 2 || c.Name != "") {
					authorized = true
					break
				}
			}
			if !authorized {
				http.Error(w, "group not found", 404)
				return
			}
			fresh := make(map[string]int64, len(u.DirectNoticesRead)+1)
			for k, v := range u.DirectNoticesRead {
				fresh[k] = v
			}
			fresh["dm:"+q.ID] = now
			u.DirectNoticesRead = fresh
		case "read_misc":
			u.OtherNoticesRead = now
		case "read_all":
			if s.db.CommunityPrefs == nil {
				s.db.CommunityPrefs = map[string]CommunityUserPrefs{}
			}
			u.OtherNoticesRead = now
			fresh := make(map[string]int64, len(u.DirectNoticesRead))
			for k, v := range u.DirectNoticesRead {
				fresh[k] = v
			}
			for _, item := range s.db.Notifications {
				if item.User == user && item.Kind == "direct" {
					fresh[directNoticeKey(item)] = now
				}
			}
			u.DirectNoticesRead = fresh
			for _, c := range s.db.Communities {
				if !contains(c.Members, user) && !s.isSuperadmin(user) {
					continue
				}
				key := communityPrefKey(user, c.ID)
				oldPrefs[key] = s.db.CommunityPrefs[key]
				cp := s.db.CommunityPrefs[key]
				cp.ReadThrough = now
				s.db.CommunityPrefs[key] = cp
			}
		default:
			http.Error(w, "invalid action", 400)
			return
		}
		s.db.Users[user] = u
		if err := s.save(); err != nil {
			s.db.Users[user] = previous
			for key, old := range oldPrefs {
				s.db.CommunityPrefs[key] = old
			}
			http.Error(w, "storage failure", 500)
			return
		}
		reply(w, 200, map[string]any{"ok": true, "unread_count": s.unreadNotificationsLocked(user)})
	case "PUT":
		var q NotifyPreferences
		if parse(r, &q) != nil || !validNotifyPrefs(q) {
			http.Error(w, "invalid preferences", 400)
			return
		}
		old := u
		u.NotificationPrefs = &q
		s.db.Users[user] = u
		if err := s.save(); err != nil {
			s.db.Users[user] = old
			http.Error(w, "storage failure", 500)
			return
		}
		reply(w, 200, map[string]any{"preferences": q})
	default:
		http.Error(w, "method", 405)
	}
}

// Separate read cursors prevent group messages from clearing unrelated DMs.
func directNoticeKey(n AppNotification) string {
	if strings.HasPrefix(n.Channel, "dm:") {
		return n.Channel
	}
	return n.Author
}
