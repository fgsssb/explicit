package main

import (
	"io"
	"net/http"
	"net/http/httptest"
	"strings"
	"testing"
)

func TestHTTPDiagnosticsNoSecretsInResponseAndID(t *testing.T) {
	handler := withHTTPDiagnostics(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) { http.Error(w, "bad request", 500) }))
	req := httptest.NewRequest("GET", "/api/messages?token=SECRET", nil)
	req.Header.Set("Authorization", "Bearer SECRET")
	res := httptest.NewRecorder()
	handler.ServeHTTP(res, req)
	if res.Code != 500 {
		t.Fatalf("status %d", res.Code)
	}
	if len(res.Header().Get("X-Explicit-Request-ID")) != 16 {
		t.Fatalf("missing request id")
	}
	if strings.Contains(res.Body.String(), "SECRET") {
		t.Fatal("secret leaked")
	}
}
func TestHTTPDiagnosticsRecoversPanics(t *testing.T) {
	h := withHTTPDiagnostics(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) { panic("SECRET VALUE") }))
	res := httptest.NewRecorder()
	h.ServeHTTP(res, httptest.NewRequest("GET", "/api/messages", nil))
	if res.Code != 500 || strings.Contains(res.Body.String(), "SECRET") {
		t.Fatalf("unsafe panic response %d: %q", res.Code, res.Body.String())
	}
	if !strings.Contains(res.Body.String(), res.Header().Get("X-Explicit-Request-ID")) {
		t.Fatal("request id missing from error")
	}
}
func TestHTTPDiagnosticsPreservesSSEFlush(t *testing.T) {
	h := withHTTPDiagnostics(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		flusher, ok := w.(http.Flusher)
		if !ok {
			t.Fatal("Flusher missing")
		}
		io.WriteString(w, ": ping\n\n")
		flusher.Flush()
	}))
	res := httptest.NewRecorder()
	h.ServeHTTP(res, httptest.NewRequest("GET", "/api/events", nil))
	if !res.Flushed || res.Body.String() != ": ping\n\n" {
		t.Fatalf("SSE broken: %v %q", res.Flushed, res.Body.String())
	}
}
