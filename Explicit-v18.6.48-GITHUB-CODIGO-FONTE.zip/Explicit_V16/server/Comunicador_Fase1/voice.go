package main

import (
	"log/slog"
	"net/http"
	"sort"
	"sync"
	"time"
)

type voiceSignal struct {
	ID   string `json:"id"`
	From string `json:"from"`
	Kind string `json:"kind"`
	Data string `json:"data"`
}
type voiceMember struct {
	User               string
	Room               string
	Seen               time.Time
	Activity           time.Time
	Muted              bool
	Deaf               bool
	Screen             bool
	AdminMuted         bool
	StaffGloballyMuted bool
	MoveTo             string
	AdminDeaf          bool
	Queue              []voiceSignal
}
type voiceHub struct {
	mu      sync.Mutex
	members map[string]*voiceMember
}

var voice = voiceHub{members: map[string]*voiceMember{}}

func (s *Server) voiceAPI(w http.ResponseWriter, r *http.Request) {
	user, err := s.auth(r)
	if err != nil {
		http.Error(w, "unauthorized", 401)
		return
	}
	var q struct {
		Community string `json:"community"`
		Channel   string `json:"channel"`
		Action    string `json:"action"`
		Muted     bool   `json:"muted"`
		Deaf      bool   `json:"deaf"`
		To        string `json:"to"`
		Kind      string `json:"kind"`
		Data      string `json:"data"`
		Screen    bool   `json:"screen"`
	}
	if r.Method != "POST" || parse(r, &q) != nil {
		http.Error(w, "bad request", 400)
		return
	}
	if len(q.Community) > 100 || len(q.Channel) > 40 || len(q.Data) > 7000 || len(q.To) > 100 || len(q.Kind) > 20 {
		http.Error(w, "invalid", 400)
		return
	}
	if q.Action == "join" || q.Action == "leave" {
		mediaControlMu.Lock()
		defer mediaControlMu.Unlock()
	}
	// Leaving must work even after a ban or channel removal.
	if q.Action == "leave" {
		voice.mu.Lock()
		if m := voice.members[user]; m != nil && m.Room == q.Community+":"+q.Channel {
			delete(voice.members, user)
		}
		voice.mu.Unlock()
		// A modified client may keep its media transport open after leaving presence.
		if err := livekitRoomAction(q.Community+":"+q.Channel, user, true); err != nil {
			reply(w, 502, map[string]string{"error": "Presença encerrada, mas a desconexão de mídia falhou"})
			return
		}
		reply(w, 200, map[string]bool{"ok": true})
		return
	}
	s.mu.Lock()
	allowed := false
	limit := 0
	canScreen := false
	canSpeak := false
	canPTT := false
	for _, c := range s.db.Communities {
		if c.ID == q.Community && s.activeSanction(c, user, q.Channel) == nil && (contains(c.Members, user) || s.isSuperadmin(user)) && contains(c.Channels, q.Channel) && c.channelType(q.Channel) == "voice" && s.channelPermission(c, user, q.Channel, "CONNECT_VOICE") && s.channelPermission(c, user, q.Channel, "VIEW_CHANNEL") {
			allowed = true
			limit = c.ChannelMeta[q.Channel].Limit
			canScreen = s.channelPermission(c, user, q.Channel, "SCREEN_SHARE")
			canSpeak = s.channelPermission(c, user, q.Channel, "SPEAK") && !s.isStaffMuted(c.ID, q.Channel, user, "voice")
			canPTT = s.channelPermission(c, user, q.Channel, "USE_PTT")
			break
		}
	}
	isRoot := s.isSuperadmin(user)
	restriction := s.db.VoiceRestrictions[q.Community][user]
	canSpeak = canSpeak && !restriction.Muted
	s.mu.Unlock()
	if !allowed {
		http.Error(w, "forbidden", 403)
		return
	}
	room := q.Community + ":" + q.Channel
	if q.Action == "join" {
		voice.mu.Lock()
		previousRoom := ""
		if previous := voice.members[user]; previous != nil && previous.Room != room {
			previousRoom = previous.Room
		}
		voice.mu.Unlock()
		if previousRoom != "" {
			if err := livekitRoomAction(previousRoom, user, true); err != nil {
				reply(w, 502, map[string]string{"error": "Falha ao encerrar a mídia do canal anterior"})
				return
			}
		}
	}
	voice.mu.Lock()
	defer voice.mu.Unlock()
	now := time.Now()
	for u, m := range voice.members {
		if now.Sub(m.Seen) > 45*time.Second {
			delete(voice.members, u)
		}
	}
	m := voice.members[user]
	switch q.Action {
	case "join":
		if m != nil && m.MoveTo != "" && m.MoveTo != room {
			http.Error(w, "moderator move pending", 403)
			return
		}
		if limit > 0 && !isRoot && (m == nil || m.Room != room) {
			n := 0
			for _, p := range voice.members {
				if p.Room == room {
					n++
				}
			}
			if n >= limit {
				http.Error(w, "channel full", 409)
				return
			}
		}
		slog.Info("voice.join", "actor", user, "room", room)
		peers := []string{}
		for u, p := range voice.members {
			if p.Room == room && u != user {
				peers = append(peers, u)
			}
		}
		if m != nil && m.Room == room {
			m.Seen = now // Rejoining the same channel must not erase moderation.
			m.AdminMuted, m.AdminDeaf = restriction.Muted, restriction.Deaf
		} else {
			voice.members[user] = &voiceMember{User: user, Room: room, Seen: now, Activity: now, AdminMuted: restriction.Muted, Muted: restriction.Muted, AdminDeaf: restriction.Deaf, Deaf: restriction.Deaf, Queue: []voiceSignal{}}
		}
		reply(w, 200, map[string]any{"peers": peers, "user": user, "can_speak": canSpeak, "can_ptt": canPTT})
	case "poll":
		if m == nil || m.Room != room {
			http.Error(w, "not joined", 409)
			return
		}
		m.Seen = now
		events := m.Queue
		m.Queue = []voiceSignal{}
		peers := []string{}
		for u, p := range voice.members {
			if p.Room == room && u != user {
				peers = append(peers, u)
			}
		}
		reply(w, 200, map[string]any{"events": events, "peers": peers, "admin_muted": !isRoot && (m.AdminMuted || m.StaffGloballyMuted || !canSpeak), "admin_deaf": !isRoot && m.AdminDeaf})
	case "state":
		if m == nil || m.Room != room {
			http.Error(w, "not joined", 409)
			return
		}
		m.Seen = now
		m.Activity = now
		m.Muted = q.Muted || (!isRoot && (m.AdminMuted || m.StaffGloballyMuted || !canSpeak))
		m.Deaf = q.Deaf || (!isRoot && m.AdminDeaf)
		reply(w, 200, map[string]bool{"ok": true})
	case "screen":
		if q.Screen && !canScreen {
			http.Error(w, "forbidden", 403)
			return
		}
		if m == nil || m.Room != room {
			http.Error(w, "not joined", 409)
			return
		}
		m.Screen = q.Screen
		m.Seen = now
		slog.Info("screen.state", "actor", user, "room", room, "active", q.Screen)
		reply(w, 200, map[string]bool{"ok": true})
	case "signal":
		if m == nil || m.Room != room {
			http.Error(w, "not joined", 409)
			return
		}
		m.Seen = now
		if q.To == user || len(q.To) == 0 || (q.Kind != "offer" && q.Kind != "answer" && q.Kind != "ice") {
			http.Error(w, "invalid signal", 400)
			return
		}
		target := voice.members[q.To]
		if target == nil || target.Room != room {
			http.Error(w, "peer unavailable", 404)
			return
		}
		if len(target.Queue) >= 128 {
			http.Error(w, "peer busy", 429)
			return
		}
		target.Queue = append(target.Queue, voiceSignal{ID: token()[:12], From: user, Kind: q.Kind, Data: q.Data})
		reply(w, 200, map[string]bool{"ok": true})
	case "leave":
		if m != nil && m.Room == room {
			delete(voice.members, user)
			slog.Info("voice.leave", "actor", user, "room", room)
		}
		reply(w, 200, map[string]bool{"ok": true})
	default:
		http.Error(w, "invalid action", 400)
	}
}

// voicePresence lists live voice sessions only for authenticated community members.
// Presence is a server-side lease; it does not prove that WebRTC media is flowing.
func (s *Server) voicePresence(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodGet {
		http.Error(w, "method", 405)
		return
	}
	user, err := s.auth(r)
	if err != nil {
		http.Error(w, "unauthorized", 401)
		return
	}
	community := r.URL.Query().Get("community")
	s.mu.Lock()
	var channels []string
	actions := map[string]map[string]bool{}
	for _, c := range s.db.Communities {
		if c.ID == community && s.activeSanction(c, user, "") == nil && (contains(c.Members, user) || s.isSuperadmin(user)) {
			for _, ch := range c.Channels {
				if c.channelType(ch) == "voice" && s.channelPermission(c, user, ch, "VIEW_CHANNEL") {
					channels = append(channels, ch)
					actions[ch] = map[string]bool{"poke": s.activeSanction(c, user, ch) == nil && s.channelPermission(c, user, ch, "POKE_MEMBERS")}
				}
			}
			break
		}
	}
	s.mu.Unlock()
	if channels == nil {
		http.Error(w, "forbidden", 403)
		return
	}
	type participant struct {
		User   string `json:"user"`
		Muted  bool   `json:"muted"`
		Deaf   bool   `json:"deaf"`
		Screen bool   `json:"screen"`
	}
	result := map[string][]participant{}
	for _, ch := range channels {
		result[ch] = []participant{}
	}
	voice.mu.Lock()
	now := time.Now()
	for name, m := range voice.members {
		if now.Sub(m.Seen) > 45*time.Second {
			delete(voice.members, name)
			continue
		}
		for _, ch := range channels {
			if m.Room == community+":"+ch {
				result[ch] = append(result[ch], participant{User: m.User, Muted: m.Muted, Deaf: m.Deaf, Screen: m.Screen})
			}
		}
	}
	voice.mu.Unlock()
	for ch := range result {
		sort.Slice(result[ch], func(i, j int) bool { return result[ch][i].User < result[ch][j].User })
	}
	reply(w, 200, map[string]any{"channels": result, "can_actions": actions, "lease_seconds": 45, "media_verified": false})
}
