package main

import (
	"encoding/json"
	"net/http/httptest"
	"strings"
	"testing"
)

func TestAccountAndMessage(t *testing.T) {
	t.Setenv("EXPLICIT_INITIAL_INVITE_KEY", "TEST-BOOTSTRAP")
	s := newServer(t.TempDir() + "/store.json")
	call := func(path, payload, auth string) *httptest.ResponseRecorder {
		r := httptest.NewRequest("POST", path, strings.NewReader(payload))
		r.Header.Set("Authorization", "Bearer "+auth)
		w := httptest.NewRecorder()
		s.routes().ServeHTTP(w, r)
		return w
	}
	if w := call("/api/register", `{"name":"alice","password":"password123","display_name":"Alice Example","invite_key":"TEST-BOOTSTRAP"}`, ""); w.Code != 201 {
		t.Fatal(w.Body)
	}
	w := call("/api/login", `{"name":"alice","password":"password123"}`, "")
	if w.Code != 200 {
		t.Fatal(w.Body)
	}
	var v map[string]string
	_ = json.Unmarshal(w.Body.Bytes(), &v)
	if w = call("/api/terms", `{"accept":true,"version":"`+currentTermsVersion+`"}`, v["token"]); w.Code != 200 {
		t.Fatal(w.Body)
	}
	if w = call("/api/messages", `{"text":"Olá mundo"}`, v["token"]); w.Code != 201 {
		t.Fatal(w.Body)
	}
	if len(newServer(s.file).db.Messages) != 1 {
		t.Fatal("message not persisted")
	}
}
