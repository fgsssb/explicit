package main

import (
	"net/http"
	"strings"
	"time"
)

// An issued invite is separate from the permanent legacy community code.
// Existing community invitations remain valid for backward compatibility.
type CommunityInvite struct {
	Code      string    `json:"code"`
	Community string    `json:"community"`
	Channel   string    `json:"channel,omitempty"`
	Creator   string    `json:"creator"`
	Created   time.Time `json:"created"`
	Expires   time.Time `json:"expires"`
}

func (s *Server) validCommunityInviteLocked(community, candidate string) bool {
	for _, v := range s.db.CommunityInvites {
		if v.Community == community && strings.EqualFold(v.Code, candidate) && time.Now().Before(v.Expires) {
			return true
		}
	}
	return false
}

func (s *Server) communityInviteAPI(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		http.Error(w, "method", 405)
		return
	}
	actor, err := s.auth(r)
	if err != nil {
		http.Error(w, "unauthorized", 401)
		return
	}
	var q struct {
		Community string `json:"community"`
		Channel   string `json:"channel"`
	}
	if parse(r, &q) != nil {
		http.Error(w, "invalid", 400)
		return
	}
	s.mu.Lock()
	defer s.mu.Unlock()
	for _, c := range s.db.Communities {
		if c.ID != q.Community {
			continue
		}
		if c.JoinClosed {
			http.Error(w, "forbidden", 403)
			return
		}
		if (q.Channel == "" && !s.hasPermission(c, actor, "CREATE_INVITES")) || (q.Channel != "" && (!contains(c.Channels, q.Channel) || !s.channelPermission(c, actor, q.Channel, "VIEW_CHANNEL") || !s.channelPermission(c, actor, q.Channel, "CREATE_INVITES"))) {
			http.Error(w, "forbidden", 403)
			return
		}
		invite := CommunityInvite{Code: token()[:24], Community: c.ID, Channel: q.Channel, Creator: actor, Created: time.Now().UTC(), Expires: time.Now().UTC().Add(7 * 24 * time.Hour)}
		before := len(s.db.CommunityInvites)
		s.db.CommunityInvites = append(s.db.CommunityInvites, invite)
		if err := s.save(); err != nil {
			s.db.CommunityInvites = s.db.CommunityInvites[:before]
			http.Error(w, "storage failure", 500)
			return
		}
		reply(w, 201, invite)
		return
	}
	http.Error(w, "not found", 404)
}
