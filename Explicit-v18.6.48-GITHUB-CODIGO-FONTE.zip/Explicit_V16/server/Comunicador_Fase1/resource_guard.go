package main

import (
	"crypto/sha256"
	"net/http"
	"os"
	"strconv"
	"strings"
	"sync"
	"time"
)

// Lightweight, in-process abuse controls. They protect bursts without requiring
// Redis or another paid service. They are not a distributed rate limiter.
const (
	messageBurst      = 12
	messageWindow     = 10 * time.Second
	uploadBurst       = 5
	uploadWindow      = time.Minute
	uploadConcurrency = 3
	controlBurst      = 18
	controlWindow     = 10 * time.Second
	presetBurst       = 40
	socialBurst       = 12
	profileBurst      = 15
	communityBurst    = 30
	directGroupBurst  = 6
)

type writeWindow struct {
	used []time.Time
	last time.Time
}
type resourceGuard struct {
	mu      sync.Mutex
	windows map[string]writeWindow
	repeats map[string][]time.Time
	uploads chan struct{}
}

func newResourceGuard() *resourceGuard {
	return &resourceGuard{windows: make(map[string]writeWindow), repeats: make(map[string][]time.Time), uploads: make(chan struct{}, uploadConcurrency)}
}
func (g *resourceGuard) allow(user, category string, now time.Time) bool {
	window, max := messageWindow, messageBurst
	if category == "upload" {
		window, max = uploadWindow, uploadBurst
	} else if category == "control" {
		window, max = controlWindow, controlBurst
	}
	switch category {
	case "voice_poke":
		window, max = 20*time.Second, 1
	case "preset":
		window, max = time.Minute, presetBurst
	case "social":
		window, max = time.Minute, socialBurst
	case "profile":
		window, max = time.Minute, profileBurst
	case "community":
		window, max = time.Minute, communityBurst
	case "direct_group":
		window, max = time.Minute, directGroupBurst
	case "voice":
		// ICE signalling can legitimately burst; reject sustained abuse only.
		window, max = 10*time.Second, 120
	case "livekit_token":
		window, max = 30*time.Second, 12
	case "presence":
		window, max = 10*time.Second, 90
	}
	// Env overrides are conservative; invalid values fall back to defaults.
	envKey := "EXPLICIT_RATE_" + strings.ToUpper(category) + "_BURST"
	if value := strings.TrimSpace(os.Getenv(envKey)); value != "" {
		if v, err := strconv.Atoi(value); err == nil && v >= 1 && v <= 1000 {
			max = v
		}
	}
	windowKey := "EXPLICIT_RATE_" + strings.ToUpper(category) + "_WINDOW_SECONDS"
	if value := strings.TrimSpace(os.Getenv(windowKey)); value != "" {
		if v, err := strconv.Atoi(value); err == nil && v >= 1 && v <= 3600 {
			window = time.Duration(v) * time.Second
		}
	}
	key := user + "\x00" + category
	g.mu.Lock()
	defer g.mu.Unlock()
	// Keep the table bounded when transient accounts stop sending requests.
	if len(g.windows) > 1024 {
		for k, v := range g.windows {
			if now.Sub(v.last) > 2*time.Minute {
				delete(g.windows, k)
			}
		}
	}
	cur := g.windows[key]
	n := 0
	for _, at := range cur.used {
		if now.Sub(at) < window {
			cur.used[n] = at
			n++
		}
	}
	cur.used = cur.used[:n]
	cur.last = now
	if n >= max {
		g.windows[key] = cur
		return false
	}
	cur.used = append(cur.used, now)
	g.windows[key] = cur
	return true
}
func expensivePostCategory(path string) string {
	switch path {
	case "/api/messages", "/api/channel-messages", "/api/direct":
		return "message"
	case "/api/voice":
		return "voice"
	case "/api/livekit-token":
		return "livekit_token"
	case "/api/presence", "/api/presence-heartbeat":
		return "presence"
	case "/api/image", "/api/video", "/api/visual", "/api/direct-file", "/api/stickers":
		return "upload"
	case "/api/name-presets":
		return "preset"
	case "/api/social":
		return "social"
	case "/api/profile":
		return "profile"
	case "/api/communities", "/api/channel-delete", "/api/channel-permissions":
		return "community"
	case "/api/storage", "/api/community-invite", "/api/direct-call", "/api/community-admin", "/api/system-admin", "/api/staff-control", "/api/staff-dm", "/api/spotlight", "/api/announcements", "/api/sanctions", "/api/voice-moderation", "/api/community-hub", "/api/invite", "/api/report", "/api/message-actions":
		return "control"
	default:
		return ""
	}
}
func (s *Server) protectExpensiveWrites(w http.ResponseWriter, r *http.Request) (release func(), ok bool) {
	if r.Method != http.MethodPost {
		return func() {}, true
	}
	category := expensivePostCategory(r.URL.Path)
	if r.URL.Path == "/api/stickers" && !strings.HasPrefix(r.Header.Get("Content-Type"), "multipart/form-data") {
		category = ""
	}
	if category == "" {
		return func() {}, true
	}
	// For /api/direct, POST also creates chats / marks messages. A generous
	// shared per-user limit prevents write floods without blocking normal use.
	user, err := s.auth(r)
	if err != nil {
		http.Error(w, "unauthorized", http.StatusUnauthorized)
		return nil, false
	}
	if s.resources == nil {
		// Some unit fixtures construct Server directly. Production servers always
		// initialize the guard in newServer, before accepting requests.
		return func() {}, true
	}
	if !s.resources.allow(user, category, time.Now()) {
		wait := 10
		if category == "upload" || category == "social" || category == "preset" || category == "profile" || category == "community" {
			wait = 60
		}
		if category == "direct_group" {
			wait = 60
		}
		w.Header().Set("Retry-After", strconv.Itoa(wait))
		http.Error(w, "Too many requests. Try again shortly.", http.StatusTooManyRequests)
		return nil, false
	}
	if category == "upload" {
		select {
		case s.resources.uploads <- struct{}{}:
			return func() { <-s.resources.uploads }, true
		default:
			w.Header().Set("Retry-After", "5")
			http.Error(w, "Uploads are busy. Try again shortly.", http.StatusServiceUnavailable)
			return nil, false
		}
	}
	return func() {}, true
}

// A user can send short repeated text occasionally, but a bot sending the same
// content into many channels/DMs within seconds is rate-limited server-side.
func (g *resourceGuard) excessiveRepeat(user, message string, now time.Time) bool {
	if g == nil {
		return false
	}
	canonical := strings.ToLower(strings.Join(strings.Fields(message), " "))
	if len(canonical) < 2 {
		return false
	}
	digest := sha256.Sum256([]byte(canonical))
	key := user + "#" + string(digest[:])
	g.mu.Lock()
	defer g.mu.Unlock()
	if g.repeats == nil {
		g.repeats = map[string][]time.Time{}
	}
	if len(g.repeats) > 1024 {
		for k, stamps := range g.repeats {
			if len(stamps) == 0 || now.Sub(stamps[len(stamps)-1]) > 30*time.Second {
				delete(g.repeats, k)
			}
		}
	}
	stamps := g.repeats[key][:0]
	for _, at := range g.repeats[key] {
		if now.Sub(at) < 20*time.Second {
			stamps = append(stamps, at)
		}
	}
	if len(stamps) >= 4 {
		g.repeats[key] = stamps
		return true
	}
	g.repeats[key] = append(stamps, now)
	return false
}
func abusiveMessageText(text string) bool {
	return strings.Count(text, "@") > 15 || strings.ContainsRune(text, '\x00')
}
