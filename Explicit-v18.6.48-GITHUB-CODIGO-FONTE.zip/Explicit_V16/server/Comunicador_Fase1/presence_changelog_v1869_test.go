package main

import (
	"bytes"
	"encoding/json"
	"net/http"
	"net/http/httptest"
	"path/filepath"
	"strings"
	"testing"
	"time"
)

func TestV1870BackgroundStaysAwayUntilExplicitExit(t *testing.T) {
	s := newServer(filepath.Join(t.TempDir(), "data.json"))
	const user = "v1869_presence_alice"
	s.db.Users[user] = User{Name: user, PreferredStatus: "online"}
	s.db.Users["v1869_presence_bob"] = User{Name: "v1869_presence_bob"}
	s.db.Communities = []Community{{ID: "presence_1869", Owner: user, Members: []string{user, "v1869_presence_bob"}}}
	s.sessions["v1869-alice-token"] = user
	s.sessions["v1869-bob-token"] = "v1869_presence_bob"
	call := func(method, url, auth, body string) *httptest.ResponseRecorder {
		r := httptest.NewRequest(method, url, bytes.NewBufferString(body))
		r.Header.Set("Authorization", "Bearer "+auth)
		w := httptest.NewRecorder()
		s.routes().ServeHTTP(w, r)
		if w.Code != http.StatusOK {
			t.Fatalf("%s %s: %d %s", method, url, w.Code, w.Body.String())
		}
		return w
	}
	status := func() string {
		w := call("GET", "/api/presence?community=presence_1869", "v1869-bob-token", "")
		var data struct {
			Members []struct {
				User, Status string
				Online       bool
			} `json:"members"`
		}
		if e := json.Unmarshal(w.Body.Bytes(), &data); e != nil {
			t.Fatal(e)
		}
		if len(data.Members) != 2 {
			t.Fatalf("members: %+v", data)
		}
		return data.Members[0].Status
	}
	call("POST", "/api/presence-heartbeat", "v1869-alice-token", `{"client":"browser1869","background":false}`)
	if got := status(); got != "online" {
		t.Fatalf("foreground: %s", got)
	}
	call("POST", "/api/presence-heartbeat", "v1869-alice-token", `{"client":"browser1869","background":true}`)
	call("GET", "/api/notifications", "v1869-alice-token", "") // notifications must not undo background.
	if got := status(); got != "away" {
		t.Fatalf("hidden background: %s", got)
	}
	online.entries[user]["browser1869"] = time.Now().Add(-21 * time.Second)
	if got := status(); got != "away" {
		t.Fatalf("throttled heartbeat: %s", got)
	}
	online.entries[user]["browser1869"] = time.Now().Add(-72 * time.Hour)
	// There is no timeout-based Offline transition, even after several days.
	delete(online.entries[user], notificationPresenceKey("Bearer v1869-alice-token"))
	if got := status(); got != "away" {
		t.Fatalf("stale session must remain away, got: %s", got)
	}
	call("POST", "/api/presence-heartbeat", "v1869-alice-token", `{"client":"browser1869","background":false}`)
	if got := status(); got != "online" {
		t.Fatalf("reactivated: %s", got)
	}
	call("POST", "/api/logout", "v1869-alice-token", "")
	if got := status(); got != "offline" {
		t.Fatalf("logout: %s", got)
	}
}

func TestV1869ChangelogDefaultAndPersistentAdminChoice(t *testing.T) {
	s := newServer(filepath.Join(t.TempDir(), "state.json"))
	s.db.Users["news1869_admin"] = User{Name: "news1869_admin", SystemRole: "superadmin"}
	s.sessions["news1869-token"] = "news1869_admin"
	read := func() map[string]string {
		w := httptest.NewRecorder()
		s.routes().ServeHTTP(w, httptest.NewRequest("GET", "/api/home-mode", nil))
		if w.Code != 200 {
			t.Fatalf("read mode: %d", w.Code)
		}
		var data map[string]string
		if e := json.Unmarshal(w.Body.Bytes(), &data); e != nil {
			t.Fatal(e)
		}
		return data
	}
	if initial := read(); initial["mode"] != "changelog" || !strings.Contains(initial["changelog"], "Explicit 18.6.8") {
		t.Fatalf("default: %+v", initial)
	}
	switchMode := func(mode, text string) {
		data, _ := json.Marshal(map[string]string{"action": "set_home_mode", "role": mode, "reason": text})
		request := httptest.NewRequest("POST", "/api/system-admin", bytes.NewBuffer(data))
		request.Header.Set("Authorization", "Bearer news1869-token")
		w := httptest.NewRecorder()
		s.routes().ServeHTTP(w, request)
		if w.Code != 200 {
			t.Fatalf("save %s: %d %s", mode, w.Code, w.Body.String())
		}
	}
	// An old stored spotlight choice is migrated once; future explicit choices persist.
	s.db.HomeMode = "spotlight"
	if got := read()["mode"]; got != "changelog" {
		t.Fatalf("migration should start on news: %s", got)
	}
	switchMode("spotlight", "")
	if got := read()["mode"]; got != "spotlight" {
		t.Fatalf("spotlight not selected: %s", got)
	}
	switchMode("changelog", "Explicit 18.6.9\nCorrigido\n• Teste")
	if got := read(); got["mode"] != "changelog" || !strings.Contains(got["changelog"], "• Teste") {
		t.Fatalf("saved news: %+v", got)
	}
}
