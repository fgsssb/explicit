package main

import (
	"encoding/json"
	"net/http"
	"os"
	"path/filepath"
	"strings"
	"time"
)

type auditEntry struct {
	At        time.Time `json:"at"`
	Community string    `json:"community"`
	Actor     string    `json:"actor"`
	Action    string    `json:"action"`
	Details   string    `json:"details"`
}

// Called while the store mutex is held; failures are logged by the caller where appropriate.
func (s *Server) appendAudit(community, actor, action, details string) {
	entry := auditEntry{At: time.Now().UTC(), Community: community, Actor: actor, Action: action, Details: details}
	if s.isSuperadmin(actor) {
		s.staffAuditLocked(actor, "community_"+action, community, details)
		_ = s.save()
	}
	b, err := json.Marshal(entry)
	if err != nil {
		return
	}
	path := filepath.Join(filepath.Dir(s.file), "audit.jsonl")
	if os.MkdirAll(filepath.Dir(path), 0700) != nil {
		return
	}
	f, err := os.OpenFile(path, os.O_CREATE|os.O_APPEND|os.O_WRONLY, 0600)
	if err != nil {
		return
	}
	defer f.Close()
	_, _ = f.Write(append(b, '\n'))
}
func (s *Server) communityAudit(w http.ResponseWriter, r *http.Request) {
	if r.Method != "GET" {
		http.Error(w, "method", 405)
		return
	}
	user, err := s.auth(r)
	if err != nil {
		http.Error(w, "unauthorized", 401)
		return
	}
	community := r.URL.Query().Get("community")
	s.mu.Lock()
	defer s.mu.Unlock()
	var found *Community
	for i := range s.db.Communities {
		if s.db.Communities[i].ID == community {
			found = &s.db.Communities[i]
			break
		}
	}
	if found == nil || (!contains(found.Members, user) && !s.isSuperadmin(user)) || !(found.Owner == user || s.hasPermission(*found, user, "VIEW_AUDIT_LOG")) {
		http.Error(w, "forbidden", 403)
		return
	}
	data, err := os.ReadFile(filepath.Join(filepath.Dir(s.file), "audit.jsonl"))
	if os.IsNotExist(err) {
		reply(w, 200, []auditEntry{})
		return
	}
	if err != nil {
		http.Error(w, "read failure", 500)
		return
	}
	lines := strings.Split(string(data), "\n")
	entries := make([]auditEntry, 0)
	for i := len(lines) - 1; i >= 0 && len(entries) < 200; i-- {
		if strings.TrimSpace(lines[i]) == "" {
			continue
		}
		var e auditEntry
		if json.Unmarshal([]byte(lines[i]), &e) == nil && e.Community == community {
			entries = append(entries, e)
		}
	}
	reply(w, 200, entries)
}
