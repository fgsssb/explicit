package main

import (
	"io"
	"net/http"
	"strings"
	"sync/atomic"
	"testing"
	"time"
)

func round4MediaFixture(t *testing.T) *Server {
	t.Helper()
	s := auditFixture(t)
	c := &s.db.Communities[0]
	c.Channels = append(c.Channels, "voice")
	c.ChannelMeta["voice"] = ChannelMeta{Type: "voice"}
	voice.mu.Lock()
	old := voice.members
	voice.members = map[string]*voiceMember{"member": {User: "member", Room: "audit-community:voice", Seen: time.Now()}, "third": {User: "third", Room: "elsewhere:voice", Seen: time.Now()}}
	voice.mu.Unlock()
	t.Cleanup(func() { voice.mu.Lock(); voice.members = old; voice.mu.Unlock() })
	return s
}

func TestAuditRound4CommunityExitRevokesMedia(t *testing.T) {
	for _, action := range []string{"leave", "delete"} {
		for _, mode := range []string{"success", "media_failure", "save_failure"} {
			t.Run(action+"/"+mode, func(t *testing.T) {
				s := round4MediaFixture(t)
				status := 200
				if mode == "media_failure" {
					status = 503
				}
				var calls []map[string]any
				auditMedia(t, s, &status, &calls)
				if mode == "save_failure" {
					s.file = t.TempDir()
				}
				actor := "member"
				path := "/api/communities"
				body := map[string]any{"leave": "audit-community"}
				if action == "delete" {
					actor = "owner"
					path = "/api/community-hub"
					body = map[string]any{"community": "audit-community", "action": "delete_community", "name": "Audit", "confirm": true}
				}
				w := auditRequest(t, s, actor, path, body)
				if mode == "save_failure" {
					if w.Code != 500 || len(calls) != 0 {
						t.Fatalf("failed save must not disconnect: %d calls=%v", w.Code, calls)
					}
					voice.mu.Lock()
					_, present := voice.members["member"]
					voice.mu.Unlock()
					if !present {
						t.Fatal("failed save removed voice presence")
					}
					return
				}
				want := 200
				if mode == "media_failure" {
					want = 502
				}
				if w.Code != want {
					t.Fatalf("status %d want %d: %s", w.Code, want, w.Body.String())
				}
				if len(calls) != 1 || calls[0]["room"] != "audit-community:voice" || calls[0]["identity"] != "member" || !strings.HasSuffix(calls[0]["method"].(string), "/RemoveParticipant") {
					t.Fatalf("missing or wrong media revocation: %v", calls)
				}
				voice.mu.Lock()
				_, left := voice.members["member"]
				_, other := voice.members["third"]
				voice.mu.Unlock()
				if left || !other {
					t.Fatal("wrong presence cleanup")
				}
				if action == "leave" && contains(s.db.Communities[0].Members, "member") {
					t.Fatal("membership not removed")
				}
				if action == "delete" && len(s.db.Communities) != 0 {
					t.Fatal("community not removed")
				}
				restored := newServer(s.file)
				if action == "leave" && contains(restored.db.Communities[0].Members, "member") {
					t.Fatal("membership removal not persisted")
				}
				if action == "delete" && len(restored.db.Communities) != 0 {
					t.Fatal("community deletion not persisted")
				}
				if mode == "media_failure" {
					marker := "membership_removed"
					if action == "delete" {
						marker = "community_deleted"
					}
					if !strings.Contains(w.Body.String(), marker) {
						t.Fatal("partial media failure not explicit")
					}
				}
			})
		}
	}
}

func TestAuditRound4CannotExitAnotherUsersCommunityMembership(t *testing.T) {
	s := round4MediaFixture(t)
	status := http.StatusOK
	var calls []map[string]any
	auditMedia(t, s, &status, &calls)
	if w := auditRequest(t, s, "outsider", "/api/communities", map[string]string{"leave": "audit-community"}); w.Code != 403 {
		t.Fatal(w.Code)
	}
	if len(calls) != 0 {
		t.Fatal("unauthorized request reached media control")
	}
}

func TestAuditRound4MediaCleanupAttemptsEveryParticipant(t *testing.T) {
	t.Setenv("LIVEKIT_WS_URL", "wss://media.example.test")
	t.Setenv("LIVEKIT_API_KEY", "fixture-api-key-123456")
	t.Setenv("LIVEKIT_API_SECRET", strings.Repeat("s", 40))
	old := http.DefaultTransport
	var count atomic.Int32
	http.DefaultTransport = auditTransport(func(r *http.Request) (*http.Response, error) {
		n := count.Add(1)
		status := 200
		if n == 1 {
			status = 503
		}
		return &http.Response{StatusCode: status, Status: http.StatusText(status), Body: io.NopCloser(strings.NewReader(`{}`)), Header: make(http.Header)}, nil
	})
	t.Cleanup(func() { http.DefaultTransport = old })
	err := revokeCommunityMedia([]communityMediaRemoval{{room: "c:voice", identity: "a"}, {room: "c:voice", identity: "b"}})
	if err == nil || count.Load() != 2 {
		t.Fatalf("cleanup failed to attempt all participants: err=%v count=%d", err, count.Load())
	}
}
