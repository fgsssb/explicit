package main

import (
	"testing"
	"time"
)

func TestSanctionScopeAndExpiry(t *testing.T) {
	s := newServer(t.TempDir() + "/db.json")
	c := Community{ID: "a", Owner: "owner", Members: []string{"owner", "member"}, Channels: []string{"general", "voice"}}
	s.db.Communities = []Community{c}
	end := time.Now().UTC().Add(time.Hour)
	s.db.Sanctions = []Sanction{{ID: "1", Community: "a", Channel: "voice", Target: "member", Type: "channel_ban", Expires: &end}}
	if s.activeSanction(c, "member", "voice") == nil {
		t.Fatal("voice must be blocked")
	}
	if s.activeSanction(c, "member", "general") != nil {
		t.Fatal("general must remain available")
	}
	past := time.Now().UTC().Add(-time.Second)
	s.db.Sanctions[0].Expires = &past
	if s.activeSanction(c, "member", "voice") != nil {
		t.Fatal("expired sanction still active")
	}
	s.db.Sanctions[0].Expires = nil
	if s.activeSanction(c, "member", "voice") == nil {
		t.Fatal("permanent sanction not active")
	}
}
