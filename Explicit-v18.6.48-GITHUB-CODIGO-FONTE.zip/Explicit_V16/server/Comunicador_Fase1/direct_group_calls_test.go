package main

import (
	"encoding/json"
	"net/http"
	"net/http/httptest"
	"strings"
	"testing"
)

func TestGroupDirectMessagesAndCallsRequireMembership(t *testing.T) {
	s := newServer(t.TempDir() + "/db.json")
	s.mu.Lock()
	for _, name := range []string{"alice", "bob", "charlie", "outsider"} {
		s.db.Users[name] = User{Name: name, DisplayName: name}
	}
	s.sessions["t-alice"] = "alice"
	s.sessions["t-bob"] = "bob"
	s.sessions["t-charlie"] = "charlie"
	s.sessions["t-outsider"] = "outsider"
	for _, name := range []string{"bob", "charlie"} {
		s.db.Friends = append(s.db.Friends, FriendRequest{From: "alice", To: name, Status: "accepted"})
	}
	s.mu.Unlock()
	call := func(username, method, path, body string) *httptest.ResponseRecorder {
		request := httptest.NewRequest(method, path, strings.NewReader(body))
		request.Header.Set("Authorization", "Bearer t-"+username)
		response := httptest.NewRecorder()
		s.routes().ServeHTTP(response, request)
		return response
	}
	create := call("alice", "POST", "/api/direct", `{"action":"create_group","targets":["bob","charlie"],"name":"Equipe"}`)
	if create.Code != 201 {
		t.Fatalf("create group: %d %s", create.Code, create.Body.String())
	}
	var chat DirectChat
	if err := json.Unmarshal(create.Body.Bytes(), &chat); err != nil || len(chat.Users) != 3 || chat.Name != "Equipe" {
		t.Fatalf("wrong group: %+v %v", chat, err)
	}
	if r := call("outsider", "GET", "/api/direct?id="+chat.ID, ""); r.Code != 404 {
		t.Fatalf("outsider read: %d", r.Code)
	}
	if r := call("outsider", "POST", "/api/direct", `{"action":"send","id":"`+chat.ID+`","text":"intrusion"}`); r.Code != 404 {
		t.Fatalf("outsider send: %d", r.Code)
	}
	if r := call("alice", "POST", "/api/direct", `{"action":"add_members","id":"`+chat.ID+`","targets":["outsider"]}`); r.Code != 403 {
		t.Fatalf("non-friend invite: %d", r.Code)
	}
	if r := call("bob", "POST", "/api/direct", `{"action":"rename_group","id":"`+chat.ID+`","name":"Amigos"}`); r.Code != 200 {
		t.Fatalf("member should be able to rename: %d", r.Code)
	}
	if r := call("outsider", "POST", "/api/direct", `{"action":"rename_group","id":"`+chat.ID+`","name":"Attack"}`); r.Code != 404 {
		t.Fatalf("outsider rename: %d", r.Code)
	}
	if r := call("bob", "POST", "/api/direct", `{"action":"send","id":"`+chat.ID+`","text":"Oi, grupo!"}`); r.Code != 200 {
		t.Fatalf("group send: %d %s", r.Code, r.Body.String())
	}
	if r := call("alice", "GET", "/api/direct?id="+chat.ID, ""); r.Code != 200 || !strings.Contains(r.Body.String(), "Oi, grupo!") {
		t.Fatalf("missing group message: %d", r.Code)
	}
	if r := call("alice", "POST", "/api/notifications", `{"action":"read_group","id":"`+chat.ID+`"}`); r.Code != 200 {
		t.Fatalf("read group: %d %s", r.Code, r.Body.String())
	}
	if r := call("outsider", "POST", "/api/notifications", `{"action":"read_group","id":"`+chat.ID+`"}`); r.Code != 404 {
		t.Fatalf("outsider read cursor: %d", r.Code)
	}
	if r := call("bob", "POST", "/api/direct-call", `{"action":"peek","id":"`+chat.ID+`"}`); r.Code != 200 || !strings.Contains(r.Body.String(), `"active":false`) {
		t.Fatalf("empty call peek: %d %s", r.Code, r.Body.String())
	}
	if r := call("outsider", "POST", "/api/direct-call", `{"action":"peek","id":"`+chat.ID+`"}`); r.Code != 404 {
		t.Fatalf("outsider peek: %d", r.Code)
	}
	// Check no call credentials are leaked before LiveKit configuration.
	if r := call("outsider", "POST", "/api/direct-call", `{"action":"join","id":"`+chat.ID+`"}`); r.Code != 404 {
		t.Fatalf("outsider call join: %d", r.Code)
	}
	if r := call("alice", "POST", "/api/direct-call", `{"action":"join","id":"`+chat.ID+`"}`); r.Code != http.StatusServiceUnavailable {
		t.Fatalf("missing LiveKit must fail safely: %d", r.Code)
	}
	// Only authorized members can obtain a scoped media token when LiveKit is ready.
	t.Setenv("LIVEKIT_WS_URL", "wss://media.example.org")
	t.Setenv("LIVEKIT_API_KEY", "test-media-api-key-12345")
	t.Setenv("LIVEKIT_API_SECRET", "test-media-secret-1234567890-abcdefghijklmnopqrstuvwxyz")
	access := call("alice", "POST", "/api/direct-call", `{"action":"join","id":"`+chat.ID+`"}`)
	if access.Code != 200 {
		t.Fatalf("member call join: %d %s", access.Code, access.Body.String())
	}
	var grant struct {
		Token string `json:"token"`
		URL   string `json:"url"`
	}
	if err := json.Unmarshal(access.Body.Bytes(), &grant); err != nil || grant.URL != "wss://media.example.org" || len(strings.Split(grant.Token, ".")) != 3 {
		t.Fatalf("invalid signed token: %+v %v", grant, err)
	}
	if r := call("outsider", "POST", "/api/direct-call", `{"action":"join","id":"`+chat.ID+`"}`); r.Code != 404 {
		t.Fatalf("outsider media token: %d", r.Code)
	}
	if r := call("bob", "POST", "/api/direct-call", `{"action":"peek","id":"`+chat.ID+`"}`); r.Code != 200 || !strings.Contains(r.Body.String(), `"active":true`) || !strings.Contains(r.Body.String(), "alice") {
		t.Fatalf("incoming call is not visible: %d %s", r.Code, r.Body.String())
	}
	if r := call("alice", "POST", "/api/direct-call", `{"action":"poll","id":"`+chat.ID+`"}`); r.Code != 200 {
		t.Fatalf("member call heartbeat: %d", r.Code)
	}
	if r := call("alice", "POST", "/api/direct-call", `{"action":"screen","id":"`+chat.ID+`","screen":true}`); r.Code != 200 {
		t.Fatalf("screen status: %d", r.Code)
	}
	if r := call("alice", "POST", "/api/direct-call", `{"action":"leave","id":"`+chat.ID+`"}`); r.Code != 200 {
		t.Fatalf("call leave: %d", r.Code)
	}
	// Member leaves and loses access to the group and its calls.
	if r := call("charlie", "POST", "/api/direct", `{"action":"leave_group","id":"`+chat.ID+`"}`); r.Code != 200 {
		t.Fatalf("leave: %d", r.Code)
	}
	if r := call("charlie", "GET", "/api/direct?id="+chat.ID, ""); r.Code != 404 {
		t.Fatalf("ex-member read: %d", r.Code)
	}
}
