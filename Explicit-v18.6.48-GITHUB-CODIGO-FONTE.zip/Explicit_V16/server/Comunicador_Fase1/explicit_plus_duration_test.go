package main

import (
	"bytes"
	"encoding/json"
	"net/http/httptest"
	"path/filepath"
	"testing"
	"time"
)

func explicitPlusRequest(s *Server, actor string, q map[string]any) *httptest.ResponseRecorder {
	data, _ := json.Marshal(q)
	r := httptest.NewRequest("POST", "/api/system-admin", bytes.NewReader(data))
	r.Header.Set("Authorization", "Bearer "+actor+"-token")
	w := httptest.NewRecorder()
	s.routes().ServeHTTP(w, r)
	return w
}
func TestExplicitPlusTimeGrantExpiryRenewAndPersistence(t *testing.T) {
	s := newServer(filepath.Join(t.TempDir(), "db.json"))
	s.db.Users["admin"] = User{Name: "admin", SystemRole: "admin"}
	s.db.Users["beta"] = User{Name: "beta", SystemRole: "user"}
	s.db.Users["alice"] = User{Name: "alice", SystemRole: "user"}
	s.sessions["admin-token"] = "admin"
	s.sessions["alice-token"] = "alice"
	grant := map[string]any{"action": "set_badges", "target": "alice", "badges": []string{"explicit_plus"}}
	if w := explicitPlusRequest(s, "admin", grant); w.Code != 400 {
		t.Fatalf("grant without time: %d %s", w.Code, w.Body)
	}
	grant["duration_seconds"] = int64(2)
	if w := explicitPlusRequest(s, "admin", grant); w.Code != 200 {
		t.Fatalf("admin grant: %d %s", w.Code, w.Body)
	}
	u := s.db.Users["alice"]
	if !explicitPlusActive(u) || u.ExplicitPlusExpiresAt == nil || !s.maySendStickersLocked("alice") || !hasNameStyles(u) {
		t.Fatalf("expected active plus: %+v", u)
	}
	persisted := newServer(s.file).db.Users["alice"]
	if !explicitPlusActive(persisted) {
		t.Fatal("grant not persisted")
	}
	end := time.Now().Add(-time.Second)
	u.ExplicitPlusExpiresAt = &end
	s.db.Users["alice"] = u
	if explicitPlusActive(u) || s.maySendStickersLocked("alice") || hasNameStyles(u) {
		t.Fatal("expired entitlement still active")
	}
	if len(userBadges(u)) != 0 {
		t.Fatal("expired badge still shown")
	}
	change := map[string]any{"action": "set_explicit_plus_duration", "target": "alice", "duration_seconds": 3600, "duration_mode": "replace"}
	if w := explicitPlusRequest(s, "admin", change); w.Code != 200 {
		t.Fatalf("renew: %d %s", w.Code, w.Body)
	}
	u = s.db.Users["alice"]
	first := *u.ExplicitPlusExpiresAt
	change["duration_mode"] = "extend"
	if w := explicitPlusRequest(s, "admin", change); w.Code != 200 {
		t.Fatalf("extend: %d %s", w.Code, w.Body)
	}
	u = s.db.Users["alice"]
	if u.ExplicitPlusExpiresAt.Sub(first) < time.Hour-time.Second {
		t.Fatal("extend did not add requested time")
	}
	if w := explicitPlusRequest(s, "admin", map[string]any{"action": "set_badges", "target": "alice", "badges": []string{}}); w.Code != 200 {
		t.Fatalf("revoke %v", w)
	}
	if s.db.Users["alice"].ExplicitPlus || s.db.Users["alice"].ExplicitPlusExpiresAt != nil {
		t.Fatal("revoke did not clear badge and time")
	}
}
func TestExplicitPlusPermissionsAndOldGrant(t *testing.T) {
	s := newServer(filepath.Join(t.TempDir(), "db.json"))
	s.db.Users["user"] = User{Name: "user"}
	s.db.Users["admin"] = User{Name: "admin", SystemRole: "admin"}
	s.db.Users["legacy"] = User{Name: "legacy", ExplicitPlus: true}
	s.sessions["user-token"] = "user"
	s.sessions["admin-token"] = "admin"
	if w := explicitPlusRequest(s, "user", map[string]any{"action": "set_badges", "target": "legacy", "badges": []string{"explicit_plus"}, "duration_seconds": 5}); w.Code != 403 {
		t.Fatalf("unauthorized: %d", w.Code)
	}
	if !explicitPlusActive(s.db.Users["legacy"]) {
		t.Fatal("legacy grant incorrectly revoked")
	}
	if w := explicitPlusRequest(s, "admin", map[string]any{"action": "set_explicit_plus_duration", "target": "legacy", "duration_seconds": -1, "duration_mode": "replace"}); w.Code != 400 {
		t.Fatalf("negative duration: %d", w.Code)
	}
	if w := explicitPlusRequest(s, "admin", map[string]any{"action": "set_explicit_plus_duration", "target": "legacy", "duration_seconds": 315360001, "duration_mode": "replace"}); w.Code != 400 {
		t.Fatalf("excessive duration: %d", w.Code)
	}
}
