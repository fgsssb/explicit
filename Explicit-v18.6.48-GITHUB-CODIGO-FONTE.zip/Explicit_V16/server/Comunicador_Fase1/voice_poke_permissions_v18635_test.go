package main

import (
	"bytes"
	"encoding/json"
	"net/http/httptest"
	"path/filepath"
	"testing"
	"time"
)

func TestVoicePokeRequiresEffectiveChannelPermissionsAndSameRoom(t *testing.T) {
	s := newServer(filepath.Join(t.TempDir(), "poke.json"))
	s.resources = nil // The test validates authorization, not rate-limiting windows.
	for _, u := range []string{"owner", "alice", "bob", "outsider"} {
		s.db.Users[u] = User{Name: u}
		s.sessions[u+"-token"] = u
	}
	s.db.Communities = []Community{{
		ID: "room", Name: "Room", Owner: "owner", Members: []string{"owner", "alice", "bob"},
		Channels:    []string{"geral", "outro"},
		Roles:       []Role{{ID: "friends", Name: "Amigos", Priority: 10, Permissions: []string{"POKE_MEMBERS"}}},
		MemberRoles: map[string][]string{},
		ChannelMeta: map[string]ChannelMeta{"geral": {Type: "voice"}, "outro": {Type: "voice"}},
	}}
	voice.mu.Lock()
	voice.members = map[string]*voiceMember{
		"alice": {User: "alice", Room: "room:geral", Seen: time.Now()},
		"bob":   {User: "bob", Room: "room:geral", Seen: time.Now()},
	}
	voice.mu.Unlock()
	defer func() { voice.mu.Lock(); voice.members = map[string]*voiceMember{}; voice.mu.Unlock() }()
	poke := func(actor string) int {
		t.Helper()
		b, _ := json.Marshal(map[string]any{"community": "room", "target": "bob", "channel": "geral", "action": "poke"})
		req := httptest.NewRequest("POST", "/api/voice-moderation", bytes.NewReader(b))
		req.Header.Set("Authorization", "Bearer "+actor+"-token")
		rr := httptest.NewRecorder()
		s.voiceModeration(rr, req)
		return rr.Code
	}
	presence := func(actor string) map[string]any {
		t.Helper()
		req := httptest.NewRequest("GET", "/api/voice-presence?community=room", nil)
		req.Header.Set("Authorization", "Bearer "+actor+"-token")
		rr := httptest.NewRecorder()
		s.voicePresence(rr, req)
		if rr.Code != 200 {
			t.Fatalf("presence %s: %d %s", actor, rr.Code, rr.Body.String())
		}
		var decoded map[string]any
		if err := json.Unmarshal(rr.Body.Bytes(), &decoded); err != nil {
			t.Fatal(err)
		}
		return decoded
	}
	canPoke := func(actor string) bool {
		t.Helper()
		return presence(actor)["can_actions"].(map[string]any)["geral"].(map[string]any)["poke"].(bool)
	}
	if poke("alice") != 403 || canPoke("alice") {
		t.Fatal("ordinary member should not have poke without grant")
	}
	s.db.Communities[0].MemberRoles["alice"] = []string{"friends"}
	if !canPoke("alice") || poke("alice") != 200 {
		t.Fatal("role permission not effective for poke")
	}
	voice.mu.Lock()
	events := append([]voiceSignal(nil), voice.members["bob"].Queue...)
	voice.mu.Unlock()
	if len(events) != 1 || events[0].Kind != "poke" || events[0].From != "alice" {
		t.Fatalf("unexpected poke event: %+v", events)
	}
	meta := s.db.Communities[0].ChannelMeta["geral"]
	meta.RolePermissions = map[string]map[string]bool{"everyone": {"POKE_MEMBERS": false}}
	s.db.Communities[0].ChannelMeta["geral"] = meta
	if canPoke("alice") || poke("alice") != 403 {
		t.Fatal("channel override deny must block role poke")
	}
	meta.RolePermissions["friends"] = map[string]bool{"POKE_MEMBERS": true}
	s.db.Communities[0].ChannelMeta["geral"] = meta
	if !canPoke("alice") {
		t.Fatal("specific role channel override should beat everyone deny")
	}
	meta.MemberPermissions = map[string]map[string]bool{"alice": {"POKE_MEMBERS": false}}
	s.db.Communities[0].ChannelMeta["geral"] = meta
	if canPoke("alice") {
		t.Fatal("individual member deny must win")
	}
	delete(meta.MemberPermissions, "alice")
	s.db.Communities[0].ChannelMeta["geral"] = meta
	voice.mu.Lock()
	voice.members["alice"].Room = "room:outro"
	voice.mu.Unlock()
	if poke("alice") != 403 {
		t.Fatal("poke must require both users in the same room")
	}
	if poke("outsider") != 403 {
		t.Fatal("nonmember must not poke")
	}
}
