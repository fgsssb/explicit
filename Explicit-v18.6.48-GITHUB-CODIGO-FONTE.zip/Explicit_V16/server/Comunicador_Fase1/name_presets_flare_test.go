package main

import (
	"encoding/json"
	"testing"
)

func TestV18617FlareDefaultsAndValidation(t *testing.T) {
	legacy := exampleNameStyle()
	if !validNameStyle(legacy) {
		t.Fatal("old presets must stay valid")
	}
	flared := legacy
	flared.Flare = true
	flared.FlareColor = "#89bfff"
	flared.FlareIntensity = 75
	if !validNameStyle(flared) {
		t.Fatal("valid flare refused")
	}
	encoded, err := json.Marshal(flared)
	if err != nil {
		t.Fatal(err)
	}
	var restored NameStyle
	if err := json.Unmarshal(encoded, &restored); err != nil {
		t.Fatal(err)
	}
	if !restored.Flare || restored.FlareColor != flared.FlareColor || restored.FlareIntensity != 75 {
		t.Fatal("flare lost during storage")
	}
	for _, c := range []string{"url(javascript:evil)", "#ff00gg", "rgb(0,0,0)"} {
		invalid := flared
		invalid.FlareColor = c
		if validNameStyle(invalid) {
			t.Fatal("unsafe flare color accepted: " + c)
		}
	}
	for _, intensity := range []int{-1, 101} {
		invalid := flared
		invalid.FlareIntensity = intensity
		if validNameStyle(invalid) {
			t.Fatalf("out-of-range flare %d", intensity)
		}
	}
}
