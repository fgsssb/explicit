package main

import (
	"net/http"
	"strings"
	"time"
)

func publicStatus(u User, connected bool) string {
	if !connected || u.PreferredStatus == "offline" {
		return "offline"
	}
	switch u.PreferredStatus {
	case "away", "busy":
		return u.PreferredStatus
	}
	return "online"
}
func (s *Server) statusAPI(w http.ResponseWriter, r *http.Request) {
	user, err := s.auth(r)
	if err != nil {
		reply(w, 401, map[string]string{"error": "Não autorizado"})
		return
	}
	s.mu.Lock()
	defer s.mu.Unlock()
	u := s.db.Users[user]
	if r.Method == "GET" {
		st := u.PreferredStatus
		if st == "" {
			st = "online"
		}
		reply(w, 200, map[string]any{"username": user, "display_name": s.displayName(user), "preferred_status": st, "email": u.Email, "avatar": u.Avatar, "system_role": systemRole(u), "beta": u.Beta, "explicit_plus": explicitPlusActive(u), "explicit_plus_expires_at": explicitPlusExpiry(u), "badges": userBadges(u), "invite_key": u.InviteKey})
		return
	}
	if r.Method != "POST" {
		http.Error(w, "method", 405)
		return
	}
	var q struct {
		Status string `json:"status"`
	}
	if parse(r, &q) != nil {
		http.Error(w, "invalid", 400)
		return
	}
	switch q.Status {
	case "online", "away", "busy", "offline":
	default:
		http.Error(w, "invalid status", 400)
		return
	}
	old := u
	u.PreferredStatus = q.Status
	s.db.Users[user] = u
	if err := s.save(); err != nil {
		s.db.Users[user] = old
		http.Error(w, "storage failure", 500)
		return
	}
	reply(w, 200, map[string]string{"status": q.Status})
}
func (s *Server) afkAPI(w http.ResponseWriter, r *http.Request) {
	user, err := s.auth(r)
	if err != nil {
		http.Error(w, "unauthorized", 401)
		return
	}
	if r.Method != "POST" {
		http.Error(w, "method", 405)
		return
	}
	var q struct {
		Community string `json:"community"`
		Channel   string `json:"channel"`
		Timeout   int    `json:"timeout_seconds"`
		Enabled   bool   `json:"enabled"`
	}
	if parse(r, &q) != nil {
		http.Error(w, "invalid", 400)
		return
	}
	if q.Enabled && (q.Timeout < 30 || q.Timeout > 86400) {
		http.Error(w, "timeout must be 30–86400 seconds", 400)
		return
	}
	s.mu.Lock()
	defer s.mu.Unlock()
	for i := range s.db.Communities {
		c := &s.db.Communities[i]
		if c.ID != q.Community {
			continue
		}
		if c.Owner != user && !s.hasPermission(*c, user, "MANAGE_COMMUNITY") {
			http.Error(w, "forbidden", 403)
			return
		}
		if q.Enabled && (!contains(c.Channels, q.Channel) || c.channelType(q.Channel) != "voice") {
			http.Error(w, "invalid voice channel", 400)
			return
		}
		old := *c
		c.AFKEnabled = q.Enabled
		c.AFKChannel = q.Channel
		c.AFKTimeout = q.Timeout
		if err := s.save(); err != nil {
			*c = old
			http.Error(w, "storage failure", 500)
			return
		}
		reply(w, 200, map[string]bool{"ok": true})
		return
	}
	http.Error(w, "community not found", 404)
}

// AFK is based on authenticated text actions and client-reported voice state.
// Voice polling alone does not count as activity. Audio-level detection is not implemented.
func (s *Server) afkWorker() {
	ticker := time.NewTicker(5 * time.Second)
	defer ticker.Stop()
	for range ticker.C {
		s.moveInactiveVoice()
	}
}
func (s *Server) moveInactiveVoice() {
	s.mu.Lock()
	configs := make(map[string]Community)
	for _, c := range s.db.Communities {
		if c.AFKEnabled && c.AFKTimeout >= 30 && contains(c.Channels, c.AFKChannel) && c.channelType(c.AFKChannel) == "voice" {
			configs[c.ID] = c
		}
	}
	s.mu.Unlock()
	voice.mu.Lock()
	defer voice.mu.Unlock()
	now := time.Now()
	for user, m := range voice.members {
		parts := strings.SplitN(m.Room, ":", 2)
		if len(parts) != 2 {
			continue
		}
		c, ok := configs[parts[0]]
		if !ok || parts[1] == c.AFKChannel || now.Sub(m.Seen) > 45*time.Second || now.Sub(m.Activity) < time.Duration(c.AFKTimeout)*time.Second {
			continue
		}
		s.mu.Lock()
		allowed := contains(c.Members, user) && s.hasPermission(c, user, "CONNECT_VOICE") && s.activeSanction(c, user, c.AFKChannel) == nil
		s.mu.Unlock()
		if !allowed {
			continue
		}
		m.Queue = append(m.Queue, voiceSignal{ID: token()[:12], Kind: "admin_move", Data: c.AFKChannel})
		m.Activity = now
	}
}
