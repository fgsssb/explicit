package main

import (
	"strings"
	"testing"
	"time"
)

// Use injected timestamps so the tests do not have to wait two minutes.
func TestDirectCallSoloTimeoutAfterLastOtherParticipantLeaves(t *testing.T) {
	now := time.Now()
	id := "solo-after-leave-test"
	directCalls.Lock()
	directCalls.Rooms[id] = map[string]directCallMember{
		"alice": {Seen: now},
		"bob":   {Seen: now},
	}
	directCalls.MediaRooms[id] = "dm:old-session"
	delete(directCalls.AloneSince, id)
	terminated := cleanDirectCallRoomsLocked(now.Add(2 * time.Second))
	if len(terminated) != 0 || !directCalls.AloneSince[id].IsZero() {
		directCalls.Unlock()
		t.Fatal("two participants must not trigger the timeout")
	}
	delete(directCalls.Rooms[id], "bob")
	directCalls.AloneSince[id] = now.Add(2 * time.Second)
	directCalls.Rooms[id]["alice"] = directCallMember{Seen: now.Add(119 * time.Second)}
	terminated = cleanDirectCallRoomsLocked(now.Add(121 * time.Second))
	if len(terminated) != 0 || len(directCalls.Rooms[id]) != 1 {
		directCalls.Unlock()
		t.Fatal("the remaining caller must get the full two-minute grace")
	}
	directCalls.Rooms[id]["alice"] = directCallMember{Seen: now.Add(122 * time.Second)}
	terminated = cleanDirectCallRoomsLocked(now.Add(122 * time.Second))
	if len(terminated) != 1 || terminated[0].Room != "dm:old-session" || len(directCalls.Rooms[id]) != 0 || directCalls.Expired[id].IsZero() {
		directCalls.Unlock()
		t.Fatalf("expired call not removed: %+v", terminated)
	}
	delete(directCalls.Expired, id)
	directCalls.Unlock()
}

func TestDirectCallTimerResetsWhenSecondUserJoins(t *testing.T) {
	now := time.Now()
	id := "solo-reset-on-join"
	directCalls.Lock()
	directCalls.Rooms[id] = map[string]directCallMember{"alice": {Seen: now}}
	directCalls.AloneSince[id] = now
	// Second participant joins after one minute: reset the old solitary countdown.
	directCalls.Rooms[id]["bob"] = directCallMember{Seen: now.Add(time.Minute)}
	delete(directCalls.AloneSince, id)
	if ended := cleanDirectCallRoomsLocked(now.Add(time.Minute)); len(ended) != 0 {
		directCalls.Unlock()
		t.Fatal("call with two people must not expire")
	}
	// The second participant leaves; the full grace period starts again now.
	delete(directCalls.Rooms[id], "bob")
	directCalls.AloneSince[id] = now.Add(time.Minute)
	directCalls.Rooms[id]["alice"] = directCallMember{Seen: now.Add(2 * time.Minute)}
	if seconds := directCallSoloRemainingLocked(id, now.Add(2*time.Minute)); seconds != 60 {
		directCalls.Unlock()
		t.Fatalf("remaining: %d", seconds)
	}
	if ended := cleanDirectCallRoomsLocked(now.Add(2 * time.Minute)); len(ended) != 0 {
		directCalls.Unlock()
		t.Fatal("call ended too early")
	}
	delete(directCalls.Rooms, id)
	delete(directCalls.AloneSince, id)
	directCalls.Unlock()
}

func TestDirectCallExpiredByHeartbeatDoesNotStayInRail(t *testing.T) {
	now := time.Now()
	id := "stale-solo-expiry"
	directCalls.Lock()
	directCalls.Rooms[id] = map[string]directCallMember{"alice": {Seen: now.Add(-50 * time.Second)}, "bob": {Seen: now}}
	directCalls.MediaRooms[id] = "dm:old-session-two"
	ended := cleanDirectCallRoomsLocked(now)
	if len(ended) != 0 || len(directCalls.Rooms[id]) != 1 || directCalls.AloneSince[id].IsZero() {
		directCalls.Unlock()
		t.Fatal("stale participant did not start solo grace")
	}
	directCalls.Rooms[id]["bob"] = directCallMember{Seen: now.Add(2 * time.Minute)}
	ended = cleanDirectCallRoomsLocked(now.Add(2 * time.Minute))
	if len(ended) != 1 || len(directCalls.Rooms[id]) != 0 {
		directCalls.Unlock()
		t.Fatal("orphaned call must be removed")
	}
	delete(directCalls.Expired, id)
	directCalls.Unlock()
}

func TestDirectCallNewMediaRoomsAreUnique(t *testing.T) {
	a, e := directCallNewRoomName("abcdefghijklmnopqrst")
	if e != nil {
		t.Fatal(e)
	}
	b, e := directCallNewRoomName("abcdefghijklmnopqrst")
	if e != nil {
		t.Fatal(e)
	}
	if a == b || !strings.HasPrefix(a, "dm:abcdefghijklmnopqrst:") {
		t.Fatalf("room generations collide or use wrong prefix: %s %s", a, b)
	}
}
