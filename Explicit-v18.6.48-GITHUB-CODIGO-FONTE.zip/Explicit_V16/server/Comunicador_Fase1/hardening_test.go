package main

import (
	"net/http/httptest"
	"strings"
	"testing"
)

func TestLoginRateLimit(t *testing.T) {
	s := newServer(t.TempDir() + "/store.json")
	for i := 0; i < 10; i++ {
		if !s.allowLogin("192.0.2.10:4444") {
			t.Fatal("premature limit")
		}
	}
	if s.allowLogin("192.0.2.10:4444") {
		t.Fatal("login flood not limited")
	}
	if !s.allowLogin("192.0.2.11:4444") {
		t.Fatal("other address incorrectly limited")
	}
}
func TestRejectTrailingJSON(t *testing.T) {
	r := httptest.NewRequest("POST", "/", strings.NewReader(`{"name":"x"}{"name":"y"}`))
	var body struct {
		Name string `json:"name"`
	}
	if parse(r, &body) == nil {
		t.Fatal("accepted multiple JSON documents")
	}
}
func TestSecurityHeaders(t *testing.T) {
	s := newServer(t.TempDir() + "/store.json")
	w := httptest.NewRecorder()
	s.routes().ServeHTTP(w, httptest.NewRequest("GET", "/api/ping", nil))
	if w.Header().Get("Content-Security-Policy") == "" || w.Header().Get("X-Frame-Options") != "DENY" {
		t.Fatal("missing security headers")
	}
}
