package main

import (
	"encoding/json"
	"net/http/httptest"
	"strings"
	"testing"
)

func TestCommunityAccessAndPersistence(t *testing.T) {
	t.Setenv("EXPLICIT_INITIAL_INVITE_KEY", "TEST-BOOTSTRAP")
	s := newServer(t.TempDir() + "/db.json")
	call := func(method, path, body, token string) *httptest.ResponseRecorder {
		r := httptest.NewRequest(method, path, strings.NewReader(body))
		r.Header.Set("Authorization", "Bearer "+token)
		w := httptest.NewRecorder()
		s.routes().ServeHTTP(w, r)
		return w
	}
	for _, name := range []string{"alice", "bob"} {
		if w := call("POST", "/api/register", `{"name":"`+name+`","display_name":"`+name+` Display","password":"password123","invite_key":"`+testInviteKey(s)+`"}`, ""); w.Code != 201 {
			t.Fatal(w.Body)
		}
	}
	login := func(name string) string {
		w := call("POST", "/api/login", `{"name":"`+name+`","display_name":"`+name+` Display","password":"password123","invite_key":"`+testInviteKey(s)+`"}`, "")
		var v map[string]string
		json.Unmarshal(w.Body.Bytes(), &v)
		if w := call("POST", "/api/terms", `{"accept":true,"version":"`+currentTermsVersion+`"}`, v["token"]); w.Code != 200 {
			t.Fatal(w.Body)
		}
		return v["token"]
	}
	alice, bob := login("alice"), login("bob")
	w := call("POST", "/api/communities", `{"name":"Test Group"}`, alice)
	if w.Code != 201 {
		t.Fatal(w.Body)
	}
	var c Community
	json.Unmarshal(w.Body.Bytes(), &c)
	// Comunidades novas devem iniciar com dois canais, com metadados corretos.
	if len(c.Channels) != 2 || c.Channels[0] != "geral" || c.Channels[1] != "voz" {
		t.Fatalf("canais iniciais invalidos: %#v", c.Channels)
	}
	if c.channelType("geral") != "text" || c.channelType("voz") != "voice" {
		t.Fatalf("tipos iniciais invalidos: %#v", c.ChannelMeta)
	}
	persisted := newServer(s.file)
	if len(persisted.db.Communities) != 1 || persisted.db.Communities[0].channelType("voz") != "voice" {
		t.Fatal("canal de voz inicial nao persistiu")
	}
	path := "/api/channel-messages?community=" + c.ID + "&channel=geral"
	if w = call("GET", path, "", bob); w.Code != 403 {
		t.Fatalf("unauthorized read %d", w.Code)
	}
	if w = call("POST", path, `{"text":"hi"}`, bob); w.Code != 403 {
		t.Fatalf("unauthorized write %d", w.Code)
	}
	if w = call("POST", "/api/communities", `{"join":"`+c.ID+`"}`, bob); w.Code != 200 {
		t.Fatal(w.Body)
	}
	if w = call("POST", path, `{"text":"hello"}`, bob); w.Code != 201 {
		t.Fatal(w.Body)
	}
	if len(newServer(s.file).db.Communities) != 1 || len(newServer(s.file).db.Messages) != 1 {
		t.Fatal("persistence failure")
	}
	if w = call("POST", "/api/logout", "", bob); w.Code != 200 {
		t.Fatal(w.Body)
	}
	if w = call("GET", path, "", bob); w.Code != 401 {
		t.Fatal("logout failed")
	}
}
