package main

import (
	"bytes"
	"encoding/json"
	"net/http/httptest"
	"path/filepath"
	"strings"
	"testing"
)

func TestReportedUserCaseGatesDMReviewAndSanction(t *testing.T) {
	s := newServer(filepath.Join(t.TempDir(), "store.json"))
	for _, name := range []string{"owner", "admin", "reporter", "accused", "other"} {
		s.db.Users[name] = User{Name: name, AccountID: token()}
		s.sessions[name+"-session"] = name
	}
	if err := s.bootstrapOwner("owner"); err != nil {
		t.Fatal(err)
	}
	u := s.db.Users["admin"]
	u.SystemRole = "moderator"
	s.db.Users["admin"] = u
	s.db.DirectChats = []DirectChat{
		{ID: "reported-chat", Users: []string{"accused", "reporter"}, Messages: []DirectMessage{{ID: "msg", Author: "accused", Text: "texto"}}},
		{ID: "group-chat", Users: []string{"accused", "reporter", "other"}, Name: "Grupo", Messages: []DirectMessage{{ID: "gmsg", Author: "other", Text: "texto"}}},
		{ID: "unrelated", Users: []string{"reporter", "other"}},
	}
	send := func(user, method, url string, payload any) *httptest.ResponseRecorder {
		t.Helper()
		b, _ := json.Marshal(payload)
		r := httptest.NewRequest(method, url, bytes.NewReader(b))
		r.Header.Set("Authorization", "Bearer "+user+"-session")
		w := httptest.NewRecorder()
		s.routes().ServeHTTP(w, r)
		return w
	}
	if got := send("admin", "GET", "/api/staff-dm?list=1", nil).Code; got != 403 {
		t.Fatalf("global DM enumeration allowed: %d", got)
	}
	if got := send("reporter", "POST", "/api/report", map[string]any{"kind": "user", "target": "missing", "reason": "abuso gravissimo"}).Code; got != 404 {
		t.Fatalf("report of nonexistent user accepted: %d", got)
	}
	created := send("reporter", "POST", "/api/report", map[string]any{"kind": "user", "target": "accused", "reason": "comportamento abusivo", "chat_id": "reported-chat", "message_id": "msg"})
	if created.Code != 201 {
		t.Fatalf("report creation: %d %s", created.Code, created.Body)
	}
	var item struct {
		ID string `json:"id"`
	}
	if err := json.Unmarshal(created.Body.Bytes(), &item); err != nil {
		t.Fatal(err)
	}
	listed := send("admin", "GET", "/api/staff-dm?list=1&report_id="+item.ID, nil)
	if listed.Code != 200 || !strings.Contains(listed.Body.String(), "reported-chat") || strings.Contains(listed.Body.String(), "group-chat") || strings.Contains(listed.Body.String(), "unrelated") {
		t.Fatalf("wrong case scope: %d %s", listed.Code, listed.Body)
	}
	reason := "&reason=Investigacao%20com%20denuncia"
	if got := send("admin", "GET", "/api/staff-dm?chat=unrelated&report_id="+item.ID+reason, nil).Code; got != 403 {
		t.Fatalf("unrelated chat: %d", got)
	}
	before := len(s.db.DirectChats[0].Messages)
	if got := send("admin", "GET", "/api/staff-dm?chat=reported-chat&report_id="+item.ID+reason, nil).Code; got != 200 {
		t.Fatalf("reported DM denied: %d", got)
	}
	if len(s.db.DirectChats[0].Messages) != before {
		t.Fatal("review emitted hidden-visible notice")
	}
	if got := send("admin", "POST", "/api/system-admin", map[string]any{"action": "ban", "target": "other", "reason": "abuso", "hours": 24, "report_id": item.ID}).Code; got != 403 {
		t.Fatalf("report used to ban unrelated: %d", got)
	}
	if got := send("admin", "POST", "/api/system-admin", map[string]any{"action": "ban", "target": "accused", "reason": "abuso", "hours": 24, "report_id": item.ID}).Code; got != 200 {
		t.Fatalf("case sanction: %d", got)
	}
	if s.db.Users["accused"].BannedUntil == nil {
		t.Fatal("sanction not persisted")
	}
	if len(s.db.StaffAudit) == 0 {
		t.Fatal("review not audited")
	}
	if got := send("admin", "POST", "/api/system-admin", map[string]any{"action": "resolve_report", "report_id": item.ID}).Code; got != 200 {
		t.Fatalf("resolve case: %d", got)
	}
	if got := send("admin", "GET", "/api/staff-dm?chat=reported-chat&report_id="+item.ID+reason, nil).Code; got != 403 {
		t.Fatalf("resolved case still usable: %d", got)
	}
}
func TestOwnerCanBeSanctionedByAdminWithoutChangingOwnerIdentity(t *testing.T) {
	s := newServer(filepath.Join(t.TempDir(), "store.json"))
	s.db.Users["creator"] = User{Name: "creator", AccountID: token()}
	s.db.Users["moderator"] = User{Name: "moderator", AccountID: token(), SystemRole: "moderator"}
	s.sessions["moderator-session"] = "moderator"
	s.sessions["creator-session"] = "creator"
	if err := s.bootstrapOwner("creator"); err != nil {
		t.Fatal(err)
	}
	b := []byte(`{"action":"ban","target":"creator","reason":"Violacao de regras","hours":24}`)
	r := httptest.NewRequest("POST", "/api/system-admin", bytes.NewReader(b))
	r.Header.Set("Authorization", "Bearer moderator-session")
	w := httptest.NewRecorder()
	s.routes().ServeHTTP(w, r)
	if w.Code != 200 {
		t.Fatalf("owner remains immune: %d %s", w.Code, w.Body)
	}
	if !s.isOwner("creator") || s.db.Users["creator"].BannedUntil == nil {
		t.Fatal("owner identity or sanction incorrect")
	}
	restored := newServer(s.file)
	if !restored.isOwner("creator") || restored.db.Users["creator"].BannedUntil == nil {
		t.Fatal("restarting server must not silently clear Owner sanction")
	}
	if _, err := s.auth(httptest.NewRequest("GET", "/", nil)); err == nil {
		t.Fatal("missing token accepted")
	}
}

func TestLegacySuperadminBecomesAdminWhenOwnerBound(t *testing.T) {
	s := newServer(filepath.Join(t.TempDir(), "store.json"))
	s.db.Users["creator"] = User{Name: "creator", AccountID: token()}
	s.db.Users["legacy"] = User{Name: "legacy", AccountID: token(), SystemRole: "superadmin"}
	if err := s.bootstrapOwner("creator"); err != nil {
		t.Fatal(err)
	}
	if s.isSuperadmin("legacy") {
		t.Fatal("legacy superadmin can bypass Owner controls")
	}
	loaded := newServer(s.file)
	if systemRole(loaded.db.Users["legacy"]) != "moderator" {
		t.Fatalf("legacy role not migrated: %s", systemRole(loaded.db.Users["legacy"]))
	}
	if systemLevel(systemRole(loaded.db.Users["legacy"])) != systemLevel("owner") {
		t.Fatal("legacy role retained higher privileges")
	}
}
