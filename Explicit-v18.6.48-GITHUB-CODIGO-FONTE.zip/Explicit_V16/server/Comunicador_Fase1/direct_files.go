package main

import (
	"crypto/rand"
	"encoding/hex"
	"encoding/json"
	"io"
	"net/http"
	"os"
	"path/filepath"
	"regexp"
	"strings"
	"time"
)

const maxDirectFile = 8 << 20

var directFileID = regexp.MustCompile(`^[a-f0-9]{32}$`)
var directFileTypes = map[string]bool{"png": true, "jpg": true, "jpeg": true, "gif": true, "webp": true, "pdf": true, "txt": true, "zip": true, "mp3": true, "mp4": true, "docx": true, "xlsx": true}

func (s *Server) directFileAPI(w http.ResponseWriter, r *http.Request) {
	user, err := s.auth(r)
	if err != nil {
		http.Error(w, "unauthorized", 401)
		return
	}
	dir := filepath.Join(filepath.Dir(s.file), "direct_files")
	if r.Method == http.MethodGet {
		id := r.URL.Query().Get("id")
		if !directFileID.MatchString(id) {
			http.Error(w, "invalid file", 400)
			return
		}
		s.mu.Lock()
		allowed := false
		name := ""
		for _, c := range s.db.DirectChats {
			if !contains(c.Users, user) {
				continue
			}
			for _, m := range c.Messages {
				if m.File == id {
					allowed = true
					name = m.FileName
					break
				}
			}
			if allowed {
				break
			}
		}
		s.mu.Unlock()
		if !allowed {
			http.Error(w, "forbidden", 403)
			return
		}
		f, err := os.Open(filepath.Join(dir, id))
		if err != nil {
			http.Error(w, "not found", 404)
			return
		}
		defer f.Close()
		safe := strings.NewReplacer("\r", "_", "\n", "_", "\"", "_", "\\", "_").Replace(filepath.Base(name))
		if safe == "" {
			safe = "arquivo"
		}
		w.Header().Set("X-Content-Type-Options", "nosniff")
		w.Header().Set("Content-Security-Policy", "default-src 'none'; sandbox")
		w.Header().Set("Cache-Control", "private, no-store")
		w.Header().Set("Content-Disposition", `attachment; filename="`+safe+`"`)
		w.Header().Set("Content-Type", "application/octet-stream")
		io.Copy(w, f)
		return
	}
	if r.Method != http.MethodPost {
		http.Error(w, "method", 405)
		return
	}
	r.Body = http.MaxBytesReader(w, r.Body, maxDirectFile+(1<<20))
	if err := r.ParseMultipartForm(4 << 20); err != nil {
		http.Error(w, "file too large", 413)
		return
	}
	if r.MultipartForm != nil {
		defer r.MultipartForm.RemoveAll()
	}
	chatID := r.FormValue("chat")
	file, head, err := r.FormFile("file")
	if err != nil {
		http.Error(w, "file required", 400)
		return
	}
	defer file.Close()
	name := filepath.Base(strings.ReplaceAll(head.Filename, "\\", "/"))
	if name == "." || name == "" || len(name) > 180 {
		http.Error(w, "invalid name", 400)
		return
	}
	ext := strings.TrimPrefix(strings.ToLower(filepath.Ext(name)), ".")
	if !directFileTypes[ext] {
		http.Error(w, "unsupported file type", 415)
		return
	}
	content, err := io.ReadAll(io.LimitReader(file, maxDirectFile+1))
	if err != nil || len(content) == 0 || len(content) > maxDirectFile {
		http.Error(w, "file too large", 413)
		return
	}
	mime := http.DetectContentType(content)
	if ext == "png" && mime != "image/png" || (ext == "jpg" || ext == "jpeg") && mime != "image/jpeg" || ext == "gif" && mime != "image/gif" || ext == "webp" && mime != "image/webp" || ext == "pdf" && mime != "application/pdf" || ext == "zip" && mime != "application/zip" {
		http.Error(w, "file content mismatch", 415)
		return
	}
	var random [16]byte
	if _, err = rand.Read(random[:]); err != nil {
		http.Error(w, "internal", 500)
		return
	}
	id := hex.EncodeToString(random[:])
	s.mu.Lock()
	defer s.mu.Unlock()
	for i := range s.db.DirectChats {
		c := &s.db.DirectChats[i]
		if c.ID != chatID || !contains(c.Users, user) {
			continue
		}
		if len(c.Users) < 2 {
			http.Error(w, "invalid conversation", 400)
			return
		}
		isGroup := len(c.Users) > 2 || c.Name != ""
		other := c.Users[0]
		if other == user {
			other = c.Users[1]
		}
		if !isGroup && !s.areFriends(user, other) {
			http.Error(w, "friendship required", 403)
			return
		}
		if !s.storageAllowedLocked(user, int64(len(content)), "") {
			http.Error(w, "Limite de armazenamento atingido. Entre em contato com a equipe do Explicit.", http.StatusRequestEntityTooLarge)
			return
		}
		if err := os.MkdirAll(dir, 0700); err != nil {
			http.Error(w, "storage error", 500)
			return
		}
		if !trustedStorageDirectory(filepath.Dir(s.file), "direct_files") {
			http.Error(w, "invalid storage directory", 500)
			return
		}
		path := filepath.Join(dir, id)
		if err := os.WriteFile(path, content, 0600); err != nil {
			http.Error(w, "storage error", 500)
			return
		}
		original := *c
		c.Visible = copyDirectVisibility(c.Visible)
		c.Messages = append(c.Messages, DirectMessage{ID: token()[:16], Author: user, File: id, FileName: name, Time: time.Now().UTC()})
		oldNotifications := append([]AppNotification(nil), s.db.Notifications...)
		for _, target := range c.Users {
			if target != user {
				channel := ""
				if isGroup {
					channel = "dm:" + c.ID
				}
				s.enqueueNotificationLocked(target, "direct", user, "", channel, "Arquivo enviado: "+name)
				c.Visible[target] = true
			}
		}
		if err := s.save(); err != nil {
			*c = original
			s.db.Notifications = oldNotifications
			os.Remove(path)
			http.Error(w, "storage error", 500)
			return
		}
		w.Header().Set("Content-Type", "application/json")
		w.WriteHeader(201)
		json.NewEncoder(w).Encode(c.Messages[len(c.Messages)-1])
		return
	}
	http.Error(w, "chat not found", 404)
}
