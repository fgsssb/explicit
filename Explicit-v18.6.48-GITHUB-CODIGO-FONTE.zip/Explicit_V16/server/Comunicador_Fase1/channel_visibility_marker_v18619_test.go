package main

import "testing"

func TestV18619ChannelPrivateBadgeByVisibilityRules(t *testing.T) {
	cases := []struct {
		label   string
		meta    ChannelMeta
		private bool
	}{
		{"public text", ChannelMeta{Type: "text"}, false},
		{"public voice", ChannelMeta{Type: "voice", RolePermissions: map[string]map[string]bool{"everyone": {"CONNECT_VOICE": false}}}, false},
		{"private role", ChannelMeta{Type: "text", RolePermissions: map[string]map[string]bool{"everyone": {"VIEW_CHANNEL": false}}}, true},
		{"private member", ChannelMeta{Type: "voice", MemberPermissions: map[string]map[string]bool{"one": {"VIEW_CHANNEL": false}}}, true},
		{"allow role only", ChannelMeta{Type: "voice", RolePermissions: map[string]map[string]bool{"members": {"VIEW_CHANNEL": true}}}, false},
		{"deny non-view permission", ChannelMeta{Type: "text", MemberPermissions: map[string]map[string]bool{"one": {"SEND_MESSAGES": false}}}, false},
	}
	for _, tc := range cases {
		t.Run(tc.label, func(t *testing.T) {
			if got := channelHasRestrictedVisibility(tc.meta); got != tc.private {
				t.Fatalf("got %v want %v", got, tc.private)
			}
		})
	}
}

func TestV18619VisibleCommunityMarksPrivacyWithoutExposingMemberACL(t *testing.T) {
	s := newServer(t.TempDir() + "/db.json")
	c := Community{ID: "test", Owner: "owner", Members: []string{"owner", "member"}, Channels: []string{"public", "private-role", "private-user", "invisible"}, ChannelMeta: map[string]ChannelMeta{
		"public":       {Type: "text"},
		"private-role": {Type: "text", RolePermissions: map[string]map[string]bool{"everyone": {"VIEW_CHANNEL": false}, "role": {"VIEW_CHANNEL": true}}},
		"private-user": {Type: "voice", MemberPermissions: map[string]map[string]bool{"member": {"VIEW_CHANNEL": false}}},
		"invisible":    {Type: "voice", RolePermissions: map[string]map[string]bool{"everyone": {"VIEW_CHANNEL": false}}},
	}}
	_ = s
	visible := s.visibleCommunity(c, "owner")
	if visible.ChannelMeta["public"].Private {
		t.Fatal("public channel marked private")
	}
	if !visible.ChannelMeta["private-role"].Private || !visible.ChannelMeta["private-user"].Private {
		t.Fatal("private channels were not marked")
	}
	if visible.ChannelMeta["private-user"].MemberPermissions != nil {
		t.Fatal("private member ACL leaked")
	}
}
