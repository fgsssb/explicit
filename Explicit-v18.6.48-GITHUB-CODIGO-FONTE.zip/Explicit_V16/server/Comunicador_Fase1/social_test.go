package main

import (
	"encoding/json"
	"net/http/httptest"
	"strings"
	"testing"
)

func TestSocialAndDirectAuthorization(t *testing.T) {
	t.Setenv("EXPLICIT_INITIAL_INVITE_KEY", "TEST-BOOTSTRAP")
	s := newServer(t.TempDir() + "/db.json")
	call := func(method, path, body, token string) *httptest.ResponseRecorder {
		r := httptest.NewRequest(method, path, strings.NewReader(body))
		// Registration limits apply per IP. Simulate Charlie registering on another network.
		if path == "/api/register" && strings.Contains(body, `"name":"charlie"`) {
			r.RemoteAddr = "198.51.100.34:1234"
		}
		r.Header.Set("Authorization", "Bearer "+token)
		w := httptest.NewRecorder()
		s.routes().ServeHTTP(w, r)
		return w
	}
	for _, n := range []string{"alice", "bob", "charlie"} {
		w := call("POST", "/api/register", `{"name":"`+n+`","password":"password123","display_name":"`+n+` Example","invite_key":"`+testInviteKey(s)+`"}`, "")
		if w.Code != 201 {
			t.Fatalf("register %s: %s", n, w.Body)
		}
	}
	tokens := map[string]string{}
	for _, n := range []string{"alice", "bob", "charlie"} {
		w := call("POST", "/api/login", `{"name":"`+n+`","password":"password123"}`, "")
		var x map[string]string
		_ = json.Unmarshal(w.Body.Bytes(), &x)
		tokens[n] = x["token"]
		if w := call("POST", "/api/terms", `{"accept":true,"version":"`+currentTermsVersion+`"}`, tokens[n]); w.Code != 200 {
			t.Fatal(w.Body)
		}
	}
	if w := call("POST", "/api/social", `{"action":"request","target":"bob"}`, tokens["alice"]); w.Code != 200 {
		t.Fatal(w.Body)
	}
	if w := call("POST", "/api/social", `{"action":"request","target":"bob"}`, tokens["alice"]); w.Code != 409 {
		t.Fatal("duplicate request allowed")
	}
	w := call("GET", "/api/social", "", tokens["bob"])
	var data struct {
		Incoming []FriendRequest `json:"incoming"`
	}
	_ = json.Unmarshal(w.Body.Bytes(), &data)
	if len(data.Incoming) != 1 {
		t.Fatal("missing request")
	}
	id := data.Incoming[0].ID
	if w = call("POST", "/api/social", `{"action":"accept","id":"`+id+`"}`, tokens["charlie"]); w.Code != 404 {
		t.Fatal("third party accepted")
	}
	if w = call("POST", "/api/social", `{"action":"accept","id":"`+id+`"}`, tokens["bob"]); w.Code != 200 {
		t.Fatal(w.Body)
	}
	w = call("POST", "/api/direct", `{"action":"open","target":"bob"}`, tokens["alice"])
	if w.Code != 201 {
		t.Fatal(w.Body)
	}
	var chat DirectChat
	_ = json.Unmarshal(w.Body.Bytes(), &chat)
	if w = call("GET", "/api/direct?id="+chat.ID, "", tokens["charlie"]); w.Code != 404 {
		t.Fatal("private chat leaked")
	}
	if w = call("POST", "/api/direct", `{"action":"send","id":"`+chat.ID+`","text":"hello"}`, tokens["alice"]); w.Code != 200 {
		t.Fatal(w.Body)
	}
	if w = call("POST", "/api/direct", `{"action":"hide","id":"`+chat.ID+`"}`, tokens["bob"]); w.Code != 200 {
		t.Fatal(w.Body)
	}
	if w = call("GET", "/api/direct?id="+chat.ID, "", tokens["bob"]); w.Code != 200 {
		t.Fatal("hidden chat history lost")
	}
}
