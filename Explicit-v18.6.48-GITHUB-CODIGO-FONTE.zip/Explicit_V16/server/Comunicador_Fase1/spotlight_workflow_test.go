package main

import (
	"bytes"
	"encoding/json"
	"net/http/httptest"
	"path/filepath"
	"testing"
)

func TestSpotlightRequestApprovalAndPersistence(t *testing.T) {
	s := newServer(filepath.Join(t.TempDir(), "store.json"))
	s.db.Users["admin"] = User{Name: "admin", SystemRole: "admin"}
	s.db.Users["user"] = User{Name: "user"}
	s.sessions["admin-session"] = "admin"
	s.sessions["user-session"] = "user"
	call := func(method, path, session string, body any) *httptest.ResponseRecorder {
		t.Helper()
		b, _ := json.Marshal(body)
		r := httptest.NewRequest(method, path, bytes.NewReader(b))
		r.Header.Set("Authorization", "Bearer "+session)
		w := httptest.NewRecorder()
		s.routes().ServeHTTP(w, r)
		return w
	}
	payload := map[string]any{"action": "request", "title": "Vídeo de teste", "video_url": "https://youtu.be/abcdef", "hours": 24}
	if w := call("POST", "/api/spotlight", "user-session", payload); w.Code != 201 {
		t.Fatalf("request status=%d %s", w.Code, w.Body)
	}
	if w := call("GET", "/api/spotlight?requests=1", "user-session", nil); w.Code != 403 {
		t.Fatalf("user read queue=%d", w.Code)
	}
	if w := call("POST", "/api/spotlight", "user-session", map[string]any{"action": "add", "title": "Teste de acesso", "video_url": "https://youtu.be/abcdef", "hours": 2}); w.Code != 403 {
		t.Fatalf("normal user published=%d", w.Code)
	}
	if w := call("GET", "/api/spotlight?requests=1", "admin-session", nil); w.Code != 200 {
		t.Fatalf("admin queue=%d", w.Code)
	}
	id := s.db.SpotlightRequests[0].ID
	if w := call("POST", "/api/spotlight", "admin-session", map[string]any{"action": "approve_request", "id": id}); w.Code != 200 {
		t.Fatalf("approve=%d %s", w.Code, w.Body)
	}
	if len(s.db.Spotlights) != 1 || s.db.SpotlightRequests[0].Status != "approved" {
		t.Fatal("approval not published")
	}
	if w := call("POST", "/api/spotlight", "admin-session", map[string]any{"action": "approve_request", "id": id}); w.Code != 409 {
		t.Fatalf("duplicate=%d", w.Code)
	}
	reloaded := newServer(s.file)
	if len(reloaded.db.Spotlights) != 1 || len(reloaded.db.SpotlightRequests) != 1 {
		t.Fatal("not persisted")
	}
	if w := call("POST", "/api/spotlight", "admin-session", map[string]any{"action": "remove", "id": s.db.Spotlights[0].ID}); w.Code != 200 {
		t.Fatalf("remove=%d", w.Code)
	}
}
func TestSpotlightInputLimits(t *testing.T) {
	s := newServer(filepath.Join(t.TempDir(), "store.json"))
	s.db.Users["u"] = User{Name: "u"}
	s.sessions["token"] = "u"
	payloads := []map[string]any{
		{"action": "request", "title": "Ok title", "video_url": "http://youtu.be/a", "hours": 24},
		{"action": "request", "title": "Ok title", "video_url": "https://youtube.com.evil.net/a", "hours": 24},
		{"action": "request", "title": "Ok title", "video_url": "https://youtu.be/a", "hours": 49},
	}
	for _, p := range payloads {
		b, _ := json.Marshal(p)
		r := httptest.NewRequest("POST", "/api/spotlight", bytes.NewReader(b))
		r.Header.Set("Authorization", "Bearer token")
		w := httptest.NewRecorder()
		s.routes().ServeHTTP(w, r)
		if w.Code != 400 {
			t.Fatalf("invalid payload accepted: %v %d", p, w.Code)
		}
	}
}
