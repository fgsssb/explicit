package main

import (
	"bytes"
	"encoding/json"
	"net/http/httptest"
	"path/filepath"
	"testing"
)

func TestChannelReorderDragServerSideAndInheritCategory(t *testing.T) {
	s := newServer(filepath.Join(t.TempDir(), "store.json"))
	s.db.Users["owner"] = User{Name: "owner"}
	s.db.Users["member"] = User{Name: "member"}
	s.sessions["owner-token"] = "owner"
	s.sessions["member-token"] = "member"
	s.db.Communities = []Community{{ID: "c", Owner: "owner", Members: []string{"owner", "member"}, Channels: []string{"geral", "avisos", "voz"}, Categories: []ChannelCategory{{ID: "cat1", Name: "Equipe", RolePermissions: map[string]map[string]bool{"everyone": {"VIEW_CHANNEL": false}}}}, ChannelMeta: map[string]ChannelMeta{"geral": {Type: "text"}, "avisos": {Type: "text"}, "voz": {Type: "voice"}}}}
	request := func(tok string, data any) *httptest.ResponseRecorder {
		b, _ := json.Marshal(data)
		req := httptest.NewRequest("POST", "/api/channel-permissions", bytes.NewReader(b))
		req.Header.Set("Authorization", "Bearer "+tok)
		w := httptest.NewRecorder()
		s.routes().ServeHTTP(w, req)
		return w
	}
	data := map[string]any{"community": "c", "action": "channel_reorder", "channel": "voz", "before": "geral", "category": "cat1", "sync": true}
	if w := request("member-token", data); w.Code != 403 {
		t.Fatalf("ordinary member reordered: %d", w.Code)
	}
	if w := request("owner-token", data); w.Code != 200 {
		t.Fatalf("owner failed: %d %s", w.Code, w.Body)
	}
	c := s.db.Communities[0]
	if c.Channels[0] != "voz" || c.ChannelMeta["voz"].Category != "cat1" || !c.ChannelMeta["voz"].Synced || c.ChannelMeta["voz"].RolePermissions["everyone"]["VIEW_CHANNEL"] {
		t.Fatalf("reorder failed: %#v", c)
	}
	reloaded := newServer(s.file).db.Communities[0]
	if reloaded.Channels[0] != "voz" {
		t.Fatal("reorder not persisted")
	}
}
