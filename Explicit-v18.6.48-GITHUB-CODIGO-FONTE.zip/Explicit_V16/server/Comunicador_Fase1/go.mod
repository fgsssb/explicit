module comunicador

go 1.22
