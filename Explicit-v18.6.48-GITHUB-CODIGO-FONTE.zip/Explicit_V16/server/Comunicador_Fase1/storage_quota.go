package main

import (
	"encoding/json"
	"log"
	"net/http"
	"os"
	"path/filepath"
	"regexp"
	"strconv"
	"strings"
	"time"
)

// Quotas are enforced while Server.mu is held; uploads in all handlers are
// serialized at the commit point, preventing concurrent quota bypasses.
const defaultUserStorageLimit int64 = 256 << 20
const defaultGlobalStorageLimit int64 = 4 << 30
const defaultOrphanGrace = 72 * time.Hour

var uploadFileName = regexp.MustCompile(`^[a-f0-9]{32}(\.(png|jpg|gif|webp|mp4|webm))?$`)

type storageSnapshot struct {
	UserBytes  map[string]int64 `json:"user_bytes"`
	TotalBytes int64            `json:"total_bytes"`
	Referenced map[string]bool  `json:"-"`
	Files      map[string]int64 `json:"-"`
}

func storageSetting(name string, fallback int64) int64 {
	raw := strings.TrimSpace(os.Getenv(name))
	if raw == "" {
		return fallback
	}
	value, err := strconv.ParseInt(raw, 10, 64)
	if err != nil || value < 0 {
		return fallback
	}
	return value
}
func storageGrace() time.Duration {
	hours := storageSetting("EXPLICIT_ORPHAN_GRACE_HOURS", 72)
	if hours < 48 {
		hours = 48
	} // never delete recently uploaded / in-flight files
	if hours > 24*365 {
		hours = 24 * 365
	}
	return time.Duration(hours) * time.Hour
}

// Relative storage keys use normalized slash separators; no client-supplied
// paths ever reach this function or the cleanup code.
func mediaKey(dir, name string) string { return dir + "/" + name }
func (s *Server) referencedFilesLocked() map[string]string {
	owners := make(map[string]string)
	for _, m := range s.db.Messages {
		if imageNamePattern.MatchString(m.Image) {
			owners[mediaKey("images", m.Image)] = m.Author
		}
		if videoNamePattern.MatchString(m.Video) {
			owners[mediaKey("videos", m.Video)] = m.Author
		}
		if stickerIDPattern.MatchString(m.Sticker) {
			if _, ok := owners[mediaKey("stickers", m.Sticker)]; !ok {
				owners[mediaKey("stickers", m.Sticker)] = ""
			}
		}
	}
	for _, c := range s.db.DirectChats {
		for _, m := range c.Messages {
			if directFileID.MatchString(m.File) {
				owners[mediaKey("direct_files", m.File)] = m.Author
			}
		}
	}
	for _, st := range s.db.Stickers {
		if stickerIDPattern.MatchString(st.ID) && !st.Removed {
			owners[mediaKey("stickers", st.ID)] = st.Owner
		}
	}
	for name, u := range s.db.Users {
		if u.Avatar != "" && validVisualID(name, false) {
			owners[mediaKey("visual/avatar", name+".jpg")] = name
		}
	}
	for _, c := range s.db.Communities {
		if c.CardImage != "" && validVisualID(c.ID, true) {
			owners[mediaKey("visual/community", c.ID+".jpg")] = c.Owner
		}
	}
	return owners
}
func validStoredName(folder, name string) bool {
	switch folder {
	case "images":
		return imageNamePattern.MatchString(name)
	case "videos":
		return videoNamePattern.MatchString(name)
	case "direct_files":
		return directFileID.MatchString(name)
	case "stickers":
		return stickerIDPattern.MatchString(name)
	case "visual/avatar", "visual/community":
		return strings.HasSuffix(name, ".jpg") && validVisualID(strings.TrimSuffix(name, ".jpg"), folder == "visual/community")
	}
	return false
}
func storageFolders() []string {
	return []string{"images", "videos", "direct_files", "stickers", "visual/avatar", "visual/community"}
}

// A replaced directory symlink must never redirect inventory or cleanup to an
// unexpected location. This also checks the visual/ parent component.
func trustedStorageDirectory(root, folder string) bool {
	path := root
	for _, component := range strings.Split(filepath.ToSlash(folder), "/") {
		path = filepath.Join(path, component)
		info, err := os.Lstat(path)
		if err != nil || !info.IsDir() || info.Mode()&os.ModeSymlink != 0 {
			return false
		}
	}
	return true
}

func (s *Server) storageSnapshotLocked() storageSnapshot {
	snap := storageSnapshot{UserBytes: map[string]int64{}, Referenced: map[string]bool{}, Files: map[string]int64{}}
	owners := s.referencedFilesLocked()
	root := filepath.Dir(s.file)
	for _, folder := range storageFolders() {
		if !trustedStorageDirectory(root, folder) {
			continue
		}
		entries, err := os.ReadDir(filepath.Join(root, filepath.FromSlash(folder)))
		if err != nil {
			if !os.IsNotExist(err) {
				log.Printf("STORAGE inventory %s: %v", folder, err)
			}
			continue
		}
		for _, entry := range entries {
			// Never follow symbolic links or special files, even during quota calculation.
			info, err := entry.Info()
			if err != nil || !info.Mode().IsRegular() {
				continue
			}
			if !validStoredName(folder, entry.Name()) {
				continue
			}
			key := mediaKey(folder, entry.Name())
			snap.Files[key] = info.Size()
			snap.TotalBytes += info.Size()
			if owner, ok := owners[key]; ok {
				snap.Referenced[key] = true
				if owner != "" {
					snap.UserBytes[owner] += info.Size()
				}
			}
		}
	}
	return snap
}
func (s *Server) storageAllowedLocked(user string, bytes int64, replacingKey string) bool {
	snap := s.storageSnapshotLocked()
	replaced := snap.Files[replacingKey]
	// The replacingKey is only accepted for overwrite-only, trusted visual paths.
	if replacingKey == "" {
		replaced = 0
	}
	userLimit := storageSetting("EXPLICIT_STORAGE_USER_BYTES", defaultUserStorageLimit)
	globalLimit := storageSetting("EXPLICIT_STORAGE_GLOBAL_BYTES", defaultGlobalStorageLimit)
	return (userLimit == 0 || snap.UserBytes[user]+bytes-replaced <= userLimit) && (globalLimit == 0 || snap.TotalBytes+bytes-replaced <= globalLimit)
}

func (s *Server) storageAllowedStagedLocked(user string, size int64) bool {
	snapshot := s.storageSnapshotLocked()
	userLimit := storageSetting("EXPLICIT_STORAGE_USER_BYTES", defaultUserStorageLimit)
	globalLimit := storageSetting("EXPLICIT_STORAGE_GLOBAL_BYTES", defaultGlobalStorageLimit)
	// The staged file is already included in TotalBytes but has not yet been
	// associated with a user. The pending writer deletes it on rejection.
	return (userLimit == 0 || snapshot.UserBytes[user]+size <= userLimit) && (globalLimit == 0 || snapshot.TotalBytes <= globalLimit)
}

type orphanReport struct {
	Candidates int   `json:"candidates"`
	Bytes      int64 `json:"bytes"`
	Deleted    int   `json:"deleted"`
	Errors     int   `json:"errors"`
	DryRun     bool  `json:"dry_run"`
}

func (s *Server) cleanOrphansLocked(dryRun bool, now time.Time) orphanReport {
	result := orphanReport{DryRun: dryRun}
	// An empty/uninitialized store is not a safe source of truth for deleting files.
	if len(s.db.Users) == 0 {
		return result
	}
	refs := s.referencedFilesLocked()
	root := filepath.Dir(s.file)
	for _, folder := range storageFolders() {
		if !trustedStorageDirectory(root, folder) {
			continue
		}
		entries, err := os.ReadDir(filepath.Join(root, filepath.FromSlash(folder)))
		if err != nil {
			continue
		}
		for _, entry := range entries {
			name := entry.Name()
			if !validStoredName(folder, name) {
				continue
			}
			info, err := entry.Info()
			if err != nil || !info.Mode().IsRegular() || now.Sub(info.ModTime()) < storageGrace() {
				continue
			}
			key := mediaKey(folder, name)
			if _, present := refs[key]; present {
				continue
			}
			result.Candidates++
			result.Bytes += info.Size()
			if dryRun {
				continue
			}
			path := filepath.Join(root, filepath.FromSlash(folder), name)
			if err := os.Remove(path); err != nil {
				result.Errors++
				log.Printf("STORAGE orphan cleanup failed %s: %v", key, err)
			} else {
				result.Deleted++
				log.Printf("STORAGE orphan cleaned %s (%d bytes)", key, info.Size())
			}
		}
	}
	return result
}
func (s *Server) storageAPI(w http.ResponseWriter, r *http.Request) {
	user, err := s.auth(r)
	if err != nil {
		http.Error(w, "unauthorized", 401)
		return
	}
	if s.resources != nil && !s.resources.allow(user, "storage_query", time.Now()) {
		w.Header().Set("Retry-After", "10")
		http.Error(w, "Too many storage queries", 429)
		return
	}
	s.mu.Lock()
	defer s.mu.Unlock()
	if r.Method == http.MethodGet {
		snap := s.storageSnapshotLocked()
		reply(w, 200, map[string]any{"used": snap.UserBytes[user], "user_limit": storageSetting("EXPLICIT_STORAGE_USER_BYTES", defaultUserStorageLimit), "global_used": snap.TotalBytes, "global_limit": storageSetting("EXPLICIT_STORAGE_GLOBAL_BYTES", defaultGlobalStorageLimit)})
		return
	}
	if r.Method != http.MethodPost {
		http.Error(w, "method", 405)
		return
	}
	if !s.isOwner(user) {
		http.Error(w, "owner required", 403)
		return
	}
	var request struct {
		DryRun bool `json:"dry_run"`
	}
	if err := json.NewDecoder(http.MaxBytesReader(w, r.Body, 2048)).Decode(&request); err != nil {
		http.Error(w, "invalid", 400)
		return
	}
	if !request.DryRun && os.Getenv("EXPLICIT_FILE_CLEANUP_ENABLE") != "1" {
		http.Error(w, "cleanup disabled; dry-run first", 403)
		return
	}
	result := s.cleanOrphansLocked(request.DryRun, time.Now())
	log.Printf("STORAGE cleanup actor=%s dry_run=%t candidates=%d removed=%d errors=%d", user, request.DryRun, result.Candidates, result.Deleted, result.Errors)
	reply(w, 200, result)
}
func (s *Server) startStorageMaintenance() {
	go func() {
		ticker := time.NewTicker(6 * time.Hour)
		defer ticker.Stop()
		for range ticker.C {
			s.mu.Lock()
			report := s.cleanOrphansLocked(os.Getenv("EXPLICIT_FILE_CLEANUP_ENABLE") != "1", time.Now())
			s.mu.Unlock()
			if report.Candidates > 0 {
				log.Printf("STORAGE maintenance dry_run=%t candidates=%d removed=%d errors=%d", report.DryRun, report.Candidates, report.Deleted, report.Errors)
			}
		}
	}()
}
