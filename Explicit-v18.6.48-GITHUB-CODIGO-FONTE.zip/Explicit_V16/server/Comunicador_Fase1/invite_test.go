package main

import "testing"

func testInviteKey(s *Server) string {
	if u, ok := s.db.Users["alice"]; ok {
		return u.InviteKey
	}
	return "TEST-BOOTSTRAP"
}
func TestInviteValidation(t *testing.T) {
	t.Setenv("EXPLICIT_INITIAL_INVITE_KEY", "TEST-BOOTSTRAP")
	s := newServer(t.TempDir() + "/db.json")
	if _, ok := s.validateInviteLocked("WRONG"); ok {
		t.Fatal("invalid accepted")
	}
	if _, ok := s.validateInviteLocked("TEST-BOOTSTRAP"); !ok {
		t.Fatal("bootstrap rejected")
	}
	s.db.Users["alice"] = User{Name: "alice", InviteKey: "FIXED-KEY", SystemRole: "user"}
	if _, ok := s.validateInviteLocked("TEST-BOOTSTRAP"); ok {
		t.Fatal("bootstrap reused")
	}
	for i := 0; i < 5; i++ {
		s.db.Invites = append(s.db.Invites, InviteRedemption{Inviter: "alice"})
	}
	if _, ok := s.validateInviteLocked("FIXED-KEY"); ok {
		t.Fatal("quota bypass")
	}
	u := s.db.Users["alice"]
	u.SystemRole = "admin"
	s.db.Users["alice"] = u
	if _, ok := s.validateInviteLocked("FIXED-KEY"); !ok {
		t.Fatal("admin quota")
	}
}
