@echo off
setlocal
cd /d "%~dp0"
set "PATH=C:\Program Files\PostgreSQL\18\bin;%PATH%"
set "PGHOST=127.0.0.1"
set "PGPORT=5432"
set "PGDATABASE=explicit"
set "PGUSER=explicit_app"
if not defined LISTEN_ADDR set /p "LISTEN_ADDR=IP Radmin e porta do servidor (ex: 26.x.x.x:8080): "
if not defined LISTEN_ADDR (echo Endereco obrigatorio. & pause & exit /b 1)
set /p "PGPASSWORD=Senha do usuario explicit_app: "
if not exist "ExplicitServer-Radmin-Postgres.exe" (echo Executavel nao encontrado. & pause & exit /b 1)
"ExplicitServer-Radmin-Postgres.exe"
pause
