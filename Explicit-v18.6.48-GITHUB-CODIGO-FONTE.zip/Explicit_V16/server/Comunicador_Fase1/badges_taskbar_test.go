package main

import (
	"bytes"
	"encoding/json"
	"net/http/httptest"
	"path/filepath"
	"testing"
	"time"
)

func TestExplicitBadgesGrantAndProtection(t *testing.T) {
	s := newServer(filepath.Join(t.TempDir(), "store.json"))
	s.db.Users["root"] = User{Name: "root", SystemRole: "superadmin"}
	s.db.Users["alice"] = User{Name: "alice"}
	s.db.Users["bob"] = User{Name: "bob"}
	s.db.Users["creator"] = User{Name: "creator", AccountID: token()}
	if err := s.bootstrapOwner("creator"); err != nil {
		t.Fatal(err)
	}
	s.sessions["owner-test"] = "creator"
	s.sessions["root-test"] = "root"
	s.sessions["alice-test"] = "alice"
	call := func(token string, badges []string) int {
		b, _ := json.Marshal(map[string]any{"action": "set_badges", "target": "alice", "badges": badges, "duration_seconds": 3600})
		r := httptest.NewRequest("POST", "/api/system-admin", bytes.NewReader(b))
		r.Header.Set("Authorization", "Bearer "+token)
		w := httptest.NewRecorder()
		s.routes().ServeHTTP(w, r)
		return w.Code
	}
	if got := call("alice-test", []string{"beta"}); got != 403 {
		t.Fatalf("ordinary user granted badge: %d", got)
	}
	if got := call("root-test", []string{"beta", "beta"}); got != 400 {
		t.Fatalf("duplicate badge accepted: %d", got)
	}
	if got := call("root-test", []string{"beta", "explicit_plus"}); got != 200 {
		t.Fatalf("two badges: %d", got)
	}
	if !s.maySendStickersLocked("alice") || systemLevel(systemRole(s.db.Users["alice"])) != 0 {
		t.Fatal("beta plus must not grant Staff privileges")
	}
	if got := call("root-test", []string{"staff", "beta", "explicit_plus"}); got != 400 {
		t.Fatalf("more than two badges accepted: %d", got)
	}
	if got := call("root-test", []string{"staff", "beta"}); got != 403 {
		t.Fatalf("Non-owner granted Admin: %d", got)
	}
	if got := call("owner-test", []string{"staff", "beta"}); got != 200 {
		t.Fatalf("staff and beta: %d", got)
	}
	u := s.db.Users["alice"]
	if len(userBadges(u)) != 2 || systemRole(u) != "moderator" {
		t.Fatalf("invalid 2-badge selection: %+v", u)
	}
	if got := call("owner-test", []string{}); got != 200 {
		t.Fatalf("remove badges: %d", got)
	}
	if s.maySendStickersLocked("alice") || systemRole(s.db.Users["alice"]) != "user" {
		t.Fatal("badge removal failed")
	}
	// Explicit+ alone is a separate persistent badge, no payments or moderator access.
	if got := call("root-test", []string{"explicit_plus"}); got != 200 {
		t.Fatalf("plus: %d", got)
	}
	saved := newServer(s.file).db.Users["alice"]
	if !saved.ExplicitPlus || saved.Beta || systemLevel(systemRole(saved)) != 0 || !s.maySendStickersLocked("alice") {
		t.Fatalf("bad badge persistence: %+v", saved)
	}
}

func TestGlobalUnreadBadgeCommunityAndDirectReads(t *testing.T) {
	s := newServer(filepath.Join(t.TempDir(), "store.json"))
	for _, n := range []string{"alice", "bob", "root"} {
		s.db.Users[n] = User{Name: n}
	}
	s.sessions["alice-token"] = "alice"
	s.db.Communities = []Community{{ID: "c", Name: "Public", Owner: "root", Members: []string{"alice", "bob", "root"}, Channels: []string{"general"}, ChannelMeta: map[string]ChannelMeta{"general": {Type: "text"}}}}
	s.enqueueNotificationLocked("alice", "message", "bob", "c", "general", "olá")
	s.enqueueNotificationLocked("alice", "direct", "bob", "", "", "oi DM")
	s.enqueueNotificationLocked("alice", "friend", "bob", "", "", "convite")
	if n := s.unreadNotificationsLocked("alice"); n != 3 {
		t.Fatalf("expected 3, got %d", n)
	}
	send := func(action, author string) int {
		b, _ := json.Marshal(map[string]any{"action": action, "author": author})
		r := httptest.NewRequest("POST", "/api/notifications", bytes.NewReader(b))
		r.Header.Set("Authorization", "Bearer alice-token")
		w := httptest.NewRecorder()
		s.routes().ServeHTTP(w, r)
		return w.Code
	}
	if got := send("read_direct", "bob"); got != 200 {
		t.Fatalf("direct read %d", got)
	}
	if n := s.unreadNotificationsLocked("alice"); n != 2 {
		t.Fatalf("direct read count %d", n)
	}
	if got := send("read_misc", ""); got != 200 {
		t.Fatalf("misc read %d", got)
	}
	if n := s.unreadNotificationsLocked("alice"); n != 1 {
		t.Fatalf("misc read count %d", n)
	}
	if got := send("read_all", ""); got != 200 {
		t.Fatalf("all read %d", got)
	}
	if n := s.unreadNotificationsLocked("alice"); n != 0 {
		t.Fatalf("all read count %d", n)
	}
	s.enqueueNotificationLocked("alice", "direct", "bob", "", "", "new dm")
	// Timestamps are strictly greater than read cursor, even if generated in the same second.
	time.Sleep(time.Millisecond)
	if err := s.save(); err != nil {
		t.Fatal(err)
	}
	if n := s.unreadNotificationsLocked("alice"); n != 1 {
		t.Fatalf("new unread count %d", n)
	}
	if n := newServer(s.file).unreadNotificationsLocked("alice"); n != 1 {
		t.Fatalf("persisted unread count %d", n)
	}
}
