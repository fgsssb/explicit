package main

import (
	"bytes"
	"encoding/json"
	"net/http/httptest"
	"path/filepath"
	"testing"
)

func TestDeleteCommunityRequiresOwnerExactNameAndConfirmation(t *testing.T) {
	s := newServer(filepath.Join(t.TempDir(), "store.json"))
	for _, name := range []string{"ana", "bia"} {
		s.db.Users[name] = User{Name: name}
		s.sessions[name+"-session"] = name
	}
	s.db.Communities = []Community{
		{ID: "keep", Name: "Keep", Owner: "ana", Members: []string{"ana"}, Channels: []string{"geral"}, ChannelMeta: map[string]ChannelMeta{"geral": {Type: "text"}}},
		{ID: "delete", Name: "Sala Teste", Owner: "ana", Members: []string{"ana", "bia"}, Channels: []string{"geral"}, ChannelMeta: map[string]ChannelMeta{"geral": {Type: "text"}}},
	}
	s.db.Messages = []Message{{ID: "m0", Channel: "keep:geral"}, {ID: "m1", Channel: "delete:geral"}}
	call := func(name string, data map[string]any) int {
		b, _ := json.Marshal(data)
		req := httptest.NewRequest("POST", "/api/community-hub", bytes.NewReader(b))
		req.Header.Set("Authorization", "Bearer "+name+"-session")
		w := httptest.NewRecorder()
		s.routes().ServeHTTP(w, req)
		return w.Code
	}
	good := map[string]any{"community": "delete", "action": "delete_community", "name": "Sala Teste", "confirm": true}
	if code := call("bia", good); code != 403 {
		t.Fatalf("regular member can delete: %d", code)
	}
	for _, bad := range []map[string]any{
		{"community": "delete", "action": "delete_community", "name": "Sala Teste"},
		{"community": "delete", "action": "delete_community", "name": "Sala teste", "confirm": true},
		{"community": "delete", "action": "delete_community", "name": "Sala Teste ", "confirm": true},
	} {
		if code := call("ana", bad); code != 400 {
			t.Fatalf("invalid confirmation: %d", code)
		}
	}
	if len(s.db.Communities) != 2 {
		t.Fatal("community removed before confirmation")
	}
	if code := call("ana", good); code != 200 {
		t.Fatalf("owner cannot delete: %d", code)
	}
	if len(s.db.Communities) != 1 || s.db.Communities[0].ID != "keep" {
		t.Fatalf("wrong community deleted: %+v", s.db.Communities)
	}
	if len(s.db.Messages) != 1 || s.db.Messages[0].Channel != "keep:geral" {
		t.Fatalf("messages not filtered: %+v", s.db.Messages)
	}
	saved := newServer(s.file)
	if len(saved.db.Communities) != 1 || saved.db.Communities[0].ID != "keep" {
		t.Fatal("deletion not persisted")
	}
	if code := call("ana", good); code != 404 {
		t.Fatalf("deleted community accessible: %d", code)
	}
}
