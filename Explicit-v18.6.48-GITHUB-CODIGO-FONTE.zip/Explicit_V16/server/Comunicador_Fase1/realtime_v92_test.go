package main

import "testing"

func TestChannelEventRejectsUnknownCommunity(t *testing.T) {
	s := newServer(t.TempDir() + "/store.json")
	if s.canReceiveChannelEvent("missing", "general", "anyone") {
		t.Fatal("unknown community received channel event")
	}
}
