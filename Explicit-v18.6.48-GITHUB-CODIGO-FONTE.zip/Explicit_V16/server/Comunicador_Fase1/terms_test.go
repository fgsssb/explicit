package main

import (
	"encoding/json"
	"net/http/httptest"
	"strings"
	"testing"
)

func TestTermsGateAndAuditedAcceptance(t *testing.T) {
	t.Setenv("EXPLICIT_INITIAL_INVITE_KEY", "TEST-BOOTSTRAP")
	s := newServer(t.TempDir() + "/store.json")
	call := func(method, path, body, tok string) *httptest.ResponseRecorder {
		r := httptest.NewRequest(method, path, strings.NewReader(body))
		if tok != "" {
			r.Header.Set("Authorization", "Bearer "+tok)
		}
		w := httptest.NewRecorder()
		s.routes().ServeHTTP(w, r)
		return w
	}
	if w := call("POST", "/api/register", `{"name":"tester","password":"password123","display_name":"Tester","invite_key":"TEST-BOOTSTRAP"}`, ""); w.Code != 201 {
		t.Fatal(w.Body)
	}
	w := call("POST", "/api/login", `{"name":"tester","password":"password123"}`, "")
	if w.Code != 200 {
		t.Fatal(w.Body)
	}
	var auth map[string]string
	_ = json.Unmarshal(w.Body.Bytes(), &auth)
	tok := auth["token"]
	if w = call("GET", "/api/communities", "", tok); w.Code != 403 {
		t.Fatalf("must refuse until acceptance: %d %s", w.Code, w.Body)
	}
	if w = call("POST", "/api/terms", `{"accept":true,"version":"wrong"}`, tok); w.Code != 400 {
		t.Fatal("wrong version was accepted")
	}
	if w = call("POST", "/api/terms", `{"accept":true,"version":"`+currentTermsVersion+`"}`, tok); w.Code != 200 {
		t.Fatal(w.Body)
	}
	if w = call("GET", "/api/communities", "", tok); w.Code != 200 {
		t.Fatalf("not unlocked: %d %s", w.Code, w.Body)
	}
	account := newServer(s.file).db.Users["tester"]
	if account.TermsAcceptedAt == nil || account.TermsVersion != currentTermsVersion {
		t.Fatal("acceptance not persisted")
	}
}
