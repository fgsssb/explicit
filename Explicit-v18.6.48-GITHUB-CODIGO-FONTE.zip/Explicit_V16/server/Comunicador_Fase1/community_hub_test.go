package main

import (
	"bytes"
	"encoding/json"
	"net/http/httptest"
	"path/filepath"
	"strings"
	"testing"
	"time"
)

func TestCommunityHubUnreadMuteReadAndPersistence(t *testing.T) {
	s := newServer(filepath.Join(t.TempDir(), "store.json"))
	for _, u := range []string{"owner", "bia", "outsider"} {
		s.db.Users[u] = User{Name: u}
		s.sessions[u+"-session"] = u
	}
	c := Community{ID: "orig-1234", Name: "Original", Owner: "owner", Members: []string{"owner", "bia"}, Channels: []string{"geral", "private"}, ChannelMeta: map[string]ChannelMeta{"geral": {Type: "text"}, "private": {Type: "text", RolePermissions: map[string]map[string]bool{"everyone": {"VIEW_CHANNEL": false}}}}}
	s.db.Communities = []Community{c}
	s.enqueueNotificationLocked("bia", "message", "owner", c.ID, "geral", "primeira")
	s.enqueueNotificationLocked("bia", "mention", "owner", c.ID, "private", "segredo")
	s.enqueueNotificationLocked("bia", "mention", "owner", c.ID, "geral", "@bia segunda")
	call := func(user, method, url string, q any) *httptest.ResponseRecorder {
		t.Helper()
		b, _ := json.Marshal(q)
		r := httptest.NewRequest(method, url, bytes.NewReader(b))
		r.Header.Set("Authorization", "Bearer "+user+"-session")
		w := httptest.NewRecorder()
		s.routes().ServeHTTP(w, r)
		return w
	}
	get := func() map[string]any {
		w := call("bia", "GET", "/api/community-hub", nil)
		if w.Code != 200 {
			t.Fatal(w.Body.String())
		}
		var m map[string]any
		if json.Unmarshal(w.Body.Bytes(), &m) != nil {
			t.Fatal(w.Body.String())
		}
		return m[c.ID].(map[string]any)
	}
	if v := get()["unread"].(float64); v != 2 {
		t.Fatalf("only public messages should count, got %v", v)
	}
	if w := call("bia", "POST", "/api/community-hub", map[string]any{"community": c.ID, "action": "preferences", "mode": "mentions"}); w.Code != 200 {
		t.Fatal(w.Body.String())
	}
	if v := get()["unread"].(float64); v != 1 {
		t.Fatalf("mentions setting %v", v)
	}
	if w := call("bia", "POST", "/api/community-hub", map[string]any{"community": c.ID, "action": "mute", "mute": "24h"}); w.Code != 200 {
		t.Fatal(w.Body.String())
	}
	if v := get()["unread"].(float64); v != 0 {
		t.Fatalf("mute badge %v", v)
	}
	if got := s.db.CommunityPrefs[communityPrefKey("bia", c.ID)]; got.MutedUntil <= time.Now().Unix() {
		t.Fatalf("mute not persisted %#v", got)
	}
	if w := call("bia", "POST", "/api/community-hub", map[string]any{"community": c.ID, "action": "mute", "mute": "off"}); w.Code != 200 {
		t.Fatal(w.Body.String())
	}
	if v := get()["unread"].(float64); v != 1 {
		t.Fatalf("unmute badge %v", v)
	}
	if w := call("bia", "POST", "/api/community-hub", map[string]any{"community": c.ID, "action": "read"}); w.Code != 200 {
		t.Fatal(w.Body.String())
	}
	if v := get()["unread"].(float64); v != 0 {
		t.Fatalf("mark read badge %v", v)
	}
	copy := newServer(s.file)
	if p := copy.db.CommunityPrefs[communityPrefKey("bia", c.ID)]; p.MessageMode != "mentions" || p.ReadThrough == 0 {
		t.Fatalf("settings lost %#v", p)
	}
	if w := call("outsider", "GET", "/api/community-hub?community="+c.ID, nil); w.Code != 403 {
		t.Fatalf("outsider info %d", w.Code)
	}
}
func TestCommunityHubInviteJoinClosedAndAuthorization(t *testing.T) {
	s := newServer(filepath.Join(t.TempDir(), "store.json"))
	for _, u := range []string{"owner", "bia", "newbie"} {
		s.db.Users[u] = User{Name: u}
		s.sessions[u+"-session"] = u
	}
	s.db.Communities = []Community{{ID: "oldinvite", Name: "Server", Owner: "owner", Members: []string{"owner", "bia"}, Channels: []string{"geral"}, ChannelMeta: map[string]ChannelMeta{"geral": {Type: "text"}}}}
	call := func(user, method, url string, q any) *httptest.ResponseRecorder {
		t.Helper()
		b, _ := json.Marshal(q)
		r := httptest.NewRequest(method, url, bytes.NewReader(b))
		r.Header.Set("Authorization", "Bearer "+user+"-session")
		w := httptest.NewRecorder()
		s.routes().ServeHTTP(w, r)
		return w
	}
	for _, action := range []string{"rename", "rotate_invite", "toggle_join"} {
		q := map[string]any{"community": "oldinvite", "action": action, "name": "Hacked", "join_closed": true}
		if w := call("bia", "POST", "/api/community-hub", q); w.Code != 403 {
			t.Fatalf("member action %s code %d", action, w.Code)
		}
	}
	if w := call("owner", "POST", "/api/community-hub", map[string]any{"community": "oldinvite", "action": "toggle_join", "join_closed": true}); w.Code != 200 {
		t.Fatal(w.Body.String())
	}
	if w := call("newbie", "POST", "/api/communities", map[string]any{"join": "oldinvite"}); w.Code != 403 {
		t.Fatalf("closed join %d %s", w.Code, w.Body.String())
	}
	if w := call("owner", "POST", "/api/community-hub", map[string]any{"community": "oldinvite", "action": "toggle_join", "join_closed": false}); w.Code != 200 {
		t.Fatal(w.Body.String())
	}
	if w := call("owner", "POST", "/api/community-hub", map[string]any{"community": "oldinvite", "action": "rotate_invite"}); w.Code != 200 {
		t.Fatal(w.Body.String())
	}
	if s.db.Communities[0].InviteCode == "oldinvite" || s.db.Communities[0].InviteCode == "" {
		t.Fatal("invite not rotated")
	}
	if w := call("newbie", "POST", "/api/communities", map[string]any{"join": "oldinvite"}); w.Code != 404 {
		t.Fatalf("old link still valid %d", w.Code)
	}
	if w := call("newbie", "POST", "/api/communities", map[string]any{"join": s.db.Communities[0].InviteCode}); w.Code != 200 {
		t.Fatalf("new invite fails %d %s", w.Code, w.Body.String())
	}
	if len(s.db.Communities[0].Members) != 3 {
		t.Fatal("new member missing")
	}
	if w := call("owner", "POST", "/api/community-hub", map[string]any{"community": "oldinvite", "action": "rename", "name": "Novo nome"}); w.Code != 200 {
		t.Fatal(w.Body.String())
	}
	if c := newServer(s.file).db.Communities[0]; c.Name != "Novo nome" || c.ID != "oldinvite" || c.InviteCode == "" {
		t.Fatalf("id or name changed %#v", c)
	}
	if w := call("bia", "POST", "/api/community-hub", map[string]any{"community": "oldinvite", "action": "preferences", "mode": "invalid"}); w.Code != 400 {
		t.Fatalf("accepted invalid prefs %d", w.Code)
	}
	if w := call("owner", "POST", "/api/community-hub", map[string]any{"community": "oldinvite", "action": "invite", "invite": "oldinvite"}); w.Code != 200 {
		t.Fatal(strings.TrimSpace(w.Body.String()))
	}
}
