package main

import (
	"encoding/json"
	"errors"
	"net/http"
	"strings"
)

// Channel ACLs use tri-state overrides: missing means inherit; true allows; false denies.
// These are permissions for features that already exist in Explicit (not Discord-only features).
var channelACLKeys = map[string]bool{
	"VIEW_CHANNEL": true, "SEND_MESSAGES": true, "ATTACH_FILES": true, "USE_STICKERS": true,
	"CONNECT_VOICE": true, "SPEAK": true, "USE_PTT": true, "SCREEN_SHARE": true, "POKE_MEMBERS": true, "CREATE_INVITES": true,
	"EDIT_OWN_MESSAGES": true, "DELETE_OWN_MESSAGES": true, "EDIT_ANY_MESSAGES": true,
	"DELETE_ANY_MESSAGES": true, "PIN_MESSAGES": true, "MUTE_MEMBERS": true,
	"DEAFEN_MEMBERS": true, "MOVE_MEMBERS": true, "DISCONNECT_VOICE": true,
}

func cloneOverrides(src map[string]map[string]bool) map[string]map[string]bool {
	if len(src) == 0 {
		return nil
	}
	out := map[string]map[string]bool{}
	for role, p := range src {
		out[role] = map[string]bool{}
		for k, v := range p {
			out[role][k] = v
		}
	}
	return out
}
func findCategory(c Community, id string) *ChannelCategory {
	for i := range c.Categories {
		if c.Categories[i].ID == id {
			return &c.Categories[i]
		}
	}
	return nil
}
func categoryExists(c Community, id string) bool { return findCategory(c, id) != nil }
func validateOverrides(c Community, roles, members map[string]map[string]bool) error {
	if len(roles) > 51 || len(members) > 150 {
		return errors.New("too many overrides")
	}
	for id, p := range roles {
		valid := id == "everyone"
		for _, r := range c.Roles {
			if r.ID == id {
				valid = true
			}
		}
		if !valid || len(p) > len(channelACLKeys) {
			return errors.New("unknown role or excessive permissions")
		}
		for k := range p {
			if !channelACLKeys[k] {
				return errors.New("unknown channel permission")
			}
		}
	}
	for id, p := range members {
		if !contains(c.Members, id) || len(p) > len(channelACLKeys) {
			return errors.New("unknown member or excessive permissions")
		}
		for k := range p {
			if !channelACLKeys[k] {
				return errors.New("unknown channel permission")
			}
		}
	}
	return nil
}

// Permission managers cannot grant permissions beyond their own effective community grants.
func (s *Server) maySetOverrides(c Community, actor string, roles, members map[string]map[string]bool) bool {
	if c.Owner == actor || s.isSuperadmin(actor) {
		return true
	}
	for _, p := range []map[string]map[string]bool{roles, members} {
		for _, v := range p {
			for k, yes := range v {
				if yes && !s.hasPermission(c, actor, k) {
					return false
				}
			}
		}
	}
	for role := range roles {
		if role == "everyone" {
			continue
		}
		for _, r := range c.Roles {
			if r.ID == role && r.Priority >= s.maxPriority(c, actor) {
				return false
			}
		}
	}
	for member := range members {
		if s.maxPriority(c, member) >= s.maxPriority(c, actor) {
			return false
		}
	}
	return true
}
func (s *Server) channelAttachAllowed(community, channel, user string) bool {
	for _, c := range s.db.Communities {
		if c.ID == community {
			return s.channelPermission(c, user, channel, "ATTACH_FILES")
		}
	}
	return false
}
func (s *Server) channelStickerAllowed(community, channel, user string) bool {
	for _, c := range s.db.Communities {
		if c.ID == community {
			return s.channelPermission(c, user, channel, "USE_STICKERS")
		}
	}
	return false
}

// channelHasRestrictedVisibility reports whether VIEW_CHANNEL is denied to any
// role or member. Only the boolean is disclosed to ordinary members: individual
// per-user ACLs must remain private. Restrictions copied from categories are
// already represented in ChannelMeta when permissions are synchronized.
func channelHasRestrictedVisibility(meta ChannelMeta) bool {
	for _, rules := range meta.RolePermissions {
		if allowed, exists := rules["VIEW_CHANNEL"]; exists && !allowed {
			return true
		}
	}
	for _, rules := range meta.MemberPermissions {
		if allowed, exists := rules["VIEW_CHANNEL"]; exists && !allowed {
			return true
		}
	}
	return false
}

// Return only channels the account is authorized to discover, not just to open.
func (s *Server) visibleCommunity(c Community, user string) Community {
	result := c
	result.Channels = []string{}
	result.ChannelMeta = map[string]ChannelMeta{}
	visibleCats := map[string]bool{}
	for _, ch := range c.Channels {
		if s.channelPermission(c, user, ch, "VIEW_CHANNEL") {
			result.Channels = append(result.Channels, ch)
			meta := c.ChannelMeta[ch]
			meta.Private = channelHasRestrictedVisibility(meta)
			// Never disclose individual ACLs for unrelated accounts through the normal list.
			meta.MemberPermissions = nil
			result.ChannelMeta[ch] = meta
			if meta.Category != "" {
				visibleCats[meta.Category] = true
			}
		}
	}
	result.Categories = []ChannelCategory{}
	for _, cat := range c.Categories {
		if visibleCats[cat.ID] || s.hasPermission(c, user, "MANAGE_CHANNELS") {
			cat.MemberPermissions = nil
			result.Categories = append(result.Categories, cat)
		}
	}
	return result
}
func (s *Server) channelPermissionsAPI(w http.ResponseWriter, r *http.Request) {
	actor, err := s.auth(r)
	if err != nil {
		http.Error(w, "unauthorized", 401)
		return
	}
	var q struct {
		Community         string                     `json:"community"`
		Action            string                     `json:"action"`
		Channel           string                     `json:"channel"`
		Before            string                     `json:"before"`
		Category          string                     `json:"category"`
		Name              string                     `json:"name"`
		RolePermissions   map[string]map[string]bool `json:"role_permissions"`
		MemberPermissions map[string]map[string]bool `json:"member_permissions"`
		Sync              bool                       `json:"sync"`
		Private           bool                       `json:"private"`
	}
	if r.Method == http.MethodGet {
		q.Community = r.URL.Query().Get("community")
		q.Channel = r.URL.Query().Get("channel")
		q.Action = "info"
	} else if r.Method == http.MethodPost {
		if parse(r, &q) != nil {
			http.Error(w, "invalid request", 400)
			return
		}
	} else {
		http.Error(w, "method", 405)
		return
	}
	s.mu.Lock()
	defer s.mu.Unlock()
	for i := range s.db.Communities {
		c := &s.db.Communities[i]
		if c.ID != q.Community {
			continue
		}
		if !s.hasPermission(*c, actor, "MANAGE_CHANNELS") {
			http.Error(w, "forbidden", 403)
			return
		}
		if q.Action == "info" {
			reply(w, 200, map[string]any{"categories": c.Categories, "channel_meta": c.ChannelMeta, "members": c.Members, "roles": c.Roles, "member_roles": c.MemberRoles})
			return
		}
		old, _ := json.Marshal(*c)
		canEditACL := s.hasPermission(*c, actor, "MANAGE_ROLES")
		if !canEditACL && (q.Action == "category_update" || q.Action == "channel_update" || q.Action == "channel_sync" || q.Action == "category_sync_all" || (q.Action == "channel_reorder" && q.Sync && q.Category != "")) {
			http.Error(w, "manage roles permission required", 403)
			return
		}
		if q.Action == "category_update" || q.Action == "channel_update" {
			if err := validateOverrides(*c, q.RolePermissions, q.MemberPermissions); err != nil {
				http.Error(w, err.Error(), 400)
				return
			}
			if !s.maySetOverrides(*c, actor, q.RolePermissions, q.MemberPermissions) {
				http.Error(w, "cannot grant permission above your role", 403)
				return
			}
		}
		switch q.Action {
		case "category_create":
			q.Name = strings.TrimSpace(q.Name)
			if len(q.Name) < 1 || len(q.Name) > 40 || len(c.Categories) >= 40 {
				http.Error(w, "invalid category", 400)
				return
			}
			c.Categories = append(c.Categories, ChannelCategory{ID: token()[:12], Name: q.Name})
		case "category_update":
			cat := findCategory(*c, q.Category)
			if cat == nil {
				http.Error(w, "unknown category", 404)
				return
			}
			name := strings.TrimSpace(q.Name)
			if len(name) > 40 {
				http.Error(w, "invalid category name", 400)
				return
			}
			if name != "" {
				cat.Name = name
			}
			cat.RolePermissions = cloneOverrides(q.RolePermissions)
			cat.MemberPermissions = cloneOverrides(q.MemberPermissions)
			for ch, meta := range c.ChannelMeta {
				if meta.Category == cat.ID && meta.Synced {
					meta.RolePermissions = cloneOverrides(cat.RolePermissions)
					meta.MemberPermissions = cloneOverrides(cat.MemberPermissions)
					c.ChannelMeta[ch] = meta
				}
			}
		case "category_sync_all":
			cat := findCategory(*c, q.Category)
			if cat == nil {
				http.Error(w, "unknown category", 404)
				return
			}
			if !s.maySetOverrides(*c, actor, cat.RolePermissions, cat.MemberPermissions) {
				http.Error(w, "forbidden", 403)
				return
			}
			for ch, meta := range c.ChannelMeta {
				if meta.Category == cat.ID {
					meta.RolePermissions = cloneOverrides(cat.RolePermissions)
					meta.MemberPermissions = cloneOverrides(cat.MemberPermissions)
					meta.Synced = true
					c.ChannelMeta[ch] = meta
				}
			}
		case "category_delete":
			if !categoryExists(*c, q.Category) {
				http.Error(w, "unknown category", 404)
				return
			}
			next := make([]ChannelCategory, 0, len(c.Categories))
			for _, cat := range c.Categories {
				if cat.ID != q.Category {
					next = append(next, cat)
				}
			}
			c.Categories = next
			for ch, meta := range c.ChannelMeta {
				if meta.Category == q.Category {
					meta.Category = ""
					meta.Synced = false
					c.ChannelMeta[ch] = meta
				}
			}
		case "channel_reorder":
			if !contains(c.Channels, q.Channel) || (q.Before != "" && (!contains(c.Channels, q.Before) || q.Before == q.Channel)) || (q.Category != "" && !categoryExists(*c, q.Category)) {
				http.Error(w, "invalid channel/order/category", 400)
				return
			}
			if q.Category != "" && q.Sync && !s.maySetOverrides(*c, actor, findCategory(*c, q.Category).RolePermissions, findCategory(*c, q.Category).MemberPermissions) {
				http.Error(w, "cannot inherit category permissions", 403)
				return
			}
			next := make([]string, 0, len(c.Channels))
			for _, name := range c.Channels {
				if name != q.Channel {
					next = append(next, name)
				}
			}
			index := len(next)
			if q.Before != "" {
				for i, name := range next {
					if name == q.Before {
						index = i
						break
					}
				}
			}
			next = append(next, "")
			copy(next[index+1:], next[index:])
			next[index] = q.Channel
			c.Channels = next
			meta := c.ChannelMeta[q.Channel]
			oldCategory := meta.Category
			meta.Category = q.Category
			if oldCategory != q.Category {
				meta.Synced = false
			}
			if q.Sync && q.Category != "" {
				cat := findCategory(*c, q.Category)
				meta.RolePermissions = cloneOverrides(cat.RolePermissions)
				meta.MemberPermissions = cloneOverrides(cat.MemberPermissions)
				meta.Synced = true
			}
			c.ChannelMeta[q.Channel] = meta
		case "channel_move":
			if !contains(c.Channels, q.Channel) || q.Category != "" && !categoryExists(*c, q.Category) {
				http.Error(w, "invalid channel/category", 400)
				return
			}
			meta := c.ChannelMeta[q.Channel]
			meta.Category = q.Category
			meta.Synced = false
			c.ChannelMeta[q.Channel] = meta
		case "channel_sync":
			meta, ok := c.ChannelMeta[q.Channel]
			if !ok || meta.Category == "" {
				http.Error(w, "channel has no category", 400)
				return
			}
			cat := findCategory(*c, meta.Category)
			if cat == nil {
				http.Error(w, "category missing", 400)
				return
			}
			if !s.maySetOverrides(*c, actor, cat.RolePermissions, cat.MemberPermissions) {
				http.Error(w, "forbidden", 403)
				return
			}
			meta.RolePermissions = cloneOverrides(cat.RolePermissions)
			meta.MemberPermissions = cloneOverrides(cat.MemberPermissions)
			meta.Synced = true
			c.ChannelMeta[q.Channel] = meta
		case "channel_update":
			meta, ok := c.ChannelMeta[q.Channel]
			if !ok {
				http.Error(w, "channel not found", 404)
				return
			}
			if q.Private {
				if q.RolePermissions == nil {
					q.RolePermissions = map[string]map[string]bool{}
				}
				if q.RolePermissions["everyone"] == nil {
					q.RolePermissions["everyone"] = map[string]bool{}
				}
				q.RolePermissions["everyone"]["VIEW_CHANNEL"] = false
			}
			meta.RolePermissions = cloneOverrides(q.RolePermissions)
			meta.MemberPermissions = cloneOverrides(q.MemberPermissions)
			meta.Synced = false
			c.ChannelMeta[q.Channel] = meta
		default:
			http.Error(w, "unknown action", 400)
			return
		}
		if err := s.save(); err != nil {
			_ = json.Unmarshal(old, c)
			http.Error(w, "storage failure", 500)
			return
		}
		s.appendAudit(c.ID, actor, "Permissões de canal/categoria", q.Action+" "+q.Channel+" "+q.Category)
		reply(w, 200, map[string]any{"ok": true, "categories": c.Categories, "channel_meta": c.ChannelMeta})
		return
	}
	http.Error(w, "community not found", 404)
}
