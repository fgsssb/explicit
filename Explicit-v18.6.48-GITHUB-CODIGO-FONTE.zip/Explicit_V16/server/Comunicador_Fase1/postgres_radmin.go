package main

import (
	"bytes"
	"encoding/json"
	"errors"
	"fmt"
	"os"
	"os/exec"
	"strings"
)

// PostgreSQL is selected only when PGDATABASE is explicitly set. The existing
// JSON-file persistence remains untouched for local development and tests.
func postgresRun(sql string) ([]byte, error) {
	if strings.TrimSpace(os.Getenv("PGDATABASE")) == "" {
		return nil, errors.New("PGDATABASE not configured")
	}
	cmd := exec.Command("psql", "-X", "-q", "-A", "-t", "-v", "ON_ERROR_STOP=1", "-f", "-")
	cmd.Stdin = strings.NewReader(sql)
	out, err := cmd.CombinedOutput()
	if err != nil {
		return nil, fmt.Errorf("psql failed: %w: %s", err, strings.TrimSpace(string(out)))
	}
	return bytes.TrimSpace(out), nil
}
func postgresInit() error {
	_, err := postgresRun(`CREATE TABLE IF NOT EXISTS explicit_state (id SMALLINT PRIMARY KEY CHECK (id=1), payload JSONB NOT NULL, updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW());`)
	return err
}
func postgresLoad() ([]byte, error) {
	if err := postgresInit(); err != nil {
		return nil, err
	}
	out, err := postgresRun("SELECT payload::text FROM explicit_state WHERE id=1;")
	if err != nil {
		return nil, err
	}
	if len(out) == 0 {
		return nil, nil
	}
	if !json.Valid(out) {
		return nil, errors.New("PostgreSQL returned invalid JSON state")
	}
	return out, nil
}
func postgresSave(b []byte) error {
	if !json.Valid(b) {
		return errors.New("invalid JSON state")
	}
	// Dollar-quoted literal avoids SQL escaping, with a delimiter not present in JSON.
	tag := "explicit_json_boundary"
	for bytes.Contains(b, []byte("$"+tag+"$")) {
		tag += "x"
	}
	marker := "$" + tag + "$"
	sql := "INSERT INTO explicit_state (id,payload,updated_at) VALUES (1," + marker + string(b) + marker + "::jsonb,NOW()) ON CONFLICT (id) DO UPDATE SET payload=EXCLUDED.payload,updated_at=NOW();"
	_, err := postgresRun(sql)
	return err
}
