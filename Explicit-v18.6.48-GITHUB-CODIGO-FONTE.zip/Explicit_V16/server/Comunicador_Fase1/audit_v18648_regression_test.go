package main

import (
	"bytes"
	"encoding/json"
	"mime/multipart"
	"net/http/httptest"
	"os"
	"path/filepath"
	"testing"
)

func TestAuditDirectFailedSaveRestoresChat(t *testing.T) {
	for _, action := range []string{"send", "hide"} {
		t.Run(action, func(t *testing.T) {
			s := auditFixture(t)
			s.db.DirectChats = []DirectChat{{ID: "dm", Name: "Group", Users: []string{"owner", "member"}, Visible: map[string]bool{"owner": true, "member": false}}}
			before, _ := json.Marshal(s.db.DirectChats)
			s.file = t.TempDir() // Existing directory cannot be replaced by the JSON store.
			r := auditRequest(t, s, "owner", "/api/direct", map[string]string{"action": action, "id": "dm", "text": "must not survive failure"})
			if r.Code != 500 { t.Fatalf("expected write failure, got %d: %s", r.Code, r.Body.String()) }
			after, _ := json.Marshal(s.db.DirectChats)
			if !bytes.Equal(before, after) { t.Fatalf("failed request changed chat: %s", after) }
		})
	}
}

func TestAuditDirectLegacyVisibilityAndUploadRollback(t *testing.T) {
	for _, failSave := range []bool{false, true} {
		t.Run(map[bool]string{false:"success", true:"save_failure"}[failSave], func(t *testing.T) {
			s := auditFixture(t)
			s.db.DirectChats = []DirectChat{{ID: "dm", Name: "Group", Users: []string{"owner", "member"}}}
			before, _ := json.Marshal(s.db.DirectChats)
			if failSave { s.file = filepath.Join(t.TempDir(), "store-directory"); if err := os.Mkdir(s.file, 0700); err != nil { t.Fatal(err) } }
			var body bytes.Buffer
			form := multipart.NewWriter(&body)
			if err := form.WriteField("chat", "dm"); err != nil { t.Fatal(err) }
			file, err := form.CreateFormFile("file", "sample.txt"); if err != nil { t.Fatal(err) }
			if _, err = file.Write([]byte("test attachment")); err != nil { t.Fatal(err) }
			if err = form.Close(); err != nil { t.Fatal(err) }
			req := httptest.NewRequest("POST", "/api/direct-file", &body)
			req.Header.Set("Authorization", "Bearer owner-token")
			req.Header.Set("Content-Type", form.FormDataContentType())
			w := httptest.NewRecorder(); s.directFileAPI(w, req)
			if failSave {
				if w.Code != 500 { t.Fatalf("expected failed save: %d %s", w.Code, w.Body.String()) }
				after, _ := json.Marshal(s.db.DirectChats)
				if !bytes.Equal(before, after) { t.Fatalf("failed upload changed chat: %s", after) }
				files, err := os.ReadDir(filepath.Join(filepath.Dir(s.file), "direct_files")); if err != nil || len(files) != 0 { t.Fatalf("orphan upload: %v %v", files, err) }
			} else if w.Code != 201 || !s.db.DirectChats[0].Visible["member"] || len(s.db.DirectChats[0].Messages) != 1 {
				t.Fatalf("legacy chat upload failed: %d %s", w.Code, w.Body.String())
			}
		})
	}
}
