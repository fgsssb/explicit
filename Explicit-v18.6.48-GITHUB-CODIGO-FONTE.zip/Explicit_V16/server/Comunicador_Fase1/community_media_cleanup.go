package main

import (
	"errors"
	"strings"
)

type communityMediaRemoval struct {
	room     string
	identity string
}

// Caller serializes membership removal with media grants via mediaControlMu.
// An empty user selects all active participants of the deleted community.
func removeCommunityVoicePresence(community, user string) []communityMediaRemoval {
	voice.mu.Lock()
	defer voice.mu.Unlock()
	removals := []communityMediaRemoval{}
	for identity, member := range voice.members {
		if member != nil && (user == "" || identity == user) && strings.HasPrefix(member.Room, community+":") {
			removals = append(removals, communityMediaRemoval{room: member.Room, identity: identity})
			delete(voice.members, identity)
		}
	}
	return removals
}

// No store/voice mutex may be held during SFU HTTP. Attempt all removals, even
// when one fails; parallel requests share the existing five-second HTTP limit.
func revokeCommunityMedia(removals []communityMediaRemoval) error {
	results := make(chan error, len(removals))
	for _, removal := range removals {
		go func(removal communityMediaRemoval) {
			results <- livekitRoomAction(removal.room, removal.identity, true)
		}(removal)
	}
	var failures error
	for range removals {
		failures = errors.Join(failures, <-results)
	}
	return failures
}
