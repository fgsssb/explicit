package main

import (
	"crypto/hmac"
	"crypto/sha256"
	"encoding/base64"
	"encoding/json"
	"net/http"
	"net/url"
	"os"
	"strings"
	"sync"
	"time"
)

// Serializes community grants and administrative changes; never hold store/voice locks over HTTP.
var mediaControlMu sync.Mutex

// The LiveKit secret never reaches the renderer: only short-lived scoped JWTs do.
func liveKitConfig() (string, string, string, bool) {
	ws, key, secret := strings.TrimSpace(os.Getenv("LIVEKIT_WS_URL")), strings.TrimSpace(os.Getenv("LIVEKIT_API_KEY")), strings.TrimSpace(os.Getenv("LIVEKIT_API_SECRET"))
	u, err := url.Parse(ws)
	if err != nil || u.Scheme != "wss" || u.Host == "" || u.User != nil || u.RawQuery != "" || u.Fragment != "" || u.Path != "" || len(key) < 12 || len(secret) < 32 {
		return "", "", "", false
	}
	return ws, key, secret, true
}

func (s *Server) mediaConfig(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodGet {
		reply(w, 405, map[string]string{"error": "Método inválido"})
		return
	}
	if _, err := s.auth(r); err != nil {
		reply(w, 401, map[string]string{"error": "Não autorizado"})
		return
	}
	_, _, _, enabled := liveKitConfig()
	reply(w, 200, map[string]bool{"livekit": enabled, "realtime_polling": os.Getenv("EXPLICIT_PILOT_POLLING") == "1"})
}

type liveKitGrant struct {
	RoomJoin          bool     `json:"roomJoin"`
	Room              string   `json:"room"`
	CanPublish        bool     `json:"canPublish"`
	CanSubscribe      bool     `json:"canSubscribe"`
	CanPublishData    bool     `json:"canPublishData"`
	CanPublishSources []string `json:"canPublishSources,omitempty"`
}
type liveKitClaims struct {
	Issuer    string       `json:"iss"`
	Subject   string       `json:"sub"`
	IssuedAt  int64        `json:"iat"`
	NotBefore int64        `json:"nbf"`
	ExpiresAt int64        `json:"exp"`
	Video     liveKitGrant `json:"video"`
}

func signedLiveKitToken(key, secret, identity, room string, canSpeak, canScreen bool, now time.Time) (string, error) {
	return signedLiveKitTokenWithSubscribe(key, secret, identity, room, canSpeak, canScreen, true, now)
}

func signedLiveKitTokenWithSubscribe(key, secret, identity, room string, canSpeak, canScreen, canSubscribe bool, now time.Time) (string, error) {
	sources := make([]string, 0, 2)
	if canSpeak {
		sources = append(sources, "microphone")
	}
	if canScreen {
		sources = append(sources, "screen_share")
	}
	claims := liveKitClaims{Issuer: key, Subject: identity, IssuedAt: now.Unix(), NotBefore: now.Add(-5 * time.Second).Unix(), ExpiresAt: now.Add(5 * time.Minute).Unix(), Video: liveKitGrant{RoomJoin: true, Room: room, CanPublish: len(sources) > 0, CanSubscribe: canSubscribe, CanPublishData: false, CanPublishSources: sources}}
	header := base64.RawURLEncoding.EncodeToString([]byte(`{"alg":"HS256","typ":"JWT"}`))
	payload, err := json.Marshal(claims)
	if err != nil {
		return "", err
	}
	unsigned := header + "." + base64.RawURLEncoding.EncodeToString(payload)
	mac := hmac.New(sha256.New, []byte(secret))
	mac.Write([]byte(unsigned))
	return unsigned + "." + base64.RawURLEncoding.EncodeToString(mac.Sum(nil)), nil
}

func (s *Server) liveKitToken(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		reply(w, 405, map[string]string{"error": "Método inválido"})
		return
	}
	user, err := s.auth(r)
	if err != nil {
		reply(w, 401, map[string]string{"error": "Não autorizado"})
		return
	}
	ws, key, secret, ok := liveKitConfig()
	if !ok {
		reply(w, 503, map[string]string{"error": "LiveKit ainda não configurado"})
		return
	}
	var q struct {
		Community string `json:"community"`
		Channel   string `json:"channel"`
	}
	if parse(r, &q) != nil || q.Community == "" || q.Channel == "" || len(q.Community) > 100 || len(q.Channel) > 40 {
		reply(w, 400, map[string]string{"error": "Canal inválido"})
		return
	}
	room := q.Community + ":" + q.Channel
	mediaControlMu.Lock()
	defer mediaControlMu.Unlock()
	s.mu.Lock()
	allowed, canSpeak, canScreen := false, false, false
	for _, c := range s.db.Communities {
		if c.ID == q.Community && (contains(c.Members, user) || s.isSuperadmin(user)) && contains(c.Channels, q.Channel) && c.channelType(q.Channel) == "voice" && s.activeSanction(c, user, q.Channel) == nil && s.channelPermission(c, user, q.Channel, "CONNECT_VOICE") && s.channelPermission(c, user, q.Channel, "VIEW_CHANNEL") {
			allowed = true
			canSpeak = s.channelPermission(c, user, q.Channel, "SPEAK") && !s.isStaffMuted(c.ID, q.Channel, user, "voice")
			canScreen = s.channelPermission(c, user, q.Channel, "SCREEN_SHARE")
			break
		}
	}
	restriction := s.db.VoiceRestrictions[q.Community][user]
	s.mu.Unlock()
	if !allowed {
		reply(w, 403, map[string]string{"error": "Acesso negado ao canal"})
		return
	}
	// Voice join and occupancy checks take place first. Tokens must not bypass channel limits.
	voice.mu.Lock()
	m := voice.members[user]
	joined := m != nil && m.Room == room && m.MoveTo == "" && time.Since(m.Seen) < 45*time.Second
	canSpeak = canSpeak && !restriction.Muted
	canSubscribe := !restriction.Deaf
	if joined {
		canSpeak = canSpeak && !m.AdminMuted && !m.StaffGloballyMuted
		canSubscribe = canSubscribe && !m.AdminDeaf
	}
	voice.mu.Unlock()
	if !joined {
		reply(w, 409, map[string]string{"error": "Entre no canal de voz primeiro"})
		return
	}
	jwt, err := signedLiveKitTokenWithSubscribe(key, secret, user, room, canSpeak, canScreen, canSubscribe, time.Now())
	if err != nil {
		reply(w, 500, map[string]string{"error": "Falha ao assinar sessão"})
		return
	}
	w.Header().Set("Cache-Control", "no-store")
	reply(w, 200, map[string]any{"url": ws, "token": jwt, "can_speak": canSpeak, "can_screen": canScreen})
}
