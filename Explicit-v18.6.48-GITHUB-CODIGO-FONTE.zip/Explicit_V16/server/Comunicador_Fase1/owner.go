package main

import (
	"errors"
	"strings"
)

// bootstrapOwner is exclusively called at startup using the local operator
// environment. No HTTP route accepts requests to grant, change or revoke Owner.
func (s *Server) bootstrapOwner(username string) error {
	username = strings.TrimSpace(username)
	s.mu.Lock()
	defer s.mu.Unlock()
	if s.db.OwnerAccountID != "" {
		return errors.New("an Owner is already bound; bootstrap cannot replace it")
	}
	account, ok := s.db.Users[username]
	if !ok || username == "" {
		return errors.New("register a real account before Owner activation")
	}
	old := account
	if account.AccountID == "" {
		account.AccountID = token()
	}
	account.SystemRole = "owner"
	s.db.OwnerAccountID = account.AccountID
	s.db.Users[username] = account
	if err := s.save(); err != nil {
		s.db.OwnerAccountID = ""
		s.db.Users[username] = old
		return err
	}
	s.staffAuditLocked(username, "owner_bootstrap", username, "Local server activation; immutable account ID")
	return nil
}
