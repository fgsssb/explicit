package main

import (
	"os"
	"path/filepath"
	"testing"
)

func TestLocalStoreUnaffected(t *testing.T) {
	old := os.Getenv("PGDATABASE")
	os.Unsetenv("PGDATABASE")
	defer os.Setenv("PGDATABASE", old)
	path := filepath.Join(t.TempDir(), "store.json")
	s := newServer(path)
	if err := s.save(); err != nil {
		t.Fatal(err)
	}
	if _, err := os.Stat(path); err != nil {
		t.Fatal(err)
	}
}
