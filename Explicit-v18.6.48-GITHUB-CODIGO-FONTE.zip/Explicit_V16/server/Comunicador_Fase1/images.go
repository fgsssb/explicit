package main

import (
	"bytes"
	"crypto/rand"
	"encoding/hex"
	"encoding/json"
	"image"
	_ "image/gif"
	_ "image/jpeg"
	_ "image/png"
	"io"
	"log"
	"net/http"
	"os"
	"path/filepath"
	"regexp"
	"strings"
	"time"
)

var imageNamePattern = regexp.MustCompile(`^[a-f0-9]{32}\.(png|jpg|gif|webp)$`)

func (s *Server) imageAPI(w http.ResponseWriter, r *http.Request) {
	user, err := s.auth(r)
	if err != nil {
		http.Error(w, "unauthorized", 401)
		return
	}
	dir := filepath.Join(filepath.Dir(s.file), "images")
	if r.Method == "GET" {
		id := r.URL.Query().Get("id")
		if !imageNamePattern.MatchString(id) {
			http.Error(w, "invalid image", 400)
			return
		}
		s.mu.Lock()
		allowed := false
		for _, m := range s.db.Messages {
			if m.Image != id || m.Deleted {
				continue
			}
			parts := strings.SplitN(m.Channel, ":", 2)
			if len(parts) == 2 {
				for _, c := range s.db.Communities {
					if c.ID == parts[0] && contains(c.Members, user) && contains(c.Channels, parts[1]) && c.channelType(parts[1]) == "text" && s.activeSanction(c, user, parts[1]) == nil && s.channelPermission(c, user, parts[1], "VIEW_CHANNEL") {
						allowed = true
						break
					}
				}
			}
			if allowed {
				break
			}
		}
		s.mu.Unlock()
		if !allowed {
			http.Error(w, "forbidden", 403)
			return
		}
		w.Header().Set("X-Content-Type-Options", "nosniff")
		w.Header().Set("Cache-Control", "private, max-age=120")
		http.ServeFile(w, r, filepath.Join(dir, id))
		return
	}
	if r.Method != "POST" {
		http.Error(w, "method", 405)
		return
	}
	r.Body = http.MaxBytesReader(w, r.Body, 9<<20)
	if err := r.ParseMultipartForm(4 << 20); err != nil {
		http.Error(w, "image too large", 413)
		return
	}
	if r.MultipartForm != nil {
		defer r.MultipartForm.RemoveAll()
	}
	community, channel := r.FormValue("community"), r.FormValue("channel")
	f, _, err := r.FormFile("image")
	if err != nil {
		http.Error(w, "image required", 400)
		return
	}
	defer f.Close()
	content, err := io.ReadAll(io.LimitReader(f, (8<<20)+1))
	if err != nil || len(content) == 0 || len(content) > 8<<20 {
		http.Error(w, "image too large", 413)
		return
	}
	mime := http.DetectContentType(content)
	ext := map[string]string{"image/png": "png", "image/jpeg": "jpg", "image/gif": "gif", "image/webp": "webp"}[mime]
	if ext == "" {
		http.Error(w, "unsupported image", 415)
		return
	}
	// A tiny compressed PNG/JPEG/GIF can advertise a huge canvas and exhaust
	// memory in the receiving renderer. Check headers before accepting it.
	if ext != "webp" {
		cfg, _, parseErr := image.DecodeConfig(bytes.NewReader(content))
		if parseErr != nil || cfg.Width < 1 || cfg.Height < 1 || cfg.Width > 8192 || cfg.Height > 8192 || int64(cfg.Width)*int64(cfg.Height) > 24000000 {
			http.Error(w, "invalid image dimensions", http.StatusBadRequest)
			return
		}
	} else if !safeWebPDimensions(content) {
		http.Error(w, "invalid webp dimensions", http.StatusBadRequest)
		return
	}
	var random [16]byte
	if _, err = rand.Read(random[:]); err != nil {
		http.Error(w, "internal error", 500)
		return
	}
	id := hex.EncodeToString(random[:]) + "." + ext
	s.mu.Lock()
	defer s.mu.Unlock()
	allowed := false
	for _, c := range s.db.Communities {
		if c.ID == community && contains(c.Members, user) && contains(c.Channels, channel) && c.channelType(channel) == "text" && s.activeSanction(c, user, channel) == nil && s.channelPermission(c, user, channel, "VIEW_CHANNEL") {
			allowed = true
			break
		}
	}
	if !allowed || !s.channelCanSend(community, channel, user) || !s.channelAttachAllowed(community, channel, user) {
		http.Error(w, "forbidden", 403)
		return
	}
	if !s.storageAllowedLocked(user, int64(len(content)), "") {
		http.Error(w, "Limite de armazenamento atingido. Entre em contato com a equipe do Explicit.", http.StatusRequestEntityTooLarge)
		return
	}
	if err = os.MkdirAll(dir, 0700); err != nil {
		log.Printf("STORAGE ERROR images directory %q: %v", dir, err)
		http.Error(w, "storage error", 500)
		return
	}
	if !trustedStorageDirectory(filepath.Dir(s.file), "images") {
		http.Error(w, "invalid storage directory", 500)
		return
	}
	path := filepath.Join(dir, id)
	if err = os.WriteFile(path, content, 0600); err != nil {
		log.Printf("STORAGE ERROR image file %q: %v", path, err)
		http.Error(w, "storage error", 500)
		return
	}
	m := Message{ID: token()[:16], Channel: community + ":" + channel, Author: user, Text: "", Image: id, Time: time.Now().UTC()}
	oldNotifications := append([]AppNotification(nil), s.db.Notifications...)
	for _, c := range s.db.Communities {
		if c.ID == community {
			s.notifyChannelMessageLocked(c, channel, user, "Imagem enviada")
			break
		}
	}
	s.db.Messages = append(s.db.Messages, m)
	if err = s.save(); err != nil {
		s.db.Messages = s.db.Messages[:len(s.db.Messages)-1]
		s.db.Notifications = oldNotifications
		os.Remove(path)
		http.Error(w, "storage error", 500)
		return
	}
	b, _ := json.Marshal(m)
	for listener, recipient := range s.listeners {
		if !s.canReceiveChannelEvent(community, channel, recipient) {
			continue
		}
		select {
		case listener <- string(b):
		default:
		}
	}
	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(201)
	json.NewEncoder(w).Encode(m)
}
