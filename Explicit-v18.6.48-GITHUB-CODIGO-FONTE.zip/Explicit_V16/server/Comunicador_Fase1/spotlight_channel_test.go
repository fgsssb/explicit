package main

import "testing"

func TestSpotlightURLValidation(t *testing.T) {
	for _, u := range []string{"https://youtube.com/watch?v=abc", "https://www.youtube.com/watch?v=abc", "https://youtu.be/abc"} {
		if !validSpotlightURL(u) {
			t.Errorf("rejected valid url %q", u)
		}
	}
	for _, u := range []string{"http://youtube.com/watch?v=abc", "https://youtube.com.evil.test/watch?v=abc", "https://evil.test/", "file:///etc/passwd", "https://youtube.com:444/watch?v=abc"} {
		if validSpotlightURL(u) {
			t.Errorf("accepted invalid url %q", u)
		}
	}
}
func TestChannelRoleDenyOverridesDefault(t *testing.T) {
	s := &Server{}
	c := Community{Owner: "owner", Members: []string{"owner", "member"}, Channels: []string{"geral", "voz"}, ChannelMeta: map[string]ChannelMeta{"geral": {Type: "text", RolePermissions: map[string]map[string]bool{"everyone": {"SEND_MESSAGES": false}}}, "voz": {Type: "voice", RolePermissions: map[string]map[string]bool{"everyone": {"CONNECT_VOICE": false}}}}}
	if s.channelPermission(c, "member", "geral", "SEND_MESSAGES") {
		t.Fatal("member bypassed text channel deny")
	}
	if s.channelPermission(c, "member", "voz", "CONNECT_VOICE") {
		t.Fatal("member bypassed voice channel deny")
	}
	if !s.channelPermission(c, "owner", "voz", "CONNECT_VOICE") {
		t.Fatal("owner should bypass channel deny")
	}
	if s.channelPermission(c, "outsider", "voz", "CONNECT_VOICE") {
		t.Fatal("nonmember can join")
	}
}
