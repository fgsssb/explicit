package main

import (
	"bytes"
	"encoding/json"
	"net/http/httptest"
	"path/filepath"
	"testing"
)

// Regression: creating text/voice channels in the default categories must
// persist and remain visible to the owner after a subsequent GET request.
func TestV18644NewCommunityCategoriesAndChannelsPersist(t *testing.T) {
	s := newServer(filepath.Join(t.TempDir(), "store.json"))
	s.mu.Lock()
	s.sessions["creator-token"] = "creator"
	s.db.Users["creator"] = User{Name: "creator"}
	s.mu.Unlock()
	call := func(method, path string, payload any) *httptest.ResponseRecorder {
		t.Helper()
		var body []byte
		if payload != nil {
			body, _ = json.Marshal(payload)
		}
		request := httptest.NewRequest(method, path, bytes.NewReader(body))
		request.Header.Set("Authorization", "Bearer creator-token")
		recorder := httptest.NewRecorder()
		s.routes().ServeHTTP(recorder, request)
		return recorder
	}
	created := call("POST", "/api/communities", map[string]any{"name": "Minha comunidade"})
	if created.Code != 201 {
		t.Fatalf("community create %d: %s", created.Code, created.Body.String())
	}
	var community Community
	if err := json.Unmarshal(created.Body.Bytes(), &community); err != nil {
		t.Fatal(err)
	}
	if len(community.Categories) != 2 || len(community.Channels) != 2 {
		t.Fatalf("missing default channels/categories: %+v", community)
	}
	if community.ChannelMeta["geral"].Category != "texto" || community.ChannelMeta["voz"].Category != "voz" {
		t.Fatalf("incorrect initial metadata: %+v", community.ChannelMeta)
	}
	for _, ch := range []struct{ name, kind, category string }{{"conversa", "text", "texto"}, {"reuniao", "voice", "voz"}} {
		response := call("POST", "/api/communities", map[string]any{"community": community.ID, "channel": ch.name, "type": ch.kind, "category": ch.category})
		if response.Code != 200 {
			t.Fatalf("create %s %d: %s", ch.name, response.Code, response.Body.String())
		}
	}
	retrieved := call("GET", "/api/communities", nil)
	if retrieved.Code != 200 {
		t.Fatalf("community list %d: %s", retrieved.Code, retrieved.Body.String())
	}
	var communities []Community
	if err := json.Unmarshal(retrieved.Body.Bytes(), &communities); err != nil {
		t.Fatal(err)
	}
	if len(communities) != 1 || len(communities[0].Channels) != 4 {
		t.Fatalf("channels absent from API: %+v", communities)
	}
	if communities[0].ChannelMeta["conversa"].Category != "texto" || communities[0].ChannelMeta["reuniao"].Category != "voz" {
		t.Fatalf("new channels lost category assignment: %+v", communities[0].ChannelMeta)
	}
	reloaded := newServer(s.file)
	if len(reloaded.db.Communities) != 1 || len(reloaded.db.Communities[0].Channels) != 4 || len(reloaded.db.Communities[0].Categories) != 2 {
		t.Fatalf("default categories/channels did not persist: %+v", reloaded.db.Communities)
	}
}
