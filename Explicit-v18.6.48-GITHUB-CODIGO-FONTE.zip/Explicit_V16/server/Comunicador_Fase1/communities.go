package main

import (
	"encoding/json"
	"log/slog"
	"net/http"
	"regexp"
	"strings"
	"time"
)

func (s *Server) logout(w http.ResponseWriter, r *http.Request) {
	if r.Method != "POST" {
		http.Error(w, "method", 405)
		return
	}
	t := strings.TrimPrefix(r.Header.Get("Authorization"), "Bearer ")
	s.mu.Lock()
	user := s.sessions[t]
	delete(s.sessions, t)
	delete(s.sessionExpiry, t)
	delete(s.termsPending, t)
	if user != "" {
		sessionKey := notificationPresenceKey(r.Header.Get("Authorization"))
		delete(online.entries[user], sessionKey)
		for client, key := range online.sessionKeys[user] {
			if key != sessionKey {
				continue
			}
			delete(online.entries[user], client)
			delete(online.background[user], client)
			delete(online.sessionKeys[user], client)
		}
		if len(online.entries[user]) == 0 {
			delete(online.entries, user)
			delete(online.background, user)
			delete(online.sessionKeys, user)
		}
	}
	s.mu.Unlock()
	voice.mu.Lock()
	if user != "" {
		delete(voice.members, user)
	}
	voice.mu.Unlock()
	reply(w, 200, map[string]bool{"ok": true})
}
func contains(a []string, x string) bool {
	for _, v := range a {
		if v == x {
			return true
		}
	}
	return false
}
func (s *Server) communities(w http.ResponseWriter, r *http.Request) {
	name, e := s.auth(r)
	if e != nil {
		http.Error(w, "unauthorized", 401)
		return
	}
	if r.Method == "GET" {
		s.mu.Lock()
		out := []Community{}
		for _, c := range s.db.Communities {
			if contains(c.Members, name) || s.isSuperadmin(name) {
				out = append(out, s.visibleCommunity(c, name))
			}
		}
		s.mu.Unlock()
		reply(w, 200, out)
		return
	}
	if r.Method != "POST" {
		http.Error(w, "method", 405)
		return
	}
	var q struct {
		Name              string                     `json:"name"`
		Join              string                     `json:"join"`
		Leave             string                     `json:"leave"`
		Channel           string                     `json:"channel"`
		Type              string                     `json:"type"`
		Limit             int                        `json:"limit"`
		Community         string                     `json:"community"`
		Invite            string                     `json:"invite"`
		RolePermissions   map[string]map[string]bool `json:"role_permissions"`
		MemberPermissions map[string]map[string]bool `json:"member_permissions"`
		Category          string                     `json:"category"`
		Sync              bool                       `json:"sync"`
		Private           bool                       `json:"private"`
	}
	if parse(r, &q) != nil {
		http.Error(w, "invalid request", 400)
		return
	}
	if q.Leave != "" {
		mediaControlMu.Lock()
		defer mediaControlMu.Unlock()
	}
	s.mu.Lock()
	locked := true
	defer func() {
		if locked {
			s.mu.Unlock()
		}
	}()
	if q.Leave != "" {
		for i := range s.db.Communities {
			c := &s.db.Communities[i]
			if c.ID != q.Leave {
				continue
			}
			if !contains(c.Members, name) {
				http.Error(w, "not member", 403)
				return
			}
			if c.Owner == name {
				http.Error(w, "community owner cannot leave", 403)
				return
			}
			old, _ := json.Marshal(*c)
			next := make([]string, 0, len(c.Members))
			for _, member := range c.Members {
				if member != name {
					next = append(next, member)
				}
			}
			c.Members = next
			delete(c.MemberRoles, name)
			// Remove user-only grants so that leaving and rejoining never restores privileges.
			for ch, meta := range c.ChannelMeta {
				delete(meta.MemberPermissions, name)
				c.ChannelMeta[ch] = meta
			}
			for j, cat := range c.Categories {
				delete(cat.MemberPermissions, name)
				c.Categories[j] = cat
			}
			if err := s.save(); err != nil {
				_ = json.Unmarshal(old, c)
				http.Error(w, "storage failure", 500)
				return
			}
			removals := removeCommunityVoicePresence(c.ID, name)
			s.mu.Unlock()
			locked = false
			if err := revokeCommunityMedia(removals); err != nil {
				reply(w, 502, map[string]any{"error": "Saída salva, mas a desconexão de mídia falhou", "membership_removed": true})
				return
			}
			reply(w, 200, map[string]bool{"ok": true})
			return
		}
		http.Error(w, "community not found", 404)
		return
	}
	if q.Join != "" {
		for i := range s.db.Communities {
			c := &s.db.Communities[i]
			if strings.EqualFold(communityInviteCode(*c), strings.TrimSpace(q.Join)) || s.validCommunityInviteLocked(c.ID, strings.TrimSpace(q.Join)) {
				if c.JoinClosed && !contains(c.Members, name) && !s.isSuperadmin(name) {
					http.Error(w, "Esta comunidade não está aceitando novos membros", http.StatusForbidden)
					return
				}
				if sanction := s.activeSanction(*c, name, ""); sanction != nil {
					sanctionDenied(w, sanction)
					return
				}
				if !contains(c.Members, name) {
					previousMembers := append([]string(nil), c.Members...)
					c.Members = append(c.Members, name)
					if err := s.save(); err != nil {
						// Never grant transient access after a failed persistence write.
						c.Members = previousMembers
						http.Error(w, "storage failure", 500)
						return
					}
				}
				reply(w, 200, s.visibleCommunity(*c, name))
				return
			}
		}
		http.Error(w, "not found", 404)
		return
	}
	if q.Channel != "" {
		for i := range s.db.Communities {
			c := &s.db.Communities[i]
			if c.ID == q.Community && s.hasPermission(*c, name, "CREATE_CHANNEL") {
				if len(q.Channel) < 1 || len(q.Channel) > 40 || len(c.Channels) >= 100 {
					http.Error(w, "invalid channel", 400)
					return
				}
				if q.Type != "" && q.Type != "text" && q.Type != "voice" {
					http.Error(w, "invalid type", 400)
					return
				}
				if q.Limit < 0 || q.Limit > 99 {
					http.Error(w, "invalid limit", 400)
					return
				}
				if contains(c.Channels, q.Channel) {
					http.Error(w, "channel exists", 409)
					return
				}
				if c.ChannelMeta == nil {
					c.ChannelMeta = map[string]ChannelMeta{}
				}
				kind := q.Type
				if kind == "" {
					kind = "text"
				}
				if kind == "text" && q.Limit != 0 {
					http.Error(w, "limit only for voice", 400)
					return
				}
				// Validate before appending the channel so failed requests remain atomic.
				if len(q.Category) > 0 && !categoryExists(*c, q.Category) {
					http.Error(w, "category not found", 400)
					return
				}
				if err := validateOverrides(*c, q.RolePermissions, q.MemberPermissions); err != nil {
					http.Error(w, err.Error(), 400)
					return
				}
				if (len(q.RolePermissions) > 0 || len(q.MemberPermissions) > 0 || q.Private) && !s.hasPermission(*c, name, "MANAGE_ROLES") {
					http.Error(w, "manage roles permission required", 403)
					return
				}
				if !s.maySetOverrides(*c, name, q.RolePermissions, q.MemberPermissions) {
					http.Error(w, "cannot grant permission above your role", 403)
					return
				}
				meta := ChannelMeta{Type: kind, Limit: q.Limit, Category: q.Category, RolePermissions: q.RolePermissions, MemberPermissions: q.MemberPermissions}
				if q.Sync && q.Category != "" {
					cat := findCategory(*c, q.Category)
					if !s.hasPermission(*c, name, "MANAGE_ROLES") || !s.maySetOverrides(*c, name, cat.RolePermissions, cat.MemberPermissions) {
						http.Error(w, "cannot inherit category permissions", 403)
						return
					}
					meta.RolePermissions = cloneOverrides(cat.RolePermissions)
					meta.MemberPermissions = cloneOverrides(cat.MemberPermissions)
					meta.Synced = true
				}
				if q.Private {
					if meta.RolePermissions == nil {
						meta.RolePermissions = map[string]map[string]bool{}
					}
					if meta.RolePermissions["everyone"] == nil {
						meta.RolePermissions["everyone"] = map[string]bool{}
					}
					meta.RolePermissions["everyone"]["VIEW_CHANNEL"] = false
					meta.Synced = false
				}
				c.Channels = append(c.Channels, q.Channel)
				c.ChannelMeta[q.Channel] = meta
				// Restore the channel list if storage fails.
				slog.Info("channel.created", "actor", name, "community", c.ID, "channel", q.Channel, "type", kind)
				if s.save() != nil {
					c.Channels = c.Channels[:len(c.Channels)-1]
					delete(c.ChannelMeta, q.Channel)
					http.Error(w, "storage failure", 500)
					return
				}
				reply(w, 200, s.visibleCommunity(*c, name))
				return
			}
		}
		http.Error(w, "forbidden", 403)
		return
	}
	q.Name = strings.TrimSpace(q.Name)
	if len(q.Name) < 3 || len(q.Name) > 60 {
		http.Error(w, "invalid name", 400)
		return
	}
	invite := strings.ToLower(strings.TrimSpace(q.Invite))
	if invite != "" {
		if !regexp.MustCompile(`^[a-z0-9_-]{4,32}$`).MatchString(invite) || invite == "api" || invite == "admin" {
			http.Error(w, "invalid invite", 400)
			return
		}
	} else {
		invite = token()[:20]
	}
	for _, existing := range s.db.Communities {
		if strings.EqualFold(communityInviteCode(existing), invite) || strings.EqualFold(existing.ID, invite) {
			http.Error(w, "invite already exists", 409)
			return
		}
	}
	// Novas comunidades comecam com categorias base para substituir os subtitulos visuais.
	// A regra se aplica somente ao cadastro de comunidades; as existentes nao sao migradas.
	c := Community{
		ID:       invite,
		Name:     q.Name,
		Owner:    name,
		Members:  []string{name},
		Channels: []string{"geral", "voz"},
		Categories: []ChannelCategory{
			{ID: "texto", Name: "TEXTO"},
			{ID: "voz", Name: "VOZ"},
		},
		ChannelMeta: map[string]ChannelMeta{
			"geral": {Type: "text", Category: "texto"},
			"voz":   {Type: "voice", Category: "voz"},
		},
	}
	s.db.Communities = append(s.db.Communities, c)
	if s.save() != nil {
		s.db.Communities = s.db.Communities[:len(s.db.Communities)-1]
		http.Error(w, "storage failure", 500)
		return
	}
	slog.Info("community.created", "actor", name, "community", c.ID)
	reply(w, 201, c)
}
func (s *Server) channelMessages(w http.ResponseWriter, r *http.Request) {
	name, e := s.auth(r)
	if e != nil {
		http.Error(w, "unauthorized", 401)
		return
	}
	id := r.URL.Query().Get("community")
	channel := r.URL.Query().Get("channel")
	s.mu.Lock()
	defer s.mu.Unlock()
	allowed := false
	for _, c := range s.db.Communities {
		if c.ID == id && s.activeSanction(c, name, channel) == nil && (contains(c.Members, name) || s.isSuperadmin(name)) && contains(c.Channels, channel) && s.channelPermission(c, name, channel, "VIEW_CHANNEL") && c.channelType(channel) == "text" {
			allowed = true
			break
		}
	}
	if !allowed {
		http.Error(w, "forbidden", 403)
		return
	}
	key := id + ":" + channel
	if r.Method == "GET" {
		out := make([]Message, 0, 100)
		for i := len(s.db.Messages) - 1; i >= 0 && len(out) < 100; i-- {
			m := s.db.Messages[i]
			if m.Channel == key && !m.Deleted {
				out = append(out, m)
			}
		}
		for i, j := 0, len(out)-1; i < j; i, j = i+1, j-1 {
			out[i], out[j] = out[j], out[i]
		}
		reply(w, 200, out)
		return
	}
	if r.Method != "POST" {
		http.Error(w, "method", 405)
		return
	}
	if !s.channelCanSend(id, channel, name) {
		http.Error(w, "forbidden", 403)
		return
	}
	var q struct {
		Text     string `json:"text"`
		ClientID string `json:"client_id"`
	}
	if parse(r, &q) != nil || len(strings.TrimSpace(q.Text)) == 0 || len(q.Text) > 2000 || !validChatClientID(q.ClientID) {
		http.Error(w, "invalid message", 400)
		return
	}
	if previous := findChatRetry(s.db.Messages, name, key, q.ClientID); previous != nil {
		if previous.Text != q.Text {
			http.Error(w, "client_id reused with different message", http.StatusConflict)
			return
		}
		reply(w, 200, previous)
		return
	}
	if abusiveMessageText(q.Text) || (!strings.HasPrefix(strings.TrimSpace(q.Text), "/") && s.resources.excessiveRepeat(name, q.Text, time.Now())) {
		http.Error(w, "message flood rejected", http.StatusTooManyRequests)
		return
	}
	// Slash command uses the account ID, never the display name, and never broadcasts.
	if strings.HasPrefix(strings.TrimSpace(q.Text), "/ban ") && s.isSuperadmin(name) {
		parts := strings.Fields(q.Text)
		if len(parts) < 2 || len(parts) > 80 {
			http.Error(w, "usage: /ban username [reason]", 400)
			return
		}
		targetName := parts[1]
		target, found := s.db.Users[targetName]
		if !found {
			http.Error(w, "username not found", 404)
			return
		}
		if s.isSuperadmin(targetName) || targetName == name {
			http.Error(w, "protected account", 403)
			return
		}
		reason := "Banimento por violação das regras"
		if len(parts) > 2 {
			reason = strings.Join(parts[2:], " ")
		}
		if len(reason) > 500 {
			http.Error(w, "reason too long", 400)
			return
		}
		target.BannedPermanent = true
		target.BannedUntil = nil
		s.db.Users[targetName] = target
		for t, who := range s.sessions {
			if who == targetName {
				delete(s.sessions, t)
				delete(s.sessionExpiry, t)
			}
		}
		s.staffAuditLocked(name, "global_ban", targetName, reason)
		if s.save() != nil {
			http.Error(w, "storage", 500)
			return
		}
		voice.mu.Lock()
		currentRoom := ""
		if v := voice.members[targetName]; v != nil {
			currentRoom = v.Room
		}
		delete(voice.members, targetName)
		voice.mu.Unlock()
		if currentRoom != "" {
			go func() {
				if err := livekitRoomAction(currentRoom, targetName, true); err != nil {
					slog.Error("LiveKit slash ban failed", "err", err)
				}
			}()
		}
		reply(w, 200, map[string]any{"ok": true, "command": "ban", "target": targetName})
		return
	}
	m := Message{ID: token()[:16], ClientID: q.ClientID, Channel: key, Author: name, Text: q.Text, Time: time.Now().UTC()}
	previousNotifications := append([]AppNotification(nil), s.db.Notifications...)
	for _, c := range s.db.Communities {
		if c.ID == id {
			s.notifyChannelMessageLocked(c, channel, name, q.Text)
			break
		}
	}
	s.db.Messages = append(s.db.Messages, m)
	if s.save() != nil {
		s.db.Notifications = previousNotifications
		s.db.Messages = s.db.Messages[:len(s.db.Messages)-1]
		http.Error(w, "storage failure", 500)
		return
	}
	b, _ := json.Marshal(m)
	for c, user := range s.listeners {
		if !s.canReceiveChannelEvent(id, channel, user) {
			continue
		}
		select {
		case c <- string(b):
		default:
		}
	}
	reply(w, 201, m)
}

func containsMembersForChannel(cs []Community, id, user string) bool {
	for _, c := range cs {
		if c.ID == id {
			return contains(c.Members, user)
		}
	}
	return false
}

// Only members authorized to read this particular channel receive its events.
func (s *Server) canReceiveChannelEvent(id, channel, user string) bool {
	for _, c := range s.db.Communities {
		if c.ID == id {
			return (contains(c.Members, user) || s.isSuperadmin(user)) && contains(c.Channels, channel) && c.channelType(channel) == "text" && s.activeSanction(c, user, channel) == nil && s.channelPermission(c, user, channel, "VIEW_CHANNEL")
		}
	}
	return false
}

// deleteChannel validates permissions server-side. The default channel is protected.
func (s *Server) deleteChannel(w http.ResponseWriter, r *http.Request) {
	if r.Method != "POST" {
		http.Error(w, "method", 405)
		return
	}
	user, err := s.auth(r)
	if err != nil {
		http.Error(w, "unauthorized", 401)
		return
	}
	var q struct {
		Community string `json:"community"`
		Channel   string `json:"channel"`
	}
	if parse(r, &q) != nil || q.Community == "" || q.Channel == "" {
		http.Error(w, "invalid request", 400)
		return
	}
	s.mu.Lock()
	defer s.mu.Unlock()
	for i := range s.db.Communities {
		c := &s.db.Communities[i]
		if c.ID != q.Community {
			continue
		}
		if !s.hasPermission(*c, user, "MANAGE_CHANNELS") {
			http.Error(w, "forbidden", 403)
			return
		}
		if q.Channel == "geral" {
			http.Error(w, "default channel cannot be deleted", 409)
			return
		}
		if !contains(c.Channels, q.Channel) {
			http.Error(w, "not found", 404)
			return
		}
		before := append([]string(nil), c.Channels...)
		meta := c.ChannelMeta[q.Channel]
		next := make([]string, 0, len(c.Channels)-1)
		for _, ch := range c.Channels {
			if ch != q.Channel {
				next = append(next, ch)
			}
		}
		c.Channels = next
		delete(c.ChannelMeta, q.Channel)
		if err := s.save(); err != nil {
			c.Channels = before
			c.ChannelMeta[q.Channel] = meta
			http.Error(w, "storage failure", 500)
			return
		}
		slog.Info("channel.deleted", "actor", user, "community", q.Community, "channel", q.Channel)
		reply(w, 200, map[string]bool{"ok": true})
		return
	}
	http.Error(w, "not found", 404)
}

func (s *Server) channelCanSend(id, channel, user string) bool {
	for _, c := range s.db.Communities {
		if c.ID == id {
			return !s.isStaffMuted(c.ID, channel, user, "text") && s.channelPermission(c, user, channel, "VIEW_CHANNEL") && s.channelPermission(c, user, channel, "SEND_MESSAGES")
		}
	}
	return false
}
