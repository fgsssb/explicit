package main

import (
	"bytes"
	"encoding/json"
	"net/http/httptest"
	"path/filepath"
	"testing"
)

func TestSystemAdminAuthorizationAndBan(t *testing.T) {
	s := newServer(filepath.Join(t.TempDir(), "store.json"))
	s.db.Users["root"] = User{Name: "root", SystemRole: "superadmin"}
	s.db.Users["admin"] = User{Name: "admin", SystemRole: "admin"}
	s.db.Users["user"] = User{Name: "user"}
	s.sessions["root-token"] = "root"
	s.sessions["admin-token"] = "admin"
	s.sessions["user-token"] = "user"
	call := func(auth string, body any) int {
		t.Helper()
		b, _ := json.Marshal(body)
		r := httptest.NewRequest("POST", "/api/system-admin", bytes.NewReader(b))
		r.Header.Set("Authorization", "Bearer "+auth)
		w := httptest.NewRecorder()
		s.routes().ServeHTTP(w, r)
		return w.Code
	}
	if n := call("user-token", map[string]any{"action": "ban", "target": "admin", "reason": "testing"}); n != 403 {
		t.Fatalf("user gained admin access: %d", n)
	}
	if n := call("admin-token", map[string]any{"action": "ban", "target": "root", "reason": "testing"}); n != 403 {
		t.Fatalf("admin banned root: %d", n)
	}
	if n := call("root-token", map[string]any{"action": "ban", "target": "user", "reason": "test ban", "hours": 1}); n != 200 {
		t.Fatalf("root ban failed: %d", n)
	}
	if _, err := s.auth(httptest.NewRequest("GET", "/", nil)); err == nil {
		t.Fatal("empty token accepted")
	}
	if _, ok := s.sessions["user-token"]; ok {
		t.Fatal("banned user's session not revoked")
	}
	if n := call("root-token", map[string]any{"action": "unban", "target": "user"}); n != 200 {
		t.Fatalf("unban failed: %d", n)
	}
}
func TestReportCannotBeReadByRegularUser(t *testing.T) {
	s := newServer(filepath.Join(t.TempDir(), "store.json"))
	s.db.Users["alice"] = User{Name: "alice"}
	s.db.Users["bob"] = User{Name: "bob"}
	s.sessions["alice-token"] = "alice"
	b := bytes.NewBufferString(`{"kind":"user","target":"bob","reason":"conteúdo abusivo"}`)
	r := httptest.NewRequest("POST", "/api/report", b)
	r.Header.Set("Authorization", "Bearer alice-token")
	w := httptest.NewRecorder()
	s.routes().ServeHTTP(w, r)
	if w.Code != 201 {
		t.Fatalf("report rejected: %d", w.Code)
	}
	r = httptest.NewRequest("GET", "/api/system-admin", nil)
	r.Header.Set("Authorization", "Bearer alice-token")
	w = httptest.NewRecorder()
	s.routes().ServeHTTP(w, r)
	if w.Code != 403 {
		t.Fatalf("user can read admin reports: %d", w.Code)
	}
}
