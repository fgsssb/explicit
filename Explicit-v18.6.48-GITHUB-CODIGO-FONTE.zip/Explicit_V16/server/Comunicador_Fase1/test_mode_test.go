package main

import (
	"os"
	"testing"
)

// Existing pre-CAPTCHA unit tests operate on seeded credentials; the anti-bot
// integration test explicitly unsets this test-only env override.
func TestMain(m *testing.M) { os.Setenv("EXPLICIT_TEST_SKIP_ANTIBOT", "1"); os.Exit(m.Run()) }
