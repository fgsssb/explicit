package main

import (
	"log/slog"
	"net/http"
	"strings"
	"time"
)

type Sanction struct {
	ID        string     `json:"id"`
	Community string     `json:"community_id"`
	Channel   string     `json:"channel_id,omitempty"`
	Target    string     `json:"target_user_id"`
	Actor     string     `json:"actor_user_id"`
	Type      string     `json:"type"`
	Reason    string     `json:"reason"`
	Created   time.Time  `json:"created_at"`
	Expires   *time.Time `json:"expires_at,omitempty"`
	Revoked   *time.Time `json:"revoked_at,omitempty"`
	RevokedBy string     `json:"revoked_by,omitempty"`
}

func (s *Sanction) active(now time.Time) bool {
	return s.Revoked == nil && (s.Expires == nil || now.Before(*s.Expires))
}
func (s *Server) activeSanction(c Community, user, channel string) *Sanction {
	if s.isSuperadmin(user) {
		return nil
	}
	now := time.Now().UTC()
	for i := len(s.db.Sanctions) - 1; i >= 0; i-- {
		v := &s.db.Sanctions[i]
		if v.Community != c.ID || v.Target != user || !v.active(now) {
			continue
		}
		if v.Type == "community_ban" || v.Type == "community_kick_restriction" || channel != "" && v.Type == "channel_ban" && v.Channel == channel {
			return v
		}
	}
	return nil
}
func sanctionDenied(w http.ResponseWriter, v *Sanction) {
	reply(w, http.StatusForbidden, map[string]any{"error": "Acesso restrito", "sanction": v})
}
func (s *Server) sanctionsAPI(w http.ResponseWriter, r *http.Request) {
	user, err := s.auth(r)
	if err != nil {
		http.Error(w, "unauthorized", 401)
		return
	}
	var q struct {
		Community string `json:"community"`
		Channel   string `json:"channel"`
		Target    string `json:"target"`
		Action    string `json:"action"`
		Type      string `json:"type"`
		Reason    string `json:"reason"`
		Unit      string `json:"unit"`
		Duration  int64  `json:"duration"`
		ID        string `json:"id"`
	}
	if r.Method == "GET" {
		q.Community = r.URL.Query().Get("community")
		q.Action = "list"
	} else if r.Method != "POST" || parse(r, &q) != nil {
		http.Error(w, "invalid request", 400)
		return
	}
	mediaControlMu.Lock()
	defer mediaControlMu.Unlock()
	s.mu.Lock()
	locked := true
	defer func() {
		if locked {
			s.mu.Unlock()
		}
	}()
	var c *Community
	for i := range s.db.Communities {
		if s.db.Communities[i].ID == q.Community {
			c = &s.db.Communities[i]
			break
		}
	}
	if c == nil {
		http.Error(w, "community not found", 404)
		return
	}
	if !contains(c.Members, user) && !s.isSuperadmin(user) {
		http.Error(w, "forbidden", 403)
		return
	}
	if q.Action == "list" {
		if !s.hasPermission(*c, user, "MANAGE_SANCTIONS") {
			http.Error(w, "forbidden", 403)
			return
		}
		out := []Sanction{}
		for _, v := range s.db.Sanctions {
			if v.Community == c.ID {
				out = append(out, v)
			}
		}
		reply(w, 200, out)
		return
	}
	if q.Action == "revoke" {
		if !s.hasPermission(*c, user, "MANAGE_SANCTIONS") {
			http.Error(w, "forbidden", 403)
			return
		}
		for i := range s.db.Sanctions {
			v := &s.db.Sanctions[i]
			if v.ID == q.ID && v.Community == c.ID && v.Revoked == nil {
				now := time.Now().UTC()
				v.Revoked = &now
				v.RevokedBy = user
				if s.save() != nil {
					http.Error(w, "storage error", 500)
					return
				}
				s.appendAudit(c.ID, user, "Sanção revogada", q.ID+" / "+v.Target)
				slog.Info("sanction.revoked", "actor", user, "sanction", q.ID)
				reply(w, 200, v)
				return
			}
		}
		http.Error(w, "not found", 404)
		return
	}
	perm := map[string]string{"disconnect_voice": "DISCONNECT_VOICE", "kick": "KICK_MEMBERS", "kick_temporary": "KICK_MEMBERS", "community_ban": "BAN_MEMBERS", "channel_ban": "BAN_CHANNEL_MEMBERS"}[q.Action]
	allowed := perm != "" && s.hasPermission(*c, user, perm)
	if perm == "DISCONNECT_VOICE" {
		voice.mu.Lock()
		if m := voice.members[q.Target]; m != nil && strings.HasPrefix(m.Room, c.ID+":") {
			sourceChannel := strings.TrimPrefix(m.Room, c.ID+":")
			allowed = s.channelPermission(*c, user, sourceChannel, "DISCONNECT_VOICE")
		}
		voice.mu.Unlock()
	}
	if !allowed {
		http.Error(w, "forbidden", 403)
		return
	}
	if q.Target == "" || q.Target == user || s.isSuperadmin(q.Target) || (q.Target == c.Owner && !s.isSuperadmin(user)) || !contains(c.Members, q.Target) {
		http.Error(w, "invalid target", 403)
		return
	}
	if c.Owner != user && !s.isSuperadmin(user) && s.maxPriority(*c, user) <= s.maxPriority(*c, q.Target) {
		http.Error(w, "target hierarchy protected", 403)
		return
	}
	if q.Action == "channel_ban" && (!contains(c.Channels, q.Channel)) {
		http.Error(w, "invalid channel", 400)
		return
	}
	if q.Action == "disconnect_voice" {
		voice.mu.Lock()
		m := voice.members[q.Target]
		if m == nil || !strings.HasPrefix(m.Room, c.ID+":") {
			voice.mu.Unlock()
			http.Error(w, "not connected", 409)
			return
		}
		room := m.Room
		voice.mu.Unlock()
		s.mu.Unlock()
		locked = false
		if err := livekitRoomAction(room, q.Target, true); err != nil {
			reply(w, 502, map[string]string{"error": "Falha ao desconectar a mídia; tente novamente"})
			return
		}
		voice.mu.Lock()
		if current := voice.members[q.Target]; current != nil && current.Room == room {
			delete(voice.members, q.Target)
		}
		voice.mu.Unlock()
		slog.Info("voice.disconnected", "actor", user, "target", q.Target, "community", c.ID)
		reply(w, 200, map[string]bool{"ok": true})
		return
	}
	q.Reason = strings.TrimSpace(q.Reason)
	if len(q.Reason) < 3 || len(q.Reason) > 500 {
		http.Error(w, "reason must have 3-500 characters", 400)
		return
	}
	var expires *time.Time
	if q.Action == "kick_temporary" || q.Action == "channel_ban" || q.Action == "community_ban" {
		if q.Unit != "permanent" {
			factor := map[string]time.Duration{"seconds": time.Second, "minutes": time.Minute, "hours": time.Hour, "days": 24 * time.Hour}[q.Unit]
			if factor == 0 || q.Duration < 1 || q.Duration > 365 || q.Duration > int64((365*24*time.Hour)/factor) {
				http.Error(w, "invalid duration", 400)
				return
			}
			v := time.Now().UTC().Add(time.Duration(q.Duration) * factor)
			expires = &v
		}
	}
	v := Sanction{ID: token()[:16], Community: c.ID, Channel: q.Channel, Target: q.Target, Actor: user, Type: q.Action, Reason: q.Reason, Created: time.Now().UTC(), Expires: expires}
	if q.Action == "kick" {
		v.Type = "community_kick"
	} else if q.Action == "kick_temporary" {
		v.Type = "community_kick_restriction"
	}
	s.db.Sanctions = append(s.db.Sanctions, v)
	if q.Action == "kick" || q.Action == "kick_temporary" || q.Action == "community_ban" {
		for i, n := range c.Members {
			if n == q.Target {
				c.Members = append(c.Members[:i], c.Members[i+1:]...)
				break
			}
		}
	}
	if err := s.save(); err != nil {
		http.Error(w, "storage error", 500)
		return
	}
	// Voice leases may expire while a modified client keeps the SFU transport.
	// Revoke in every affected voice room, not only the currently advertised one.
	rooms := make(map[string]bool)
	for _, channel := range c.Channels {
		if c.channelType(channel) == "voice" && (q.Action != "channel_ban" || channel == q.Channel) {
			rooms[c.ID+":"+channel] = true
		}
	}
	voice.mu.Lock()
	if m := voice.members[q.Target]; m != nil && strings.HasPrefix(m.Room, c.ID+":") && (q.Action != "channel_ban" || m.Room == c.ID+":"+q.Channel) {
		rooms[m.Room] = true
		delete(voice.members, q.Target)
	}
	voice.mu.Unlock()
	if s.isSuperadmin(user) {
		s.staffAuditLocked(user, "community_"+q.Action, q.Target, q.Community+"/"+q.Channel+" "+q.Reason)
		_ = s.save()
	}
	s.appendAudit(c.ID, user, "Sanção aplicada", v.Type+" / "+q.Target+" / "+q.Reason)
	slog.Info("sanction.created", "actor", user, "target", q.Target, "type", v.Type, "community", c.ID, "channel", q.Channel)
	s.mu.Unlock()
	locked = false
	mediaFailed := false
	for room := range rooms {
		if err := livekitRoomAction(room, q.Target, true); err != nil {
			mediaFailed = true
		}
	}
	if mediaFailed {
		reply(w, 502, map[string]any{"error": "Sanção salva, mas a desconexão de mídia falhou", "sanction": v, "sanction_saved": true})
		return
	}
	reply(w, 201, v)
}
func (s *Server) sanctionNotices(w http.ResponseWriter, r *http.Request) {
	user, err := s.auth(r)
	if err != nil {
		http.Error(w, "unauthorized", 401)
		return
	}
	if r.Method != "GET" {
		http.Error(w, "method", 405)
		return
	}
	s.mu.Lock()
	defer s.mu.Unlock()
	out := []Sanction{}
	for _, v := range s.db.Sanctions {
		if v.Target == user && v.Revoked == nil {
			out = append(out, v)
		}
	}
	reply(w, 200, out)
}
