package main

import (
	"bytes"
	"encoding/json"
	"net/http"
	"net/http/httptest"
	"path/filepath"
	"testing"
	"time"
)

func TestV1870AwayPersistsUntilExitWithMultipleSessions(t *testing.T) {
	s := newServer(filepath.Join(t.TempDir(), "data.json"))
	s.db.Users["alice1870"] = User{Name: "alice1870", PreferredStatus: "online"}
	s.db.Users["bob1870"] = User{Name: "bob1870"}
	s.db.Communities = []Community{{ID: "c1870", Owner: "alice1870", Members: []string{"alice1870", "bob1870"}}}
	s.sessions["token-a"] = "alice1870"
	s.sessions["token-b"] = "alice1870"
	s.sessions["token-reader"] = "bob1870"
	call := func(method, path, token, body string) *httptest.ResponseRecorder {
		r := httptest.NewRequest(method, path, bytes.NewBufferString(body))
		r.Header.Set("Authorization", "Bearer "+token)
		w := httptest.NewRecorder()
		s.routes().ServeHTTP(w, r)
		if w.Code != http.StatusOK {
			t.Fatalf("%s %s: %d %s", method, path, w.Code, w.Body.String())
		}
		return w
	}
	getStatus := func() string {
		w := call("GET", "/api/presence?community=c1870", "token-reader", "")
		var result struct {
			Members []struct{ User, Status string } `json:"members"`
		}
		if err := json.Unmarshal(w.Body.Bytes(), &result); err != nil {
			t.Fatal(err)
		}
		return result.Members[0].Status
	}
	call("POST", "/api/presence-heartbeat", "token-a", `{"client":"client-a-1870","background":false}`)
	call("POST", "/api/presence-heartbeat", "token-b", `{"client":"client-b-1870","background":true}`)
	// Reload with the same token can create an extra client. Leaving a session
	// must clean both clients and preserve the other logged-in session.
	call("POST", "/api/presence-heartbeat", "token-a", `{"client":"client-a-reloaded-1870","background":true}`)
	online.entries["alice1870"]["client-a-1870"] = time.Now().Add(-240 * time.Hour)
	online.entries["alice1870"]["client-a-reloaded-1870"] = time.Now().Add(-240 * time.Hour)
	if got := getStatus(); got != "away" {
		t.Fatalf("old session must remain away: %s", got)
	}
	call("POST", "/api/presence-heartbeat", "token-a", `{"client":"client-a-reloaded-1870","leaving":true}`)
	if _, ok := online.entries["alice1870"]["client-a-1870"]; ok {
		t.Fatal("stale client from exited session remains")
	}
	if _, ok := online.entries["alice1870"]["client-a-reloaded-1870"]; ok {
		t.Fatal("exited client remains")
	}
	if got := getStatus(); got != "away" {
		t.Fatalf("remaining background session should be away: %s", got)
	}
	call("POST", "/api/presence-heartbeat", "token-b", `{"client":"client-b-1870","background":false}`)
	if got := getStatus(); got != "online" {
		t.Fatalf("returning session should be online: %s", got)
	}
	call("POST", "/api/presence-heartbeat", "token-b", `{"client":"client-b-1870","leaving":true}`)
	if got := getStatus(); got != "offline" {
		t.Fatalf("all sessions exited must be offline: %s", got)
	}
}

func TestV1870UserManualOfflineWins(t *testing.T) {
	s := newServer(filepath.Join(t.TempDir(), "data.json"))
	s.db.Users["alice1870"] = User{Name: "alice1870", PreferredStatus: "offline"}
	s.db.Users["reader1870"] = User{Name: "reader1870"}
	s.db.Communities = []Community{{ID: "c1870", Owner: "alice1870", Members: []string{"alice1870", "reader1870"}}}
	s.sessions["a1870"] = "alice1870"
	s.sessions["r1870"] = "reader1870"
	r := httptest.NewRequest("POST", "/api/presence-heartbeat", bytes.NewBufferString(`{"client":"client-a-1870","background":false}`))
	r.Header.Set("Authorization", "Bearer a1870")
	w := httptest.NewRecorder()
	s.routes().ServeHTTP(w, r)
	r = httptest.NewRequest("GET", "/api/presence?community=c1870", nil)
	r.Header.Set("Authorization", "Bearer r1870")
	w = httptest.NewRecorder()
	s.routes().ServeHTTP(w, r)
	var data struct {
		Members []struct{ Status string } `json:"members"`
	}
	if err := json.Unmarshal(w.Body.Bytes(), &data); err != nil {
		t.Fatal(err)
	}
	if data.Members[0].Status != "offline" {
		t.Fatalf("manual Offline ignored: %s", data.Members[0].Status)
	}
}
