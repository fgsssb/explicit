package main

import (
	"bytes"
	"encoding/json"
	"net/http/httptest"
	"path/filepath"
	"testing"
)

func TestAnnouncementsPermissionsValidationAndPersistence(t *testing.T) {
	s := newServer(filepath.Join(t.TempDir(), "store.json"))
	s.db.Users["staff"] = User{Name: "staff", SystemRole: "moderator"}
	s.db.Users["visitor"] = User{Name: "visitor"}
	s.sessions["staff-token"] = "staff"
	s.sessions["visitor-token"] = "visitor"
	call := func(method, session string, payload any) *httptest.ResponseRecorder {
		t.Helper()
		b, _ := json.Marshal(payload)
		r := httptest.NewRequest(method, "/api/announcements", bytes.NewReader(b))
		r.Header.Set("Authorization", "Bearer "+session)
		w := httptest.NewRecorder()
		s.routes().ServeHTTP(w, r)
		return w
	}
	pub := map[string]any{"action": "add", "title": "Manutenção programada", "body": "Nosso servidor ficará indisponível amanhã às 10h.", "links": []map[string]string{{"label": "Saiba mais", "url": "https://example.com/avisos"}}}
	if w := call("POST", "visitor-token", pub); w.Code != 403 {
		t.Fatalf("visitor may publish: %d", w.Code)
	}
	bad := map[string]any{"action": "add", "title": "Site malicioso", "body": "Clique no endereço abaixo e acesse a notícia.", "links": []map[string]string{{"label": "Site", "url": "javascript:alert(1)"}}}
	if w := call("POST", "staff-token", bad); w.Code != 400 {
		t.Fatalf("invalid protocol accepted: %d", w.Code)
	}
	if w := call("POST", "staff-token", pub); w.Code != 201 {
		t.Fatalf("publish failed: %d %s", w.Code, w.Body)
	}
	if w := call("GET", "visitor-token", nil); w.Code != 200 {
		t.Fatalf("visitor cannot read: %d", w.Code)
	}
	reloaded := newServer(s.file)
	if len(reloaded.db.Announcements) != 1 {
		t.Fatal("not persisted")
	}
	id := s.db.Announcements[0].ID
	if w := call("POST", "staff-token", map[string]any{"action": "remove", "id": id}); w.Code != 200 {
		t.Fatalf("cannot remove: %d", w.Code)
	}
}
