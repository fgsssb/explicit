package main

import (
	"bytes"
	"encoding/json"
	"net/http/httptest"
	"path/filepath"
	"testing"
	"time"
)

func TestVoiceMoveRequiresSourceAndDestinationPermissions(t *testing.T) {
	s := newServer(filepath.Join(t.TempDir(), "voice-move.json"))
	for _, u := range []string{"owner", "mod", "guest"} {
		s.db.Users[u] = User{Name: u}
	}
	s.sessions["mod-session"] = "mod"
	s.db.Communities = []Community{{ID: "c", Name: "Teste", Owner: "owner", Members: []string{"owner", "mod", "guest"}, Channels: []string{"fonte", "destino"},
		Roles: []Role{{ID: "modrole", Name: "Mod", Priority: 10, Permissions: []string{"MOVE_MEMBERS"}}}, MemberRoles: map[string][]string{"mod": {"modrole"}},
		ChannelMeta: map[string]ChannelMeta{"fonte": {Type: "voice"}, "destino": {Type: "voice", RolePermissions: map[string]map[string]bool{"everyone": {"MOVE_MEMBERS": false}}}},
	}}
	voice.mu.Lock()
	voice.members = map[string]*voiceMember{"guest": {User: "guest", Room: "c:fonte", Seen: time.Now()}}
	voice.mu.Unlock()
	defer func() { voice.mu.Lock(); voice.members = map[string]*voiceMember{}; voice.mu.Unlock() }()
	call := func() int {
		t.Helper()
		body, _ := json.Marshal(map[string]any{"community": "c", "target": "guest", "action": "move", "channel": "destino"})
		req := httptest.NewRequest("POST", "/api/voice-moderation", bytes.NewReader(body))
		req.Header.Set("Authorization", "Bearer mod-session")
		w := httptest.NewRecorder()
		s.voiceModeration(w, req)
		return w.Code
	}
	if got := call(); got != 400 {
		t.Fatalf("destination deny not enforced: %d", got)
	}
	target := s.db.Communities[0].ChannelMeta["destino"]
	target.RolePermissions["modrole"] = map[string]bool{"MOVE_MEMBERS": true}
	s.db.Communities[0].ChannelMeta["destino"] = target
	if got := call(); got != 200 {
		t.Fatalf("source+destination allow rejected: %d", got)
	}
	voice.mu.Lock()
	signals := append([]voiceSignal(nil), voice.members["guest"].Queue...)
	voice.mu.Unlock()
	if len(signals) != 1 || signals[0].Kind != "admin_move" || signals[0].Data != "destino" {
		t.Fatalf("unexpected voice move notification: %+v", signals)
	}
}
