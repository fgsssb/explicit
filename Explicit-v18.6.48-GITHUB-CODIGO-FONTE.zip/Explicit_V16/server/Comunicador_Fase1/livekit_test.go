package main

import (
	"bytes"
	"crypto/hmac"
	"crypto/sha256"
	"encoding/base64"
	"encoding/json"
	"net/http"
	"net/http/httptest"
	"path/filepath"
	"strings"
	"testing"
	"time"
)

func TestSignedLiveKitTokenConstraintsAndSignature(t *testing.T) {
	now := time.Unix(1800000000, 0)
	key := "my-explicit-api-key-123"
	secret := strings.Repeat("s", 40)
	raw, err := signedLiveKitToken(key, secret, "ana", "community:voice", true, false, now)
	if err != nil {
		t.Fatal(err)
	}
	parts := strings.Split(raw, ".")
	if len(parts) != 3 {
		t.Fatal("invalid JWT format")
	}
	mac := hmac.New(sha256.New, []byte(secret))
	mac.Write([]byte(parts[0] + "." + parts[1]))
	actual, err := base64.RawURLEncoding.DecodeString(parts[2])
	if err != nil || !hmac.Equal(actual, mac.Sum(nil)) {
		t.Fatal("invalid signature")
	}
	payload, err := base64.RawURLEncoding.DecodeString(parts[1])
	if err != nil {
		t.Fatal(err)
	}
	var claims liveKitClaims
	if err = json.Unmarshal(payload, &claims); err != nil {
		t.Fatal(err)
	}
	if claims.Issuer != key || claims.Subject != "ana" || claims.Video.Room != "community:voice" || claims.ExpiresAt-now.Unix() != 300 {
		t.Fatalf("unexpected claims %+v", claims)
	}
	if !claims.Video.CanPublish || len(claims.Video.CanPublishSources) != 1 || claims.Video.CanPublishSources[0] != "microphone" {
		t.Fatalf("unauthorized camera or screen grant: %+v", claims.Video)
	}
	spectator, _ := signedLiveKitToken(key, secret, "bia", "community:voice", false, false, now)
	parts = strings.Split(spectator, ".")
	payload, _ = base64.RawURLEncoding.DecodeString(parts[1])
	claims = liveKitClaims{}
	json.Unmarshal(payload, &claims)
	if claims.Video.CanPublish || len(claims.Video.CanPublishSources) != 0 || !claims.Video.CanSubscribe {
		t.Fatalf("invalid spectator grants: %+v", claims.Video)
	}
}

func TestLiveKitTokenMustRequireAuthenticatedVoiceJoin(t *testing.T) {
	t.Setenv("LIVEKIT_WS_URL", "wss://media.example.test")
	t.Setenv("LIVEKIT_API_KEY", "explicit-api-key-123")
	t.Setenv("LIVEKIT_API_SECRET", strings.Repeat("x", 48))
	s := newServer(filepath.Join(t.TempDir(), "store.json"))
	s.db.Users["ana"] = User{Name: "ana"}
	s.db.Users["intruso"] = User{Name: "intruso"}
	s.db.Communities = []Community{{ID: "space", Owner: "ana", Members: []string{"ana"}, Channels: []string{"voz"}, ChannelMeta: map[string]ChannelMeta{"voz": {Type: "voice"}}}}
	s.sessions["valid"] = "ana"
	s.sessions["invalid"] = "intruso"
	send := func(authorization string) (int, map[string]any) {
		t.Helper()
		data := []byte(`{"community":"space","channel":"voz"}`)
		r := httptest.NewRequest(http.MethodPost, "/api/livekit-token", bytes.NewReader(data))
		r.Header.Set("Authorization", "Bearer "+authorization)
		w := httptest.NewRecorder()
		s.liveKitToken(w, r)
		var response map[string]any
		_ = json.Unmarshal(w.Body.Bytes(), &response)
		return w.Code, response
	}
	if code, _ := send(""); code != http.StatusUnauthorized {
		t.Fatalf("anonymous=%d", code)
	}
	if code, _ := send("invalid"); code != http.StatusForbidden {
		t.Fatalf("nonmember=%d", code)
	}
	if code, _ := send("valid"); code != http.StatusConflict {
		t.Fatalf("not joined=%d", code)
	}
	join := httptest.NewRequest(http.MethodPost, "/api/voice", strings.NewReader(`{"community":"space","channel":"voz","action":"join"}`))
	join.Header.Set("Authorization", "Bearer valid")
	w := httptest.NewRecorder()
	s.voiceAPI(w, join)
	if w.Code != 200 {
		t.Fatalf("voice join=%d", w.Code)
	}
	if code, body := send("valid"); code != 200 || body["token"] == nil || body["url"] != "wss://media.example.test" {
		t.Fatalf("token=%d %v", code, body)
	}
	voice.mu.Lock()
	delete(voice.members, "ana")
	voice.mu.Unlock()
	if code, _ := send("valid"); code != 409 {
		t.Fatalf("after leave=%d", code)
	}
}

func TestLiveKitConfigRejectsInsecureOrPartialSetup(t *testing.T) {
	t.Setenv("LIVEKIT_WS_URL", "http://media.example.test")
	t.Setenv("LIVEKIT_API_KEY", "explicit-api-key-123")
	t.Setenv("LIVEKIT_API_SECRET", strings.Repeat("s", 40))
	if _, _, _, ok := liveKitConfig(); ok {
		t.Fatal("insecure URL accepted")
	}
	t.Setenv("LIVEKIT_WS_URL", "wss://media.example.test")
	t.Setenv("LIVEKIT_API_SECRET", "weak")
	if _, _, _, ok := liveKitConfig(); ok {
		t.Fatal("weak secret accepted")
	}
}
