package main

import (
	"log/slog"
	"net/http"
	"regexp"
	"strconv"
	"strings"
	"time"
)

type SystemAuditEntry struct {
	At     time.Time `json:"at"`
	Actor  string    `json:"actor"`
	Action string    `json:"action"`
	Target string    `json:"target"`
	Reason string    `json:"reason,omitempty"`
}
type SystemReport struct {
	ID                   string    `json:"id"`
	Reporter             string    `json:"reporter"`
	Kind                 string    `json:"kind"`
	Target               string    `json:"target"`
	Reason               string    `json:"reason"`
	At                   time.Time `json:"at"`
	Status               string    `json:"status"`
	ChatID               string    `json:"chat_id,omitempty"`
	MessageID            string    `json:"message_id,omitempty"`
	ExpansionReason      string    `json:"expansion_reason,omitempty"`
	ExpansionRequestedBy string    `json:"expansion_requested_by,omitempty"`
	ExpansionApprovedBy  string    `json:"expansion_approved_by,omitempty"`
}

func systemRole(u User) string {
	if u.SystemRole == "" {
		return "user"
	}
	return u.SystemRole
}
func systemLevel(role string) int {
	switch role {
	case "superadmin":
		return 3
	case "owner":
		return 2
	case "admin":
		return 2
	case "moderator":
		return 2
	}
	return 0
}
func (s *Server) systemAdminAPI(w http.ResponseWriter, r *http.Request) {
	actor, err := s.auth(r)
	if err != nil {
		http.Error(w, "unauthorized", 401)
		return
	}
	s.mu.Lock()
	defer s.mu.Unlock()
	level := systemLevel(systemRole(s.db.Users[actor]))
	if level == 0 {
		http.Error(w, "forbidden", 403)
		return
	}
	if r.Method == "GET" {
		users := []map[string]any{}
		for _, u := range s.db.Users {
			users = append(users, map[string]any{"name": u.Name, "display_name": u.DisplayName, "email": u.Email, "role": systemRole(u), "beta": u.Beta, "explicit_plus": explicitPlusActive(u), "explicit_plus_expires_at": explicitPlusExpiry(u), "explicit_plus_legacy": u.ExplicitPlus && u.ExplicitPlusExpiresAt == nil, "badges": userBadges(u), "require_password_change": u.RequirePasswordChange, "terms_accepted_at": u.TermsAcceptedAt, "terms_version": u.TermsVersion, "invite_key": u.InviteKey, "banned_permanent": u.BannedPermanent, "banned_until": u.BannedUntil})
		}
		reply(w, 200, map[string]any{"role": systemRole(s.db.Users[actor]), "require_invite": s.db.RequireInvite, "invite_limit": s.inviteLimitLocked(), "users": users, "communities": s.db.Communities, "reports": s.db.Reports, "audit": s.db.SystemAudit})
		return
	}
	if r.Method != "POST" {
		http.Error(w, "method", 405)
		return
	}
	var q struct {
		Action          string   `json:"action"`
		Target          string   `json:"target"`
		Role            string   `json:"role"`
		Beta            *bool    `json:"beta"`
		Badges          []string `json:"badges"`
		Reason          string   `json:"reason"`
		Hours           int      `json:"hours"`
		ReportID        string   `json:"report_id"`
		RequireInvite   *bool    `json:"require_invite"`
		InviteLimit     *int     `json:"invite_limit"`
		InviteKey       string   `json:"invite_key"`
		NewPassword     string   `json:"new_password"`
		ForceChange     bool     `json:"force_change"`
		DurationSeconds int64    `json:"duration_seconds"`
		DurationMode    string   `json:"duration_mode"`
	}
	if parse(r, &q) != nil {
		http.Error(w, "invalid request", 400)
		return
	}
	q.Reason = strings.TrimSpace(q.Reason)
	if q.Action == "resolve_report" {
		if level < 1 {
			http.Error(w, "forbidden", 403)
			return
		}
		for i := range s.db.Reports {
			if s.db.Reports[i].ID == q.ReportID {
				old := s.db.Reports[i].Status
				s.db.Reports[i].Status = "resolved"
				s.staffAuditLocked(actor, "report_resolved", q.ReportID, "Denúncia revisada")
				if s.save() != nil {
					s.db.Reports[i].Status = old
					http.Error(w, "storage", 500)
					return
				}
				reply(w, 200, map[string]bool{"ok": true})
				return
			}
		}
		http.Error(w, "not found", 404)
		return
	}
	if level < 2 && q.Action != "reset_password" {
		http.Error(w, "forbidden", 403)
		return
	}
	if q.Action == "set_home_mode" {
		if q.Role != "spotlight" && q.Role != "changelog" || len(q.Reason) > 12000 {
			http.Error(w, "invalid home mode", 400)
			return
		}
		oldMode, oldLog, oldSet := s.db.HomeMode, s.db.Changelog, s.db.HomeModeConfiguredV1869
		s.db.HomeMode, s.db.Changelog = q.Role, q.Reason
		s.db.HomeModeConfiguredV1869 = true
		if err := s.save(); err != nil {
			s.db.HomeMode, s.db.Changelog = oldMode, oldLog
			s.db.HomeModeConfiguredV1869 = oldSet
			http.Error(w, "storage", 500)
			return
		}
		reply(w, 200, map[string]bool{"ok": true})
		return
	}
	if q.Action == "set_invite_limit" {
		if !s.isOwner(actor) && !s.isSuperadmin(actor) {
			http.Error(w, "owner required", 403)
			return
		}
		if q.InviteLimit == nil || *q.InviteLimit < 1 || *q.InviteLimit > 1000 {
			http.Error(w, "invite limit must be 1-1000", 400)
			return
		}
		old := s.db.InviteLimit
		s.db.InviteLimit = *q.InviteLimit
		if err := s.save(); err != nil {
			s.db.InviteLimit = old
			http.Error(w, "storage failure", 500)
			return
		}
		reply(w, 200, map[string]bool{"ok": true})
		return
	}
	if q.Action == "set_invite_requirement" {
		if q.RequireInvite == nil {
			http.Error(w, "missing setting", 400)
			return
		}
		previous := s.db.RequireInvite
		s.db.RequireInvite = *q.RequireInvite
		s.staffAuditLocked(actor, "invite_requirement", strconv.FormatBool(*q.RequireInvite), "Configuração global alterada")
		s.db.SystemAudit = append(s.db.SystemAudit, SystemAuditEntry{At: time.Now(), Actor: actor, Action: q.Action, Target: strconv.FormatBool(*q.RequireInvite)})
		if s.save() != nil {
			s.db.RequireInvite = previous
			s.db.SystemAudit = s.db.SystemAudit[:len(s.db.SystemAudit)-1]
			http.Error(w, "storage failure", 500)
			return
		}
		reply(w, 200, map[string]bool{"ok": true})
		return
	}
	target, ok := s.db.Users[q.Target]
	if !ok {
		http.Error(w, "not found", 404)
		return
	}
	if (q.Target == actor && q.Action != "set_badges") ||
		(s.isOwner(q.Target) && q.Action != "ban" && q.Action != "unban") ||
		(systemLevel(systemRole(target)) >= level &&
			!((q.Action == "ban" || q.Action == "unban") && systemLevel(systemRole(target)) <= level) &&
			!(s.isOwner(actor) && (q.Action == "set_role" || q.Action == "set_badges")) &&
			!(q.Action == "set_badges" && level >= 3 && q.Target == actor)) {
		http.Error(w, "cannot modify self or equal/higher role", 403)
		return
	}
	old := target
	switch q.Action {
	case "reset_password":
		if len(q.NewPassword) < 8 || len(q.NewPassword) > 256 {
			http.Error(w, "A senha temporária deve ter entre 8 e 256 caracteres", 400)
			return
		}
		target.Salt = token()
		target.Hash = secureHash(target.Salt, q.NewPassword)
		target.RequirePasswordChange = q.ForceChange
	case "set_badges":
		if level < 2 {
			http.Error(w, "admin required", 403)
			return
		}
		staff, beta, plus, valid := parseBadgeSelection(q.Badges)
		if !valid {
			http.Error(w, "invalid or duplicate badge", 400)
			return
		}
		// Only the authenticated Owner can issue or revoke the Admin badge.
		// No alternate role/badge API can bypass this check.
		if staff != (systemLevel(systemRole(target)) > 0) && !s.isOwner(actor) {
			http.Error(w, "only Owner may manage Admin badge", 403)
			return
		}
		// Never pretend a user is Staff: the badge corresponds to an actual
		// moderation role. Existing admins keep their role and cannot hide it.
		role := systemRole(target)
		if role == "user" && staff {
			target.SystemRole = "moderator"
		}
		if role == "moderator" && !staff {
			target.SystemRole = "user"
		}
		if (role == "admin" || role == "superadmin" || role == "owner") && !staff {
			http.Error(w, "administrator staff badge cannot be removed independently of role", 409)
			return
		}

		// Every NEW or expired grant needs a staff-defined finite term.
		// Retaining an existing active grant does not change its deadline.
		if plus && (!explicitPlusActive(old) || q.DurationSeconds > 0) {
			if !validExplicitPlusDuration(q.DurationSeconds) {
				http.Error(w, "Informe uma duração de Explicit+ válida (1 segundo a 10 anos)", 400)
				return
			}
			end := time.Now().UTC().Add(time.Duration(q.DurationSeconds) * time.Second)
			target.ExplicitPlusExpiresAt = &end
		}
		target.Beta = beta
		target.ExplicitPlus = plus
		if !plus {
			target.ExplicitPlusExpiresAt = nil
		}
	case "set_explicit_plus_duration":
		if level < 2 {
			http.Error(w, "admin required", 403)
			return
		}
		if !target.ExplicitPlus || !validExplicitPlusDuration(q.DurationSeconds) || (q.DurationMode != "replace" && q.DurationMode != "extend") {
			http.Error(w, "Duração inválida ou Explicit+ não concedido", 400)
			return
		}
		base := time.Now().UTC()
		if q.DurationMode == "extend" && target.ExplicitPlusExpiresAt != nil && target.ExplicitPlusExpiresAt.After(base) {
			base = *target.ExplicitPlusExpiresAt
		}
		end := base.Add(time.Duration(q.DurationSeconds) * time.Second)
		// Keep every expiry within ten years of now, including extensions.
		if end.After(time.Now().UTC().Add(10 * 365 * 24 * time.Hour)) {
			http.Error(w, "Prazo máximo de dez anos", 400)
			return
		}
		target.ExplicitPlusExpiresAt = &end
	case "set_beta":
		if level < 3 || q.Beta == nil {
			http.Error(w, "superadmin and beta field required", 403)
			return
		}
		target.Beta = *q.Beta
	case "set_invite_key":
		key := strings.ToUpper(strings.TrimSpace(q.InviteKey))
		if !regexp.MustCompile(`^[A-Z0-9-]{8,64}$`).MatchString(key) {
			http.Error(w, "invalid key", 400)
			return
		}
		for name, u := range s.db.Users {
			if name != q.Target && u.InviteKey == key {
				http.Error(w, "key already in use", 409)
				return
			}
		}
		// Previously redeemed invitations remain in the audit/history and count against this user's quota.
		target.InviteKey = key
	case "set_role":
		if !s.isOwner(actor) && !s.isSuperadmin(actor) {
			http.Error(w, "only Owner may manage Admin roles", 403)
			return
		}
		if q.Role != "user" && q.Role != "moderator" {
			http.Error(w, "invalid role", 400)
			return
		}
		if q.Role == "owner" || systemRole(target) == "superadmin" {
			http.Error(w, "forbidden role", 403)
			return
		}
		target.SystemRole = q.Role
	case "ban":
		if q.ReportID != "" {
			report := s.investigationCaseLocked(q.ReportID)
			if report == nil || report.Target != q.Target {
				http.Error(w, "open report must match sanctioned user", 403)
				return
			}
			q.Reason = "Denúncia " + report.ID + ": " + q.Reason
		}
		if len(q.Reason) < 3 || len(q.Reason) > 500 || q.Hours < 0 || q.Hours > 87600 {
			http.Error(w, "invalid ban", 400)
			return
		}
		target.BannedPermanent = q.Hours == 0
		target.BannedUntil = nil
		if q.Hours > 0 {
			t := time.Now().Add(time.Duration(q.Hours) * time.Hour)
			target.BannedUntil = &t
		}
	case "unban":
		target.BannedPermanent = false
		target.BannedUntil = nil
	default:
		http.Error(w, "invalid action", 400)
		return
	}
	s.db.Users[q.Target] = target
	auditReason := q.Reason + " " + strconv.Itoa(q.Hours)
	if q.Action == "set_explicit_plus_duration" || (q.Action == "set_badges" && q.DurationSeconds > 0) {
		auditReason = "Explicit+ duration_seconds=" + strconv.FormatInt(q.DurationSeconds, 10) + " mode=" + q.DurationMode
	}
	entry := SystemAuditEntry{At: time.Now(), Actor: actor, Action: q.Action, Target: q.Target, Reason: auditReason}
	s.db.SystemAudit = append(s.db.SystemAudit, entry)
	if systemLevel(systemRole(s.db.Users[actor])) >= 2 {
		s.staffAuditLocked(actor, q.Action, q.Target, auditReason)
	}
	if err := s.save(); err != nil {
		s.db.Users[q.Target] = old
		s.db.SystemAudit = s.db.SystemAudit[:len(s.db.SystemAudit)-1]
		http.Error(w, "storage failure", 500)
		return
	}
	if q.Action == "ban" || q.Action == "set_role" || q.Action == "reset_password" || (q.Action == "set_badges" && old.SystemRole != target.SystemRole) {
		for token, user := range s.sessions {
			if user == q.Target {
				delete(s.sessions, token)
				delete(s.sessionExpiry, token)
			}
		}
	}
	if q.Action == "ban" {
		voice.mu.Lock()
		room := ""
		if v := voice.members[q.Target]; v != nil {
			room = v.Room
			delete(voice.members, q.Target)
		}
		voice.mu.Unlock()
		if room != "" {
			go func() {
				if err := livekitRoomAction(room, q.Target, true); err != nil {
					slog.Error("LiveKit ban failed", "err", err)
				}
			}()
		}
	}
	reply(w, 200, map[string]bool{"ok": true})
}
func (s *Server) reportAPI(w http.ResponseWriter, r *http.Request) {
	user, err := s.auth(r)
	if err != nil {
		http.Error(w, "unauthorized", 401)
		return
	}
	if r.Method != "POST" {
		http.Error(w, "method", 405)
		return
	}
	var q struct {
		Kind      string `json:"kind"`
		Target    string `json:"target"`
		Reason    string `json:"reason"`
		ChatID    string `json:"chat_id"`
		MessageID string `json:"message_id"`
	}
	if parse(r, &q) != nil || len(strings.TrimSpace(q.Reason)) < 5 || len(q.Reason) > 500 || len(q.Target) > 120 {
		http.Error(w, "invalid report", 400)
		return
	}
	if q.Kind != "user" && q.Kind != "community" && q.Kind != "message" && q.Kind != "image" {
		http.Error(w, "invalid kind", 400)
		return
	}
	s.mu.Lock()
	defer s.mu.Unlock()
	if q.Kind == "user" {
		if q.Target == user {
			http.Error(w, "self-report not allowed", 400)
			return
		}
		if _, found := s.db.Users[q.Target]; !found {
			http.Error(w, "reported user not found", 404)
			return
		}
	}
	// Message evidence must be a real message by the reported user in a DM
	// that the reporter participates in. Generic profile reports never grant
	// read access to private history, regardless of reason text.
	if q.ChatID != "" || q.MessageID != "" {
		if q.Kind != "user" || q.ChatID == "" || q.MessageID == "" {
			http.Error(w, "invalid evidence", 400)
			return
		}
		valid := false
		for _, c := range s.db.DirectChats {
			if c.ID != q.ChatID || !contains(c.Users, user) || !contains(c.Users, q.Target) {
				continue
			}
			for _, m := range c.Messages {
				if m.ID == q.MessageID && m.Author == q.Target && !m.StaffNotice {
					valid = true
					break
				}
			}
		}
		if !valid {
			http.Error(w, "evidence not authorized", 403)
			return
		}
	}
	item := SystemReport{ID: token()[:16], Reporter: user, Kind: q.Kind, Target: q.Target, Reason: strings.TrimSpace(q.Reason), At: time.Now(), Status: "open", ChatID: q.ChatID, MessageID: q.MessageID}
	s.db.Reports = append(s.db.Reports, item)
	if s.save() != nil {
		s.db.Reports = s.db.Reports[:len(s.db.Reports)-1]
		http.Error(w, "storage failure", 500)
		return
	}
	reply(w, 201, map[string]string{"id": item.ID})
}
