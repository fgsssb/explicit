package main

import (
	"bytes"
	"encoding/json"
	"fmt"
	"net/http"
	"net/http/httptest"
	"path/filepath"
	"strings"
	"sync"
	"testing"
	"time"
)

func auditRequest(t *testing.T, s *Server, user, path string, data any) *httptest.ResponseRecorder {
	t.Helper()
	b, err := json.Marshal(data)
	if err != nil {
		t.Fatal(err)
	}
	req := httptest.NewRequest(http.MethodPost, path, bytes.NewReader(b))
	req.Header.Set("Authorization", "Bearer "+user+"-token")
	rec := httptest.NewRecorder()
	s.routes().ServeHTTP(rec, req)
	return rec
}
func auditFixture(t *testing.T) *Server {
	t.Helper()
	s := newServer(filepath.Join(t.TempDir(), "store.json"))
	for _, name := range []string{"owner", "member", "third", "outsider"} {
		s.db.Users[name] = User{Name: name, DisplayName: name, AccountID: name}
		s.sessions[name+"-token"] = name
	}
	s.db.Communities = []Community{{
		ID: "audit-community", Name: "Audit", Owner: "owner", Members: []string{"owner", "member", "third"},
		Channels:    []string{"geral", "private"},
		ChannelMeta: map[string]ChannelMeta{"geral": {Type: "text"}, "private": {Type: "text", RolePermissions: map[string]map[string]bool{"everyone": {"VIEW_CHANNEL": false, "CREATE_INVITES": true}}}},
		Roles:       []Role{{ID: "helper", Name: "Helper", Color: "#5588AA", Priority: 1, Permissions: []string{"CREATE_INVITES"}}},
		MemberRoles: map[string][]string{"member": {"helper"}},
	}}
	return s
}

func TestAuditInviteToHiddenChannelRequiresVisibility(t *testing.T) {
	s := auditFixture(t)
	// Although CREATE_INVITES is allowed, hidden channel visibility is denied.
	data := map[string]string{"community": "audit-community", "channel": "private"}
	if rec := auditRequest(t, s, "member", "/api/community-invite", data); rec.Code != http.StatusForbidden {
		t.Fatalf("hidden channel invite should be denied, got %d: %s", rec.Code, rec.Body.String())
	}
	if len(s.db.CommunityInvites) != 0 {
		t.Fatal("unauthorized invite persisted")
	}
	// The global invite permission still works for a visible community invitation.
	if rec := auditRequest(t, s, "member", "/api/community-invite", map[string]string{"community": "audit-community"}); rec.Code != http.StatusCreated {
		t.Fatalf("community invitation unexpectedly blocked: %d %s", rec.Code, rec.Body.String())
	}
	s.db.Communities[0].ChannelMeta["private"] = ChannelMeta{Type: "text", RolePermissions: map[string]map[string]bool{"everyone": {"VIEW_CHANNEL": true, "CREATE_INVITES": true}}}
	if rec := auditRequest(t, s, "member", "/api/community-invite", data); rec.Code != http.StatusCreated {
		t.Fatalf("visible channel invitation unexpectedly blocked: %d %s", rec.Code, rec.Body.String())
	}
}

func TestAuditJoinFailureRollsBackInMemoryMembership(t *testing.T) {
	s := auditFixture(t)
	s.db.Communities[0].InviteCode = "invitetojoin"
	s.file = t.TempDir() // A directory cannot be replaced by a JSON store file.
	rec := auditRequest(t, s, "outsider", "/api/communities", map[string]string{"join": "invitetojoin"})
	if rec.Code != http.StatusInternalServerError {
		t.Fatalf("expected persistence failure: %d %s", rec.Code, rec.Body.String())
	}
	if contains(s.db.Communities[0].Members, "outsider") {
		t.Fatal("transient access granted after failed write")
	}
}

func TestAuditRoleWritesRollBackPermissionsOnStorageFailure(t *testing.T) {
	for _, tc := range []struct {
		name   string
		action string
		data   map[string]any
	}{
		{"create", "create_role", map[string]any{"name": "Elevated", "color": "#123456", "permissions": []string{"ADMINISTRATOR"}, "priority": 30}},
		{"update", "update_role", map[string]any{"role": "helper", "name": "Changed", "color": "#ABCDEF", "permissions": []string{"ADMINISTRATOR"}, "priority": 30}},
		{"assign", "assign_role", map[string]any{"role": "helper", "target": "third"}},
		{"remove", "remove_role", map[string]any{"role": "helper", "target": "member"}},
		{"delete", "delete_role", map[string]any{"role": "helper"}},
	} {
		t.Run(tc.name, func(t *testing.T) {
			s := auditFixture(t)
			before, _ := json.Marshal(s.db.Communities[0])
			s.file = t.TempDir() // Force a deterministic write failure.
			data := map[string]any{"action": tc.action, "community": "audit-community"}
			for k, v := range tc.data {
				data[k] = v
			}
			rec := auditRequest(t, s, "owner", "/api/community-admin", data)
			if rec.Code != http.StatusInternalServerError {
				t.Fatalf("expected failed write, got %d: %s", rec.Code, rec.Body.String())
			}
			after, _ := json.Marshal(s.db.Communities[0])
			if !bytes.Equal(before, after) {
				t.Fatalf("role permissions changed in RAM after failed write; before=%s after=%s", before, after)
			}
		})
	}
}

func TestAuditPresenceDoesNotGrowIndefinitely(t *testing.T) {
	s := auditFixture(t)
	previous := online
	online.entries = map[string]map[string]time.Time{}
	online.background = map[string]map[string]bool{}
	online.sessionKeys = map[string]map[string]string{}
	t.Cleanup(func() { online = previous })
	// A rogue client cannot spoof the server's notification pseudo-client names.
	rec := auditRequest(t, s, "owner", "/api/presence-heartbeat", map[string]any{"client": "notifications:forged-client"})
	if rec.Code != http.StatusBadRequest {
		t.Fatalf("reserved namespace accepted: %d", rec.Code)
	}
	// Call the shared insert helper, which is used by both presence endpoints.
	s.mu.Lock()
	for i := 0; i < 200; i++ {
		s.updatePresenceClientLocked("owner", fmt.Sprintf("browser-session-%03d", i), "Bearer owner-token", false)
	}
	count := len(online.entries["owner"])
	other := len(online.sessionKeys["owner"])
	backgrounds := len(online.background["owner"])
	s.mu.Unlock()
	if count != maxPresenceClientsPerUser || other != count || backgrounds != count {
		t.Fatalf("unbounded presence state: entries=%d sessionKeys=%d backgrounds=%d", count, other, backgrounds)
	}
	// The last client should have survived eviction.
	if _, ok := online.entries["owner"]["browser-session-199"]; !ok {
		t.Fatal("newest presence evicted")
	}
}

func TestAuditVoiceAndTokenEndpointRateLimits(t *testing.T) {
	assert := func(path, want string) {
		t.Helper()
		if got := expensivePostCategory(path); got != want {
			t.Fatalf("%s category %q expected %q", path, got, want)
		}
	}
	assert("/api/voice", "voice")
	assert("/api/livekit-token", "livekit_token")
	assert("/api/presence-heartbeat", "presence")
	assert("/api/presence", "presence")
	g := newResourceGuard()
	now := time.Now()
	for i := 0; i < 12; i++ {
		if !g.allow("user", "livekit_token", now) {
			t.Fatalf("token cap premature at %d", i)
		}
	}
	if g.allow("user", "livekit_token", now) {
		t.Fatal("media token burst not throttled")
	}
	if !g.allow("user", "livekit_token", now.Add(31*time.Second)) {
		t.Fatal("rate window did not recover")
	}
	if !g.allow("other", "livekit_token", now) {
		t.Fatal("one user throttled another")
	}
	for i := 0; i < 120; i++ {
		if !g.allow("user", "voice", now) {
			t.Fatalf("voice ICE burst prematurely blocked at %d", i)
		}
	}
	if g.allow("user", "voice", now) {
		t.Fatal("sustained voice flood not throttled")
	}
	for _, path := range []string{"/api/messages", "/api/channel-messages"} {
		if strings.TrimSpace(expensivePostCategory(path)) != "message" {
			t.Fatal("message category lost")
		}
	}
}

// Local JSON-store stress test only. This does not simulate real WebRTC media or
// predict performance under PostgreSQL/VPS conditions.
func TestAuditLocalConcurrentTextProfiles(t *testing.T) {
	if testing.Short() {
		t.Skip("local message write stress test")
	}
	for _, clients := range []int{2, 5, 10, 20, 30, 50} {
		t.Run(fmt.Sprintf("users_%d", clients), func(t *testing.T) {
			s := newServer(filepath.Join(t.TempDir(), "messages.json"))
			s.db.Users = make(map[string]User, clients)
			s.db.Communities = []Community{{ID: "load", Name: "Load", Owner: "user00", Channels: []string{"geral"}, ChannelMeta: map[string]ChannelMeta{"geral": {Type: "text"}}}}
			for i := 0; i < clients; i++ {
				u := fmt.Sprintf("user%02d", i)
				s.db.Users[u] = User{Name: u, DisplayName: u, AccountID: u}
				s.sessions[u+"-token"] = u
				s.db.Communities[0].Members = append(s.db.Communities[0].Members, u)
			}
			handler := s.routes()
			var wg sync.WaitGroup
			problems := make(chan string, clients)
			start := time.Now()
			for i := 0; i < clients; i++ {
				wg.Add(1)
				go func(i int) {
					defer wg.Done()
					user := fmt.Sprintf("user%02d", i)
					req := httptest.NewRequest(http.MethodPost, "/api/channel-messages?community=load&channel=geral", strings.NewReader(fmt.Sprintf(`{"text":"audit message %d"}`, i)))
					req.Header.Set("Authorization", "Bearer "+user+"-token")
					rec := httptest.NewRecorder()
					handler.ServeHTTP(rec, req)
					if rec.Code != http.StatusCreated {
						problems <- fmt.Sprintf("%s HTTP %d: %s", user, rec.Code, rec.Body.String())
					}
				}(i)
			}
			wg.Wait()
			close(problems)
			for p := range problems {
				t.Error(p)
			}
			if got := len(s.db.Messages); got != clients {
				t.Fatalf("committed messages %d expected %d", got, clients)
			}
			t.Logf("Local JSON store, %d concurrent text writes: %s elapsed (not a media or production benchmark)", clients, time.Since(start))
		})
	}
}
