package main

import (
	"bytes"
	"encoding/base64"
	"encoding/json"
	"io"
	"mime/multipart"
	"net/http"
	"net/http/httptest"
	"strings"
	"testing"
	"time"
)

func TestAuditRound4MultiAccountHTTPIsolation(t *testing.T) {
	t.Setenv("EXPLICIT_TEST_SKIP_ANTIBOT", "0")
	s := auditFixture(t)
	now := time.Now().UTC()
	for name, u := range s.db.Users {
		u.Salt = "fixture-salt-" + name
		u.Hash = secureHash(u.Salt, "fixture-password-123")
		u.TermsVersion = currentTermsVersion
		u.TermsAcceptedAt = &now
		s.db.Users[name] = u
	}
	s.db.Communities[0].ChannelMeta["private"] = ChannelMeta{Type: "text", RolePermissions: map[string]map[string]bool{"everyone": {"VIEW_CHANNEL": false}}, MemberPermissions: map[string]map[string]bool{"member": {"VIEW_CHANNEL": true}}}
	s.db.Communities = append(s.db.Communities, Community{ID: "other", Name: "Other", Owner: "outsider", Members: []string{"outsider"}, Channels: []string{"geral"}, ChannelMeta: map[string]ChannelMeta{"geral": {Type: "text"}}})
	s.db.Friends = []FriendRequest{{From: "owner", To: "member", Status: "accepted"}, {From: "owner", To: "third", Status: "accepted"}}
	transport := http.DefaultTransport.(*http.Transport).Clone()
	defer transport.CloseIdleConnections()
	client := &http.Client{Transport: transport, Timeout: 5 * time.Second}
	ts := httptest.NewServer(s.routes())
	defer ts.Close()
	tokens := map[string]string{}
	request := func(who, method, path, kind string, raw []byte) (int, []byte) {
		t.Helper()
		r, err := http.NewRequest(method, ts.URL+path, bytes.NewReader(raw))
		if err != nil {
			t.Fatal(err)
		}
		if who != "" {
			r.Header.Set("Authorization", "Bearer "+tokens[who])
		}
		if kind != "" {
			r.Header.Set("Content-Type", kind)
		}
		response, err := client.Do(r)
		if err != nil {
			t.Fatal(err)
		}
		defer response.Body.Close()
		data, err := io.ReadAll(response.Body)
		if err != nil {
			t.Fatal(err)
		}
		return response.StatusCode, data
	}
	post := func(who, path string, payload any) (int, []byte) {
		t.Helper()
		raw, err := json.Marshal(payload)
		if err != nil {
			t.Fatal(err)
		}
		return request(who, "POST", path, "application/json", raw)
	}
	challenge := func(id string) {
		s.captchaMu.Lock()
		if s.captchas == nil {
			s.captchas = map[string]explicitCaptcha{}
		}
		s.captchas[id] = explicitCaptcha{AnswerHash: registrationHash(id, "ABCDEF"), Expires: time.Now().Add(time.Minute)}
		s.captchaMu.Unlock()
	}
	challenge("bad-password")
	if code, _ := post("", "/api/login", map[string]string{"name": "owner", "password": "wrong-password", "captcha_id": "bad-password", "captcha_answer": "ABCDEF"}); code != 401 {
		t.Fatalf("wrong password accepted: %d", code)
	}
	for _, name := range []string{"owner", "member", "third", "outsider"} {
		challenge(name)
		code, data := post("", "/api/login", map[string]string{"name": name, "password": "fixture-password-123", "captcha_id": name, "captcha_answer": "ABCDEF"})
		var result struct {
			Token string `json:"token"`
		}
		if code != 200 || json.Unmarshal(data, &result) != nil || result.Token == "" {
			t.Fatalf("login failed for %s status=%d", name, code)
		}
		tokens[name] = result.Token
	}
	if code, _ := post("owner", "/api/channel-messages?community=audit-community&channel=private", map[string]string{"text": "synthetic-private-channel"}); code != 201 {
		t.Fatalf("owner send failed: %d", code)
	}
	if code, data := request("member", "GET", "/api/channel-messages?community=audit-community&channel=private", "", nil); code != 200 || !bytes.Contains(data, []byte("synthetic-private-channel")) {
		t.Fatalf("authorized private channel read failed: %d", code)
	}
	for _, who := range []string{"third", "outsider"} {
		if code, _ := request(who, "GET", "/api/channel-messages?community=audit-community&channel=private", "", nil); code != 403 {
			t.Fatalf("private channel leaked to %s: %d", who, code)
		}
	}
	code, data := post("owner", "/api/direct", map[string]any{"action": "create_group", "name": "HTTP fixture group", "targets": []string{"member", "third"}})
	var chat DirectChat
	if code != 201 || json.Unmarshal(data, &chat) != nil || len(chat.ID) != 20 {
		t.Fatalf("group create failed: %d", code)
	}
	defer func() {
		directCalls.Lock()
		delete(directCalls.Rooms, chat.ID)
		delete(directCalls.MediaRooms, chat.ID)
		delete(directCalls.AloneSince, chat.ID)
		delete(directCalls.Expired, chat.ID)
		directCalls.Unlock()
	}()
	if code, _ := post("owner", "/api/direct", map[string]string{"action": "send", "id": chat.ID, "text": "synthetic-private-dm"}); code != 200 {
		t.Fatal(code)
	}
	if code, data := request("member", "GET", "/api/direct?id="+chat.ID, "", nil); code != 200 || !bytes.Contains(data, []byte("synthetic-private-dm")) {
		t.Fatalf("DM delivery failed: %d", code)
	}
	if code, _ := request("outsider", "GET", "/api/direct?id="+chat.ID, "", nil); code != 404 {
		t.Fatalf("outsider DM access %d", code)
	}
	upload := func(who, name string, content []byte) (int, []byte) {
		t.Helper()
		var body bytes.Buffer
		form := multipart.NewWriter(&body)
		if err := form.WriteField("chat", chat.ID); err != nil {
			t.Fatal(err)
		}
		part, err := form.CreateFormFile("file", name)
		if err != nil {
			t.Fatal(err)
		}
		if _, err = part.Write(content); err != nil {
			t.Fatal(err)
		}
		if err = form.Close(); err != nil {
			t.Fatal(err)
		}
		return request(who, "POST", "/api/direct-file", form.FormDataContentType(), body.Bytes())
	}
	code, data = upload("owner", "fixture.txt", []byte("synthetic-file-content"))
	var attachment DirectMessage
	if code != 201 || json.Unmarshal(data, &attachment) != nil || attachment.File == "" {
		t.Fatalf("upload failed: %d", code)
	}
	for _, who := range []string{"member", "third"} {
		if code, data := request(who, "GET", "/api/direct-file?id="+attachment.File, "", nil); code != 200 || string(data) != "synthetic-file-content" {
			t.Fatalf("authorized download failed %s %d", who, code)
		}
	}
	if code, _ := request("outsider", "GET", "/api/direct-file?id="+attachment.File, "", nil); code != 403 {
		t.Fatalf("outsider file access: %d", code)
	}
	if code, _ := upload("outsider", "fixture.txt", []byte("no membership")); code != 404 {
		t.Fatalf("outsider upload: %d", code)
	}
	if code, _ := upload("owner", "fake.png", []byte("this is not a png")); code != 415 {
		t.Fatalf("disguised file accepted: %d", code)
	}
	if code, _ := upload("owner", "huge.txt", bytes.Repeat([]byte("x"), maxDirectFile+1)); code != 413 {
		t.Fatalf("oversized upload accepted: %d", code)
	}
	status := 200
	var calls []map[string]any
	auditMedia(t, s, &status, &calls)
	for _, who := range []string{"owner", "third"} {
		code, data := post(who, "/api/direct-call", map[string]string{"action": "join", "id": chat.ID})
		var result struct {
			Token string `json:"token"`
		}
		if code != 200 || json.Unmarshal(data, &result) != nil {
			t.Fatalf("call join failed: %d", code)
		}
		parts := strings.Split(result.Token, ".")
		if len(parts) != 3 {
			t.Fatal("malformed call token")
		}
		raw, err := base64.RawURLEncoding.DecodeString(parts[1])
		if err != nil {
			t.Fatal(err)
		}
		var claims liveKitClaims
		if json.Unmarshal(raw, &claims) != nil || claims.Subject != who || !strings.HasPrefix(claims.Video.Room, "dm:"+chat.ID+":") {
			t.Fatal("call token not scoped to member/room")
		}
	}
	if code, _ := post("outsider", "/api/direct-call", map[string]string{"action": "join", "id": chat.ID}); code != 404 {
		t.Fatalf("outsider call grant %d", code)
	}
	if code, _ := post("third", "/api/direct", map[string]string{"action": "leave_group", "id": chat.ID}); code != 200 {
		t.Fatalf("group leave %d", code)
	}
	if len(calls) != 1 || calls[0]["identity"] != "third" || !strings.HasPrefix(calls[0]["room"].(string), "dm:"+chat.ID+":") {
		t.Fatal("group leave did not revoke actual media room")
	}
	if code, _ := request("third", "GET", "/api/direct-file?id="+attachment.File, "", nil); code != 403 {
		t.Fatalf("former member file access %d", code)
	}
	if code, _ := request("third", "GET", "/api/direct?id="+chat.ID, "", nil); code != 404 {
		t.Fatalf("former member DM access %d", code)
	}
	if code, _ := post("third", "/api/direct-call", map[string]string{"action": "join", "id": chat.ID}); code != 404 {
		t.Fatalf("former member call grant %d", code)
	}
	restored := newServer(s.file)
	found := false
	for _, c := range restored.db.DirectChats {
		if c.ID == chat.ID {
			found = true
			if contains(c.Users, "third") || len(c.Messages) != 2 {
				t.Fatal("restart did not preserve membership/messages")
			}
		}
	}
	if !found {
		t.Fatal("group not persisted")
	}
	if code, _ := post("member", "/api/logout", map[string]bool{}); code != 200 {
		t.Fatal(code)
	}
	if code, _ := request("member", "GET", "/api/direct?id="+chat.ID, "", nil); code != 401 {
		t.Fatalf("revoked login reused: %d", code)
	}
	t.Log("HTTP loopback: four independent logins; private channel/DM/file/call isolation; invalid uploads; group leave revocation; persisted restart; logout passed. SFU transport mocked; no real media.")
}
