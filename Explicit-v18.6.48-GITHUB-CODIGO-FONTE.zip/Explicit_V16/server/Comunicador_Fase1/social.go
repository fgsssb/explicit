package main

import (
	"net/http"
	"sort"
	"strings"
	"time"
	"unicode/utf8"
)

type FriendRequest struct {
	ID      string    `json:"id"`
	From    string    `json:"from"`
	To      string    `json:"to"`
	Status  string    `json:"status"`
	Created time.Time `json:"created"`
}
type DirectMessage struct {
	ID             string     `json:"id"`
	Author         string     `json:"author"`
	Text           string     `json:"text"`
	File           string     `json:"file,omitempty"`
	FileName       string     `json:"file_name,omitempty"`
	StaffNotice    bool       `json:"staff_notice,omitempty"`
	StaffRecipient string     `json:"staff_recipient,omitempty"`
	Sticker        string     `json:"sticker,omitempty"`
	EditedAt       *time.Time `json:"edited_at,omitempty"`
	Pinned         bool       `json:"pinned,omitempty"`
	Deleted        bool       `json:"deleted,omitempty"`
	Time           time.Time  `json:"time"`
}
type DirectChat struct {
	Name     string          `json:"name,omitempty"`
	Creator  string          `json:"creator,omitempty"`
	ID       string          `json:"id"`
	Users    []string        `json:"users"`
	Visible  map[string]bool `json:"visible"`
	Messages []DirectMessage `json:"messages"`
}

func (s *Server) areFriends(a, b string) bool {
	for _, f := range s.db.Friends {
		if f.Status == "accepted" && ((f.From == a && f.To == b) || (f.From == b && f.To == a)) {
			return true
		}
	}
	return false
}
func (s *Server) socialAPI(w http.ResponseWriter, r *http.Request) {
	user, err := s.auth(r)
	if err != nil {
		http.Error(w, "unauthorized", 401)
		return
	}
	s.mu.Lock()
	defer s.mu.Unlock()
	if r.Method == "GET" {
		type friendView struct {
			Username       string `json:"username"`
			DisplayName    string `json:"display_name"`
			Status         string `json:"status"`
			VoiceChannel   string `json:"voice_channel,omitempty"`
			VoiceCommunity string `json:"voice_community,omitempty"`
			SystemRole     string `json:"system_role"`
			Beta           bool   `json:"beta"`
			ExplicitPlus   bool   `json:"explicit_plus"`
		}
		friends := []friendView{}
		incoming := []FriendRequest{}
		outgoing := []FriendRequest{}
		for _, f := range s.db.Friends {
			if f.Status == "accepted" && (f.From == user || f.To == user) {
				other := f.From
				if other == user {
					other = f.To
				}
				u := s.db.Users[other]
				connected := len(online.entries[other]) > 0
				status := publicStatus(u, connected)
				member := friendView{Username: other, DisplayName: u.DisplayName, Status: status, SystemRole: systemRole(u), Beta: u.Beta, ExplicitPlus: u.ExplicitPlus}
				if status != "offline" {
					voice.mu.Lock()
					room := ""
					if v := voice.members[other]; v != nil && time.Since(v.Seen) < 45*time.Second {
						room = v.Room
					}
					voice.mu.Unlock()
					for _, community := range s.db.Communities {
						if !contains(community.Members, user) || !contains(community.Members, other) {
							continue
						}
						prefix := community.ID + ":"
						if !strings.HasPrefix(room, prefix) {
							continue
						}
						ch := strings.TrimPrefix(room, prefix)
						if contains(community.Channels, ch) && s.channelPermission(community, user, ch, "VIEW_CHANNEL") && s.channelPermission(community, user, ch, "CONNECT_VOICE") {
							member.VoiceChannel = ch
							member.VoiceCommunity = community.ID
							break
						}
					}
				}
				friends = append(friends, member)
			}
			if f.Status == "pending" {
				if f.To == user {
					incoming = append(incoming, f)
				}
				if f.From == user {
					outgoing = append(outgoing, f)
				}
			}
		}
		reply(w, 200, map[string]any{"friends": friends, "incoming": incoming, "outgoing": outgoing})
		return
	}
	if r.Method != "POST" {
		http.Error(w, "method", 405)
		return
	}
	var q struct {
		Action string `json:"action"`
		Target string `json:"target"`
		ID     string `json:"id"`
	}
	if parse(r, &q) != nil {
		http.Error(w, "invalid", 400)
		return
	}
	q.Target = strings.TrimSpace(q.Target)
	oldNotifications := append([]AppNotification(nil), s.db.Notifications...)
	oldReading := s.db.Users[user]
	oldFriends := append([]FriendRequest(nil), s.db.Friends...)
	switch q.Action {
	case "request":
		if q.Target == user {
			http.Error(w, "cannot add yourself", 400)
			return
		}
		if _, ok := s.db.Users[q.Target]; !ok {
			http.Error(w, "user not found", 404)
			return
		}
		if s.areFriends(user, q.Target) {
			http.Error(w, "already friends", 409)
			return
		}
		for _, f := range s.db.Friends {
			if f.Status == "pending" && ((f.From == user && f.To == q.Target) || (f.From == q.Target && f.To == user)) {
				http.Error(w, "request pending", 409)
				return
			}
		}
		s.db.Friends = append(s.db.Friends, FriendRequest{token()[:16], user, q.Target, "pending", time.Now().UTC()})
		s.enqueueNotificationLocked(q.Target, "friend", user, "", "", "Solicitação de amizade")
	case "accept", "decline":
		found := false
		for i := range s.db.Friends {
			f := &s.db.Friends[i]
			if f.ID == q.ID && f.To == user && f.Status == "pending" {
				if q.Action == "accept" {
					s.enqueueNotificationLocked(f.From, "friend", user, "", "", "Aceitou seu pedido de amizade")
					f.Status = "accepted"
				} else {
					f.Status = "declined"
				}
				found = true
				break
			}
		}
		if found {
			u := s.db.Users[user]
			u.OtherNoticesRead = time.Now().UTC().UnixNano()
			s.db.Users[user] = u
		}
		if !found {
			http.Error(w, "request not found", 404)
			return
		}
	case "remove":
		found := false
		for i := range s.db.Friends {
			f := &s.db.Friends[i]
			if f.Status == "accepted" && ((f.From == user && f.To == q.Target) || (f.To == user && f.From == q.Target)) {
				f.Status = "removed"
				found = true
			}
		}
		if !found {
			http.Error(w, "friend not found", 404)
			return
		}
	default:
		http.Error(w, "invalid action", 400)
		return
	}
	if err := s.save(); err != nil {
		s.db.Notifications = oldNotifications
		s.db.Friends = oldFriends
		s.db.Users[user] = oldReading
		http.Error(w, "storage failure", 500)
		return
	}
	reply(w, 200, map[string]bool{"ok": true})
}
func (s *Server) directAPI(w http.ResponseWriter, r *http.Request) {
	user, err := s.auth(r)
	if err != nil {
		http.Error(w, "unauthorized", 401)
		return
	}
	s.mu.Lock()
	locked := true
	defer func() {
		if locked {
			s.mu.Unlock()
		}
	}()
	if r.Method == "GET" {
		id := r.URL.Query().Get("id")
		if id == "" {
			out := []map[string]any{}
			for _, c := range s.db.DirectChats {
				if contains(c.Users, user) && c.Visible[user] {
					if len(c.Users) < 2 {
						continue
					}
					isGroup := len(c.Users) > 2 || c.Name != ""
					other := c.Users[0]
					if other == user {
						other = c.Users[1]
					}
					notifyKey := other
					if isGroup {
						notifyKey = "dm:" + c.ID
					}
					unread := 0
					if userNotifyPrefs(s.db.Users[user]).Direct {
						for _, notice := range s.db.Notifications {
							if notice.User == user && notice.Kind == "direct" && ((isGroup && notice.Channel == notifyKey) || (!isGroup && notice.Channel == "" && notice.Author == other)) && notice.Community == "" && notice.At.UnixNano() > s.db.Users[user].DirectNoticesRead[notifyKey] {
								unread++
							}
						}
					}
					if unread > 99 {
						unread = 99
					}
					title := c.Name
					if isGroup && title == "" {
						title = "Grupo privado"
					}
					if !isGroup {
						title = s.db.Users[other].DisplayName
					}
					out = append(out, map[string]any{"id": c.ID, "other": other, "users": c.Users, "group": isGroup, "name": title, "creator": c.Creator, "display_name": title, "system_role": systemRole(s.db.Users[other]), "beta": !isGroup && s.db.Users[other].Beta, "explicit_plus": !isGroup && explicitPlusActive(s.db.Users[other]), "unread": unread, "call_active": directCallPresent(c.ID)})
				}
			}
			reply(w, 200, out)
			return
		}
		for _, c := range s.db.DirectChats {
			if c.ID == id && contains(c.Users, user) {
				copyChat := c
				copyChat.Messages = filterDMs(c.Messages, user)
				reply(w, 200, copyChat)
				return
			}
		}
		http.Error(w, "not found", 404)
		return
	}
	if r.Method != "POST" {
		http.Error(w, "method", 405)
		return
	}
	var q struct {
		Action    string   `json:"action"`
		Target    string   `json:"target"`
		ID        string   `json:"id"`
		Text      string   `json:"text"`
		Targets   []string `json:"targets"`
		Name      string   `json:"name"`
		MessageID string   `json:"message_id"`
		Sticker   string   `json:"sticker"`
	}
	if parse(r, &q) != nil {
		http.Error(w, "invalid", 400)
		return
	}
	oldNotifications := append([]AppNotification(nil), s.db.Notifications...)
	switch q.Action {
	case "open":
		if !s.areFriends(user, q.Target) {
			http.Error(w, "friendship required", 403)
			return
		}
		for i := range s.db.DirectChats {
			c := &s.db.DirectChats[i]
			if len(c.Users) == 2 && c.Name == "" && contains(c.Users, user) && contains(c.Users, q.Target) {
				if c.Visible == nil {
					c.Visible = map[string]bool{}
				}
				// Reopening a visible DM is read-only: do not rewrite the
				// full PostgreSQL/JSON snapshot for a no-op.
				if !c.Visible[user] {
					c.Visible[user] = true
					if s.save() != nil {
						c.Visible[user] = false
						http.Error(w, "storage failure", 500)
						return
					}
				}
				copyChat := *c
				copyChat.Messages = filterDMs(c.Messages, user)
				reply(w, 200, copyChat)
				return
			}
		}
		c := DirectChat{ID: token()[:20], Users: []string{user, q.Target}, Visible: map[string]bool{user: true, q.Target: true}, Messages: []DirectMessage{}}
		s.db.DirectChats = append(s.db.DirectChats, c)
		if s.save() != nil {
			http.Error(w, "storage failure", 500)
			return
		}
		reply(w, 201, c)
		return
	case "create_group":
		if s.resources != nil && !s.resources.allow(user, "direct_group", time.Now()) {
			w.Header().Set("Retry-After", "60")
			http.Error(w, "Too many group creations. Try again shortly.", 429)
			return
		}
		// New group is a separate chat. Existing 1:1 messages never leak into it.
		users := []string{user}
		seen := map[string]bool{user: true}
		for _, target := range q.Targets {
			if target == "" || seen[target] {
				http.Error(w, "duplicate or invalid member", 400)
				return
			}
			if len(target) > 64 || !s.areFriends(user, target) {
				http.Error(w, "friendship required", 403)
				return
			}
			seen[target] = true
			users = append(users, target)
		}
		if len(users) < 3 || len(users) > 8 {
			http.Error(w, "group must have 3 to 8 members", 400)
			return
		}
		name := strings.TrimSpace(q.Name)
		if utf8.RuneCountInString(name) > 48 {
			http.Error(w, "group name too long", 400)
			return
		}
		if name == "" {
			name = string([]rune(strings.Join(users[1:], ", "))[:min(len([]rune(strings.Join(users[1:], ", "))), 48)])
		}
		visible := map[string]bool{}
		for _, u := range users {
			visible[u] = true
		}
		chat := DirectChat{ID: token()[:20], Name: name, Creator: user, Users: users, Visible: visible, Messages: []DirectMessage{}}
		s.db.DirectChats = append(s.db.DirectChats, chat)
		if s.save() != nil {
			s.db.DirectChats = s.db.DirectChats[:len(s.db.DirectChats)-1]
			http.Error(w, "storage failure", 500)
			return
		}
		reply(w, 201, chat)
		return
	case "add_members", "rename_group", "leave_group":
		for i := range s.db.DirectChats {
			c := &s.db.DirectChats[i]
			if c.ID != q.ID || !contains(c.Users, user) || (c.Name == "" && len(c.Users) == 2) {
				continue
			}
			original := *c
			original.Users = append([]string(nil), c.Users...)
			c.Visible = copyDirectVisibility(c.Visible)
			if q.Action == "rename_group" {
				title := strings.TrimSpace(q.Name)
				if utf8.RuneCountInString(title) < 1 || utf8.RuneCountInString(title) > 48 {
					http.Error(w, "invalid name or permissions", 403)
					return
				}
				c.Name = title
			} else if q.Action == "leave_group" {
				members := make([]string, 0, len(c.Users)-1)
				for _, u := range c.Users {
					if u != user {
						members = append(members, u)
					}
				}
				c.Users = members
				delete(c.Visible, user)
				if c.Creator == user && len(members) > 0 {
					c.Creator = members[0]
				}

			} else {
				if len(q.Targets) == 0 || len(c.Users)+len(q.Targets) > 8 {
					http.Error(w, "group full", 400)
					return
				}
				seen := map[string]bool{}
				for _, target := range q.Targets {
					if seen[target] || contains(c.Users, target) || len(target) > 64 || !s.areFriends(user, target) {
						http.Error(w, "invalid members or friendship required", 403)
						return
					}
					seen[target] = true
				}
				autoName := strings.Join(c.Users[1:], ", ")
				wasAutomatic := c.Name == autoName || c.Name == string([]rune(autoName)[:min(len([]rune(autoName)), 48)])
				for _, target := range q.Targets {
					c.Users = append(c.Users, target)
					c.Visible[target] = true
				}
				if wasAutomatic {
					updated := []rune(strings.Join(c.Users[1:], ", "))
					c.Name = string(updated[:min(len(updated), 48)])
				}
			}
			if s.save() != nil {
				*c = original
				http.Error(w, "storage failure", 500)
				return
			}
			if q.Action == "leave_group" {
				directCalls.Lock()
				if roomMembers := directCalls.Rooms[c.ID]; roomMembers != nil {
					delete(roomMembers, user)
				}
				mediaRoom := directCalls.MediaRooms[c.ID]
				if len(directCalls.Rooms[c.ID]) == 1 {
					directCalls.AloneSince[c.ID] = time.Now()
				}
				if len(directCalls.Rooms[c.ID]) == 0 {
					delete(directCalls.Rooms, c.ID)
					delete(directCalls.MediaRooms, c.ID)
					delete(directCalls.AloneSince, c.ID)
				}
				directCalls.Unlock()
				result := map[string]any{"id": c.ID, "name": c.Name, "users": append([]string(nil), c.Users...), "creator": c.Creator}
				s.mu.Unlock()
				locked = false
				if mediaRoom != "" {
					if err := livekitRoomAction(mediaRoom, user, true); err != nil {
						reply(w, 502, map[string]any{"error": "Saída do grupo salva, mas a desconexão de mídia falhou", "membership_removed": true})
						return
					}
				}
				reply(w, 200, result)
				return
			}
			reply(w, 200, map[string]any{"id": c.ID, "name": c.Name, "users": c.Users, "creator": c.Creator})
			return
		}
		http.Error(w, "group not found", 404)
		return
	case "edit_message", "delete_message", "pin_message", "unpin_message":
		for ci := range s.db.DirectChats {
			c := &s.db.DirectChats[ci]
			if c.ID != q.ID || !contains(c.Users, user) {
				continue
			}
			for mi := range c.Messages {
				m := &c.Messages[mi]
				if m.ID != q.MessageID || m.StaffNotice {
					continue
				}
				own := m.Author == user
				if (q.Action == "edit_message" || q.Action == "delete_message") && !own {
					http.Error(w, "forbidden", 403)
					return
				}
				if (q.Action == "pin_message" || q.Action == "unpin_message") && !contains(c.Users, user) {
					http.Error(w, "forbidden", 403)
					return
				}
				before := *m
				switch q.Action {
				case "edit_message":
					text := strings.TrimSpace(q.Text)
					if m.Sticker != "" || m.File != "" || len(text) == 0 || len(text) > 2000 || abusiveMessageText(text) {
						http.Error(w, "invalid message", 400)
						return
					}
					m.Text = text
					now := time.Now().UTC()
					m.EditedAt = &now
				case "delete_message":
					m.Deleted = true
					m.Text = ""
					m.File = ""
					m.FileName = ""
					m.Sticker = ""
					m.Pinned = false
				case "pin_message":
					m.Pinned = true
				case "unpin_message":
					m.Pinned = false
				}
				if err := s.save(); err != nil {
					*m = before
					http.Error(w, "storage failure", 500)
					return
				}
				reply(w, 200, map[string]bool{"ok": true})
				return
			}
			http.Error(w, "message not found", 404)
			return
		}
		http.Error(w, "chat not found", 404)
		return
	case "send_sticker":
		for ci := range s.db.DirectChats {
			c := &s.db.DirectChats[ci]
			if c.ID != q.ID || !contains(c.Users, user) {
				continue
			}
			original := *c
			c.Visible = copyDirectVisibility(c.Visible)
			if len(c.Users) < 2 {
				http.Error(w, "invalid conversation", 400)
				return
			}
			if len(c.Users) == 2 && c.Name == "" {
				other := c.Users[0]
				if other == user {
					other = c.Users[1]
				}
				if !s.areFriends(user, other) {
					http.Error(w, "friendship required", 403)
					return
				}
			}
			if !s.maySendStickersLocked(user) || !stickerIDPattern.MatchString(q.Sticker) || !s.stickerReadableLocked(user, q.Sticker) {
				http.Error(w, "sticker forbidden", 403)
				return
			}
			m := DirectMessage{ID: token()[:16], Author: user, Sticker: q.Sticker, Time: time.Now().UTC()}
			c.Messages = append(c.Messages, m)
			previous := append([]AppNotification(nil), s.db.Notifications...)
			for _, target := range c.Users {
				if target != user {
					s.enqueueNotificationLocked(target, "direct", user, "", "dm:"+c.ID, "Figurinha enviada")
					c.Visible[target] = true
				}
			}
			if err := s.save(); err != nil {
				*c = original
				s.db.Notifications = previous
				http.Error(w, "storage failure", 500)
				return
			}
			reply(w, 201, m)
			return
		}
		http.Error(w, "chat not found", 404)
		return
	case "hide", "send":
		for i := range s.db.DirectChats {
			c := &s.db.DirectChats[i]
			if c.ID != q.ID || !contains(c.Users, user) {
				continue
			}
			original := *c
			c.Visible = copyDirectVisibility(c.Visible)
			if q.Action == "hide" {
				c.Visible[user] = false
			} else {
				if len(c.Users) < 2 {
					http.Error(w, "invalid conversation", 400)
					return
				}
				isGroup := len(c.Users) > 2 || c.Name != ""
				other := c.Users[0]
				if other == user {
					other = c.Users[1]
				}
				if !isGroup && !s.areFriends(user, other) {
					http.Error(w, "friendship required", 403)
					return
				}
				q.Text = strings.TrimSpace(q.Text)
				if len(q.Text) == 0 || len(q.Text) > 2000 {
					http.Error(w, "invalid text", 400)
					return
				}
				if abusiveMessageText(q.Text) || s.resources.excessiveRepeat(user, q.Text, time.Now()) {
					http.Error(w, "message flood rejected", http.StatusTooManyRequests)
					return
				}
				c.Messages = append(c.Messages, DirectMessage{ID: token()[:16], Author: user, Text: q.Text, Time: time.Now().UTC()})
				for _, target := range c.Users {
					if target == user {
						continue
					}
					channel := ""
					if isGroup {
						channel = "dm:" + c.ID
					}
					s.enqueueNotificationLocked(target, "direct", user, "", channel, q.Text)
					c.Visible[target] = true
				}
			}
			if s.save() != nil {
				*c = original
				s.db.Notifications = oldNotifications
				http.Error(w, "storage failure", 500)
				return
			}
			copyChat := *c
			copyChat.Messages = filterDMs(c.Messages, user)
			reply(w, 200, copyChat)
			return
		}
		http.Error(w, "not found", 404)
		return
	}
	http.Error(w, "invalid action", 400)
}
func (s *Server) messageActions(w http.ResponseWriter, r *http.Request) {
	user, err := s.auth(r)
	if err != nil {
		http.Error(w, "unauthorized", 401)
		return
	}
	if r.Method != "POST" {
		http.Error(w, "method", 405)
		return
	}
	var q struct {
		Community string `json:"community"`
		Channel   string `json:"channel"`
		ID        string `json:"id"`
		Action    string `json:"action"`
		Text      string `json:"text"`
	}
	if parse(r, &q) != nil {
		http.Error(w, "invalid", 400)
		return
	}
	s.mu.Lock()
	defer s.mu.Unlock()
	var community *Community
	for i := range s.db.Communities {
		c := &s.db.Communities[i]
		if c.ID == q.Community && contains(c.Channels, q.Channel) && c.channelType(q.Channel) == "text" && s.activeSanction(*c, user, q.Channel) == nil && s.channelPermission(*c, user, q.Channel, "VIEW_CHANNEL") {
			community = c
			break
		}
	}
	if community == nil {
		http.Error(w, "forbidden", 403)
		return
	}
	for i := range s.db.Messages {
		m := &s.db.Messages[i]
		if m.ID != q.ID || m.Channel != q.Community+":"+q.Channel || m.Deleted {
			continue
		}
		own := m.Author == user
		perm := ""
		switch q.Action {
		case "delete":
			if own {
				perm = "DELETE_OWN_MESSAGES"
			} else {
				perm = "DELETE_ANY_MESSAGES"
			}
		case "edit":
			if own {
				perm = "EDIT_OWN_MESSAGES"
			} else {
				perm = "EDIT_ANY_MESSAGES"
			}
		case "pin", "unpin":
			perm = "PIN_MESSAGES"
		default:
			http.Error(w, "invalid action", 400)
			return
		}
		if !s.channelPermission(*community, user, q.Channel, perm) {
			http.Error(w, "forbidden", 403)
			return
		}
		switch q.Action {
		case "delete":
			m.Deleted = true
		case "edit":
			q.Text = strings.TrimSpace(q.Text)
			if q.Text == "" || len(q.Text) > 2000 {
				http.Error(w, "invalid text", 400)
				return
			}
			m.Text = q.Text
			now := time.Now().UTC()
			m.EditedAt = &now
			m.EditedBy = user
		case "pin":
			m.Pinned = true
		case "unpin":
			m.Pinned = false
		}
		if s.isSuperadmin(user) {
			s.staffAuditLocked(user, "message_"+q.Action, m.ID, q.Community+"/"+q.Channel)
		}
		if s.save() != nil {
			http.Error(w, "storage failure", 500)
			return
		}
		reply(w, 200, m)
		return
	}
	http.Error(w, "message not found", 404)
}
func (s *Server) channelSearch(w http.ResponseWriter, r *http.Request) {
	user, err := s.auth(r)
	if err != nil {
		http.Error(w, "unauthorized", 401)
		return
	}
	if r.Method != "GET" {
		http.Error(w, "method", 405)
		return
	}
	id, ch, q := r.URL.Query().Get("community"), r.URL.Query().Get("channel"), strings.TrimSpace(r.URL.Query().Get("q"))
	if len(q) < 2 || len(q) > 120 {
		http.Error(w, "invalid query", 400)
		return
	}
	s.mu.Lock()
	defer s.mu.Unlock()
	allowed := false
	for _, c := range s.db.Communities {
		if c.ID == id && contains(c.Channels, ch) && c.channelType(ch) == "text" && s.activeSanction(c, user, ch) == nil && s.channelPermission(c, user, ch, "VIEW_CHANNEL") {
			allowed = true
		}
	}
	if !allowed {
		http.Error(w, "forbidden", 403)
		return
	}
	out := []Message{}
	for _, m := range s.db.Messages {
		if !m.Deleted && m.Channel == id+":"+ch && strings.Contains(strings.ToLower(m.Text), strings.ToLower(q)) {
			out = append(out, m)
		}
	}
	sort.Slice(out, func(i, j int) bool { return out[i].Time.After(out[j].Time) })
	if len(out) > 50 {
		out = out[:50]
	}
	reply(w, 200, out)
}

func filterDMs(messages []DirectMessage, user string) []DirectMessage {
	out := make([]DirectMessage, 0, len(messages))
	for _, m := range messages {
		if !m.Deleted && (m.StaffRecipient == "" || m.StaffRecipient == user) {
			out = append(out, m)
		}
	}
	return out
}

// Copy before mutation so failed persistence can restore the original map.
func copyDirectVisibility(source map[string]bool) map[string]bool {
	result := make(map[string]bool, len(source))
	for user, visible := range source {
		result[user] = visible
	}
	return result
}
