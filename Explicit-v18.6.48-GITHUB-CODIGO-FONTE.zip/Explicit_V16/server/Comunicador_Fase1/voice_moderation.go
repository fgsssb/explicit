package main

import (
	"log/slog"
	"net/http"
	"strings"
	"time"
)

func (s *Server) voiceModeration(w http.ResponseWriter, r *http.Request) {
	actor, err := s.auth(r)
	if err != nil {
		reply(w, 401, map[string]string{"error": "Não autorizado"})
		return
	}
	if r.Method != "POST" {
		reply(w, 405, map[string]string{"error": "Método inválido"})
		return
	}
	var q struct {
		Community string `json:"community"`
		Target    string `json:"target"`
		Action    string `json:"action"`
		Channel   string `json:"channel"`
		Enabled   bool   `json:"enabled"`
	}
	if parse(r, &q) != nil {
		reply(w, 400, map[string]string{"error": "Dados inválidos"})
		return
	}
	if q.Action == "poke" {
		if actor == q.Target {
			reply(w, 403, map[string]string{"error": "Você não pode enviar poke para si."})
			return
		}
		voice.mu.Lock()
		source := ""
		if target := voice.members[q.Target]; target != nil && time.Since(target.Seen) < 45*time.Second {
			source = target.Room
		}
		actorRoom := ""
		if caller := voice.members[actor]; caller != nil && time.Since(caller.Seen) < 45*time.Second {
			actorRoom = caller.Room
		}
		voice.mu.Unlock()
		if source == "" || source != actorRoom || !strings.HasPrefix(source, q.Community+":") {
			reply(w, 403, map[string]string{"error": "Ambos precisam estar no mesmo canal de voz."})
			return
		}
		channel := strings.TrimPrefix(source, q.Community+":")
		s.mu.Lock()
		allowed := false
		for _, c := range s.db.Communities {
			if c.ID == q.Community && s.activeSanction(c, actor, channel) == nil && s.channelPermission(c, actor, channel, "POKE_MEMBERS") {
				allowed = true
				break
			}
		}
		s.mu.Unlock()
		if !allowed {
			reply(w, 403, map[string]string{"error": "Sem permissão para poke."})
			return
		}
		if s.resources != nil && !s.resources.allow(actor+":"+q.Target, "voice_poke", time.Now()) {
			w.Header().Set("Retry-After", "20")
			reply(w, 429, map[string]string{"error": "Aguarde antes de enviar outro poke."})
			return
		}
		voice.mu.Lock()
		// Both parties must still share the live room when the signal is queued.
		// An actor may disconnect after the first snapshot and before ACL evaluation.
		caller := voice.members[actor]
		if caller == nil || caller.Room != source || time.Since(caller.Seen) >= 45*time.Second {
			voice.mu.Unlock()
			reply(w, 403, map[string]string{"error": "Você saiu do canal de voz."})
			return
		}
		if target := voice.members[q.Target]; target != nil && target.Room == source && time.Since(target.Seen) < 45*time.Second {
			target.Queue = append(target.Queue, voiceSignal{ID: token()[:12], From: actor, Kind: "poke"})
			voice.mu.Unlock()
			reply(w, 200, map[string]bool{"ok": true})
			return
		}
		voice.mu.Unlock()
		reply(w, 404, map[string]string{"error": "Usuário não está mais conectado."})
		return
	}
	if actor == q.Target {
		reply(w, 403, map[string]string{"error": "Ação no próprio usuário não permitida"})
		return
	}
	perm := map[string]string{"mute": "MUTE_MEMBERS", "deafen": "DEAFEN_MEMBERS", "move": "MOVE_MEMBERS"}[q.Action]
	if perm == "" {
		reply(w, 400, map[string]string{"error": "Ação inválida"})
		return
	}
	mediaControlMu.Lock()
	defer mediaControlMu.Unlock()
	// Capture the target's actual voice channel without holding the voice mutex
	// while acquiring the community mutex (avoids lock-order inversions).
	voice.mu.Lock()
	sourceRoom := ""
	if current := voice.members[q.Target]; current != nil {
		sourceRoom = current.Room
	}
	voice.mu.Unlock()
	sourceChannel := strings.TrimPrefix(sourceRoom, q.Community+":")
	s.mu.Lock()
	var c *Community
	for i := range s.db.Communities {
		if s.db.Communities[i].ID == q.Community {
			c = &s.db.Communities[i]
			break
		}
	}
	if c == nil || !contains(c.Members, q.Target) || !strings.HasPrefix(sourceRoom, q.Community+":") || !s.channelPermission(*c, actor, sourceChannel, perm) || (q.Target == c.Owner && !s.isSuperadmin(actor)) || s.isSuperadmin(q.Target) || (c.Owner != actor && !s.isSuperadmin(actor) && s.maxPriority(*c, q.Target) >= s.maxPriority(*c, actor)) {
		s.mu.Unlock()
		reply(w, 403, map[string]string{"error": "Sem permissão ou hierarquia insuficiente"})
		return
	}
	if q.Action == "move" && (!contains(c.Channels, q.Channel) || c.channelType(q.Channel) != "voice" || !s.channelPermission(*c, q.Target, q.Channel, "VIEW_CHANNEL") || !s.channelPermission(*c, q.Target, q.Channel, "CONNECT_VOICE") || !s.channelPermission(*c, actor, q.Channel, "MOVE_MEMBERS")) {
		s.mu.Unlock()
		reply(w, 400, map[string]string{"error": "Canal de destino inválido"})
		return
	}
	limit := 0
	if q.Action == "move" {
		limit = c.ChannelMeta[q.Channel].Limit
	}
	// Community moderation survives transport leave/rejoin and server restarts.
	if q.Action == "mute" || q.Action == "deafen" {
		if s.db.VoiceRestrictions == nil {
			s.db.VoiceRestrictions = make(map[string]map[string]CommunityVoiceRestriction)
		}
		if s.db.VoiceRestrictions[q.Community] == nil {
			s.db.VoiceRestrictions[q.Community] = make(map[string]CommunityVoiceRestriction)
		}
		previous, existed := s.db.VoiceRestrictions[q.Community][q.Target]
		next := previous
		if q.Action == "mute" {
			next.Muted = q.Enabled
		} else {
			next.Deaf = q.Enabled
		}
		s.db.VoiceRestrictions[q.Community][q.Target] = next
		if err := s.save(); err != nil {
			if existed {
				s.db.VoiceRestrictions[q.Community][q.Target] = previous
			} else {
				delete(s.db.VoiceRestrictions[q.Community], q.Target)
			}
			s.mu.Unlock()
			reply(w, 500, map[string]string{"error": "Falha ao salvar a moderação"})
			return
		}
	}
	restriction := s.db.VoiceRestrictions[q.Community][q.Target]
	canSpeak := s.channelPermission(*c, q.Target, sourceChannel, "SPEAK") && !s.isStaffMuted(c.ID, sourceChannel, q.Target, "voice")
	canScreen := s.channelPermission(*c, q.Target, sourceChannel, "SCREEN_SHARE")
	s.mu.Unlock()
	voice.mu.Lock()
	locked := true
	defer func() {
		if locked {
			voice.mu.Unlock()
		}
	}()
	target := voice.members[q.Target]
	if target == nil || target.Room != sourceRoom || time.Since(target.Seen) > 45*time.Second {
		reply(w, 404, map[string]string{"error": "Usuário não conectado à voz"})
		return
	}
	switch q.Action {
	case "mute":
		target.AdminMuted = q.Enabled
		target.Muted = q.Enabled
	case "deafen":
		target.AdminDeaf = q.Enabled
		target.Deaf = q.Enabled
	case "move":
		dest := q.Community + ":" + q.Channel
		if target.Room == dest {
			reply(w, 200, map[string]bool{"ok": true})
			return
		}
		if target.Room != dest && limit > 0 {
			count := 0
			for _, v := range voice.members {
				if v.Room == dest {
					count++
				}
			}
			if count >= limit {
				reply(w, 409, map[string]string{"error": "Canal lotado"})
				return
			}
		}
		// Revoke the old transport; the client must join the authorized destination.
		target.MoveTo = dest
		target.Queue = append(target.Queue, voiceSignal{ID: token()[:12], From: actor, Kind: "admin_move", Data: q.Channel})
	}
	canSpeak = canSpeak && !restriction.Muted && !target.AdminMuted && !target.StaffGloballyMuted
	canSubscribe := !restriction.Deaf && !target.AdminDeaf
	voice.mu.Unlock()
	locked = false
	var mediaErr error
	if q.Action == "move" {
		mediaErr = livekitRoomAction(sourceRoom, q.Target, true)
	} else {
		mediaErr = livekitSetMediaPermission(sourceRoom, q.Target, false, canSpeak, canScreen, canSubscribe)
	}
	if mediaErr != nil {
		reply(w, 502, map[string]any{"error": "Estado de moderação atualizado, mas a aplicação na mídia falhou; tente novamente", "media_enforced": false})
		return
	}
	slog.Info("voice.moderation", "actor", actor, "target", q.Target, "action", q.Action, "enabled", q.Enabled, "channel", q.Channel)
	reply(w, 200, map[string]bool{"ok": true})
}
