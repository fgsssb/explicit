package main

import (
	"encoding/json"
	"net/http/httptest"
	"strings"
	"testing"
)

func TestDisplayNameAndHashMigration(t *testing.T) {
	t.Setenv("EXPLICIT_INITIAL_INVITE_KEY", "TEST-BOOTSTRAP")
	s := newServer(t.TempDir() + "/store.json")
	call := func(path, payload string) *httptest.ResponseRecorder {
		r := httptest.NewRequest("POST", path, strings.NewReader(payload))
		w := httptest.NewRecorder()
		s.routes().ServeHTTP(w, r)
		return w
	}
	if w := call("/api/register", `{"name":"demo","password":"password123"}`); w.Code != 400 {
		t.Fatalf("missing display name accepted: %d", w.Code)
	}
	if w := call("/api/register", `{"name":"demo","display_name":"Demo Público","password":"password123","invite_key":"TEST-BOOTSTRAP"}`); w.Code != 201 {
		t.Fatal(w.Body)
	}
	u := s.db.Users["demo"]
	if u.DisplayName != "Demo Público" || !strings.HasPrefix(u.Hash, "pbkdf2-sha256$") {
		t.Fatal("registration fields or hash incorrect")
	}
	if w := call("/api/login", `{"name":"demo","password":"password123"}`); w.Code != 200 {
		t.Fatal(w.Body)
	}
	// Simulate a legacy account; verify automatic migration without losing the display name.
	u.Hash = hash(u.Salt, "password123")
	s.db.Users["demo"] = u
	if w := call("/api/login", `{"name":"demo","password":"password123"}`); w.Code != 200 {
		t.Fatal(w.Body)
	}
	if !strings.HasPrefix(s.db.Users["demo"].Hash, "pbkdf2-sha256$") {
		t.Fatal("legacy hash not upgraded")
	}
	var response map[string]string
	_ = json.Unmarshal(call("/api/login", `{"name":"demo","password":"password123"}`).Body.Bytes(), &response)
	if response["display_name"] != "Demo Público" {
		t.Fatal("display name missing from login")
	}
}
