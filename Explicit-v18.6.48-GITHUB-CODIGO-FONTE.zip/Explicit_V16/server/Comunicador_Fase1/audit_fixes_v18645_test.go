package main

import (
	"encoding/base64"
	"encoding/json"
	"io"
	"net/http"
	"net/http/httptest"
	"runtime"
	"strings"
	"testing"
	"time"
)

type auditTransport func(*http.Request) (*http.Response, error)

func (f auditTransport) RoundTrip(r *http.Request) (*http.Response, error) { return f(r) }

func auditFixRequest(h http.HandlerFunc, session, body string) *httptest.ResponseRecorder {
	r := httptest.NewRequest("POST", "/api/test", strings.NewReader(body))
	r.Header.Set("Authorization", "Bearer "+session)
	w := httptest.NewRecorder()
	h(w, r)
	return w
}

func auditMedia(t *testing.T, s *Server, status *int, calls *[]map[string]any) {
	t.Helper()
	t.Setenv("LIVEKIT_WS_URL", "wss://media.example.test")
	t.Setenv("LIVEKIT_API_KEY", "test-explicit-api-key")
	t.Setenv("LIVEKIT_API_SECRET", strings.Repeat("s", 40))
	old := http.DefaultTransport
	http.DefaultTransport = auditTransport(func(r *http.Request) (*http.Response, error) {
		if !s.mu.TryLock() {
			t.Fatal("SFU HTTP while holding global store lock")
		}
		s.mu.Unlock()
		if !voice.mu.TryLock() {
			t.Fatal("SFU HTTP while holding voice lock")
		}
		voice.mu.Unlock()
		if !directCalls.TryLock() {
			t.Fatal("SFU HTTP while holding direct call lock")
		}
		directCalls.Unlock()
		var body map[string]any
		if err := json.NewDecoder(r.Body).Decode(&body); err != nil {
			t.Fatal(err)
		}
		body["method"] = r.URL.Path
		*calls = append(*calls, body)
		return &http.Response{StatusCode: *status, Status: http.StatusText(*status), Body: io.NopCloser(strings.NewReader(`{}`)), Header: make(http.Header)}, nil
	})
	t.Cleanup(func() { http.DefaultTransport = old })
}

func auditVoiceFixture(t *testing.T) *Server {
	t.Helper()
	s := newServer(t.TempDir() + "/db.json")
	for _, u := range []string{"owner", "guest", "other"} {
		s.db.Users[u] = User{Name: u}
		s.sessions[u] = u
	}
	s.db.Communities = []Community{{ID: "c", Owner: "owner", Members: []string{"owner", "guest", "other"}, Channels: []string{"voice", "dest"}, ChannelMeta: map[string]ChannelMeta{"voice": {Type: "voice"}, "dest": {Type: "voice"}}}}
	voice.mu.Lock()
	voice.members = map[string]*voiceMember{"guest": {User: "guest", Room: "c:voice", Seen: time.Now()}}
	voice.mu.Unlock()
	t.Cleanup(func() { voice.mu.Lock(); voice.members = map[string]*voiceMember{}; voice.mu.Unlock() })
	return s
}

func auditToken(t *testing.T, s *Server) liveKitGrant {
	t.Helper()
	w := auditFixRequest(s.liveKitToken, "guest", `{"community":"c","channel":"voice"}`)
	if w.Code != 200 {
		t.Fatalf("token: %d %s", w.Code, w.Body)
	}
	var response struct {
		Token string `json:"token"`
	}
	json.Unmarshal(w.Body.Bytes(), &response)
	payload, err := base64.RawURLEncoding.DecodeString(strings.Split(response.Token, ".")[1])
	if err != nil {
		t.Fatal(err)
	}
	var claims liveKitClaims
	if err = json.Unmarshal(payload, &claims); err != nil {
		t.Fatal(err)
	}
	return claims.Video
}

func TestAuditCommunityModerationEnforcesIndependentMediaGrants(t *testing.T) {
	s := auditVoiceFixture(t)
	status := 200
	var calls []map[string]any
	auditMedia(t, s, &status, &calls)
	apply := func(action string, enabled bool) {
		t.Helper()
		body, _ := json.Marshal(map[string]any{"community": "c", "target": "guest", "action": action, "enabled": enabled})
		w := auditFixRequest(s.voiceModeration, "owner", string(body))
		if w.Code != 200 {
			t.Fatalf("%s: %d %s", action, w.Code, w.Body)
		}
	}
	apply("mute", true)
	permission := calls[len(calls)-1]["permission"].(map[string]any)
	sources := permission["canPublishSources"].([]any)
	if len(sources) != 1 || sources[0] != "SCREEN_SHARE" || permission["canPublish"] != true {
		t.Fatalf("mute must preserve authorized screen sharing: %v", permission)
	}
	grant := auditToken(t, s)
	if len(grant.CanPublishSources) != 1 || grant.CanPublishSources[0] != "screen_share" {
		t.Fatalf("muted microphone granted: %+v", grant)
	}
	w := auditFixRequest(s.voiceAPI, "guest", `{"community":"c","channel":"voice","action":"join"}`)
	if w.Code != 200 {
		t.Fatal(w.Body)
	}
	if grant = auditToken(t, s); len(grant.CanPublishSources) != 1 || grant.CanPublishSources[0] != "screen_share" {
		t.Fatal("duplicate join erased mute")
	}
	apply("deafen", true)
	// Actual leave/rejoin and persisted storage must retain community restrictions.
	w = auditFixRequest(s.voiceAPI, "guest", `{"community":"c","channel":"voice","action":"leave"}`)
	if w.Code != 200 {
		t.Fatal(w.Body)
	}
	w = auditFixRequest(s.voiceAPI, "guest", `{"community":"c","channel":"voice","action":"join"}`)
	if w.Code != 200 {
		t.Fatal(w.Body)
	}
	persisted := newServer(s.file).db.VoiceRestrictions["c"]["guest"]
	if !persisted.Muted || !persisted.Deaf {
		t.Fatal("moderation was not persisted")
	}
	if grant = auditToken(t, s); len(grant.CanPublishSources) != 1 || grant.CanPublishSources[0] != "screen_share" {
		t.Fatal("leave/rejoin bypassed mute")
	}
	if grant = auditToken(t, s); grant.CanSubscribe {
		t.Fatal("deaf user can subscribe")
	}
	apply("mute", false)
	permission = calls[len(calls)-1]["permission"].(map[string]any)
	if permission["canSubscribe"] != false {
		t.Fatal("unmute lifted deafen")
	}
	apply("deafen", false)
	if !auditToken(t, s).CanSubscribe {
		t.Fatal("undeafen not restored")
	}
	// Unmute must still honor the target's channel permission.
	meta := s.db.Communities[0].ChannelMeta["voice"]
	meta.RolePermissions = map[string]map[string]bool{"everyone": {"SPEAK": false}}
	s.db.Communities[0].ChannelMeta["voice"] = meta
	apply("mute", false)
	permission = calls[len(calls)-1]["permission"].(map[string]any)
	for _, source := range permission["canPublishSources"].([]any) {
		if source == "MICROPHONE" {
			t.Fatal("unmute bypassed SPEAK deny")
		}
	}
	status = 503
	w = auditFixRequest(s.voiceModeration, "owner", `{"community":"c","target":"guest","action":"mute","enabled":true}`)
	if w.Code != 502 {
		t.Fatalf("SFU failure hidden: %d", w.Code)
	}
}

func TestAuditSanctionsRevokeOnlyAffectedRoom(t *testing.T) {
	for _, action := range []string{"disconnect_voice", "kick", "kick_temporary", "community_ban", "channel_ban"} {
		t.Run(action, func(t *testing.T) {
			s := auditVoiceFixture(t)
			status := 200
			var calls []map[string]any
			auditMedia(t, s, &status, &calls)
			body, _ := json.Marshal(map[string]any{"community": "c", "target": "guest", "action": action, "channel": "voice", "reason": "test reason", "unit": "permanent"})
			w := auditFixRequest(s.sanctionsAPI, "owner", string(body))
			if w.Code != 200 && w.Code != 201 {
				t.Fatalf("%d %s", w.Code, w.Body)
			}
			expected := 2
			if action == "disconnect_voice" || action == "channel_ban" {
				expected = 1
			}
			if len(calls) != expected {
				t.Fatalf("wrong media removal count: %v", calls)
			}
			found := false
			for _, call := range calls {
				if call["room"] == "c:voice" {
					found = true
				}
				if !strings.HasPrefix(call["room"].(string), "c:") || !strings.HasSuffix(call["method"].(string), "/RemoveParticipant") {
					t.Fatalf("wrong media removal: %v", calls)
				}
			}
			if !found {
				t.Fatal("active room not revoked")
			}
			if w = auditFixRequest(s.liveKitToken, "guest", `{"community":"c","channel":"voice"}`); w.Code == 200 {
				t.Fatal("sanctioned user got new token")
			}
		})
	}
	t.Run("unrelated community", func(t *testing.T) {
		s := auditVoiceFixture(t)
		status := 200
		var calls []map[string]any
		auditMedia(t, s, &status, &calls)
		voice.mu.Lock()
		voice.members["guest"].Room = "different:voice"
		voice.mu.Unlock()
		w := auditFixRequest(s.sanctionsAPI, "owner", `{"community":"c","target":"guest","action":"community_ban","reason":"test reason","unit":"permanent"}`)
		if w.Code != 201 || len(calls) != 2 {
			t.Fatalf("scoped revocation: %d %v", w.Code, calls)
		}
		for _, call := range calls {
			if !strings.HasPrefix(call["room"].(string), "c:") {
				t.Fatalf("unrelated media removed: %v", calls)
			}
		}
		voice.mu.Lock()
		present := voice.members["guest"] != nil
		voice.mu.Unlock()
		if !present {
			t.Fatal("unrelated presence removed")
		}
	})
	t.Run("SFU failure", func(t *testing.T) {
		s := auditVoiceFixture(t)
		status := 503
		var calls []map[string]any
		auditMedia(t, s, &status, &calls)
		w := auditFixRequest(s.sanctionsAPI, "owner", `{"community":"c","target":"guest","action":"disconnect_voice"}`)
		if w.Code != 502 {
			t.Fatal("failed disconnect reported success")
		}
		voice.mu.Lock()
		present := voice.members["guest"] != nil
		voice.mu.Unlock()
		if !present {
			t.Fatal("failed disconnect lost retry state")
		}
		status = 200
		w = auditFixRequest(s.sanctionsAPI, "owner", `{"community":"c","target":"guest","action":"disconnect_voice"}`)
		if w.Code != 200 || len(calls) != 2 {
			t.Fatal("disconnect could not be retried")
		}
	})
}

func TestAuditMoveRevokesOldMediaAndBlocksOldGrant(t *testing.T) {
	s := auditVoiceFixture(t)
	status := 200
	var calls []map[string]any
	auditMedia(t, s, &status, &calls)
	w := auditFixRequest(s.voiceModeration, "owner", `{"community":"c","target":"guest","action":"move","channel":"dest"}`)
	if w.Code != 200 || len(calls) != 1 || calls[0]["room"] != "c:voice" {
		t.Fatalf("move: %d %v", w.Code, calls)
	}
	if w = auditFixRequest(s.liveKitToken, "guest", `{"community":"c","channel":"voice"}`); w.Code != 409 {
		t.Fatal("old room token allowed")
	}
	if w = auditFixRequest(s.voiceAPI, "guest", `{"community":"c","channel":"voice","action":"join"}`); w.Code != 403 {
		t.Fatal("pending move bypassed")
	}
	if w = auditFixRequest(s.voiceAPI, "guest", `{"community":"c","channel":"dest","action":"join"}`); w.Code != 200 {
		t.Fatalf("destination: %d %s", w.Code, w.Body)
	}
}

func TestAuditGroupDepartureUsesActualMediaRoom(t *testing.T) {
	s := auditVoiceFixture(t)
	status := 200
	var calls []map[string]any
	auditMedia(t, s, &status, &calls)
	id := strings.Repeat("a", 20)
	room := "dm:" + id + ":nonce-test"
	s.db.DirectChats = []DirectChat{{ID: id, Name: "Group", Creator: "owner", Users: []string{"owner", "guest", "other"}, Visible: map[string]bool{"guest": true}}}
	directCalls.Lock()
	directCalls.Rooms[id] = map[string]directCallMember{"guest": {Seen: time.Now()}, "owner": {Seen: time.Now()}, "other": {Seen: time.Now()}}
	directCalls.MediaRooms[id] = room
	directCalls.Unlock()
	t.Cleanup(func() {
		directCalls.Lock()
		delete(directCalls.Rooms, id)
		delete(directCalls.MediaRooms, id)
		delete(directCalls.AloneSince, id)
		directCalls.Unlock()
	})
	w := auditFixRequest(s.directAPI, "guest", `{"action":"leave_group","id":"`+id+`"}`)
	if w.Code != 200 || len(calls) != 1 || calls[0]["room"] != room || calls[0]["identity"] != "guest" {
		t.Fatalf("departure: %d %v %s", w.Code, calls, w.Body)
	}
	if w = auditFixRequest(s.directCallAPI, "guest", `{"action":"join","id":"`+id+`"}`); w.Code != 404 {
		t.Fatal("ex-member issued call grant")
	}
	if len(s.db.DirectChats[0].Users) != 2 {
		t.Fatal("remaining group members lost")
	}
}

func TestAuditStickerRequiresCurrentFriendshipOnlyForIndividualDM(t *testing.T) {
	s := newServer(t.TempDir() + "/db.json")
	s.db.Users["alice"] = User{Name: "alice", Beta: true}
	s.db.Users["bob"] = User{Name: "bob"}
	s.sessions["alice"] = "alice"
	sticker := strings.Repeat("a", 32) + ".png"
	s.db.Stickers = []Sticker{{ID: sticker, Owner: "alice"}}
	s.db.DirectChats = []DirectChat{{ID: "dm", Users: []string{"alice", "bob"}, Visible: map[string]bool{"alice": true}}}
	body := `{"action":"send_sticker","id":"dm","sticker":"` + sticker + `"}`
	w := auditFixRequest(s.directAPI, "alice", body)
	if w.Code != 403 || len(s.db.DirectChats[0].Messages) != 0 || len(s.db.Notifications) != 0 || s.db.DirectChats[0].Visible["bob"] {
		t.Fatalf("nonfriend sticker side effects: %d", w.Code)
	}
	s.db.Friends = []FriendRequest{{From: "alice", To: "bob", Status: "accepted"}}
	if w = auditFixRequest(s.directAPI, "alice", body); w.Code != 201 {
		t.Fatalf("friend sticker: %d %s", w.Code, w.Body)
	}
	s.db.Friends[0].Status = "removed"
	before := len(s.db.Notifications)
	if w = auditFixRequest(s.directAPI, "alice", body); w.Code != 403 || len(s.db.DirectChats[0].Messages) != 1 || len(s.db.Notifications) != before {
		t.Fatal("ex-friend sticker allowed")
	}
	s.db.DirectChats[0].Name = "Group reduced to two"
	if w = auditFixRequest(s.directAPI, "alice", body); w.Code != 201 {
		t.Fatalf("group regression: %d %s", w.Code, w.Body)
	}
}

func TestAuditPasswordCompatibilityAndLoginBounds(t *testing.T) {
	// Independent Python hashlib.pbkdf2_hmac vector at the original 120000 rounds.
	if got := secureHash("test-salt", "password123"); got != "pbkdf2-sha256$120000$ded45c1f2e179b74518a8b8edfc74376b6df0a735ce2953749142217904fc5c3" {
		t.Fatalf("PBKDF2 changed: %s", got)
	}
	s := newServer(t.TempDir() + "/db.json")
	s.db.Users["alice"] = User{Name: "alice", Salt: "salt", Hash: hash("salt", "password123")}
	w := auditFixRequest(s.login, "", `{"name":"alice","password":"`+strings.Repeat("p", 257)+`"}`)
	if w.Code != 400 || len(s.sessions) != 0 {
		t.Fatal("oversized login accepted")
	}
	w = auditFixRequest(s.login, "", `{"name":"alice","password":"password123"}`)
	if w.Code != 200 || !strings.HasPrefix(s.db.Users["alice"].Hash, "pbkdf2-sha256$120000$") {
		t.Fatalf("legacy upgrade failed: %d %s", w.Code, w.Body)
	}
	if !checkPassword(s.db.Users["alice"], "password123") {
		t.Fatal("upgraded password incompatible")
	}
}

func TestAuditLoginDoesNotHoldStoreLockAndRechecksSuspension(t *testing.T) {
	s := newServer(t.TempDir() + "/db.json")
	password := strings.Repeat("p", 256)
	s.db.Users["alice"] = User{Name: "alice", Salt: "salt", Hash: secureHash("salt", password)}
	done := make(chan *httptest.ResponseRecorder, 1)
	go func() { done <- auditFixRequest(s.login, "", `{"name":"alice","password":"`+password+`"}`) }()
	deadline := time.Now().Add(3 * time.Second)
	observed := false
	for time.Now().Before(deadline) {
		stack := make([]byte, 128*1024)
		n := runtime.Stack(stack, true)
		if strings.Contains(string(stack[:n]), "comunicador.secureHash(") {
			if !s.mu.TryLock() {
				t.Fatal("PBKDF2 holds shared store mutex")
			}
			user := s.db.Users["alice"]
			user.BannedPermanent = true
			s.db.Users["alice"] = user
			s.mu.Unlock()
			observed = true
			break
		}
		runtime.Gosched()
	}
	response := <-done
	if !observed {
		t.Fatal("did not observe password derivation")
	}
	if response.Code != 403 || len(s.sessions) != 0 {
		t.Fatalf("concurrent suspension bypassed: %d", response.Code)
	}
}

func TestAuditCloudRemovalSetsExplicitRevocationCutoff(t *testing.T) {
	s := auditVoiceFixture(t)
	status := 200
	var calls []map[string]any
	auditMedia(t, s, &status, &calls)
	t.Setenv("LIVEKIT_WS_URL", "wss://example.livekit.cloud")
	before := time.Now().Unix()
	if err := livekitRoomAction("c:voice", "guest", true); err != nil {
		t.Fatal(err)
	}
	cutoff, ok := calls[0]["revoke_token_ts"].(float64)
	if !ok || int64(cutoff) < before || int64(cutoff) > time.Now().Unix() {
		t.Fatalf("missing Cloud cutoff: %v", calls)
	}
}
