package main

import (
	"bytes"
	"encoding/json"
	"net/http/httptest"
	"path/filepath"
	"testing"
)

func TestV1868NotificationPollKeepsAccountOnlineOutsideCommunity(t *testing.T) {
	s := newServer(filepath.Join(t.TempDir(), "presence.json"))
	const name = "presence1868_alice"
	s.db.Users[name] = User{Name: name, PreferredStatus: "away"}
	s.db.Users["presence1868_bob"] = User{Name: "presence1868_bob"}
	s.db.Communities = []Community{
		{ID: "one1868", Owner: name, Members: []string{name, "presence1868_bob"}},
		{ID: "two1868", Owner: name, Members: []string{name, "presence1868_bob"}},
	}
	s.sessions["presence-session1868"] = name
	s.sessions["bob-session1868"] = "presence1868_bob"
	call := func(method, path, auth string) *httptest.ResponseRecorder {
		r := httptest.NewRequest(method, path, nil)
		r.Header.Set("Authorization", "Bearer "+auth)
		w := httptest.NewRecorder()
		s.routes().ServeHTTP(w, r)
		return w
	}
	if r := call("GET", "/api/notifications", "presence-session1868"); r.Code != 200 {
		t.Fatalf("notification heartbeat: %d: %s", r.Code, r.Body.String())
	}
	for _, id := range []string{"one1868", "two1868"} {
		r := call("GET", "/api/presence?community="+id, "bob-session1868")
		var data struct {
			Members []struct {
				User, Status string
				Online       bool
			} `json:"members"`
		}
		if err := json.Unmarshal(r.Body.Bytes(), &data); err != nil {
			t.Fatal(err)
		}
		if len(data.Members) == 0 || data.Members[0].Status != "away" || !data.Members[0].Online {
			t.Fatalf("presence outside viewed community %s: %+v", id, data.Members)
		}
	}
	if r := call("POST", "/api/logout", "presence-session1868"); r.Code != 200 {
		t.Fatal(r.Body.String())
	}
	r := call("GET", "/api/presence?community=one1868", "bob-session1868")
	var state struct {
		Members []struct{ Status string } `json:"members"`
	}
	_ = json.Unmarshal(r.Body.Bytes(), &state)
	if state.Members[0].Status != "offline" {
		t.Fatalf("logged out user remains online: %+v", state)
	}
}

func TestV1868FriendAcceptNotificationClearsWhenViewed(t *testing.T) {
	s := newServer(filepath.Join(t.TempDir(), "friend.json"))
	s.db.Users["sender1868"] = User{Name: "sender1868"}
	s.db.Users["receiver1868"] = User{Name: "receiver1868"}
	s.sessions["sender-token1868"] = "sender1868"
	s.sessions["receiver-token1868"] = "receiver1868"
	call := func(method, path, token, body string) *httptest.ResponseRecorder {
		r := httptest.NewRequest(method, path, bytes.NewBufferString(body))
		r.Header.Set("Authorization", "Bearer "+token)
		w := httptest.NewRecorder()
		s.routes().ServeHTTP(w, r)
		return w
	}
	if r := call("POST", "/api/social", "sender-token1868", `{"action":"request","target":"receiver1868"}`); r.Code != 200 {
		t.Fatal(r.Body.String())
	}
	var requestID string
	for _, fr := range s.db.Friends {
		if fr.To == "receiver1868" {
			requestID = fr.ID
		}
	}
	if requestID == "" {
		t.Fatal("request ID missing")
	}
	if r := call("POST", "/api/social", "receiver-token1868", `{"action":"accept","id":"`+requestID+`"}`); r.Code != 200 {
		t.Fatal(r.Body.String())
	}
	if n := s.unreadNotificationsLocked("receiver1868"); n != 0 {
		t.Fatalf("accepted request still unread: %d", n)
	}
	if n := s.unreadNotificationsLocked("sender1868"); n != 1 {
		t.Fatalf("sender missing acceptance alert: %d", n)
	}
	if r := call("POST", "/api/notifications", "sender-token1868", `{"action":"read_misc"}`); r.Code != 200 {
		t.Fatal(r.Body.String())
	}
	if n := s.unreadNotificationsLocked("sender1868"); n != 0 {
		t.Fatalf("acceptance notification not cleared on Home: %d", n)
	}
}
