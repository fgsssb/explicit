package main

import (
	"crypto/hmac"
	"crypto/sha256"
	"encoding/base64"
	"encoding/hex"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"net/http"
	"net/url"
	"os"
	"path/filepath"
	"strings"
	"time"
)

// These checks are always performed against the authenticated account in the database;
// client-provided badges, display names and community roles never grant global privileges.
func (s *Server) isOwner(user string) bool {
	u, ok := s.db.Users[user]
	return ok && s.db.OwnerAccountID != "" && u.AccountID != "" && u.AccountID == s.db.OwnerAccountID
}
func (s *Server) isSuperadmin(user string) bool {
	return s.db.OwnerAccountID == "" && systemRole(s.db.Users[user]) == "superadmin"
}
func (s *Server) isStaffMuted(community, channel, user, medium string) bool {
	if s.isSuperadmin(user) {
		return false
	}
	for _, m := range s.db.StaffMutes {
		if m.Community == community && (m.Channel == "" || m.Channel == channel) && (m.Target == "" || m.Target == user) && (m.Medium == "both" || m.Medium == medium) {
			return true
		}
	}
	return false
}
func (s *Server) staffAuditLocked(actor, action, target, details string) {
	previous := ""
	if len(s.db.StaffAudit) > 0 {
		previous = s.db.StaffAudit[len(s.db.StaffAudit)-1].Hash
	}
	entry := StaffAuditEntry{At: time.Now().UTC(), Actor: actor, Action: action, Target: target, Details: details, PrevHash: previous}
	value := fmt.Sprintf("%s\n%s\n%s\n%s\n%s\n%s", entry.At.Format(time.RFC3339Nano), actor, action, target, details, previous)
	digest := sha256.Sum256([]byte(value))
	entry.Hash = hex.EncodeToString(digest[:])
	s.db.StaffAudit = append(s.db.StaffAudit, entry)
	// Append-only through this application. OS administrators can still modify local files;
	// external WORM storage is required for an audit that even the operator cannot erase.
	path := filepath.Join(filepath.Dir(s.file), "staff-audit.jsonl")
	if err := os.MkdirAll(filepath.Dir(path), 0700); err == nil {
		if f, e := os.OpenFile(path, os.O_CREATE|os.O_APPEND|os.O_WRONLY, 0600); e == nil {
			b, _ := json.Marshal(entry)
			_, _ = f.Write(append(b, '\n'))
			_ = f.Sync()
			_ = f.Close()
		}
	}
}
func (s *Server) staffControlAPI(w http.ResponseWriter, r *http.Request) {
	mediaControlMu.Lock()
	defer mediaControlMu.Unlock()
	actor, err := s.auth(r)
	if err != nil {
		http.Error(w, "unauthorized", 401)
		return
	}
	s.mu.Lock()
	if systemLevel(systemRole(s.db.Users[actor])) < 2 {
		s.mu.Unlock()
		http.Error(w, "staff required", 403)
		return
	}
	if r.Method == http.MethodGet {
		audits := s.db.StaffAudit
		if len(audits) > 300 {
			audits = audits[len(audits)-300:]
		}
		reply(w, 200, map[string]any{"mutes": s.db.StaffMutes, "audit": audits, "communities": s.db.Communities})
		s.mu.Unlock()
		return
	}
	if r.Method != http.MethodPost {
		s.mu.Unlock()
		http.Error(w, "method", 405)
		return
	}
	var q struct {
		Action    string `json:"action"`
		Community string `json:"community"`
		Channel   string `json:"channel"`
		Target    string `json:"target"`
		Medium    string `json:"medium"`
		Reason    string `json:"reason"`
		Name      string `json:"name"`
		Type      string `json:"type"`
		Limit     int    `json:"limit"`
		ID        string `json:"id"`
	}
	if parse(r, &q) != nil {
		s.mu.Unlock()
		http.Error(w, "invalid", 400)
		return
	}
	q.Reason = strings.TrimSpace(q.Reason)
	if len(q.Reason) < 3 || len(q.Reason) > 500 {
		s.mu.Unlock()
		http.Error(w, "reason must have 3-500 characters", 400)
		return
	}
	var c *Community
	for i := range s.db.Communities {
		if s.db.Communities[i].ID == q.Community {
			c = &s.db.Communities[i]
			break
		}
	}
	if c == nil {
		s.mu.Unlock()
		http.Error(w, "community not found", 404)
		return
	}
	if q.Channel != "" && !contains(c.Channels, q.Channel) {
		s.mu.Unlock()
		http.Error(w, "channel not found", 404)
		return
	}
	if q.Target != "" {
		if _, ok := s.db.Users[q.Target]; !ok {
			s.mu.Unlock()
			http.Error(w, "target not found", 404)
			return
		}
	}
	if q.Target == actor || q.Target != "" && s.isSuperadmin(q.Target) {
		s.mu.Unlock()
		http.Error(w, "superadmin protected", 403)
		return
	}
	var affected []string
	var revokeRoom string
	switch q.Action {
	case "mute":
		if q.Medium != "voice" && q.Medium != "text" && q.Medium != "both" {
			s.mu.Unlock()
			http.Error(w, "invalid medium", 400)
			return
		}
		if q.Target != "" && !contains(c.Members, q.Target) {
			s.mu.Unlock()
			http.Error(w, "not a member", 404)
			return
		}
		item := StaffMute{ID: token()[:16], Community: c.ID, Channel: q.Channel, Target: q.Target, Medium: q.Medium, Actor: actor, Reason: q.Reason, Created: time.Now().UTC()}
		s.db.StaffMutes = append(s.db.StaffMutes, item)
		if q.Medium != "text" {
			for _, member := range c.Members {
				if (q.Target == "" || q.Target == member) && !s.isSuperadmin(member) {
					affected = append(affected, member)
				}
			}
		}
	case "unmute":
		idx := -1
		for i, m := range s.db.StaffMutes {
			if m.ID == q.ID && m.Community == c.ID {
				idx = i
				break
			}
		}
		if idx < 0 {
			s.mu.Unlock()
			http.Error(w, "mute not found", 404)
			return
		}
		removed := s.db.StaffMutes[idx]
		s.db.StaffMutes = append(s.db.StaffMutes[:idx], s.db.StaffMutes[idx+1:]...)
		if removed.Medium != "text" {
			for _, member := range c.Members {
				if !s.isStaffMuted(c.ID, removed.Channel, member, "voice") && (removed.Target == "" || removed.Target == member) && !s.isSuperadmin(member) {
					affected = append(affected, member)
				}
			}
		}
	case "join":
		if !contains(c.Members, actor) {
			c.Members = append(c.Members, actor)
		}
	case "change_invite":
		q.Name = strings.ToLower(strings.TrimSpace(q.Name))
		if len(q.Name) < 4 || len(q.Name) > 32 {
			s.mu.Unlock()
			http.Error(w, "invalid invite", 400)
			return
		}
		for _, r := range q.Name {
			if !(r >= 'a' && r <= 'z' || r >= '0' && r <= '9' || r == '-' || r == '_') {
				s.mu.Unlock()
				http.Error(w, "invalid invite", 400)
				return
			}
		}
		for _, other := range s.db.Communities {
			if other.ID == q.Name {
				s.mu.Unlock()
				http.Error(w, "invite already exists", 409)
				return
			}
		}
		voice.mu.Lock()
		busy := false
		for _, member := range voice.members {
			if strings.HasPrefix(member.Room, c.ID+":") {
				busy = true
				break
			}
		}
		voice.mu.Unlock()
		if busy {
			s.mu.Unlock()
			http.Error(w, "disconnect voice participants before changing invite", 409)
			return
		}
		oldID := c.ID
		c.ID = q.Name
		for i := range s.db.Messages {
			if strings.HasPrefix(s.db.Messages[i].Channel, oldID+":") {
				s.db.Messages[i].Channel = q.Name + strings.TrimPrefix(s.db.Messages[i].Channel, oldID)
			}
		}
		for i := range s.db.Sanctions {
			if s.db.Sanctions[i].Community == oldID {
				s.db.Sanctions[i].Community = q.Name
			}
		}
		for i := range s.db.StaffMutes {
			if s.db.StaffMutes[i].Community == oldID {
				s.db.StaffMutes[i].Community = q.Name
			}
		}
	case "rename_community":
		q.Name = strings.TrimSpace(q.Name)
		if len(q.Name) < 3 || len(q.Name) > 60 {
			s.mu.Unlock()
			http.Error(w, "invalid name", 400)
			return
		}
		c.Name = q.Name
	case "rename_channel":
		if q.Channel == "" {
			s.mu.Unlock()
			http.Error(w, "channel required", 400)
			return
		}
		voice.mu.Lock()
		busy := false
		for _, m := range voice.members {
			if m.Room == c.ID+":"+q.Channel {
				busy = true
				break
			}
		}
		voice.mu.Unlock()
		if busy {
			s.mu.Unlock()
			http.Error(w, "disconnect voice participants before renaming channel", 409)
			return
		}
		if c.ChannelMeta == nil {
			c.ChannelMeta = map[string]ChannelMeta{}
		}
		q.Name = strings.TrimSpace(q.Name)
		if q.Channel == "" || len(q.Name) < 1 || len(q.Name) > 40 || contains(c.Channels, q.Name) {
			s.mu.Unlock()
			http.Error(w, "invalid new channel", 400)
			return
		}
		for i, ch := range c.Channels {
			if ch == q.Channel {
				c.Channels[i] = q.Name
			}
		}
		c.ChannelMeta[q.Name] = c.ChannelMeta[q.Channel]
		delete(c.ChannelMeta, q.Channel)
		oldKey, newKey := c.ID+":"+q.Channel, c.ID+":"+q.Name
		for i := range s.db.Messages {
			if s.db.Messages[i].Channel == oldKey {
				s.db.Messages[i].Channel = newKey
			}
		}
		// Existing voice participants must reconnect, rather than remain in a renamed room.
		revokeRoom = oldKey
	case "update_channel":
		if c.ChannelMeta == nil {
			c.ChannelMeta = map[string]ChannelMeta{}
		}
		if q.Channel == "" || (q.Type != "voice" && q.Type != "text") || q.Limit < 0 || q.Limit > 99 || (q.Type == "text" && q.Limit != 0) {
			s.mu.Unlock()
			http.Error(w, "invalid channel configuration", 400)
			return
		}
		voice.mu.Lock()
		busy := false
		for _, m := range voice.members {
			if m.Room == c.ID+":"+q.Channel {
				busy = true
				break
			}
		}
		voice.mu.Unlock()
		if busy {
			s.mu.Unlock()
			http.Error(w, "disconnect voice users before editing channel", 409)
			return
		}
		current := c.ChannelMeta[q.Channel]
		current.Type = q.Type
		current.Limit = q.Limit
		c.ChannelMeta[q.Channel] = current
	case "purge_channel":
		if q.Channel == "" || c.channelType(q.Channel) != "text" {
			s.mu.Unlock()
			http.Error(w, "text channel required", 400)
			return
		}
		for i := range s.db.Messages {
			if s.db.Messages[i].Channel == c.ID+":"+q.Channel {
				s.db.Messages[i].Deleted = true
			}
		}
	case "delete_channel":
		voice.mu.Lock()
		busy := false
		for _, m := range voice.members {
			if m.Room == c.ID+":"+q.Channel {
				busy = true
				break
			}
		}
		voice.mu.Unlock()
		if busy {
			s.mu.Unlock()
			http.Error(w, "disconnect voice participants before deleting channel", 409)
			return
		}
		if q.Channel == "" || q.Channel == "geral" {
			s.mu.Unlock()
			http.Error(w, "default channel protected", 409)
			return
		}
		chs := []string{}
		for _, ch := range c.Channels {
			if ch != q.Channel {
				chs = append(chs, ch)
			}
		}
		c.Channels = chs
		delete(c.ChannelMeta, q.Channel)
		revokeRoom = c.ID + ":" + q.Channel
		for i := range s.db.Messages {
			if s.db.Messages[i].Channel == revokeRoom {
				s.db.Messages[i].Deleted = true
			}
		}
	case "kick", "community_ban", "disconnect":
		if q.Target == "" || !contains(c.Members, q.Target) {
			s.mu.Unlock()
			http.Error(w, "member required", 400)
			return
		}
		if q.Action != "disconnect" {
			newMembers := []string{}
			for _, v := range c.Members {
				if v != q.Target {
					newMembers = append(newMembers, v)
				}
			}
			c.Members = newMembers
			if c.Owner == q.Target {
				c.Owner = actor
				if !contains(c.Members, actor) {
					c.Members = append(c.Members, actor)
				}
			}
			if q.Action == "community_ban" {
				s.db.Sanctions = append(s.db.Sanctions, Sanction{ID: token()[:16], Community: c.ID, Target: q.Target, Actor: actor, Type: "community_ban", Reason: q.Reason, Created: time.Now().UTC()})
			}
		}
		affected = []string{q.Target}
	default:
		s.mu.Unlock()
		http.Error(w, "unsupported action", 400)
		return
	}
	s.staffAuditLocked(actor, q.Action, firstNonEmpty(q.Target, q.Channel, c.ID), q.Reason+" / "+q.Medium+" / "+q.Name)
	if err := s.save(); err != nil {
		s.mu.Unlock()
		http.Error(w, "storage error", 500)
		return
	}
	// Immutable snapshot avoids taking s.mu while holding voice.mu.
	communityID := c.ID
	remaining := append([]StaffMute(nil), s.db.StaffMutes...)
	s.mu.Unlock()
	if q.Action == "disconnect" || q.Action == "kick" || q.Action == "community_ban" {
		voice.mu.Lock()
		if m := voice.members[q.Target]; m != nil && strings.HasPrefix(m.Room, communityID+":") {
			revokeRoom = m.Room
			delete(voice.members, q.Target)
		}
		voice.mu.Unlock()
	}
	// After changing voice permissions, also apply changes to active SFU sessions.
	// A failed SFU call is reported, never silently treated as an enforced mute.
	errorsOut := []string{}
	if revokeRoom != "" && q.Target != "" {
		if err := livekitRoomAction(revokeRoom, q.Target, true); err != nil {
			errorsOut = append(errorsOut, err.Error())
		}
	}
	if len(affected) > 0 && (q.Action == "mute" || q.Action == "unmute") {
		voice.mu.Lock()
		rooms := map[string]string{}
		for _, u := range affected {
			if v := voice.members[u]; v != nil && strings.HasPrefix(v.Room, communityID+":") && (q.Channel == "" || strings.HasSuffix(v.Room, ":"+q.Channel)) {
				currentChannel := strings.TrimPrefix(v.Room, communityID+":")
				hasRemaining := false
				for _, rule := range remaining {
					if rule.Community == communityID && (rule.Channel == "" || rule.Channel == currentChannel) && (rule.Target == "" || rule.Target == u) && (rule.Medium == "both" || rule.Medium == "voice") {
						hasRemaining = true
						break
					}
				}
				if q.Action == "mute" || !hasRemaining {
					rooms[u] = v.Room
				}
				v.StaffGloballyMuted = hasRemaining
			}
		}
		voice.mu.Unlock()
		for u, room := range rooms {
			s.mu.Lock()
			channel := strings.TrimPrefix(room, communityID+":")
			canSpeak := false
			canScreen := false
			for _, current := range s.db.Communities {
				if current.ID == q.Community {
					canSpeak = s.channelPermission(current, u, channel, "SPEAK") && !s.isStaffMuted(current.ID, channel, u, "voice")
					canScreen = s.channelPermission(current, u, channel, "SCREEN_SHARE")
					break
				}
			}
			restriction := s.db.VoiceRestrictions[q.Community][u]
			canSpeak = canSpeak && !restriction.Muted
			s.mu.Unlock()
			voice.mu.Lock()
			canSubscribe := !restriction.Deaf
			if m := voice.members[u]; m != nil && m.Room == room {
				canSpeak = canSpeak && !m.AdminMuted && !m.StaffGloballyMuted
				canSubscribe = canSubscribe && !m.AdminDeaf
			}
			voice.mu.Unlock()
			if err := livekitSetMediaPermission(room, u, false, canSpeak, canScreen, canSubscribe); err != nil {
				errorsOut = append(errorsOut, "@"+u+": "+err.Error())
			}
		}
	}
	reply(w, 200, map[string]any{"ok": true, "media_warnings": errorsOut})
}
func firstNonEmpty(v ...string) string {
	for _, x := range v {
		if x != "" {
			return x
		}
	}
	return ""
}

// LiveKit RoomService is Twirp over HTTPS. UpdateParticipant changes active
// participants' publish permission, while RemoveParticipant revokes Cloud tokens.
func livekitRoomAction(room, identity string, remove bool) error {
	return livekitSetPermissionAction(room, identity, remove, false, false)
}
func livekitSetPermission(room, identity string, canPublish, canScreen bool) error {
	return livekitSetPermissionAction(room, identity, false, canPublish, canScreen)
}
func livekitSetPermissionAction(room, identity string, remove, canPublish, canScreen bool) error {
	return livekitSetMediaPermission(room, identity, remove, canPublish, canScreen, true)
}

func livekitSetMediaPermission(room, identity string, remove, canSpeak, canScreen, canSubscribe bool) error {
	ws, key, secret, ok := liveKitConfig()
	if !ok {
		return nil
	} // P2P deployments have no SFU.
	claims := map[string]any{"iss": key, "sub": "explicit-staff-service", "iat": time.Now().Unix(), "exp": time.Now().Add(time.Minute).Unix(), "video": map[string]any{"roomAdmin": true, "room": room}}
	header := base64.RawURLEncoding.EncodeToString([]byte(`{"alg":"HS256","typ":"JWT"}`))
	payload, _ := json.Marshal(claims)
	raw := header + "." + base64.RawURLEncoding.EncodeToString(payload)
	mac := hmac.New(sha256.New, []byte(secret))
	_, _ = mac.Write([]byte(raw))
	jwt := raw + "." + base64.RawURLEncoding.EncodeToString(mac.Sum(nil))
	action := "UpdateParticipant"
	sources := []string{}
	if canSpeak {
		sources = append(sources, "MICROPHONE")
	}
	if canScreen {
		sources = append(sources, "SCREEN_SHARE")
	}
	body := map[string]any{"room": room, "identity": identity, "permission": map[string]any{"canPublish": len(sources) > 0, "canSubscribe": canSubscribe, "canPublishData": false, "canPublishSources": sources}}
	if remove {
		action = "RemoveParticipant"
		body = map[string]any{"room": room, "identity": identity}
		endpoint, _ := url.Parse(ws)
		if endpoint != nil && strings.HasSuffix(strings.ToLower(endpoint.Hostname()), ".livekit.cloud") {
			// Cloud's default one-minute buffer can accept a freshly cached token.
			body["revoke_token_ts"] = time.Now().Unix()
		}
	}
	data, _ := json.Marshal(body)
	uri, err := url.Parse(ws)
	if err != nil {
		return err
	}
	uri.Scheme = "https"
	uri.Path = "/twirp/livekit.RoomService/" + action
	uri.RawQuery = ""
	req, err := http.NewRequest(http.MethodPost, uri.String(), strings.NewReader(string(data)))
	if err != nil {
		return err
	}
	req.Header.Set("Authorization", "Bearer "+jwt)
	req.Header.Set("Content-Type", "application/json")
	client := &http.Client{Timeout: 5 * time.Second}
	response, err := client.Do(req)
	if err != nil {
		return err
	}
	defer response.Body.Close()
	if response.StatusCode >= 300 {
		body, _ := io.ReadAll(io.LimitReader(response.Body, 256))
		var failure struct {
			Code string `json:"code"`
		}
		// Removal is idempotent. Cloud also revokes tokens for absent participants.
		if remove && response.StatusCode == http.StatusNotFound && json.Unmarshal(body, &failure) == nil && failure.Code == "not_found" {
			return nil
		}
		return errors.New("LiveKit " + response.Status + ": " + string(body))
	}
	return nil
}

// Review is allowed only through an active user report. Every query is audited.
// Individual notifications are intentionally not sent during an investigation;
// the platform-wide privacy disclosure describes this exceptional access.
func (s *Server) investigationCaseLocked(id string) *SystemReport {
	for i := range s.db.Reports {
		report := &s.db.Reports[i]
		if report.ID == id && report.Status == "open" && report.Kind == "user" && report.Target != "" {
			if _, exists := s.db.Users[report.Target]; exists {
				return report
			}
		}
	}
	return nil
}

// Report-scoped DM access. A generic user report exposes zero messages.
// Reviewing a message report reveals only the reported message and six
// surrounding messages from the same conversation. Expansion requires a
// separate administrator and is confined to the same evidence conversation.
func (s *Server) staffDMAPI(w http.ResponseWriter, r *http.Request) {
	actor, err := s.auth(r)
	if err != nil {
		http.Error(w, "unauthorized", 401)
		return
	}
	s.mu.Lock()
	defer s.mu.Unlock()
	if systemLevel(systemRole(s.db.Users[actor])) < 2 {
		http.Error(w, "staff required", 403)
		return
	}
	reportID := r.URL.Query().Get("report_id")
	var q struct {
		ReportID string `json:"report_id"`
		Chat     string `json:"chat"`
		Reason   string `json:"reason"`
		Action   string `json:"action"`
		Text     string `json:"text"`
		Target   string `json:"target"`
	}
	if r.Method == http.MethodPost {
		if parse(r, &q) != nil {
			http.Error(w, "invalid", 400)
			return
		}
		reportID = q.ReportID
	} else if r.Method != http.MethodGet {
		http.Error(w, "method", 405)
		return
	}
	report := s.investigationCaseLocked(reportID)
	if report == nil {
		http.Error(w, "open user report required", 403)
		return
	}
	if report.Target == actor {
		http.Error(w, "staff member cannot investigate own report", 403)
		return
	}
	if r.Method == http.MethodPost && (q.Action == "notice" || (q.Action == "" && strings.TrimSpace(q.Text) != "")) {
		// Explicit staff communication is an intentional visible action, never a
		// side-effect of reading evidence. It cannot target an arbitrary DM.
		if report.ChatID == "" || report.MessageID == "" || q.Chat != report.ChatID || q.Target != report.Target || len(strings.TrimSpace(q.Text)) < 2 || len(q.Text) > 2000 || len(strings.TrimSpace(q.Reason)) < 10 {
			http.Error(w, "invalid case notice", 403)
			return
		}
		for i := range s.db.DirectChats {
			c := &s.db.DirectChats[i]
			if c.ID != report.ChatID || !contains(c.Users, report.Target) {
				continue
			}
			old := append([]DirectMessage(nil), c.Messages...)
			m := DirectMessage{ID: token()[:16], Author: "Admin • @" + actor, Text: "Comunicado da moderação: " + strings.TrimSpace(q.Text), StaffNotice: true, StaffRecipient: q.Target, Time: time.Now().UTC()}
			c.Messages = append(c.Messages, m)
			s.staffAuditLocked(actor, "report_staff_notice", c.ID, "case="+report.ID+" reason="+q.Reason)
			if err := s.save(); err != nil {
				c.Messages = old
				http.Error(w, "storage", 500)
				return
			}
			reply(w, 200, map[string]bool{"ok": true})
			return
		}
		http.Error(w, "chat not found", 404)
		return
	}
	if r.Method == http.MethodPost {
		reason := strings.TrimSpace(q.Reason)
		if len(reason) < 15 || len(reason) > 500 {
			http.Error(w, "justification required", 400)
			return
		}
		if report.ChatID == "" || report.MessageID == "" || q.Chat != report.ChatID {
			http.Error(w, "evidence required", 403)
			return
		}
		old := *report
		switch q.Action {
		case "request_expand":
			if report.ExpansionApprovedBy != "" {
				http.Error(w, "already approved", 409)
				return
			}
			report.ExpansionRequestedBy = actor
			report.ExpansionReason = reason
			s.staffAuditLocked(actor, "report_expansion_requested", report.ChatID, "case="+report.ID+" scope=same_conversation reason="+reason)
		case "approve_expand":
			if report.ExpansionRequestedBy == "" || actor == report.ExpansionRequestedBy || report.ExpansionReason == "" {
				http.Error(w, "independent approval required", 403)
				return
			}
			report.ExpansionApprovedBy = actor
			s.staffAuditLocked(actor, "report_expansion_approved", report.ChatID, "case="+report.ID+" scope=same_conversation reason="+reason)
		default:
			http.Error(w, "invalid action", 400)
			return
		}
		if err := s.save(); err != nil {
			*report = old
			http.Error(w, "storage", 500)
			return
		}
		reply(w, 200, map[string]any{"ok": true, "report": report})
		return
	}
	if r.URL.Query().Get("list") == "1" {
		// Do not enumerate all of the reported user's conversations.
		out := []map[string]any{}
		if report.ChatID != "" && report.MessageID != "" {
			for _, c := range s.db.DirectChats {
				if c.ID == report.ChatID && contains(c.Users, report.Target) && contains(c.Users, report.Reporter) {
					for _, m := range c.Messages {
						if m.ID == report.MessageID && m.Author == report.Target {
							out = append(out, map[string]any{"id": c.ID, "users": c.Users, "group": len(c.Users) > 2 || c.Name != "", "name": c.Name, "message_count": 1})
							break
						}
					}
				}
			}
		}
		s.staffAuditLocked(actor, "report_evidence_list", report.Target, "case="+report.ID)
		if err := s.save(); err != nil {
			http.Error(w, "audit storage", 500)
			return
		}
		w.Header().Set("Cache-Control", "no-store")
		reply(w, 200, map[string]any{"report": report, "conversations": out})
		return
	}
	chatID := r.URL.Query().Get("chat")
	reason := strings.TrimSpace(r.URL.Query().Get("reason"))
	if len(reason) < 10 || len(reason) > 500 {
		http.Error(w, "justification required", 400)
		return
	}
	if report.ChatID == "" || report.MessageID == "" || chatID != report.ChatID {
		http.Error(w, "conversation outside report scope", 403)
		return
	}
	for _, c := range s.db.DirectChats {
		if c.ID != chatID || !contains(c.Users, report.Target) || !contains(c.Users, report.Reporter) {
			continue
		}
		index := -1
		for i, m := range c.Messages {
			if m.ID == report.MessageID && m.Author == report.Target {
				index = i
				break
			}
		}
		if index < 0 {
			http.Error(w, "evidence missing", 404)
			return
		}
		radius := 6
		if report.ExpansionApprovedBy != "" {
			radius = 30
		}
		start, end := index-radius, index+radius+1
		if start < 0 {
			start = 0
		}
		if end > len(c.Messages) {
			end = len(c.Messages)
		}
		scoped := append([]DirectMessage(nil), c.Messages[start:end]...)
		fileID := r.URL.Query().Get("file")
		if fileID != "" {
			if !directFileID.MatchString(fileID) {
				http.Error(w, "invalid file", 400)
				return
			}
			found := false
			for _, m := range scoped {
				if m.File == fileID && (strings.HasSuffix(strings.ToLower(m.FileName), ".png") || strings.HasSuffix(strings.ToLower(m.FileName), ".jpg") || strings.HasSuffix(strings.ToLower(m.FileName), ".jpeg") || strings.HasSuffix(strings.ToLower(m.FileName), ".gif") || strings.HasSuffix(strings.ToLower(m.FileName), ".webp")) {
					found = true
					break
				}
			}
			if !found {
				http.Error(w, "file outside evidence scope", 403)
				return
			}
		}
		s.staffAuditLocked(actor, "report_evidence_review", c.ID, "case="+report.ID+" message="+report.MessageID+" context="+fmt.Sprint(radius)+" reason="+reason+" file="+fileID)
		if err := s.save(); err != nil {
			http.Error(w, "audit storage", 500)
			return
		}
		w.Header().Set("Cache-Control", "no-store")
		if fileID != "" {
			w.Header().Set("X-Content-Type-Options", "nosniff")
			w.Header().Set("Content-Security-Policy", "default-src 'none'; sandbox")
			http.ServeFile(w, r, filepath.Join(filepath.Dir(s.file), "direct_files", fileID))
			return
		}
		reply(w, 200, map[string]any{"id": c.ID, "name": c.Name, "users": c.Users, "messages": scoped, "evidence_message_id": report.MessageID, "expanded": radius > 6})
		return
	}
	http.Error(w, "conversation not found", 404)
}
