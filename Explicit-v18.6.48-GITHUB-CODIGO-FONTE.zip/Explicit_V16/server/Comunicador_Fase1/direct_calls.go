package main

import (
	"crypto/rand"
	"encoding/hex"
	"log"
	"net/http"
	"sync"
	"time"
)

// Direct calls are ephemeral. The server alone decides whether the user may
// participate. LiveKit room names are unique per call, so closing an old idle
// room cannot inadvertently disconnect a newly started call for the same DM.
type directCallMember struct {
	Seen   time.Time
	Screen bool
}

const (
	directCallHeartbeatTTL     = 40 * time.Second
	directCallAloneTimeout     = 2 * time.Minute
	directCallSweepInterval    = 5 * time.Second
	directCallExpiredRetention = 5 * time.Minute
)

type directCallTermination struct {
	Room         string
	Participants []string
}

var directCalls = struct {
	sync.Mutex
	Rooms      map[string]map[string]directCallMember
	AloneSince map[string]time.Time
	MediaRooms map[string]string
	Expired    map[string]time.Time
}{
	Rooms:      make(map[string]map[string]directCallMember),
	AloneSince: make(map[string]time.Time),
	MediaRooms: make(map[string]string),
	Expired:    make(map[string]time.Time),
}

var directCallSweepOnce sync.Once

func startDirectCallSweeper() {
	directCallSweepOnce.Do(func() {
		go func() {
			ticker := time.NewTicker(directCallSweepInterval)
			defer ticker.Stop()
			for now := range ticker.C {
				directCalls.Lock()
				ended := cleanDirectCallRoomsLocked(now)
				directCalls.Unlock()
				terminateDirectCallMedia(ended)
			}
		}()
	})
}

// Must be called with directCalls locked. The returned terminations must be
// processed only after the mutex is released: Twirp calls can block on network.
func cleanDirectCallRoomsLocked(now time.Time) []directCallTermination {
	ended := make([]directCallTermination, 0)
	for id, members := range directCalls.Rooms {
		prior := make([]string, 0, len(members))
		for user, m := range members {
			prior = append(prior, user)
			if now.Sub(m.Seen) > directCallHeartbeatTTL {
				delete(members, user)
			}
		}
		if len(members) > 1 {
			delete(directCalls.AloneSince, id)
			continue
		}
		if len(members) == 1 {
			if directCalls.AloneSince[id].IsZero() {
				directCalls.AloneSince[id] = now
			}
			if now.Sub(directCalls.AloneSince[id]) < directCallAloneTimeout {
				continue
			}
			directCalls.Expired[id] = now
		}
		// Either no one remains, or one participant's two-minute grace expired.
		if room := directCalls.MediaRooms[id]; room != "" {
			ended = append(ended, directCallTermination{Room: room, Participants: prior})
		}
		delete(directCalls.Rooms, id)
		delete(directCalls.AloneSince, id)
		delete(directCalls.MediaRooms, id)
	}
	for id, at := range directCalls.Expired {
		if now.Sub(at) > directCallExpiredRetention {
			delete(directCalls.Expired, id)
		}
	}
	return ended
}

func terminateDirectCallMedia(ended []directCallTermination) {
	for _, terminated := range ended {
		for _, participant := range terminated.Participants {
			room, user := terminated.Room, participant
			go func() {
				if err := livekitRoomAction(room, user, true); err != nil {
					log.Printf("direct call cleanup: unable to remove participant from expired room: %v", err)
				}
			}()
		}
	}
}

func directCallNewRoomName(id string) (string, error) {
	var nonce [12]byte
	if _, err := rand.Read(nonce[:]); err != nil {
		return "", err
	}
	return "dm:" + id + ":" + hex.EncodeToString(nonce[:]), nil
}

func directCallSoloRemainingLocked(id string, now time.Time) int {
	since := directCalls.AloneSince[id]
	if since.IsZero() || len(directCalls.Rooms[id]) != 1 {
		return 0
	}
	left := directCallAloneTimeout - now.Sub(since)
	if left <= 0 {
		return 0
	}
	// Round up so the initial display reads 2:00, not 1:59.
	return int((left + time.Second - 1) / time.Second)
}

func (s *Server) directCallAPI(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		http.Error(w, "method not allowed", 405)
		return
	}
	user, err := s.auth(r)
	if err != nil {
		http.Error(w, "unauthorized", 401)
		return
	}
	var q struct {
		ID     string `json:"id"`
		Action string `json:"action"`
		Screen bool   `json:"screen"`
	}
	if parse(r, &q) != nil || len(q.ID) != 20 {
		http.Error(w, "invalid call", 400)
		return
	}
	// Always check current membership on every action, never trust the client.
	s.mu.Lock()
	allowed := false
	for _, chat := range s.db.DirectChats {
		if chat.ID == q.ID && contains(chat.Users, user) && len(chat.Users) >= 2 {
			allowed = true
			break
		}
	}
	if !allowed {
		s.mu.Unlock()
		http.Error(w, "conversation not found", 404)
		return
	}

	startDirectCallSweeper()
	now := time.Now()
	directCalls.Lock()
	s.mu.Unlock() // Membership check and call-state acquisition are atomic with leave_group.
	ended := cleanDirectCallRoomsLocked(now)
	// Release the mutex for any network cleanup, but keep request changes atomic.
	members := directCalls.Rooms[q.ID]
	participants := func() []map[string]any {
		people := make([]map[string]any, 0, len(members))
		for name, m := range members {
			people = append(people, map[string]any{"user": name, "screen": m.Screen})
		}
		return people
	}
	replyCall := func(code int, body any) {
		directCalls.Unlock()
		terminateDirectCallMedia(ended)
		reply(w, code, body)
	}
	errorCall := func(code int, message string) {
		directCalls.Unlock()
		terminateDirectCallMedia(ended)
		reply(w, code, map[string]string{"error": message})
	}
	switch q.Action {
	case "peek":
		replyCall(200, map[string]any{"active": len(members) > 0, "participants": participants(), "solo_remaining_seconds": directCallSoloRemainingLocked(q.ID, now)})
	case "join":
		ws, key, secret, ok := liveKitConfig()
		if !ok {
			errorCall(503, "Chamadas privadas exigem LiveKit configurado")
			return
		}
		if len(members) >= 8 {
			if _, joined := members[user]; !joined {
				errorCall(409, "call full")
				return
			}
		}
		// This ID is generated once per call; all participants use the same room.
		mediaRoom := directCalls.MediaRooms[q.ID]
		if mediaRoom == "" {
			mediaRoom, err = directCallNewRoomName(q.ID)
			if err != nil {
				errorCall(500, "Falha ao preparar chamada")
				return
			}
		}
		jwt, err := signedLiveKitToken(key, secret, user, mediaRoom, true, true, now)
		if err != nil {
			errorCall(500, "token error")
			return
		}
		if members == nil {
			members = map[string]directCallMember{}
			directCalls.Rooms[q.ID] = members
		}
		directCalls.MediaRooms[q.ID] = mediaRoom
		// Preserve a user's active screen state on a quick rejoin.
		member := members[user]
		member.Seen = now
		members[user] = member
		if len(members) == 1 {
			if directCalls.AloneSince[q.ID].IsZero() {
				directCalls.AloneSince[q.ID] = now
			}
		} else {
			delete(directCalls.AloneSince, q.ID)
		}
		w.Header().Set("Cache-Control", "no-store")
		replyCall(200, map[string]any{"url": ws, "token": jwt, "participants": participants(), "can_screen": true, "solo_remaining_seconds": directCallSoloRemainingLocked(q.ID, now)})
	case "poll":
		member, ok := members[user]
		if !ok {
			if _, expired := directCalls.Expired[q.ID]; expired {
				errorCall(409, "Chamada encerrada automaticamente após 2 minutos com apenas uma pessoa")
				return
			}
			errorCall(409, "not joined")
			return
		}
		member.Seen = now
		members[user] = member
		replyCall(200, map[string]any{"participants": participants(), "solo_remaining_seconds": directCallSoloRemainingLocked(q.ID, now)})
	case "screen":
		member, ok := members[user]
		if !ok {
			errorCall(409, "not joined")
			return
		}
		member.Seen, member.Screen = now, q.Screen
		members[user] = member
		replyCall(200, map[string]bool{"ok": true})
	case "leave":
		delete(members, user)
		if len(members) == 1 {
			directCalls.AloneSince[q.ID] = now
		}
		if len(members) == 0 {
			if room := directCalls.MediaRooms[q.ID]; room != "" {
				ended = append(ended, directCallTermination{Room: room, Participants: []string{user}})
			}
			delete(directCalls.Rooms, q.ID)
			delete(directCalls.AloneSince, q.ID)
			delete(directCalls.MediaRooms, q.ID)
		}
		replyCall(200, map[string]bool{"ok": true})
	default:
		errorCall(400, "invalid action")
	}
}

// Pure presence hint for the DM rail, never a media grant.
func directCallPresent(id string) bool {
	directCalls.Lock()
	defer directCalls.Unlock()
	if since := directCalls.AloneSince[id]; !since.IsZero() && time.Since(since) >= directCallAloneTimeout {
		return false
	}
	for _, member := range directCalls.Rooms[id] {
		if time.Since(member.Seen) < directCallHeartbeatTTL {
			return true
		}
	}
	return false
}
