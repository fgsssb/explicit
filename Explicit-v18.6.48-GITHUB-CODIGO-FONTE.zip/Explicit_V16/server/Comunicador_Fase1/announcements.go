package main

import (
	"net/http"
	"net/url"
	"strings"
	"time"
	"unicode/utf8"
)

// StaffAnnouncement is a first-party editorial message. Body is plain text with
// limited Markdown understood by the client; no arbitrary HTML is accepted.
type AnnouncementLink struct {
	Label string `json:"label"`
	URL   string `json:"url"`
}
type StaffAnnouncement struct {
	ID     string             `json:"id"`
	Title  string             `json:"title"`
	Body   string             `json:"body"`
	Links  []AnnouncementLink `json:"links,omitempty"`
	Author string             `json:"author"`
	At     time.Time          `json:"at"`
}

func announcementValid(title, body string, links []AnnouncementLink) bool {
	title = strings.TrimSpace(title)
	body = strings.TrimSpace(body)
	if utf8.RuneCountInString(title) < 3 || utf8.RuneCountInString(title) > 120 || utf8.RuneCountInString(body) < 10 || utf8.RuneCountInString(body) > 3000 || len(links) > 3 {
		return false
	}
	for _, link := range links {
		if utf8.RuneCountInString(strings.TrimSpace(link.Label)) < 1 || utf8.RuneCountInString(link.Label) > 70 || len(link.URL) > 500 {
			return false
		}
		u, err := url.Parse(link.URL)
		if err != nil || u.Scheme != "https" || u.Hostname() == "" || u.User != nil || u.Opaque != "" {
			return false
		}
	}
	return true
}
func (s *Server) announcementsAPI(w http.ResponseWriter, r *http.Request) {
	user, err := s.auth(r)
	if err != nil {
		http.Error(w, "unauthorized", http.StatusUnauthorized)
		return
	}
	s.mu.Lock()
	defer s.mu.Unlock()
	if r.Method == http.MethodGet {
		data := s.db.Announcements
		if data == nil {
			data = []StaffAnnouncement{}
		}
		reply(w, 200, data)
		return
	}
	if r.Method != http.MethodPost {
		http.Error(w, "method not allowed", 405)
		return
	}
	if systemLevel(systemRole(s.db.Users[user])) < 1 {
		http.Error(w, "staff only", 403)
		return
	}
	var q struct {
		Action string             `json:"action"`
		ID     string             `json:"id"`
		Title  string             `json:"title"`
		Body   string             `json:"body"`
		Links  []AnnouncementLink `json:"links"`
	}
	if parse(r, &q) != nil {
		http.Error(w, "invalid JSON", 400)
		return
	}
	if q.Action == "add" {
		if !announcementValid(q.Title, q.Body, q.Links) {
			http.Error(w, "Título 3–120, texto 10–3000 e até três links HTTPS válidos são obrigatórios", 400)
			return
		}
		if len(s.db.Announcements) >= 10 {
			http.Error(w, "Limite de 10 comunicados ativos", 409)
			return
		}
		a := StaffAnnouncement{ID: token()[:16], Title: strings.TrimSpace(q.Title), Body: strings.TrimSpace(q.Body), Links: q.Links, Author: user, At: time.Now().UTC()}
		s.db.Announcements = append(s.db.Announcements, a)
		s.staffAuditLocked(user, "announcement_create", a.ID, a.Title)
		if s.save() != nil {
			s.db.Announcements = s.db.Announcements[:len(s.db.Announcements)-1]
			http.Error(w, "storage", 500)
			return
		}
		reply(w, 201, a)
		return
	}
	if q.Action == "remove" {
		for i, a := range s.db.Announcements {
			if a.ID == q.ID {
				old := append([]StaffAnnouncement(nil), s.db.Announcements...)
				s.db.Announcements = append(s.db.Announcements[:i], s.db.Announcements[i+1:]...)
				s.staffAuditLocked(user, "announcement_remove", q.ID, a.Title)
				if s.save() != nil {
					s.db.Announcements = old
					http.Error(w, "storage", 500)
					return
				}
				reply(w, 200, map[string]bool{"ok": true})
				return
			}
		}
		http.Error(w, "not found", 404)
		return
	}
	http.Error(w, "invalid action", 400)
}
