package main

import (
	"bytes"
	"crypto/rand"
	"encoding/hex"
	"encoding/json"
	"errors"
	"image"
	"image/color"
	"image/draw"
	"image/jpeg"
	"image/png"
	"io"
	"log"
	"math"
	"net/http"
	"os"
	"path/filepath"
	"regexp"
	"strings"
	"time"
)

// Stickers belong to accounts; a favorite is a reference, not a second upload.
// No animated media is accepted and all uploaded pixels are decoded/re-encoded.
type Sticker struct {
	ID      string    `json:"id"`
	Owner   string    `json:"owner"`
	Created time.Time `json:"created"`
	Width   int       `json:"width"`
	Height  int       `json:"height"`
	Removed bool      `json:"removed,omitempty"`
}

const stickerMaxUpload = 5 << 20
const stickerMaxOwned = 40
const stickerMaxFavorites = 100

var stickerIDPattern = regexp.MustCompile(`^[a-f0-9]{32}\.(png|jpg)$`)

func (s *Server) maySendStickersLocked(user string) bool {
	u, ok := s.db.Users[user]
	return ok && (u.Beta || explicitPlusActive(u) || systemLevel(systemRole(u)) >= 1)
}
func (s *Server) stickerByIDLocked(id string) *Sticker {
	for i := range s.db.Stickers {
		if s.db.Stickers[i].ID == id {
			return &s.db.Stickers[i]
		}
	}
	return nil
}
func (s *Server) stickerChannelAllowedLocked(user, community, channel string) bool {
	for _, c := range s.db.Communities {
		if c.ID == community && (contains(c.Members, user) || s.isSuperadmin(user)) && contains(c.Channels, channel) && c.channelType(channel) == "text" && s.activeSanction(c, user, channel) == nil && s.channelPermission(c, user, channel, "VIEW_CHANNEL") {
			return true
		}
	}
	return false
}
func (s *Server) stickerReadableLocked(user, id string) bool {
	item := s.stickerByIDLocked(id)
	if item == nil {
		return false
	}
	if item.Owner == user || contains(s.db.StickerFavorites[user], id) {
		return true
	}
	for _, m := range s.db.Messages {
		if m.Sticker != id || m.Deleted {
			continue
		}
		parts := strings.SplitN(m.Channel, ":", 2)
		if len(parts) == 2 && s.stickerChannelAllowedLocked(user, parts[0], parts[1]) {
			return true
		}
	}
	for _, chat := range s.db.DirectChats {
		if contains(chat.Users, user) {
			for _, m := range chat.Messages {
				if m.Sticker == id {
					return true
				}
			}
		}
	}
	return false
}

// Resize using smooth bilinear sampling. Opaque art becomes compact JPEG,
// transparent art remains PNG so transparent edges are not flattened.
func makeSticker(content []byte) ([]byte, string, int, int, error) {
	cfg, format, err := image.DecodeConfig(bytes.NewReader(content))
	if err != nil || (format != "png" && format != "jpeg") {
		return nil, "", 0, 0, errors.New("Envie PNG ou JPEG estático")
	}
	if cfg.Width < 1 || cfg.Height < 1 || cfg.Width > 4096 || cfg.Height > 4096 || int64(cfg.Width)*int64(cfg.Height) > 12000000 {
		return nil, "", 0, 0, errors.New("Dimensões inválidas")
	}
	source, _, err := image.Decode(bytes.NewReader(content))
	if err != nil {
		return nil, "", 0, 0, errors.New("Imagem inválida")
	}
	scale := math.Min(1, math.Min(256/float64(cfg.Width), 256/float64(cfg.Height)))
	w, h := int(math.Max(1, math.Round(float64(cfg.Width)*scale))), int(math.Max(1, math.Round(float64(cfg.Height)*scale)))
	out := image.NewNRGBA(image.Rect(0, 0, w, h))
	for y := 0; y < h; y++ {
		for x := 0; x < w; x++ {
			fx := (float64(x)+.5)*float64(cfg.Width)/float64(w) - .5
			fy := (float64(y)+.5)*float64(cfg.Height)/float64(h) - .5
			x0, y0 := int(math.Floor(fx)), int(math.Floor(fy))
			dx, dy := fx-float64(x0), fy-float64(y0)
			var r, g, b, a float64
			for j := 0; j < 2; j++ {
				for i := 0; i < 2; i++ {
					px := x0 + i
					py := y0 + j
					if px < 0 {
						px = 0
					}
					if px >= cfg.Width {
						px = cfg.Width - 1
					}
					if py < 0 {
						py = 0
					}
					if py >= cfg.Height {
						py = cfg.Height - 1
					}
					cr, cg, cb, ca := source.At(source.Bounds().Min.X+px, source.Bounds().Min.Y+py).RGBA()
					weight := math.Abs(float64(1-i)-dx) * math.Abs(float64(1-j)-dy)
					r += float64(cr) * weight
					g += float64(cg) * weight
					b += float64(cb) * weight
					a += float64(ca) * weight
				}
			}
			if a > 0 {
				out.Set(x, y, color.NRGBA{R: uint8(math.Round(math.Min(255, r/a*255))), G: uint8(math.Round(math.Min(255, g/a*255))), B: uint8(math.Round(math.Min(255, b/a*255))), A: uint8(math.Round(a / 257))})
			}
		}
	}
	transparent := false
	for i := 3; i < len(out.Pix); i += 4 {
		if out.Pix[i] < 255 {
			transparent = true
			break
		}
	}
	var buf bytes.Buffer
	if transparent {
		encoder := png.Encoder{CompressionLevel: png.BestCompression}
		err = encoder.Encode(&buf, out)
	} else {
		opaque := image.NewRGBA(out.Bounds())
		draw.Draw(opaque, opaque.Bounds(), out, image.Point{}, draw.Src)
		err = jpeg.Encode(&buf, opaque, &jpeg.Options{Quality: 78})
	}
	if err != nil || buf.Len() == 0 || buf.Len() > 512<<10 {
		return nil, "", 0, 0, errors.New("Não foi possível otimizar a imagem")
	}
	ext := "jpg"
	if transparent {
		ext = "png"
	}
	return buf.Bytes(), ext, w, h, nil
}
func (s *Server) stickerAPI(w http.ResponseWriter, r *http.Request) {
	user, err := s.auth(r)
	if err != nil {
		http.Error(w, "unauthorized", 401)
		return
	}
	dir := filepath.Join(filepath.Dir(s.file), "stickers")
	if r.Method == http.MethodGet {
		id := r.URL.Query().Get("id")
		if id != "" {
			if !stickerIDPattern.MatchString(id) {
				http.Error(w, "invalid sticker", 400)
				return
			}
			s.mu.Lock()
			allowed := s.stickerReadableLocked(user, id)
			s.mu.Unlock()
			if !allowed {
				http.Error(w, "forbidden", 403)
				return
			}
			w.Header().Set("X-Content-Type-Options", "nosniff")
			w.Header().Set("Cache-Control", "private, max-age=120")
			if strings.HasSuffix(id, ".jpg") {
				w.Header().Set("Content-Type", "image/jpeg")
			} else {
				w.Header().Set("Content-Type", "image/png")
			}
			http.ServeFile(w, r, filepath.Join(dir, id))
			return
		}
		s.mu.Lock()
		owned, favs := []Sticker{}, []Sticker{}
		for _, st := range s.db.Stickers {
			if st.Owner == user && !st.Removed {
				owned = append(owned, st)
			}
			if contains(s.db.StickerFavorites[user], st.ID) && !st.Removed {
				favs = append(favs, st)
			}
		}
		allowed := s.maySendStickersLocked(user)
		s.mu.Unlock()
		reply(w, 200, map[string]any{"can_upload": allowed, "can_send": allowed, "owned": owned, "favorites": favs, "limit_owned": stickerMaxOwned, "limit_favorites": stickerMaxFavorites})
		return
	}
	if r.Method != http.MethodPost {
		http.Error(w, "method", 405)
		return
	}
	if strings.HasPrefix(r.Header.Get("Content-Type"), "multipart/form-data") {
		// The server, not the browser, decides whether an account may upload.
		s.mu.Lock()
		allowed := s.maySendStickersLocked(user)
		count := 0
		for _, st := range s.db.Stickers {
			if st.Owner == user && !st.Removed {
				count++
			}
		}
		s.mu.Unlock()
		if !allowed {
			http.Error(w, "Badge Admin, Beta ou Explicit+ necessário", 403)
			return
		}
		if count >= stickerMaxOwned {
			http.Error(w, "Limite de 40 figurinhas", 409)
			return
		}
		r.Body = http.MaxBytesReader(w, r.Body, stickerMaxUpload+65536)
		if err = r.ParseMultipartForm(4 << 20); err != nil {
			http.Error(w, "Arquivo muito grande", 413)
			return
		}
		if r.MultipartForm != nil {
			defer r.MultipartForm.RemoveAll()
		}
		file, _, err := r.FormFile("image")
		if err != nil {
			http.Error(w, "Selecione uma imagem", 400)
			return
		}
		defer file.Close()
		content, err := io.ReadAll(io.LimitReader(file, stickerMaxUpload+1))
		if err != nil || len(content) == 0 || len(content) > stickerMaxUpload {
			http.Error(w, "Arquivo deve ter até 5 MB", 413)
			return
		}
		data, ext, width, height, err := makeSticker(content)
		if err != nil {
			http.Error(w, err.Error(), 415)
			return
		}
		var random [16]byte
		if _, err = rand.Read(random[:]); err != nil {
			http.Error(w, "random failure", 500)
			return
		}
		id := hex.EncodeToString(random[:]) + "." + ext
		if err = os.MkdirAll(dir, 0700); err != nil {
			log.Printf("STICKER STORAGE mkdir: %v", err)
			http.Error(w, "storage", 500)
			return
		}
		if !trustedStorageDirectory(filepath.Dir(s.file), "stickers") {
			http.Error(w, "invalid storage directory", 500)
			return
		}
		// O_EXCL prevents accidental overwrite.
		f, err := os.OpenFile(filepath.Join(dir, id), os.O_WRONLY|os.O_CREATE|os.O_EXCL, 0600)
		if err != nil {
			http.Error(w, "storage", 500)
			return
		}
		_, err = f.Write(data)
		closeErr := f.Close()
		if err == nil {
			err = closeErr
		}
		if err != nil {
			os.Remove(filepath.Join(dir, id))
			http.Error(w, "storage", 500)
			return
		}
		s.mu.Lock()
		defer s.mu.Unlock()
		count = 0
		for _, st := range s.db.Stickers {
			if st.Owner == user && !st.Removed {
				count++
			}
		}
		if !s.storageAllowedStagedLocked(user, int64(len(data))) {
			os.Remove(filepath.Join(dir, id))
			http.Error(w, "Limite de armazenamento atingido. Entre em contato com a equipe do Explicit.", http.StatusRequestEntityTooLarge)
			return
		}
		if !s.maySendStickersLocked(user) || count >= stickerMaxOwned {
			os.Remove(filepath.Join(dir, id))
			http.Error(w, "permission or limit", 403)
			return
		}
		entry := Sticker{ID: id, Owner: user, Created: time.Now().UTC(), Width: width, Height: height}
		s.db.Stickers = append(s.db.Stickers, entry)
		if err = s.save(); err != nil {
			s.db.Stickers = s.db.Stickers[:len(s.db.Stickers)-1]
			os.Remove(filepath.Join(dir, id))
			http.Error(w, "storage", 500)
			return
		}
		reply(w, 201, entry)
		return
	}
	var q struct {
		Action    string `json:"action"`
		ID        string `json:"id"`
		Community string `json:"community"`
		Channel   string `json:"channel"`
	}
	if parse(r, &q) != nil || !stickerIDPattern.MatchString(q.ID) {
		http.Error(w, "invalid request", 400)
		return
	}
	s.mu.Lock()
	defer s.mu.Unlock()
	entry := s.stickerByIDLocked(q.ID)
	if entry == nil {
		http.Error(w, "sticker not found", 404)
		return
	}
	switch q.Action {
	case "favorite":
		if entry.Removed || !s.stickerReadableLocked(user, q.ID) {
			http.Error(w, "sticker unavailable", 403)
			return
		}
		if contains(s.db.StickerFavorites[user], q.ID) {
			reply(w, 200, map[string]bool{"ok": true})
			return
		}
		if len(s.db.StickerFavorites[user]) >= stickerMaxFavorites {
			http.Error(w, "favorites full", 409)
			return
		}
		if s.db.StickerFavorites == nil {
			s.db.StickerFavorites = map[string][]string{}
		}
		s.db.StickerFavorites[user] = append(s.db.StickerFavorites[user], q.ID)
		if s.save() != nil {
			s.db.StickerFavorites[user] = s.db.StickerFavorites[user][:len(s.db.StickerFavorites[user])-1]
			http.Error(w, "storage", 500)
			return
		}
	case "unfavorite":
		old := append([]string(nil), s.db.StickerFavorites[user]...)
		a := []string{}
		for _, v := range old {
			if v != q.ID {
				a = append(a, v)
			}
		}
		s.db.StickerFavorites[user] = a
		if s.save() != nil {
			s.db.StickerFavorites[user] = old
			http.Error(w, "storage", 500)
			return
		}
	case "delete":
		if entry.Owner != user {
			http.Error(w, "only owner can delete", 403)
			return
		}
		if entry.Removed {
			reply(w, 200, map[string]bool{"ok": true})
			return
		}
		entry.Removed = true
		if s.save() != nil {
			entry.Removed = false
			http.Error(w, "storage", 500)
			return
		}
	case "send":
		if entry.Removed || !s.maySendStickersLocked(user) || !s.stickerReadableLocked(user, q.ID) || !s.stickerChannelAllowedLocked(user, q.Community, q.Channel) || !s.channelCanSend(q.Community, q.Channel, user) || !s.channelStickerAllowed(q.Community, q.Channel, user) {
			http.Error(w, "forbidden", 403)
			return
		}
		m := Message{ID: token()[:16], Channel: q.Community + ":" + q.Channel, Author: user, Sticker: q.ID, Time: time.Now().UTC()}
		oldNotifications := append([]AppNotification(nil), s.db.Notifications...)
		for _, c := range s.db.Communities {
			if c.ID == q.Community {
				s.notifyChannelMessageLocked(c, q.Channel, user, "Figurinha enviada")
				break
			}
		}
		s.db.Messages = append(s.db.Messages, m)
		if s.save() != nil {
			s.db.Messages = s.db.Messages[:len(s.db.Messages)-1]
			s.db.Notifications = oldNotifications
			http.Error(w, "storage", 500)
			return
		}
		encoded, _ := json.Marshal(m)
		for listener, recipient := range s.listeners {
			if s.canReceiveChannelEvent(q.Community, q.Channel, recipient) {
				select {
				case listener <- string(encoded):
				default:
				}
			}
		}
		reply(w, 201, m)
		return
	default:
		http.Error(w, "invalid action", 400)
		return
	}
	reply(w, 200, map[string]bool{"ok": true})
}
