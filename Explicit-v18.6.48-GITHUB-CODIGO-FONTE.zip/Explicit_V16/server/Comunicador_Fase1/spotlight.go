package main

import (
	"net/http"
	"net/url"
	"strings"
	"time"
)

type SpotlightRequest struct {
	ID       string    `json:"id"`
	Author   string    `json:"author"`
	Title    string    `json:"title"`
	VideoURL string    `json:"video_url"`
	Hours    int       `json:"hours"`
	Status   string    `json:"status"`
	At       time.Time `json:"at"`
}
type Spotlight struct {
	ID        string    `json:"id"`
	Title     string    `json:"title"`
	VideoURL  string    `json:"video_url"`
	Author    string    `json:"author"`
	CreatedBy string    `json:"created_by"`
	Start     time.Time `json:"start"`
	End       time.Time `json:"end"`
}

func validSpotlightURL(raw string) bool {
	u, e := url.Parse(raw)
	if e != nil || u.Scheme != "https" || u.User != nil || u.Port() != "" {
		return false
	}
	h := strings.ToLower(u.Hostname())
	return h == "youtube.com" || h == "www.youtube.com" || h == "youtu.be"
}
func validSpotlightInput(title, videoURL string, hours int) bool {
	title = strings.TrimSpace(title)
	return len(title) >= 3 && len(title) <= 100 && hours >= 1 && hours <= 48 && validSpotlightURL(videoURL)
}
func (s *Server) spotlightAPI(w http.ResponseWriter, r *http.Request) {
	user, err := s.auth(r)
	if err != nil {
		http.Error(w, "unauthorized", 401)
		return
	}
	s.mu.Lock()
	defer s.mu.Unlock()
	level := systemLevel(systemRole(s.db.Users[user]))
	now := time.Now().UTC()
	active := []Spotlight{}
	for _, v := range s.db.Spotlights {
		if !now.Before(v.Start) && now.Before(v.End) {
			active = append(active, v)
		}
	}
	if r.Method == http.MethodGet {
		if r.URL.Query().Get("requests") == "1" {
			if level < 1 {
				http.Error(w, "staff only", 403)
				return
			}
			reply(w, 200, s.db.SpotlightRequests)
			return
		}
		reply(w, 200, active)
		return
	}
	if r.Method != http.MethodPost {
		http.Error(w, "method", 405)
		return
	}
	var q struct {
		Action   string `json:"action"`
		ID       string `json:"id"`
		Title    string `json:"title"`
		VideoURL string `json:"video_url"`
		Author   string `json:"author"`
		Hours    int    `json:"hours"`
	}
	if parse(r, &q) != nil {
		http.Error(w, "invalid request", 400)
		return
	}
	if q.Action == "request" {
		if !validSpotlightInput(q.Title, q.VideoURL, q.Hours) {
			http.Error(w, "Título (3–100), URL HTTPS do YouTube e duração de 1–48 horas são obrigatórios", 400)
			return
		}
		pending := 0
		for _, v := range s.db.SpotlightRequests {
			if v.Author == user && v.Status == "pending" {
				pending++
			}
		}
		if pending >= 3 {
			http.Error(w, "Você já possui 3 solicitações aguardando análise", 429)
			return
		}
		if len(s.db.SpotlightRequests) >= 500 {
			http.Error(w, "Limite de solicitações atingido", 429)
			return
		}
		req := SpotlightRequest{ID: token()[:16], Author: user, Title: strings.TrimSpace(q.Title), VideoURL: q.VideoURL, Hours: q.Hours, Status: "pending", At: now}
		s.db.SpotlightRequests = append(s.db.SpotlightRequests, req)
		if s.save() != nil {
			s.db.SpotlightRequests = s.db.SpotlightRequests[:len(s.db.SpotlightRequests)-1]
			http.Error(w, "storage", 500)
			return
		}
		reply(w, 201, req)
		return
	}
	// Ações de publicação e revisão exigem administrador global.
	if level < 2 {
		http.Error(w, "admin only", 403)
		return
	}
	if q.Action == "resolve_request" || q.Action == "reject_request" || q.Action == "approve_request" {
		for i, v := range s.db.SpotlightRequests {
			if v.ID != q.ID {
				continue
			}
			if v.Status != "pending" {
				http.Error(w, "Solicitação já revisada", 409)
				return
			}
			if q.Action == "approve_request" && len(active) >= 5 {
				http.Error(w, "Limite de 5 divulgações ativas", 409)
				return
			}
			old := s.db.SpotlightRequests[i]
			if q.Action == "approve_request" {
				if !validSpotlightInput(v.Title, v.VideoURL, v.Hours) {
					http.Error(w, "invalid request data", 400)
					return
				}
				s.db.SpotlightRequests[i].Status = "approved"
				s.db.Spotlights = append(s.db.Spotlights, Spotlight{ID: token()[:16], Title: v.Title, VideoURL: v.VideoURL, Author: v.Author, CreatedBy: user, Start: now, End: now.Add(time.Duration(v.Hours) * time.Hour)})
			} else if q.Action == "reject_request" {
				s.db.SpotlightRequests[i].Status = "rejected"
			} else {
				s.db.SpotlightRequests[i].Status = "reviewed"
			}
			s.staffAuditLocked(user, "spotlight_"+q.Action, q.ID, v.Title)
			if s.save() != nil {
				s.db.SpotlightRequests[i] = old
				if q.Action == "approve_request" {
					s.db.Spotlights = s.db.Spotlights[:len(s.db.Spotlights)-1]
				}
				http.Error(w, "storage", 500)
				return
			}
			reply(w, 200, map[string]bool{"ok": true})
			return
		}
		http.Error(w, "not found", 404)
		return
	}
	if q.Action == "remove" {
		for i, v := range s.db.Spotlights {
			if v.ID == q.ID {
				old := append([]Spotlight(nil), s.db.Spotlights...)
				s.db.Spotlights = append(s.db.Spotlights[:i], s.db.Spotlights[i+1:]...)
				s.staffAuditLocked(user, "spotlight_remove", q.ID, v.Title)
				if s.save() != nil {
					s.db.Spotlights = old
					http.Error(w, "storage", 500)
					return
				}
				reply(w, 200, map[string]bool{"ok": true})
				return
			}
		}
		http.Error(w, "not found", 404)
		return
	}
	if q.Action != "add" || len(active) >= 5 || !validSpotlightInput(q.Title, q.VideoURL, q.Hours) || len(q.Author) > 60 {
		http.Error(w, "Título, URL HTTPS do YouTube, duração de 1–48h ou limite de 5 divulgações inválido", 400)
		return
	}
	v := Spotlight{ID: token()[:16], Title: strings.TrimSpace(q.Title), VideoURL: q.VideoURL, Author: strings.TrimSpace(q.Author), CreatedBy: user, Start: now, End: now.Add(time.Duration(q.Hours) * time.Hour)}
	s.db.Spotlights = append(s.db.Spotlights, v)
	s.staffAuditLocked(user, "spotlight_add", v.ID, v.Title)
	if s.save() != nil {
		s.db.Spotlights = s.db.Spotlights[:len(s.db.Spotlights)-1]
		http.Error(w, "storage", 500)
		return
	}
	reply(w, 201, v)
}
