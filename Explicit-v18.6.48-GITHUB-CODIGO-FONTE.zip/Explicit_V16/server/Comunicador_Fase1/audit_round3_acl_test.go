package main

import (
	"encoding/json"
	"testing"
)

func round3ChannelFixture(t *testing.T, manageRoles bool) *Server {
	t.Helper()
	s := auditFixture(t)
	c := &s.db.Communities[0]
	permissions := []string{"MANAGE_CHANNELS", "CREATE_CHANNEL"}
	if manageRoles {
		permissions = append(permissions, "MANAGE_ROLES")
	}
	c.Roles = []Role{{ID: "manager", Name: "Manager", Priority: 10, Permissions: permissions}}
	c.MemberRoles = map[string][]string{"member": {"manager"}}
	c.Categories = []ChannelCategory{{ID: "cat", Name: "Category", RolePermissions: map[string]map[string]bool{"everyone": {"SEND_MESSAGES": false}}}}
	return s
}

func TestAuditRound3ReorderSyncRequiresManageRoles(t *testing.T) {
	for _, canManage := range []bool{false, true} {
		t.Run(map[bool]string{false: "denied", true: "allowed"}[canManage], func(t *testing.T) {
			s := round3ChannelFixture(t, canManage)
			before, _ := json.Marshal(s.db.Communities[0])
			w := auditRequest(t, s, "member", "/api/channel-permissions", map[string]any{"community": "audit-community", "action": "channel_reorder", "channel": "geral", "category": "cat", "sync": true})
			if !canManage {
				if w.Code != 403 {
					t.Fatalf("sync without MANAGE_ROLES accepted: %d %s", w.Code, w.Body.String())
				}
				after, _ := json.Marshal(s.db.Communities[0])
				if string(before) != string(after) {
					t.Fatal("denied request changed state")
				}
			} else if w.Code != 200 || !s.db.Communities[0].ChannelMeta["geral"].Synced {
				t.Fatalf("authorized sync failed: %d %s", w.Code, w.Body.String())
			}
		})
	}
	// Moving without copying permissions remains available to channel managers.
	s := round3ChannelFixture(t, false)
	w := auditRequest(t, s, "member", "/api/channel-permissions", map[string]any{"community": "audit-community", "action": "channel_reorder", "channel": "geral", "category": "cat", "sync": false})
	if w.Code != 200 {
		t.Fatalf("ordinary reorder blocked: %d %s", w.Code, w.Body.String())
	}
}

func TestAuditRound3ChannelCreateCannotInheritUncheckedACL(t *testing.T) {
	for _, mode := range []string{"no_manage_roles", "above_own_grants", "authorized", "ordinary"} {
		t.Run(mode, func(t *testing.T) {
			s := round3ChannelFixture(t, mode != "no_manage_roles")
			c := &s.db.Communities[0]
			if mode == "above_own_grants" {
				c.Categories[0].RolePermissions = map[string]map[string]bool{"everyone": {"MUTE_MEMBERS": true}}
			}
			before, _ := json.Marshal(*c)
			w := auditRequest(t, s, "member", "/api/communities", map[string]any{"community": "audit-community", "channel": "new-voice", "type": "voice", "category": "cat", "sync": mode != "ordinary"})
			if mode == "no_manage_roles" || mode == "above_own_grants" {
				if w.Code != 403 {
					t.Fatalf("unchecked inherited ACL accepted: %d %s", w.Code, w.Body.String())
				}
				after, _ := json.Marshal(*c)
				if string(before) != string(after) {
					t.Fatal("denied request changed state")
				}
			} else if w.Code != 200 {
				t.Fatalf("authorized create failed: %d %s", w.Code, w.Body.String())
			}
		})
	}
}
