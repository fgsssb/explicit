package main

import (
	"bytes"
	"encoding/binary"
	"net/http"
	"net/http/httptest"
	"os"
	"path/filepath"
	"strings"
	"testing"
	"time"
)

func TestV18620StaticWebDoesNotServeTestSourcesOrDirectoryListings(t *testing.T) {
	for _, tc := range []struct {
		path   string
		public bool
	}{
		{"/", true}, {"/index.html", true}, {"/channel-sidebar.js", true}, {"/security-ui.css", true}, {"/vendor/livekit-client.umd.min.js", true},
		{"/media-src/realtime-events.test.js", false}, {"/vendor/", false}, {"/media-src/", false},
		{"/.env", false}, {"/something.map", false}, {"/fake.json", false}, {"/private.txt", false},
	} {
		if got := publicWebPath(tc.path); got != tc.public {
			t.Errorf("%s public=%v wanted %v", tc.path, got, tc.public)
		}
	}
	tmp := t.TempDir()
	_ = os.WriteFile(filepath.Join(tmp, "visible.js"), []byte("public"), 0600)
	_ = os.MkdirAll(filepath.Join(tmp, "media-src"), 0700)
	_ = os.WriteFile(filepath.Join(tmp, "media-src", "secret.test.js"), []byte("private"), 0600)
	h := secureWebAssets(tmp)
	for _, route := range []string{"/media-src/secret.test.js", "/media-src/", "/hidden.json"} {
		rec := httptest.NewRecorder()
		h.ServeHTTP(rec, httptest.NewRequest(http.MethodGet, route, nil))
		if rec.Code != 404 {
			t.Fatalf("leaked %s: %d", route, rec.Code)
		}
	}
	rec := httptest.NewRecorder()
	h.ServeHTTP(rec, httptest.NewRequest(http.MethodPost, "/visible.js", nil))
	if rec.Code != 405 {
		t.Fatal("static write request accepted")
	}
}
func TestV18620OriginFilterAndHeaders(t *testing.T) {
	s := newServer(filepath.Join(t.TempDir(), "store.json"))
	h := s.routes()
	for _, tc := range []struct {
		origin string
		want   int
	}{
		{"https://evil.example", 403}, {"null", 403}, {"https://explicit.example.evil.test", 403}, {"https://explicit.example", 401}, {"", 401},
	} {
		r := httptest.NewRequest(http.MethodGet, "http://explicit.example/api/ping", nil)
		if tc.origin != "" {
			r.Header.Set("Origin", tc.origin)
		}
		w := httptest.NewRecorder()
		h.ServeHTTP(w, r)
		if w.Code != tc.want {
			t.Fatalf("origin %q -> %d expected %d", tc.origin, w.Code, tc.want)
		}
		if w.Header().Get("X-Content-Type-Options") != "nosniff" || w.Header().Get("Cross-Origin-Resource-Policy") != "same-origin" {
			t.Fatal("missing security headers")
		}
	}
}
func TestV18620RepeatedSpamGuard(t *testing.T) {
	g := newResourceGuard()
	now := time.Now()
	for i := 0; i < 4; i++ {
		if g.excessiveRepeat("spammer", "  COMPRE! \n  Já!  ", now) {
			t.Fatal("blocked too early")
		}
	}
	if !g.excessiveRepeat("spammer", "compre! já!", now) {
		t.Fatal("identical text evaded spam guard")
	}
	if g.excessiveRepeat("friend", "compre! já!", now) {
		t.Fatal("different account blocked")
	}
	if g.excessiveRepeat("spammer", "compre! já!", now.Add(21*time.Second)) {
		t.Fatal("guard did not recover")
	}
	if !abusiveMessageText(strings.Repeat("@", 16)) || abusiveMessageText("ola mundo") {
		t.Fatal("mass mentions not detected")
	}
	for i := 0; i < controlBurst; i++ {
		if !g.allow("alice", "control", now) {
			t.Fatal("premature control cap")
		}
	}
	if g.allow("alice", "control", now) || !g.allow("bob", "control", now) {
		t.Fatal("control cap failure")
	}
}
func TestV18620WebPCanvasCap(t *testing.T) {
	payload := make([]byte, 30)
	copy(payload[:4], "RIFF")
	binary.LittleEndian.PutUint32(payload[4:8], 22)
	copy(payload[8:12], "WEBP")
	copy(payload[12:16], "VP8X")
	binary.LittleEndian.PutUint32(payload[16:20], 10)
	// 1920x1080, the values stored are dimension minus 1.
	w, h := 1919, 1079
	payload[24] = byte(w)
	payload[25] = byte(w >> 8)
	payload[26] = byte(w >> 16)
	payload[27] = byte(h)
	payload[28] = byte(h >> 8)
	payload[29] = byte(h >> 16)
	if !safeWebPDimensions(payload) {
		t.Fatal("ordinary WebP rejected")
	}
	payload[26] = 0xff
	if safeWebPDimensions(payload) {
		t.Fatal("huge canvas accepted")
	}
	if safeWebPDimensions(bytes.Repeat([]byte{0}, 64)) {
		t.Fatal("malformed WebP accepted")
	}
}
