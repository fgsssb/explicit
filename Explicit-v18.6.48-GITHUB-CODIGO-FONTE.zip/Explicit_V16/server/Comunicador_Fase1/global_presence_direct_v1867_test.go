package main

import (
	"bytes"
	"encoding/json"
	"net/http/httptest"
	"path/filepath"
	"testing"
)

func TestGlobalPresencePersistsAcrossCommunityNavigation(t *testing.T) {
	s := newServer(filepath.Join(t.TempDir(), "store.json"))
	s.db.Users["alice"] = User{Name: "alice", PreferredStatus: "away"}
	s.db.Users["bob"] = User{Name: "bob"}
	s.db.Communities = []Community{
		{ID: "first", Name: "First", Owner: "alice", Members: []string{"alice", "bob"}},
		{ID: "second", Name: "Second", Owner: "alice", Members: []string{"alice", "bob"}},
	}
	s.sessions["alice-session"] = "alice"
	s.sessions["bob-session"] = "bob"
	call := func(method, path, token, body string) *httptest.ResponseRecorder {
		r := httptest.NewRequest(method, path, bytes.NewBufferString(body))
		if token != "" {
			r.Header.Set("Authorization", "Bearer "+token)
		}
		w := httptest.NewRecorder()
		s.routes().ServeHTTP(w, r)
		return w
	}
	if r := call("POST", "/api/presence-heartbeat", "alice-session", `{"client":"device-1234"}`); r.Code != 200 {
		t.Fatal(r.Body.String())
	}
	for _, id := range []string{"first", "second"} {
		r := call("GET", "/api/presence?community="+id, "bob-session", "")
		if r.Code != 200 {
			t.Fatalf("presence in %s: %d", id, r.Code)
		}
		var data struct {
			Members []struct {
				User   string `json:"user"`
				Status string `json:"status"`
				Online bool   `json:"online"`
			} `json:"members"`
		}
		if err := json.Unmarshal(r.Body.Bytes(), &data); err != nil {
			t.Fatal(err)
		}
		if len(data.Members) == 0 || data.Members[0].Status != "away" || !data.Members[0].Online {
			t.Fatalf("not globally away in %s: %+v", id, data.Members)
		}
	}
	if r := call("POST", "/api/presence-heartbeat", "", `{"client":"device-1234"}`); r.Code != 401 {
		t.Fatalf("anonymous heartbeat %d", r.Code)
	}
	if r := call("POST", "/api/presence-heartbeat", "alice-session", `{"client":"device-1234","leaving":true}`); r.Code != 200 {
		t.Fatal(r.Body.String())
	}
	r := call("GET", "/api/presence?community=second", "bob-session", "")
	var state struct {
		Members []struct {
			Status string `json:"status"`
		} `json:"members"`
	}
	_ = json.Unmarshal(r.Body.Bytes(), &state)
	if state.Members[0].Status != "offline" {
		t.Fatalf("logout should remove this device's presence: %+v", state)
	}
}

func TestDirectListProvidesOnlyOwnUnreadNotices(t *testing.T) {
	s := newServer(filepath.Join(t.TempDir(), "store.json"))
	s.db.Users["alice"] = User{Name: "alice"}
	s.db.Users["bob"] = User{Name: "bob"}
	s.db.Users["mallory"] = User{Name: "mallory"}
	s.sessions["alice-token"] = "alice"
	s.sessions["bob-token"] = "bob"
	s.db.DirectChats = []DirectChat{{ID: "dm1", Users: []string{"alice", "bob"}, Visible: map[string]bool{"alice": true, "bob": true}}}
	s.enqueueNotificationLocked("alice", "direct", "bob", "", "", "hello")
	s.enqueueNotificationLocked("mallory", "direct", "bob", "", "", "secret")
	call := func(method, path, token, body string) *httptest.ResponseRecorder {
		r := httptest.NewRequest(method, path, bytes.NewBufferString(body))
		r.Header.Set("Authorization", "Bearer "+token)
		w := httptest.NewRecorder()
		s.routes().ServeHTTP(w, r)
		return w
	}
	list := func() []map[string]any {
		r := call("GET", "/api/direct", "alice-token", "")
		if r.Code != 200 {
			t.Fatal(r.Body.String())
		}
		var result []map[string]any
		if err := json.Unmarshal(r.Body.Bytes(), &result); err != nil {
			t.Fatal(err)
		}
		return result
	}
	if count := list()[0]["unread"].(float64); count != 1 {
		t.Fatalf("unread = %v", count)
	}
	if r := call("POST", "/api/notifications", "alice-token", `{"action":"read_direct","author":"bob"}`); r.Code != 200 {
		t.Fatal(r.Body.String())
	}
	if count := list()[0]["unread"].(float64); count != 0 {
		t.Fatalf("read DM badge not cleared: %v", count)
	}
	s.enqueueNotificationLocked("alice", "direct", "bob", "", "", "new")
	if count := list()[0]["unread"].(float64); count != 1 {
		t.Fatalf("new DM badge missing: %v", count)
	}
	if count := s.unreadNotificationsLocked("alice"); count != 1 {
		t.Fatalf("taskbar count not in sync: %v", count)
	}
}
