package main

import (
	"bufio"
	"context"
	"io"
	"net/http"
	"net/http/httptest"
	"strings"
	"testing"
	"time"
)

func TestAuditRound2SSERejectsRevokedSessionBeforeEvent(t *testing.T) {
	for _, mode := range []string{"logout", "expired", "banned"} {
		t.Run(mode, func(t *testing.T) {
			s := auditFixture(t)
			ts := httptest.NewServer(http.HandlerFunc(s.events))
			defer ts.Close()
			ctx, cancel := context.WithTimeout(context.Background(), 3*time.Second)
			defer cancel()
			req, err := http.NewRequestWithContext(ctx, "GET", ts.URL, nil)
			if err != nil {
				t.Fatal(err)
			}
			req.Header.Set("Authorization", "Bearer member-token")
			resp, err := ts.Client().Do(req)
			if err != nil {
				t.Fatal(err)
			}
			defer resp.Body.Close()
			if resp.StatusCode != 200 {
				t.Fatal(resp.StatusCode)
			}
			reader := bufio.NewReader(resp.Body)
			if line, err := reader.ReadString('\n'); err != nil || !strings.Contains(line, "connected") {
				t.Fatalf("handshake %q %v", line, err)
			}
			if _, err := reader.ReadString('\n'); err != nil {
				t.Fatal(err)
			}
			if mode == "logout" {
				logout := httptest.NewRequest("POST", "/api/logout", nil)
				logout.Header.Set("Authorization", "Bearer member-token")
				s.logout(httptest.NewRecorder(), logout)
			}
			s.mu.Lock()
			if mode == "expired" {
				s.sessionExpiry["member-token"] = time.Now().Add(-time.Second)
			}
			if mode == "banned" {
				u := s.db.Users["member"]
				u.BannedPermanent = true
				s.db.Users["member"] = u
			}
			for ch := range s.listeners {
				ch <- `{"id":"private-after-revocation","channel":"geral","text":"synthetic"}`
			}
			s.mu.Unlock()
			line, err := reader.ReadString('\n')
			if err != io.EOF || line != "" {
				t.Fatalf("revoked stream delivered event or failed to close: %q %v", line, err)
			}
		})
	}
}
