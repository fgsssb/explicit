package main

import (
	"net/http"
	"net/http/httptest"
	"path/filepath"
	"testing"
	"time"
)

func TestSessionExpiryAndLogout(t *testing.T) {
	s := newServer(filepath.Join(t.TempDir(), "store.json"))

	s.db.Users["alice"] = User{Name: "alice"}
	s.sessions["expired"] = "alice"
	s.sessionExpiry["expired"] = time.Now().Add(-time.Second)
	r := httptest.NewRequest(http.MethodGet, "/", nil)
	r.Header.Set("Authorization", "Bearer expired")
	if _, err := s.auth(r); err == nil {
		t.Fatal("expired session accepted")
	}
	if _, ok := s.sessions["expired"]; ok {
		t.Fatal("expired token not revoked")
	}
	s.sessions["valid"] = "alice"
	s.sessionExpiry["valid"] = time.Now().Add(time.Hour)
	r.Header.Set("Authorization", "Bearer valid")
	if u, err := s.auth(r); err != nil || u != "alice" {
		t.Fatalf("valid session rejected: %v", err)
	}
	w := httptest.NewRecorder()
	logoutRequest := httptest.NewRequest(http.MethodPost, "/api/logout", nil)
	logoutRequest.Header.Set("Authorization", "Bearer valid")
	s.logout(w, logoutRequest)
	if w.Code != http.StatusOK {
		t.Fatalf("logout status: %d", w.Code)
	}
	if _, err := s.auth(r); err == nil {
		t.Fatal("logged out token accepted")
	}
	if _, ok := s.sessionExpiry["valid"]; ok {
		t.Fatal("logout did not remove expiry")
	}
}
