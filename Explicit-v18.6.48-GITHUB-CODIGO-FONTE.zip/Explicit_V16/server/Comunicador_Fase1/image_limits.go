package main

import (
	"bytes"
	"encoding/binary"
)

// Parse WebP canvas size without allocating an image. Supports VP8, VP8L, VP8X.
func safeWebPDimensions(data []byte) bool {
	if len(data) < 30 || !bytes.Equal(data[:4], []byte("RIFF")) || !bytes.Equal(data[8:12], []byte("WEBP")) {
		return false
	}
	// RIFF size describes the payload after the first 8 bytes; tolerate padding.
	size := uint64(binary.LittleEndian.Uint32(data[4:8]))
	if size+8 > uint64(len(data)) || size < 22 {
		return false
	}
	payload := data[20:]
	w, h := 0, 0
	switch string(data[12:16]) {
	case "VP8X":
		if len(payload) < 10 || binary.LittleEndian.Uint32(data[16:20]) < 10 {
			return false
		}
		w = 1 + int(payload[4]) + (int(payload[5]) << 8) + (int(payload[6]) << 16)
		h = 1 + int(payload[7]) + (int(payload[8]) << 8) + (int(payload[9]) << 16)
	case "VP8L":
		if len(payload) < 5 || payload[0] != 0x2f {
			return false
		}
		w = 1 + int(payload[1]) + (int(payload[2]&0x3f) << 8)
		h = 1 + int(payload[2]>>6) + (int(payload[3]) << 2) + (int(payload[4]&0x0f) << 10)
	case "VP8 ":
		if len(payload) < 10 || payload[3] != 0x9d || payload[4] != 0x01 || payload[5] != 0x2a {
			return false
		}
		w = int(binary.LittleEndian.Uint16(payload[6:8]) & 0x3fff)
		h = int(binary.LittleEndian.Uint16(payload[8:10]) & 0x3fff)
	default:
		return false
	}
	return w > 0 && h > 0 && w <= 8192 && h <= 8192 && int64(w)*int64(h) <= 24000000
}
