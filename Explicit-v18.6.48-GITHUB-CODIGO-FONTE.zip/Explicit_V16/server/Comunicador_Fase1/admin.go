package main

import (
	"encoding/json"
	"log/slog"
	"net/http"
	"regexp"
	"sort"
	"strings"
	"time"
)

var roleColorPattern = regexp.MustCompile(`^#[0-9a-fA-F]{6}$`)
var basePermissions = []string{"VIEW_CHANNEL", "SEND_MESSAGES", "CONNECT_VOICE", "SPEAK", "USE_PTT", "SCREEN_SHARE", "VIEW_INVITES", "EDIT_OWN_MESSAGES", "DELETE_OWN_MESSAGES", "ATTACH_FILES", "USE_STICKERS"}
var validPermissions = map[string]bool{"VIEW_CHANNEL": true, "SEND_MESSAGES": true, "CONNECT_VOICE": true, "SPEAK": true, "USE_PTT": true, "SCREEN_SHARE": true, "CREATE_CHANNEL": true, "MANAGE_CHANNELS": true, "MANAGE_COMMUNITY": true, "MANAGE_ROLES": true, "ASSIGN_ROLES": true, "MANAGE_MEMBERS": true, "CREATE_INVITES": true, "VIEW_INVITES": true, "MUTE_MEMBERS": true, "DEAFEN_MEMBERS": true, "MOVE_MEMBERS": true, "DISCONNECT_VOICE": true, "KICK_MEMBERS": true, "BAN_MEMBERS": true, "BAN_CHANNEL_MEMBERS": true, "MANAGE_SANCTIONS": true, "EDIT_OWN_MESSAGES": true, "DELETE_OWN_MESSAGES": true, "EDIT_ANY_MESSAGES": true, "DELETE_ANY_MESSAGES": true, "PIN_MESSAGES": true, "ADMINISTRATOR": true, "ATTACH_FILES": true, "USE_STICKERS": true, "POKE_MEMBERS": true, "VIEW_AUDIT_LOG": true}

func (c Community) channelType(ch string) string {
	if m, ok := c.ChannelMeta[ch]; ok && m.Type == "voice" {
		return "voice"
	}
	return "text"
}
func (s *Server) hasPermission(c Community, user, permission string) bool {
	if s.isSuperadmin(user) {
		return true
	}
	if !contains(c.Members, user) {
		return false
	}
	if c.Owner == user {
		return true
	}
	if contains(basePermissions, permission) {
		return true
	}
	for _, id := range c.MemberRoles[user] {
		for _, role := range c.Roles {
			if role.ID == id && (contains(role.Permissions, permission) || contains(role.Permissions, "ADMINISTRATOR")) {
				return true
			}
		}
	}
	return false
}

// Permission resolution: community baseline -> @everyone -> combined role overrides
// -> member-specific override. At each tier, allow wins over deny among roles.
// A per-member decision always takes precedence, and only real community members qualify.
// System superadmins, community owner and community ADMINISTRATOR bypass channel overrides.
func (s *Server) channelPermission(c Community, user, channel, permission string) bool {
	if s.isSuperadmin(user) {
		return true
	}
	if !contains(c.Members, user) {
		return false
	}
	if !contains(c.Channels, channel) {
		return false
	}
	if c.Owner == user {
		return true
	}
	for _, role := range c.Roles {
		if contains(c.MemberRoles[user], role.ID) && contains(role.Permissions, "ADMINISTRATOR") {
			return true
		}
	}
	meta, ok := c.ChannelMeta[channel]
	if !ok {
		return false
	}
	allowed := s.hasPermission(c, user, permission)
	if v, ok := meta.RolePermissions["everyone"][permission]; ok {
		allowed = v
	}
	hasAllow, hasDeny := false, false
	for _, roleID := range c.MemberRoles[user] {
		if v, ok := meta.RolePermissions[roleID][permission]; ok {
			if v {
				hasAllow = true
			} else {
				hasDeny = true
			}
		}
	}
	if hasAllow {
		allowed = true
	} else if hasDeny {
		allowed = false
	}
	if v, ok := meta.MemberPermissions[user][permission]; ok {
		allowed = v
	}
	return allowed
}
func (s *Server) canSend(id, user string) bool {
	for _, c := range s.db.Communities {
		if c.ID == id {
			return s.hasPermission(c, user, "SEND_MESSAGES")
		}
	}
	return false
}
func (s *Server) communityAdmin(w http.ResponseWriter, r *http.Request) {
	user, err := s.auth(r)
	if err != nil {
		http.Error(w, "unauthorized", 401)
		return
	}
	var q struct {
		Community   string   `json:"community"`
		Action      string   `json:"action"`
		Name        string   `json:"name"`
		Role        string   `json:"role"`
		Target      string   `json:"target"`
		Color       string   `json:"color"`
		Priority    int      `json:"priority"`
		Permissions []string `json:"permissions"`
	}
	if r.Method == "GET" {
		q.Community = r.URL.Query().Get("community")
		q.Action = "info"
	} else if r.Method == "POST" {
		if parse(r, &q) != nil {
			http.Error(w, "invalid", 400)
			return
		}
	} else {
		http.Error(w, "method", 405)
		return
	}
	s.mu.Lock()
	defer s.mu.Unlock()
	for i := range s.db.Communities {
		c := &s.db.Communities[i]
		if c.ID != q.Community {
			continue
		}
		if !contains(c.Members, user) && !s.isSuperadmin(user) {
			http.Error(w, "forbidden", 403)
			return
		}
		if q.Role == "everyone" && q.Action != "info" {
			http.Error(w, "@everyone is immutable", http.StatusForbidden)
			return
		}
		// Role changes alter slices, nested maps and permissions. Snapshot them as
		// a unit: failed writes must not leave newly granted privileges in RAM.
		var previousCommunity []byte
		if q.Action != "info" {
			previousCommunity, err = json.Marshal(*c)
			if err != nil {
				http.Error(w, "storage snapshot failed", http.StatusInternalServerError)
				return
			}
		}
		rollback := func() {
			if len(previousCommunity) > 0 {
				var restored Community
				if restoreErr := json.Unmarshal(previousCommunity, &restored); restoreErr != nil {
					// A valid snapshot was produced immediately before mutation.
					// Fail loudly rather than continue with potentially unsafe grants.
					panic("cannot restore community after persistence failure: " + restoreErr.Error())
				}
				*c = restored // Replace maps, do not merge keys with json.Unmarshal.
			}
		}
		switch q.Action {
		case "info":
			visible := s.visibleCommunity(*c, user)
			if s.hasPermission(*c, user, "MANAGE_CHANNELS") {
				visible = *c
			}
			reply(w, 200, map[string]any{"id": c.ID, "name": c.Name, "owner": c.Owner, "members": c.Members, "roles": c.Roles, "member_roles": c.MemberRoles, "permissions": s.userPermissions(*c, user), "channel_meta": visible.ChannelMeta, "categories": visible.Categories})
			return
		case "create_role":
			if !s.hasPermission(*c, user, "MANAGE_ROLES") {
				break
			}
			if strings.EqualFold(strings.TrimSpace(q.Name), "@everyone") || len(strings.TrimSpace(q.Name)) < 2 || len(q.Name) > 32 || len(c.Roles) >= 50 {
				http.Error(w, "invalid role", 400)
				return
			}
			for _, perm := range q.Permissions {
				if !validPermissions[perm] {
					http.Error(w, "invalid permission", 400)
					return
				}
			}
			if q.Color == "" {
				q.Color = "#8DD8FF"
			}
			if !roleColorPattern.MatchString(q.Color) || q.Color[0] != '#' {
				http.Error(w, "invalid color", 400)
				return
			}
			if q.Priority < 0 || q.Priority > 100 {
				http.Error(w, "invalid priority", 400)
				return
			}
			if c.Owner != user && !s.isSuperadmin(user) && (q.Priority >= s.maxPriority(*c, user) || !s.canGrantPermissions(*c, user, q.Permissions)) {
				http.Error(w, "hierarchy", 403)
				return
			}
			role := Role{ID: token()[:12], Name: q.Name, Color: q.Color, Priority: q.Priority, Permissions: q.Permissions}
			c.Roles = append(c.Roles, role)
			if s.save() != nil {
				rollback()
				http.Error(w, "storage failure", 500)
				return
			}
			s.appendAudit(c.ID, user, "Cargo criado", role.Name)
			slog.Info("role.created", "actor", user, "community", c.ID, "role", role.ID)
			reply(w, 201, role)
			return
		case "update_role", "reorder_role":
			if !s.hasPermission(*c, user, "MANAGE_ROLES") {
				break
			}
			idx := -1
			for j := range c.Roles {
				if c.Roles[j].ID == q.Role {
					idx = j
					break
				}
			}
			if idx < 0 {
				http.Error(w, "role not found", 404)
				return
			}
			existing := c.Roles[idx]
			if c.Owner != user && !s.isSuperadmin(user) && existing.Priority >= s.maxPriority(*c, user) {
				http.Error(w, "hierarchy", 403)
				return
			}
			if q.Priority < 0 || q.Priority > 100 || (c.Owner != user && !s.isSuperadmin(user) && q.Priority >= s.maxPriority(*c, user)) {
				http.Error(w, "invalid priority", 400)
				return
			}
			if q.Action == "update_role" {
				if strings.EqualFold(strings.TrimSpace(q.Name), "@everyone") || len(strings.TrimSpace(q.Name)) < 2 || len(q.Name) > 32 || !roleColorPattern.MatchString(q.Color) {
					http.Error(w, "invalid role", 400)
					return
				}
				for _, perm := range q.Permissions {
					if !validPermissions[perm] {
						http.Error(w, "invalid permission", 400)
						return
					}
				}
				if c.Owner != user && !s.isSuperadmin(user) && !s.canGrantPermissions(*c, user, q.Permissions) {
					http.Error(w, "cannot grant permissions you do not have", 403)
					return
				}
				c.Roles[idx].Name = strings.TrimSpace(q.Name)
				c.Roles[idx].Color = q.Color
				c.Roles[idx].Permissions = q.Permissions
			}
			c.Roles[idx].Priority = q.Priority
			if err := s.save(); err != nil {
				rollback()
				http.Error(w, "storage failure", 500)
				return
			}
			s.appendAudit(c.ID, user, "Cargo alterado", q.Role+" / "+q.Action)
			slog.Info("role.updated", "actor", user, "role", q.Role, "action", q.Action)
			reply(w, 200, c.Roles[idx])
			return
		case "assign_role", "remove_role":
			if !s.hasPermission(*c, user, "ASSIGN_ROLES") {
				break
			}
			if !contains(c.Members, q.Target) || q.Target == c.Owner && !s.isSuperadmin(user) {
				http.Error(w, "invalid target", 403)
				return
			}
			var role *Role
			for j := range c.Roles {
				if c.Roles[j].ID == q.Role {
					role = &c.Roles[j]
					break
				}
			}
			if role == nil {
				http.Error(w, "role not found", 404)
				return
			}
			if c.Owner != user && !s.isSuperadmin(user) && (role.Priority >= s.maxPriority(*c, user) || s.maxPriority(*c, q.Target) >= s.maxPriority(*c, user) || (q.Action == "assign_role" && !s.canGrantPermissions(*c, user, role.Permissions))) {
				http.Error(w, "hierarchy", 403)
				return
			}
			if c.MemberRoles == nil {
				c.MemberRoles = map[string][]string{}
			}
			if q.Action == "assign_role" {
				if !contains(c.MemberRoles[q.Target], q.Role) {
					c.MemberRoles[q.Target] = append(c.MemberRoles[q.Target], q.Role)
				}
			} else {
				out := []string{}
				for _, id := range c.MemberRoles[q.Target] {
					if id != q.Role {
						out = append(out, id)
					}
				}
				c.MemberRoles[q.Target] = out
			}
			if s.save() != nil {
				rollback()
				http.Error(w, "storage failure", 500)
				return
			}
			s.appendAudit(c.ID, user, "Cargo atribuído/removido", q.Action+" / "+q.Target+" / "+q.Role)
			slog.Info("role.membership", "actor", user, "target", q.Target, "role", q.Role, "action", q.Action)
			reply(w, 200, map[string]bool{"ok": true})
			return
		case "delete_role":
			if !s.hasPermission(*c, user, "MANAGE_ROLES") {
				break
			}
			idx := -1
			for j, role := range c.Roles {
				if role.ID == q.Role {
					idx = j
					if c.Owner != user && !s.isSuperadmin(user) && role.Priority >= s.maxPriority(*c, user) {
						http.Error(w, "hierarchy", 403)
						return
					}
					break
				}
			}
			if idx < 0 {
				http.Error(w, "not found", 404)
				return
			}
			c.Roles = append(c.Roles[:idx], c.Roles[idx+1:]...)
			for member, ids := range c.MemberRoles {
				next := []string{}
				for _, id := range ids {
					if id != q.Role {
						next = append(next, id)
					}
				}
				c.MemberRoles[member] = next
			}
			if s.save() != nil {
				rollback()
				http.Error(w, "storage failure", 500)
				return
			}
			s.appendAudit(c.ID, user, "Cargo excluído", q.Role)
			slog.Info("role.deleted", "actor", user, "role", q.Role)
			reply(w, 200, map[string]bool{"ok": true})
			return
		}
		http.Error(w, "forbidden", 403)
		return
	}
	http.Error(w, "not found", 404)
}
func (s *Server) canGrantPermissions(c Community, actor string, permissions []string) bool {
	if actor == c.Owner {
		return true
	}
	for _, permission := range permissions {
		if !validPermissions[permission] || !s.hasPermission(c, actor, permission) {
			return false
		}
	}
	return true
}
func (s *Server) maxPriority(c Community, user string) int {
	if c.Owner == user {
		return 1000
	}
	n := 0
	for _, r := range c.Roles {
		if contains(c.MemberRoles[user], r.ID) && r.Priority > n {
			n = r.Priority
		}
	}
	return n
}
func (s *Server) userPermissions(c Community, user string) []string {
	out := []string{}
	for p := range validPermissions {
		if s.hasPermission(c, user, p) {
			out = append(out, p)
		}
	}
	sort.Strings(out)
	return out
}

// Browser session heartbeat is separate from the voice lease.
var online = struct {
	entries     map[string]map[string]time.Time
	background  map[string]map[string]bool
	sessionKeys map[string]map[string]string
}{entries: map[string]map[string]time.Time{}, background: map[string]map[string]bool{}, sessionKeys: map[string]map[string]string{}}

// Each authenticated account may have multiple clients, but client identifiers
// arrive from the renderer and cannot be allowed to grow this map without bound.
const maxPresenceClientsPerUser = 16

// Caller holds s.mu. The notification pseudo-client namespace is reserved.
func (s *Server) updatePresenceClientLocked(user, client, authorization string, background bool) {
	if online.entries[user] == nil {
		online.entries[user] = make(map[string]time.Time)
	}
	if online.background[user] == nil {
		online.background[user] = make(map[string]bool)
	}
	if online.sessionKeys[user] == nil {
		online.sessionKeys[user] = make(map[string]string)
	}
	if _, exists := online.entries[user][client]; !exists {
		count := 0
		oldestClient := ""
		var oldest time.Time
		for id, at := range online.entries[user] {
			if strings.HasPrefix(id, "notifications:") {
				continue
			}
			count++
			if oldestClient == "" || at.Before(oldest) {
				oldest, oldestClient = at, id
			}
		}
		if count >= maxPresenceClientsPerUser && oldestClient != "" {
			delete(online.entries[user], oldestClient)
			delete(online.background[user], oldestClient)
			delete(online.sessionKeys[user], oldestClient)
		}
	}
	online.entries[user][client] = time.Now()
	online.background[user][client] = background
	online.sessionKeys[user][client] = notificationPresenceKey(authorization)
}

// Account-wide session heartbeat. Visiting Home or a DM must not make the
// account disappear from every community's online list.
func (s *Server) presenceHeartbeatAPI(w http.ResponseWriter, r *http.Request) {
	user, err := s.auth(r)
	if err != nil {
		http.Error(w, "unauthorized", http.StatusUnauthorized)
		return
	}
	if r.Method != http.MethodPost {
		http.Error(w, "method", http.StatusMethodNotAllowed)
		return
	}
	var q struct {
		Client     string `json:"client"`
		Leaving    bool   `json:"leaving"`
		Background bool   `json:"background"`
	}
	if parse(r, &q) != nil || len(q.Client) < 8 || len(q.Client) > 100 || strings.HasPrefix(q.Client, "notifications:") {
		http.Error(w, "invalid client", 400)
		return
	}
	s.mu.Lock()
	defer s.mu.Unlock()
	if q.Leaving {
		// A real exit ends this authenticated session's presence on every
		// community. Remove any clients left by reloads of the same session,
		// but never disconnect another browser/app session of this user.
		sessionKey := notificationPresenceKey(r.Header.Get("Authorization"))
		delete(online.entries[user], sessionKey)
		for client, key := range online.sessionKeys[user] {
			if key == sessionKey {
				delete(online.entries[user], client)
				delete(online.background[user], client)
				delete(online.sessionKeys[user], client)
			}
		}
		if len(online.entries[user]) == 0 {
			delete(online.entries, user)
			delete(online.background, user)
			delete(online.sessionKeys, user)
		}
	} else {
		s.updatePresenceClientLocked(user, q.Client, r.Header.Get("Authorization"), q.Background)
	}
	reply(w, 200, map[string]bool{"ok": true})
}

func (s *Server) presenceAPI(w http.ResponseWriter, r *http.Request) {
	user, err := s.auth(r)
	if err != nil {
		http.Error(w, "unauthorized", 401)
		return
	}
	community := r.URL.Query().Get("community")
	s.mu.Lock()
	defer s.mu.Unlock()
	var c *Community
	for i := range s.db.Communities {
		if s.db.Communities[i].ID == community {
			c = &s.db.Communities[i]
			break
		}
	}
	if c == nil || (!contains(c.Members, user) && !s.isSuperadmin(user)) {
		http.Error(w, "forbidden", 403)
		return
	}
	if r.Method == "POST" {
		var q struct {
			Client string `json:"client"`
		}
		if parse(r, &q) != nil || len(q.Client) < 8 || len(q.Client) > 100 || strings.HasPrefix(q.Client, "notifications:") {
			http.Error(w, "invalid client", 400)
			return
		}
		s.updatePresenceClientLocked(user, q.Client, r.Header.Get("Authorization"), false)
	}
	if r.Method != "POST" && r.Method != "GET" {
		http.Error(w, "method", 405)
		return
	}
	now := time.Now()
	members := []map[string]any{}
	for _, name := range c.Members {
		// No inactivity timeout: once authenticated, an unresponsive/background
		// session stays Away (even after hours). Only explicit exit/logout or a
		// user-selected Offline status removes/hides it; returning refreshes Online.
		foreground, away, directClient := false, false, false
		for client, t := range online.entries[name] {
			elapsed := now.Sub(t)
			if !strings.HasPrefix(client, "notifications:") {
				directClient = true
				if elapsed <= 16*time.Second && !online.background[name][client] {
					foreground = true
				} else {
					away = true
				}
			}
		}
		// Old clients without a dedicated heartbeat still signal via notifications.
		if !directClient {
			for client, t := range online.entries[name] {
				if strings.HasPrefix(client, "notifications:") && now.Sub(t) <= 16*time.Second {
					foreground = true
				}
				if strings.HasPrefix(client, "notifications:") && now.Sub(t) > 16*time.Second {
					away = true
				}
			}
		}
		connected := foreground || away
		status := publicStatus(s.db.Users[name], connected)
		if !foreground && connected && status == "online" {
			status = "away"
		}
		members = append(members, map[string]any{"user": name, "display_name": s.displayName(name), "online": connected && s.db.Users[name].PreferredStatus != "offline", "status": status, "roles": c.MemberRoles[name], "owner": name == c.Owner, "system_role": systemRole(s.db.Users[name]), "avatar": s.db.Users[name].Avatar, "beta": s.db.Users[name].Beta, "explicit_plus": explicitPlusActive(s.db.Users[name])})
	}
	reply(w, 200, map[string]any{"members": members})
}

func (s *Server) displayName(user string) string {
	u, ok := s.db.Users[user]
	if ok && u.DisplayName != "" {
		return u.DisplayName
	}
	return user
}
