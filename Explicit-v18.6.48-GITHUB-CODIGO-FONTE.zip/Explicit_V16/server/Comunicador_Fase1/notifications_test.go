package main

import (
	"bytes"
	"encoding/json"
	"net/http/httptest"
	"path/filepath"
	"strconv"
	"testing"
)

func TestNotifyMentionsRolesAndEveryone(t *testing.T) {
	s := newServer(filepath.Join(t.TempDir(), "db.json"))
	for _, u := range []string{"ana", "bia", "carol", "davi"} {
		s.db.Users[u] = User{Name: u}
	}
	c := Community{ID: "c", Owner: "ana", Members: []string{"ana", "bia", "carol", "davi"}, Channels: []string{"geral"}, Roles: []Role{{ID: "mods", Name: "Minha Staff"}}, MemberRoles: map[string][]string{"bia": {"mods"}, "carol": {"mods"}}, ChannelMeta: map[string]ChannelMeta{"geral": {Type: "text"}}}
	s.db.Communities = []Community{c}
	got := s.channelMentionTargets(c, "ana", "Ei @{Minha Staff} @davi")
	if !got["bia"] || !got["carol"] || !got["davi"] || got["ana"] {
		t.Fatalf("role and user mention: %#v", got)
	}
	got = s.channelMentionTargets(c, "ana", "@everyone")
	if len(got) != 3 {
		t.Fatalf("everyone expected 3, got %#v", got)
	}
	s.notifyChannelMessageLocked(c, "geral", "ana", "@{Minha Staff} oi")
	kinds := map[string]string{}
	for _, n := range s.db.Notifications {
		kinds[n.User] = n.Kind
	}
	if kinds["bia"] != "mention" || kinds["carol"] != "mention" || kinds["davi"] != "message" {
		t.Fatalf("wrong kind %#v", kinds)
	}
}
func TestNotifyPrivateAccessAndPreferencesPersistence(t *testing.T) {
	s := newServer(filepath.Join(t.TempDir(), "db.json"))
	for _, u := range []string{"owner", "ana", "bia"} {
		s.db.Users[u] = User{Name: u}
		s.sessions[u+"-token"] = u
	}
	c := Community{ID: "c", Owner: "owner", Members: []string{"owner", "ana", "bia"},
		Channels: []string{"geral", "secreto"}, ChannelMeta: map[string]ChannelMeta{
			"geral":   {Type: "text"},
			"secreto": {Type: "text", RolePermissions: map[string]map[string]bool{"everyone": {"VIEW_CHANNEL": false}}, MemberPermissions: map[string]map[string]bool{"ana": {"VIEW_CHANNEL": true}}},
		},
	}
	s.db.Communities = []Community{c}
	s.enqueueNotificationLocked("ana", "mention", "owner", "c", "secreto", "@ana oi")
	s.enqueueNotificationLocked("bia", "mention", "owner", "c", "secreto", "@bia segredo")
	s.enqueueNotificationLocked("bia", "message", "ana", "c", "geral", "olá")
	if err := s.save(); err != nil {
		t.Fatal(err)
	}
	call := func(method, path, user string, body any) *httptest.ResponseRecorder {
		t.Helper()
		b, _ := json.Marshal(body)
		req := httptest.NewRequest(method, path, bytes.NewReader(b))
		req.Header.Set("Authorization", "Bearer "+user+"-token")
		w := httptest.NewRecorder()
		s.routes().ServeHTTP(w, req)
		return w
	}
	for _, tc := range []struct{ user, expect string }{{"ana", "@ana oi"}, {"bia", "olá"}} {
		w := call("GET", "/api/notifications?after=1", tc.user, nil)
		if w.Code != 200 {
			t.Fatalf("get %d %s", w.Code, w.Body.String())
		}
		var data struct {
			Items  []AppNotification `json:"items"`
			Cursor string            `json:"cursor"`
		}
		if err := json.Unmarshal(w.Body.Bytes(), &data); err != nil {
			t.Fatal(err)
		}
		if len(data.Items) != 1 || data.Items[0].Text != tc.expect {
			t.Fatalf("private leak: %s %s", tc.user, w.Body.String())
		}
		if _, err := strconv.ParseInt(data.Cursor, 10, 64); err != nil {
			t.Fatal(err)
		}
	}
	prefs := defaultNotifyPrefs()
	prefs.MessageMode = "mentions"
	prefs.VoiceJoin = false
	if w := call("PUT", "/api/notifications", "bia", prefs); w.Code != 200 {
		t.Fatalf("put %d %s", w.Code, w.Body.String())
	}
	if got := userNotifyPrefs(newServer(s.file).db.Users["bia"]); got.MessageMode != "mentions" || got.VoiceJoin {
		t.Fatalf("not saved %#v", got)
	}
	if w := call("GET", "/api/notifications?after=1", "invalid", nil); w.Code != 401 {
		t.Fatalf("auth leak %d", w.Code)
	}
}

func TestNotifyFromActualChannelMessageAndNoDuplicates(t *testing.T) {
	s := newServer(filepath.Join(t.TempDir(), "store.json"))
	for _, u := range []string{"ana", "bia", "carol"} {
		s.db.Users[u] = User{Name: u}
	}
	s.db.Communities = []Community{{ID: "community", Owner: "ana", Members: []string{"ana", "bia", "carol"}, Channels: []string{"geral"}, ChannelMeta: map[string]ChannelMeta{"geral": {Type: "text"}}}}
	s.sessions["test-anatoken"] = "ana"
	payload := map[string]any{"text": "@bia mensagem de teste", "client_id": "11111111-1111-4111-8111-000000000012"}
	b, _ := json.Marshal(payload)
	send := func() *httptest.ResponseRecorder {
		req := httptest.NewRequest("POST", "/api/channel-messages?community=community&channel=geral", bytes.NewReader(b))
		req.Header.Set("Authorization", "Bearer test-anatoken")
		w := httptest.NewRecorder()
		s.routes().ServeHTTP(w, req)
		return w
	}
	if w := send(); w.Code != 201 {
		t.Fatalf("send %d: %s", w.Code, w.Body.String())
	}
	if len(s.db.Notifications) != 2 {
		t.Fatalf("expected exactly 2 notifications, got %d", len(s.db.Notifications))
	}
	result := map[string]string{}
	for _, n := range s.db.Notifications {
		result[n.User] = n.Kind
	}
	if result["bia"] != "mention" || result["carol"] != "message" {
		t.Fatalf("unexpected categories: %#v", result)
	}
	if w := send(); w.Code != 200 {
		t.Fatalf("dedup %d: %s", w.Code, w.Body.String())
	}
	if len(s.db.Notifications) != 2 {
		t.Fatalf("retry generated extra notifications: %d", len(s.db.Notifications))
	}
}
