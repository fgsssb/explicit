@echo off
cd /d "%~dp0"
if not exist "ExplicitServer.exe" (
 echo ERRO: ExplicitServer.exe nao encontrado nesta pasta.
 pause
 exit /b 1
)
"%~dp0ExplicitServer.exe"
pause
