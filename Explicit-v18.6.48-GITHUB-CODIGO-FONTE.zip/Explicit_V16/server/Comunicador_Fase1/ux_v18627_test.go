package main

import (
	"encoding/json"
	"net/http"
	"net/http/httptest"
	"strings"
	"testing"
	"time"
)

func TestDirectMessageEditPinDeleteOwnerOnly(t *testing.T) {
	s := newServer(t.TempDir() + "/state.json")
	s.mu.Lock()
	for _, n := range []string{"alice", "bob", "outsider"} {
		s.db.Users[n] = User{Name: n, DisplayName: n}
		s.sessions["token-"+n] = n
	}
	s.db.DirectChats = []DirectChat{{ID: "dm-test", Users: []string{"alice", "bob"}, Visible: map[string]bool{"alice": true, "bob": true}, Messages: []DirectMessage{{ID: "msg-1", Author: "alice", Text: "olá", Time: time.Now()}}}}
	s.mu.Unlock()
	call := func(user, body string) *httptest.ResponseRecorder {
		r := httptest.NewRequest(http.MethodPost, "/api/direct", strings.NewReader(body))
		r.Header.Set("Authorization", "Bearer token-"+user)
		w := httptest.NewRecorder()
		s.routes().ServeHTTP(w, r)
		return w
	}
	if w := call("outsider", `{"action":"delete_message","id":"dm-test","message_id":"msg-1"}`); w.Code != 404 {
		t.Fatalf("outsider delete: %d", w.Code)
	}
	if w := call("bob", `{"action":"edit_message","id":"dm-test","message_id":"msg-1","text":"invadido"}`); w.Code != 403 {
		t.Fatalf("not author edit: %d", w.Code)
	}
	if w := call("alice", `{"action":"edit_message","id":"dm-test","message_id":"msg-1","text":"olá editado"}`); w.Code != 200 {
		t.Fatalf("author edit: %d %s", w.Code, w.Body.String())
	}
	if w := call("bob", `{"action":"pin_message","id":"dm-test","message_id":"msg-1"}`); w.Code != 200 {
		t.Fatalf("member pin: %d", w.Code)
	}
	s.mu.Lock()
	msg := s.db.DirectChats[0].Messages[0]
	s.mu.Unlock()
	if msg.Text != "olá editado" || msg.EditedAt == nil || !msg.Pinned {
		t.Fatalf("edit and pin %+v", msg)
	}
	if w := call("alice", `{"action":"delete_message","id":"dm-test","message_id":"msg-1"}`); w.Code != 200 {
		t.Fatalf("delete: %d", w.Code)
	}
	r := httptest.NewRequest(http.MethodGet, "/api/direct?id=dm-test", nil)
	r.Header.Set("Authorization", "Bearer token-bob")
	w := httptest.NewRecorder()
	s.routes().ServeHTTP(w, r)
	var data DirectChat
	if err := json.Unmarshal(w.Body.Bytes(), &data); err != nil || len(data.Messages) != 0 {
		t.Fatalf("deleted message exposed: %s (%v)", w.Body.String(), err)
	}
}

func TestRegistrationKeyVisibilityAndInvitesHaveACL(t *testing.T) {
	s := newServer(t.TempDir() + "/state.json")
	s.mu.Lock()
	s.db.Users["founder"] = User{Name: "founder"}
	s.db.Users["guest"] = User{Name: "guest"}
	s.sessions["founder-token"] = "founder"
	s.sessions["guest-token"] = "guest"
	s.db.Communities = []Community{{ID: "c-test", Name: "Teste", Owner: "founder", Members: []string{"founder", "guest"}, Channels: []string{"geral"}, ChannelMeta: map[string]ChannelMeta{"geral": {Type: "text", RolePermissions: map[string]map[string]bool{"everyone": {"CREATE_INVITES": false}}}}}}
	s.db.RequireInvite = false
	s.mu.Unlock()
	api := func(user, path, body string) *httptest.ResponseRecorder {
		r := httptest.NewRequest(http.MethodPost, path, strings.NewReader(body))
		if user != "" {
			r.Header.Set("Authorization", "Bearer "+user+"-token")
		}
		w := httptest.NewRecorder()
		s.routes().ServeHTTP(w, r)
		return w
	}
	r := httptest.NewRequest(http.MethodGet, "/api/register-config", nil)
	w := httptest.NewRecorder()
	s.routes().ServeHTTP(w, r)
	if w.Code != 200 || !strings.Contains(w.Body.String(), `"require_invite":false`) {
		t.Fatalf("registration config: %d %s", w.Code, w.Body.String())
	}
	body := `{"community":"c-test","channel":"geral"}`
	if w := api("guest", "/api/community-invite", body); w.Code != 403 {
		t.Fatalf("channel deny ignored %d %s", w.Code, w.Body.String())
	}
	permitted := api("founder", "/api/community-invite", body)
	if permitted.Code != 201 {
		t.Fatalf("founder invite %d %s", permitted.Code, permitted.Body.String())
	}
	var issued CommunityInvite
	if err := json.Unmarshal(permitted.Body.Bytes(), &issued); err != nil || issued.Code == "" || issued.Community != "c-test" {
		t.Fatalf("invalid invite %+v %v", issued, err)
	}
	s.mu.Lock()
	ok := s.validCommunityInviteLocked("c-test", issued.Code)
	s.mu.Unlock()
	if !ok {
		t.Fatal("new invitation was not saved")
	}
}

func TestPokeOnlySameVoiceAndAuthorized(t *testing.T) {
	s := newServer(t.TempDir() + "/state.json")
	s.mu.Lock()
	for _, name := range []string{"owner", "guest", "other"} {
		s.db.Users[name] = User{Name: name}
		s.sessions[name+"-t"] = name
	}
	s.db.Communities = []Community{{ID: "c", Owner: "owner", Members: []string{"owner", "guest", "other"}, Channels: []string{"voz"}, ChannelMeta: map[string]ChannelMeta{"voz": {Type: "voice"}}}}
	s.mu.Unlock()
	voice.mu.Lock()
	previous := voice.members
	voice.members = map[string]*voiceMember{"owner": {User: "owner", Room: "c:voz", Seen: time.Now()}, "guest": {User: "guest", Room: "c:voz", Seen: time.Now()}, "other": {User: "other", Room: "outro:voz", Seen: time.Now()}}
	voice.mu.Unlock()
	t.Cleanup(func() { voice.mu.Lock(); voice.members = previous; voice.mu.Unlock() })
	call := func(user, target string) *httptest.ResponseRecorder {
		r := httptest.NewRequest(http.MethodPost, "/api/voice-moderation", strings.NewReader(`{"community":"c","target":"`+target+`","action":"poke"}`))
		r.Header.Set("Authorization", "Bearer "+user+"-t")
		w := httptest.NewRecorder()
		s.routes().ServeHTTP(w, r)
		return w
	}
	if w := call("guest", "owner"); w.Code != 403 {
		t.Fatalf("guest without role poked owner: %d", w.Code)
	}
	if w := call("owner", "other"); w.Code != 403 {
		t.Fatalf("cross-channel poke: %d", w.Code)
	}
	if w := call("owner", "guest"); w.Code != 200 {
		t.Fatalf("owner could not poke: %d %s", w.Code, w.Body.String())
	}
	voice.mu.Lock()
	queue := append([]voiceSignal(nil), voice.members["guest"].Queue...)
	voice.mu.Unlock()
	if len(queue) != 1 || queue[0].Kind != "poke" || queue[0].From != "owner" {
		t.Fatalf("poke signaling %+v", queue)
	}
	if w := call("owner", "guest"); w.Code != 429 {
		t.Fatalf("poke spam not throttled: %d", w.Code)
	}
}
