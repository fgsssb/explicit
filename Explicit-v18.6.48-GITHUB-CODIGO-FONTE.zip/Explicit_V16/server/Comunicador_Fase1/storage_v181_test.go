package main

import (
	"encoding/json"
	"os"
	"path/filepath"
	"strings"
	"testing"
)

func TestPersistLocalStoreReplaceWithoutDataLoss(t *testing.T) {
	dest := filepath.Join(t.TempDir(), "data", "store.json")
	if err := persistLocalStore(dest, []byte(`{"messages":[{"id":"old"}]}`)); err != nil {
		t.Fatal(err)
	}
	if err := persistLocalStore(dest, []byte(`{"messages":[{"id":"new"}]}`)); err != nil {
		t.Fatal(err)
	}
	b, err := os.ReadFile(dest)
	if err != nil {
		t.Fatal(err)
	}
	var parsed map[string]any
	if err := json.Unmarshal(b, &parsed); err != nil {
		t.Fatal(err)
	}
	if !strings.Contains(string(b), "new") || strings.Contains(string(b), "old") {
		t.Fatalf("unexpected content: %s", b)
	}
	matches, err := filepath.Glob(filepath.Join(filepath.Dir(dest), ".explicit-store-*.tmp"))
	if err != nil || len(matches) > 0 {
		t.Fatalf("temporary files remain: %v %v", matches, err)
	}
}
