package main

import (
	"bytes"
	"crypto/sha256"
	_ "embed"
	"encoding/hex"
	"flag"
	"image"
	"image/color"
	"image/draw"
	"image/png"
	"math/rand"
	"net"
	"net/http"
	"os"
	"strings"
	"sync"
	"time"
)

//go:embed captcha_glyphs.png
var explicitCaptchaGlyphs []byte

var captchaAtlasOnce sync.Once
var captchaAtlas image.Image
var captchaAtlasErr error

type explicitCaptcha struct {
	AnswerHash string
	Expires    time.Time
	Attempts   int
	Views      int
	glyphs     string
	seed       int64
}

func registrationHash(secret, value string) string {
	sum := sha256.Sum256([]byte(secret + "|" + value))
	return hex.EncodeToString(sum[:])
}
func registrationRemoteIP(r *http.Request) string {
	host, _, err := net.SplitHostPort(r.RemoteAddr)
	if err != nil {
		host = r.RemoteAddr
	}
	if v := os.Getenv("EXPLICIT_TRUSTED_PROXY_IPS"); v != "" {
		for _, p := range strings.Split(v, ",") {
			if strings.TrimSpace(p) == host {
				forwarded := strings.TrimSpace(strings.Split(r.Header.Get("X-Forwarded-For"), ",")[0])
				if ip := net.ParseIP(forwarded); ip != nil {
					return ip.String()
				}
			}
		}
	}
	if ip := net.ParseIP(host); ip != nil {
		return ip.String()
	}
	return host
}
func validDeviceID(s string) bool {
	if len(s) < 24 || len(s) > 128 {
		return false
	}
	for _, r := range s {
		if !(r >= 'a' && r <= 'z' || r >= 'A' && r <= 'Z' || r >= '0' && r <= '9' || r == '-' || r == '_') {
			return false
		}
	}
	return true
}
func (s *Server) verifyCaptcha(id, answer string) bool {
	// The test bypass must never work in a production server binary, even if
	// an operator accidentally copies EXPLICIT_TEST_SKIP_ANTIBOT into its env.
	if flag.Lookup("test.v") != nil && os.Getenv("EXPLICIT_TEST_SKIP_ANTIBOT") == "1" {
		return true
	}
	s.captchaMu.Lock()
	defer s.captchaMu.Unlock()
	c, ok := s.captchas[id]
	if !ok || time.Now().After(c.Expires) {
		delete(s.captchas, id)
		return false
	}
	c.Attempts++
	delete(s.captchas, id) // one attempt per challenge, never reuse
	return registrationHash(id, strings.ToUpper(strings.TrimSpace(answer))) == c.AnswerHash
}
func (s *Server) captchaAPI(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodGet {
		http.Error(w, "method", 405)
		return
	}
	s.captchaMu.Lock()
	defer s.captchaMu.Unlock()
	if s.captchas == nil {
		s.captchas = make(map[string]explicitCaptcha)
	}
	now := time.Now()
	for id, c := range s.captchas {
		if now.After(c.Expires) {
			delete(s.captchas, id)
		}
	}
	if r.URL.Query().Get("image") != "" {
		id := r.URL.Query().Get("image")
		c, ok := s.captchas[id]
		if !ok || now.After(c.Expires) {
			http.NotFound(w, r)
			return
		}
		if c.Views >= 12 {
			http.Error(w, "captcha image limit", http.StatusTooManyRequests)
			return
		}
		c.Views++
		s.captchas[id] = c
		w.Header().Set("Content-Type", "image/png")
		w.Header().Set("X-Content-Type-Options", "nosniff")
		w.Header().Set("Cache-Control", "no-store")
		captchaAtlasOnce.Do(func() {
			captchaAtlas, _, captchaAtlasErr = image.Decode(bytes.NewReader(explicitCaptchaGlyphs))
		})
		if captchaAtlasErr != nil || captchaAtlas == nil {
			http.Error(w, "captcha unavailable", 500)
			return
		}
		dst := image.NewRGBA(image.Rect(0, 0, 186, 58))
		draw.Draw(dst, dst.Bounds(), &image.Uniform{C: color.RGBA{16, 36, 58, 255}}, image.Point{}, draw.Src)
		rng := rand.New(rand.NewSource(c.seed))
		for i := 0; i < 110; i++ {
			x, y := rng.Intn(186), rng.Intn(58)
			dst.SetRGBA(x, y, color.RGBA{80, 118, 155, 255})
		}
		alphabet := "ACDEFGHJKLMNPQRTUVWXY346789"
		for i, letter := range c.glyphs {
			idx := strings.IndexRune(alphabet, letter)
			if idx < 0 {
				continue
			}
			baseX, baseY := 10+i*33, 2+rng.Intn(7)
			// Glyphs are rasterized server-side, with per-row distortion.
			for y := 0; y < 54; y++ {
				rowShift := int(float64(y-27) * float64(rng.Intn(7)-3) / 35)
				for x := 0; x < 44; x++ {
					_, _, _, a := captchaAtlas.At(idx*44+x, y).RGBA()
					if a < 14000 {
						continue
					}
					dx, dy := baseX+x+rowShift, baseY+y
					if dx >= 0 && dx < 186 && dy >= 0 && dy < 58 {
						dst.SetRGBA(dx, dy, color.RGBA{197 + uint8(rng.Intn(36)), 219 + uint8(rng.Intn(20)), 250, 255})
					}
				}
			}
		}
		if err := png.Encode(w, dst); err != nil {
			return
		}

		return
	}
	if s.captchaIssued == nil {
		s.captchaIssued = map[string][]time.Time{}
	}
	ip := registrationRemoteIP(r)
	seen := s.captchaIssued[ip][:0]
	for _, t := range s.captchaIssued[ip] {
		if now.Sub(t) < time.Minute {
			seen = append(seen, t)
		}
	}
	if len(seen) >= 18 {
		http.Error(w, "too many captcha requests", 429)
		return
	}
	s.captchaIssued[ip] = append(seen, now)
	if len(s.captchaIssued) > 1000 {
		for ip, dates := range s.captchaIssued {
			if len(dates) == 0 || now.Sub(dates[len(dates)-1]) > time.Minute {
				delete(s.captchaIssued, ip)
			}
		}
	}
	if len(s.captchas) > 1500 {
		http.Error(w, "captcha busy", 429)
		return
	}
	id := token()
	alphabet := "ACDEFGHJKLMNPQRTUVWXY346789"
	b := make([]byte, 5)
	for i := range b {
		tmp := token()
		b[i] = alphabet[int(tmp[0])%len(alphabet)]
	}
	answer := string(b)
	seed := int64(0)
	for _, c := range id[:16] {
		seed = seed*31 + int64(c)
	}
	s.captchas[id] = explicitCaptcha{AnswerHash: registrationHash(id, answer), Expires: now.Add(3 * time.Minute), glyphs: answer, seed: seed}
	w.Header().Set("Cache-Control", "no-store")
	reply(w, 200, map[string]string{"id": id, "image": "/api/captcha?image=" + id})
}
