package main

import (
	"bytes"
	"encoding/json"
	"net/http/httptest"
	"path/filepath"
	"strings"
	"testing"
)

func staffFixture(t *testing.T) *Server {
	t.Helper()
	s := newServer(filepath.Join(t.TempDir(), "store.json"))
	for name, role := range map[string]string{"root": "superadmin", "root2": "superadmin", "owner": "user", "member": "user", "visitor": "user"} {
		s.db.Users[name] = User{Name: name, SystemRole: role}
		s.sessions[name+"-token"] = name
	}
	s.db.Communities = []Community{{ID: "c1", Name: "Community", Owner: "owner", Members: []string{"owner", "member"}, Channels: []string{"geral", "voz"}, ChannelMeta: map[string]ChannelMeta{"geral": {Type: "text"}, "voz": {Type: "voice"}}}}
	return s
}
func staffReq(s *Server, method, path, who string, body any) *httptest.ResponseRecorder {
	data, _ := json.Marshal(body)
	r := httptest.NewRequest(method, path, bytes.NewReader(data))
	r.Header.Set("Authorization", "Bearer "+who+"-token")
	w := httptest.NewRecorder()
	s.routes().ServeHTTP(w, r)
	return w
}
func TestSuperadminGlobalMuteScopes(t *testing.T) {
	s := staffFixture(t)
	if w := staffReq(s, "POST", "/api/staff-control", "member", map[string]any{"action": "mute", "community": "c1", "medium": "both", "reason": "Incidente em sala"}); w.Code != 403 {
		t.Fatalf("regular user muted: %d", w.Code)
	}
	w := staffReq(s, "POST", "/api/staff-control", "root", map[string]any{"action": "mute", "community": "c1", "medium": "both", "reason": "Incidente em sala"})
	if w.Code != 200 {
		t.Fatalf("mute failed: %d %s", w.Code, w.Body)
	}
	if !s.isStaffMuted("c1", "geral", "member", "text") || !s.isStaffMuted("c1", "voz", "owner", "voice") {
		t.Fatal("community mute did not propagate")
	}
	if s.isStaffMuted("c1", "geral", "root", "text") || s.isStaffMuted("c1", "voz", "root2", "voice") {
		t.Fatal("superadmin cannot be muted")
	}
	if s.channelCanSend("c1", "geral", "member") {
		t.Fatal("muted user can post")
	}
	if !s.channelCanSend("c1", "geral", "root") {
		t.Fatal("superadmin cannot speak")
	}
	id := s.db.StaffMutes[0].ID
	w = staffReq(s, "POST", "/api/staff-control", "root", map[string]any{"action": "unmute", "community": "c1", "id": id, "reason": "Fim do incidente"})
	if w.Code != 200 || s.isStaffMuted("c1", "geral", "member", "text") {
		t.Fatalf("unmute failed %d %s", w.Code, w.Body)
	}
	if len(s.db.StaffAudit) != 2 || s.db.StaffAudit[1].PrevHash != s.db.StaffAudit[0].Hash {
		t.Fatal("audit chain missing")
	}
	if len(newServer(s.file).db.StaffAudit) != 2 {
		t.Fatal("audit not persistent")
	}
}
func TestSuperadminCrossCommunityAndProtectedOwners(t *testing.T) {
	s := staffFixture(t)
	if w := staffReq(s, "POST", "/api/staff-control", "root", map[string]any{"action": "join", "community": "c1", "reason": "Fiscalização de sala"}); w.Code != 200 {
		t.Fatalf("join %d %s", w.Code, w.Body)
	}
	if !contains(s.db.Communities[0].Members, "root") {
		t.Fatal("staff not joined")
	}
	if w := staffReq(s, "POST", "/api/staff-control", "root", map[string]any{"action": "kick", "community": "c1", "target": "owner", "reason": "Violação de regras"}); w.Code != 200 {
		t.Fatalf("kick owner %d %s", w.Code, w.Body)
	}
	if contains(s.db.Communities[0].Members, "owner") {
		t.Fatal("owner still member")
	}
	if w := staffReq(s, "POST", "/api/staff-control", "root", map[string]any{"action": "kick", "community": "c1", "target": "root2", "reason": "Teste"}); w.Code != 403 {
		t.Fatalf("superadmin not protected: %d", w.Code)
	}
}
func TestReportedDMReviewDoesNotNotifyAndRequiresCase(t *testing.T) {
	s := staffFixture(t)
	s.db.DirectChats = []DirectChat{{ID: "dm1", Users: []string{"owner", "member"}, Visible: map[string]bool{"owner": true, "member": true}, Messages: []DirectMessage{{ID: "m1", Author: "member", Text: "Original"}}}, {ID: "dm2", Users: []string{"owner", "visitor"}}}
	if w := staffReq(s, "GET", "/api/staff-dm?list=1", "root", nil); w.Code != 403 {
		t.Fatalf("unreported chats leaked: %d", w.Code)
	}
	s.db.Reports = append(s.db.Reports, SystemReport{ID: "case1", Reporter: "owner", Kind: "user", Target: "member", Reason: "Mensagem abusiva", Status: "open", ChatID: "dm1", MessageID: "m1"})
	if w := staffReq(s, "GET", "/api/staff-dm?list=1&report_id=case1", "member", nil); w.Code != 403 {
		t.Fatalf("non-staff viewed report: %d", w.Code)
	}
	if w := staffReq(s, "GET", "/api/staff-dm?list=1&report_id=case1", "root", nil); w.Code != 200 || !strings.Contains(w.Body.String(), "dm1") || strings.Contains(w.Body.String(), "dm2") {
		t.Fatalf("wrong chats disclosed: %d %s", w.Code, w.Body.String())
	}
	if w := staffReq(s, "GET", "/api/staff-dm?chat=dm2&report_id=case1&reason=Investigacao%20por%20abuso", "root", nil); w.Code != 403 {
		t.Fatalf("unrelated chat leaked: %d", w.Code)
	}
	before := len(s.db.DirectChats[0].Messages)
	w := staffReq(s, "GET", "/api/staff-dm?chat=dm1&report_id=case1&reason=Investigacao%20por%20abuso", "root", nil)
	if w.Code != 200 {
		t.Fatalf("reported chat blocked: %d %s", w.Code, w.Body)
	}
	if len(s.db.DirectChats[0].Messages) != before {
		t.Fatal("silent review injected visible staff notice")
	}
	s.db.Reports[0].Status = "resolved"
	if w := staffReq(s, "GET", "/api/staff-dm?chat=dm1&report_id=case1&reason=Investigacao%20por%20abuso", "root", nil); w.Code != 403 {
		t.Fatalf("resolved report still accessible: %d", w.Code)
	}
}
func TestSlashBanUsesAccountUsernameAndProtectsStaff(t *testing.T) {
	s := staffFixture(t)
	w := staffReq(s, "POST", "/api/channel-messages?community=c1&channel=geral", "root", map[string]string{"text": "/ban member conteúdo abusivo"})
	if w.Code != 200 || !s.db.Users["member"].BannedPermanent {
		t.Fatalf("ban command failed %d %s", w.Code, w.Body)
	}
	if len(s.db.Messages) != 0 {
		t.Fatal("slash command was broadcast")
	}
	w = staffReq(s, "POST", "/api/channel-messages?community=c1&channel=geral", "root", map[string]string{"text": "/ban root2"})
	if w.Code != 403 {
		t.Fatalf("protected superadmin banned %d", w.Code)
	}
}
func TestRegularMembersCannotReadPrivateAudit(t *testing.T) {
	s := staffFixture(t)
	for _, path := range []string{"/api/staff-control", "/api/staff-dm?list=1"} {
		if w := staffReq(s, "GET", path, "member", nil); w.Code != 403 {
			t.Fatalf("private endpoint %s exposed: %d", path, w.Code)
		}
	}
}

func TestSuperadminInviteChangeAndMessageMigration(t *testing.T) {
	s := staffFixture(t)
	s.db.Messages = []Message{{ID: "msg1", Channel: "c1:geral", Author: "member", Text: "teste"}}
	w := staffReq(s, "POST", "/api/staff-control", "root", map[string]any{"action": "change_invite", "community": "c1", "name": "nova-sala", "reason": "Código comprometido"})
	if w.Code != 200 {
		t.Fatalf("invite migration failed %d %s", w.Code, w.Body)
	}
	if s.db.Communities[0].ID != "nova-sala" || s.db.Messages[0].Channel != "nova-sala:geral" {
		t.Fatal("community/message migration failed")
	}
	if w := staffReq(s, "GET", "/api/channel-messages?community=nova-sala&channel=geral", "member", nil); w.Code != 200 {
		t.Fatalf("migrated messages unavailable: %d", w.Code)
	}
}
func TestOnlyOwnerCanGrantAdminRole(t *testing.T) {
	s := staffFixture(t)
	s.db.Users["creator"] = User{Name: "creator", AccountID: token()}
	s.sessions["creator-token"] = "creator"
	if err := s.bootstrapOwner("creator"); err != nil {
		t.Fatal(err)
	}
	if w := staffReq(s, "POST", "/api/system-admin", "root", map[string]any{"action": "set_role", "target": "member", "role": "moderator"}); w.Code != 403 {
		t.Fatalf("legacy superadmin promoted: %d", w.Code)
	}
	if w := staffReq(s, "POST", "/api/system-admin", "creator", map[string]any{"action": "set_role", "target": "member", "role": "moderator"}); w.Code != 200 {
		t.Fatalf("Owner did not grant Admin: %d %s", w.Code, w.Body)
	}
	if systemRole(s.db.Users["member"]) != "moderator" {
		t.Fatal("Admin role not saved")
	}
}
