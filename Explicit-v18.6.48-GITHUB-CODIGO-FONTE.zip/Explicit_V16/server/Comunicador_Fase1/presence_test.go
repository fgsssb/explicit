package main

import (
	"bytes"
	"encoding/json"
	"net/http/httptest"
	"path/filepath"
	"testing"
)

func TestVoicePresenceAuthorizationAndLifecycle(t *testing.T) {
	voice.mu.Lock()
	voice.members = map[string]*voiceMember{}
	voice.mu.Unlock()
	t.Cleanup(func() { voice.mu.Lock(); voice.members = map[string]*voiceMember{}; voice.mu.Unlock() })
	s := newServer(filepath.Join(t.TempDir(), "store.json"))
	s.db.Communities = []Community{{ID: "c1", Owner: "ana", Members: []string{"ana", "bia"}, Channels: []string{"geral", "jogos"}, ChannelMeta: map[string]ChannelMeta{"geral": {Type: "voice"}, "jogos": {Type: "voice"}}}}

	s.db.Users["ana"] = User{Name: "ana"}
	s.db.Users["bia"] = User{Name: "bia"}
	s.db.Users["intruso"] = User{Name: "intruso"}
	s.sessions["a"] = "ana"
	s.sessions["b"] = "bia"
	s.sessions["x"] = "intruso"
	request := func(token, action, channel string) int {
		t.Helper()
		payload, _ := json.Marshal(map[string]any{"community": "c1", "channel": channel, "action": action})
		r := httptest.NewRequest("POST", "/api/voice", bytes.NewReader(payload))
		r.Header.Set("Authorization", "Bearer "+token)
		w := httptest.NewRecorder()
		s.voiceAPI(w, r)
		return w.Code
	}
	snapshot := func(token string) (int, map[string]any) {
		t.Helper()
		r := httptest.NewRequest("GET", "/api/voice-presence?community=c1", nil)
		r.Header.Set("Authorization", "Bearer "+token)
		w := httptest.NewRecorder()
		s.voicePresence(w, r)
		var v map[string]any
		_ = json.Unmarshal(w.Body.Bytes(), &v)
		return w.Code, v
	}
	if code, _ := snapshot("x"); code != 403 {
		t.Fatalf("intruder read: %d", code)
	}
	if code := request("a", "join", "geral"); code != 200 {
		t.Fatalf("join: %d", code)
	}
	if code, v := snapshot("b"); code != 200 || len(v["channels"].(map[string]any)["geral"].([]any)) != 1 {
		t.Fatalf("snapshot: %d %v", code, v)
	}
	if code := request("a", "leave", "geral"); code != 200 {
		t.Fatalf("leave: %d", code)
	}
	if _, v := snapshot("b"); len(v["channels"].(map[string]any)["geral"].([]any)) != 0 {
		t.Fatalf("stale presence: %v", v)
	}
}
