package main

import (
	"bytes"
	"encoding/json"
	"net/http/httptest"
	"path/filepath"
	"testing"
)

func TestV8RolesPermissionsAndLimits(t *testing.T) {
	s := newServer(filepath.Join(t.TempDir(), "store.json"))
	s.db.Communities = []Community{{ID: "test", Name: "Test", Owner: "alice", Members: []string{"alice", "bob", "carol"}, Channels: []string{"geral", "voz"}, ChannelMeta: map[string]ChannelMeta{"geral": {Type: "text"}, "voz": {Type: "voice", Limit: 1}}}}

	s.db.Users["alice"] = User{Name: "alice"}
	s.db.Users["bob"] = User{Name: "bob"}
	s.db.Users["carol"] = User{Name: "carol"}
	s.sessions["a"] = "alice"
	s.sessions["b"] = "bob"
	s.sessions["c"] = "carol"
	call := func(endpoint, auth string, data any) int {
		t.Helper()
		b, _ := json.Marshal(data)
		r := httptest.NewRequest("POST", endpoint, bytes.NewReader(b))
		r.Header.Set("Authorization", "Bearer "+auth)
		w := httptest.NewRecorder()
		s.routes().ServeHTTP(w, r)
		return w.Code
	}
	if got := call("/api/community-admin", "b", map[string]any{"community": "test", "action": "create_role", "name": "Admins", "permissions": []string{"MANAGE_ROLES"}}); got != 403 {
		t.Fatalf("nonadmin created role: %d", got)
	}
	if got := call("/api/community-admin", "a", map[string]any{"community": "test", "action": "create_role", "name": "Mod", "priority": 10, "permissions": []string{"CREATE_CHANNEL", "ASSIGN_ROLES"}}); got != 201 {
		t.Fatalf("owner role: %d", got)
	}
	role := s.db.Communities[0].Roles[0].ID
	if got := call("/api/community-admin", "a", map[string]any{"community": "test", "action": "assign_role", "role": role, "target": "bob"}); got != 200 {
		t.Fatalf("assign: %d", got)
	}
	if got := call("/api/communities", "b", map[string]any{"community": "test", "channel": "novo", "type": "voice", "limit": 2}); got != 200 {
		t.Fatalf("create permitted channel: %d", got)
	}
	if got := call("/api/voice", "b", map[string]any{"community": "test", "channel": "voz", "action": "join"}); got != 200 {
		t.Fatalf("first join: %d", got)
	}
	if got := call("/api/voice", "c", map[string]any{"community": "test", "channel": "voz", "action": "join"}); got != 409 {
		t.Fatalf("capacity bypass: %d", got)
	}
	if got := call("/api/voice", "c", map[string]any{"community": "test", "channel": "geral", "action": "join"}); got != 403 {
		t.Fatalf("text channel voice: %d", got)
	}
	_ = call("/api/voice", "b", map[string]any{"community": "test", "channel": "voz", "action": "leave"})
}
