package main

import (
	"encoding/json"
	"net/http"
	"path/filepath"
	"testing"
)

func exampleNameStyle() NameStyle {
	return NameStyle{Color: "#aabbcc", Color2: "#aabbdd", Color3: "#cceeaa", Gradient: true, Font: "rounded", Weight: 700, Spacing: 4, ShadowColor: "#223355", ShadowBlur: 8, Glow: 12, OutlineColor: "#001122", Outline: 1, Animation: "none", Speed: 5, Effect: "none", EffectIntensity: 0}
}
func TestV1871InventoryAuthorizationStorageAndPublicVisibility(t *testing.T) {
	s := newServer(filepath.Join(t.TempDir(), "db.json"))
	s.db.Users["regular"] = User{Name: "regular"}
	s.db.Users["beta"] = User{Name: "beta", Beta: true}
	s.db.Users["plus"] = User{Name: "plus", ExplicitPlus: true}
	for _, name := range []string{"regular", "beta", "plus"} {
		s.sessions[name+"-token"] = name
	}
	post := func(user string, payload any) (int, string) {
		w := stickerRequest(s, http.MethodPost, "/api/name-presets", user, payload)
		return w.Code, w.Body.String()
	}
	req := map[string]any{"action": "save", "name": "Nome brilhante", "style": exampleNameStyle()}
	if code, _ := post("regular", req); code != 403 {
		t.Fatalf("non member created preset %d", code)
	}
	for _, name := range []string{"beta", "plus"} {
		if code, body := post(name, req); code != 200 {
			t.Fatalf("%s could not create: %d %s", name, code, body)
		}
	}
	beta := s.db.Users["beta"]
	id := beta.NamePresets[0].ID
	if code, _ := post("regular", map[string]any{"action": "equip", "id": id}); code != 403 {
		t.Fatalf("non member could equip: %d", code)
	}
	if code, _ := post("plus", map[string]any{"action": "equip", "id": id}); code != 404 {
		t.Fatalf("other user's preset could equip: %d", code)
	}
	if code, _ := post("beta", map[string]any{"action": "equip", "id": id}); code != 200 {
		t.Fatalf("beta equip: %d", code)
	}
	w := stickerRequest(s, http.MethodGet, "/api/name-presets?users=beta,regular", "regular", nil)
	if w.Code != 200 {
		t.Fatal(w.Code, w.Body.String())
	}
	var result struct {
		Styles map[string]*NameStyle `json:"styles"`
	}
	if err := json.Unmarshal(w.Body.Bytes(), &result); err != nil {
		t.Fatal(err)
	}
	if result.Styles["beta"] == nil || result.Styles["regular"] != nil {
		t.Fatalf("public style incorrect: %+v", result)
	}
	// Badge revocation must immediately stop displaying effects, preserving saved work.
	beta = s.db.Users["beta"]
	beta.Beta = false
	s.db.Users["beta"] = beta
	if activeNameStyle(beta) != nil {
		t.Fatal("premium style leaked after entitlement revoked")
	}
	if code, _ := post("beta", req); code != 403 {
		t.Fatalf("revoked user modified presets: %d", code)
	}
	if code, _ := post("plus", map[string]any{"action": "save", "name": "Unsafe", "style": map[string]any{"color": "url(javascript:evil)"}}); code != 400 {
		t.Fatalf("unsafe style accepted: %d", code)
	}
	beta.Beta = true
	s.db.Users["beta"] = beta
	if code, _ := post("beta", map[string]any{"action": "delete", "id": id}); code != 200 {
		t.Fatalf("deletion: %d", code)
	}
	if s.db.Users["beta"].EquippedNamePreset != "" {
		t.Fatal("deleted preset stays equipped")
	}
	// Persist across restart without losing owner-created style.
	if x := newServer(s.file).db.Users["plus"].NamePresets; x == nil || len(x) != 1 {
		t.Fatal("presets did not survive restart")
	}
}
func TestV18631FiveNamePresetsAndLegacyCompatibility(t *testing.T) {
	s := newServer(filepath.Join(t.TempDir(), "store.json"))
	s.db.Users["beta"] = User{Name: "beta", Beta: true}
	s.sessions["beta-token"] = "beta"
	for i := 0; i < maxSavedNamePresets; i++ {
		w := stickerRequest(s, http.MethodPost, "/api/name-presets", "beta", map[string]any{"action": "save", "name": "Preset", "style": exampleNameStyle()})
		if w.Code != http.StatusOK {
			t.Fatalf("preset %d rejected: %d %s", i, w.Code, w.Body.String())
		}
	}
	w := stickerRequest(s, http.MethodPost, "/api/name-presets", "beta", map[string]any{"action": "save", "name": "extra", "style": exampleNameStyle()})
	if w.Code != http.StatusConflict {
		t.Fatalf("sixth preset accepted: %d", w.Code)
	}
	user := s.db.Users["beta"]
	id := user.NamePresets[0].ID
	w = stickerRequest(s, http.MethodPost, "/api/name-presets", "beta", map[string]any{"action": "save", "id": id, "name": "Updated", "style": exampleNameStyle()})
	if w.Code != http.StatusOK {
		t.Fatalf("editing at limit rejected: %d", w.Code)
	}
	// Existing legacy users with more than five remain able to edit, equip and delete.
	user = s.db.Users["beta"]
	for len(user.NamePresets) < 7 {
		user.NamePresets = append(user.NamePresets, NamePreset{ID: token()[:16], Name: "Legado", Style: exampleNameStyle()})
	}
	s.db.Users["beta"] = user
	w = stickerRequest(s, http.MethodPost, "/api/name-presets", "beta", map[string]any{"action": "equip", "id": user.NamePresets[6].ID})
	if w.Code != http.StatusOK {
		t.Fatalf("legacy equip failed: %d", w.Code)
	}
	w = stickerRequest(s, http.MethodPost, "/api/name-presets", "beta", map[string]any{"action": "save", "name": "extra", "style": exampleNameStyle()})
	if w.Code != http.StatusConflict {
		t.Fatalf("legacy bypassed cap: %d", w.Code)
	}
}
