/* Explicit 18.6.4: record actual view changes; no fragile function reassignments. */
(()=>{'use strict';
 let entries=[],index=-1,replaying=false,pending=false;
 const equal=(a,b)=>a?.kind===b?.kind&&a?.id===b?.id;
 const currentView=()=>{
  if(typeof session!=='string'||!session)return null;
  if(document.body.classList.contains('explicit-direct-mode')&&typeof activeDirect==='string'&&activeDirect)return {kind:'direct',id:activeDirect};
  if(document.body.classList.contains('explicit-home'))return {kind:'home'};
  if(typeof activeCommunity==='string'&&activeCommunity)return {kind:'community',id:activeCommunity};
  return null;
 };
 const labelFor=(route)=>{
  if(route?.kind==='direct')return 'MENSAGENS DIRETAS';
  if(route?.kind==='community'){
   const c=typeof communities!=='undefined'&&Array.isArray(communities)?communities.find(x=>x.id===route.id):null;
   return c?.name||'COMUNIDADE';
  }
  return 'INICIO';
 };
 function render(){
  const label=document.getElementById('explicitNavLabel');if(label)label.textContent=(typeof session==='undefined'||!session)?(window.explicitAuthMode==='register'?'CADASTRO':'LOGIN'):labelFor(entries[index]).toLocaleUpperCase('pt-BR');
  const back=document.getElementById('explicitNavBack'),forward=document.getElementById('explicitNavForward');
  if(back)back.disabled=pending||index<=0;
  if(forward)forward.disabled=pending||index>=entries.length-1;
 }
 function record(route){
  if(!route||!['home','community','direct'].includes(route.kind))return;
  if(replaying){render();return}
  if(equal(entries[index],route)){render();return}
  entries=entries.slice(0,index+1);entries.push({kind:route.kind,id:route.id||''});
  if(entries.length>50)entries.shift();index=entries.length-1;render();
 }
 window.explicitNavRecord=record;window.explicitNavRender=render;window.explicitNavReset=()=>{entries=[];index=-1;replaying=false;pending=false;render()};
 async function navigate(delta){
  if(pending)return;
  const targetIndex=index+delta;
  if(targetIndex<0||targetIndex>=entries.length)return;
  const target=entries[targetIndex];pending=true;replaying=true;render();
  try{
   if(target.kind==='home')await openHome();
   else if(target.kind==='community'){
    if(typeof communities!=='undefined'&&!communities.some(c=>c.id===target.id))throw Error('Comunidade indisponível');
    await selectCommunity(target.id);
   }else if(target.kind==='direct')await openDirect(target.id);
   index=targetIndex;
  }catch(e){if(typeof nexoToast==='function')nexoToast('Navegação: '+e.message,'error');else console.warn('Navegação:',e)}
  finally{replaying=false;pending=false;render()}
 }
 document.addEventListener('click',event=>{
  const back=event.target.closest?.('#explicitNavBack');const forward=event.target.closest?.('#explicitNavForward');
  if(back){event.preventDefault();void navigate(-1)}
  else if(forward){event.preventDefault();void navigate(1)}
 });
 function initialize(){const route=currentView();if(route)record(route);render()}
 if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',initialize,{once:true});else initialize();
 // The Windows titlebar is created by Electron preload; refresh after it is inserted.
 const observer=new MutationObserver(changes=>{if(changes.some(m=>[...m.addedNodes].some(n=>n.id==='explicitDesktopTitlebar'))){render();observer.disconnect()}});
 if(document.body&&!document.getElementById('explicitDesktopTitlebar'))observer.observe(document.body,{childList:true});
 window.addEventListener('pageshow',initialize);
})();
