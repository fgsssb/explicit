/* Required first-login rules. The server independently enforces acceptance. */
(()=>{'use strict';
let ongoing=null;
window.explicitEnsureTerms=async function(){if(!session)return;if(ongoing)return ongoing;ongoing=run().finally(()=>{ongoing=null});return ongoing};
async function run(){const state=await api('terms');if(state.accepted)return;
return new Promise((resolve,reject)=>{
 const back=document.createElement('div');back.className='explicit-terms-backdrop';back.setAttribute('role','dialog');back.setAttribute('aria-modal','true');back.setAttribute('aria-label','Regras do Explicit');
 const card=document.createElement('section');card.className='explicit-terms-card';const heading=document.createElement('header');heading.className='explicit-terms-heading';heading.innerHTML='<small>ANTES DE CONTINUAR • EXPLICIT</small><h2>Regras de convivência</h2><p>Leia até o final para liberar o aceite. Estas regras se aplicam às comunidades, mensagens privadas e chamadas.</p>';
 const scroll=document.createElement('div');scroll.className='explicit-terms-scroll';scroll.tabIndex=0;
 const rules=[
 ['Respeito acima de tudo','Não pratique ameaças, perseguição, humilhação, assédio, discriminação ou ataques a outros usuários. Divergências não justificam agressões.'],
 ['Nada de conteúdo ilegal ou abusivo','É proibido distribuir material de abuso sexual infantil, divulgar exploração, fraudes ou orientar ações ilícitas. Denuncie imediatamente conteúdo perigoso.'],
 ['Sem spam e golpes','Não envie publicidade repetitiva, phishing, links maliciosos, malware, correntes ou mensagens automatizadas abusivas.'],
 ['Privacidade e consentimento','Não divulgue dados pessoais de outras pessoas sem autorização. Não exponha conversas, imagens ou transmissões privadas sem consentimento.'],
 ['Segurança nas comunidades','Respeite regras adicionais de cada comunidade. Não tente contornar bloqueios, punições, controle de acesso ou permissões.'],
 ['Contas e identidade','Não se passe por membros da Staff, pessoas ou organizações. Proteja suas credenciais e não compartilhe senhas ou tokens.'],
 ['Voz, vídeo e compartilhamento','Não use chamadas ou transmissão para ameaçar, perseguir, expor dados privados ou exibir conteúdo proibido. Respeite quem está na sala.'],
 ['Moderação e denúncias','A Staff pode aplicar medidas proporcionais, como avisos, silenciamentos, expulsões e banimentos. Utilize as ferramentas de denúncia de boa-fé.'],
 ['Conversas privadas','Mensagens privadas não são criptografadas de ponta a ponta nesta versão. A moderação pode consultar mensagens de conversas relacionadas a denúncias abertas, com justificativa e auditoria, sem aviso individual durante a investigação.'],
 ['Armazenamento e registros','Mensagens, arquivos, ações administrativas e registro de aceite podem ficar armazenados para operar e proteger o serviço. Evite compartilhar dados sensíveis.'],
 ['Atualizações das regras','Mudanças relevantes podem exigir novo aceite. A data e a versão aceitas são armazenadas na sua conta.']
 ];
 for(const [title,body] of rules){const h=document.createElement('h3');h.textContent=title;const p=document.createElement('p');p.textContent=body;scroll.append(h,p)}const end=document.createElement('p');end.className='explicit-terms-end';end.textContent='Fim das regras · versão '+state.version+'. Ao aceitar, você confirma ter recebido estas regras e concorda em segui-las.';scroll.append(end);
 const footer=document.createElement('footer');footer.className='explicit-terms-footer';const hint=document.createElement('small');hint.textContent='Role até o final para habilitar o aceite.';const label=document.createElement('label');const checkbox=document.createElement('input');checkbox.type='checkbox';checkbox.disabled=true;label.append(checkbox,document.createTextNode('Eu li e concordo com as regras do Explicit'));const button=document.createElement('button');button.type='button';button.textContent='Continuar para o Explicit';button.disabled=true;const scrolled=()=>{if(scroll.scrollTop+scroll.clientHeight>=scroll.scrollHeight-14){checkbox.disabled=false;hint.textContent='Agora marque a caixa para confirmar seu aceite.'}};scroll.addEventListener('scroll',scrolled);checkbox.onchange=()=>button.disabled=!checkbox.checked;button.onclick=async()=>{button.disabled=true;try{await api('terms','POST',{accept:true,version:state.version});back.remove();resolve()}catch(e){hint.textContent='Falha ao salvar o aceite: '+e.message;button.disabled=false}};footer.append(hint,label,button);card.append(heading,scroll,footer);back.append(card);document.body.append(back);scroll.focus();setTimeout(scrolled,50);
 });}
})();
