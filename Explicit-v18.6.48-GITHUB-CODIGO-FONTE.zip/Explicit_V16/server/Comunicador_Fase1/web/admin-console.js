'use strict';
// Explicit v18.0: global moderation, transparent DM review and chained staff audit. All privileged actions are enforced server-side.
(function(){
const txt=(tag,value,cls)=>{const e=document.createElement(tag);e.textContent=String(value??'');if(cls)e.className=cls;return e};
const btn=(label,cb,cls)=>{const b=txt('button',label,cls||'explicit-admin-action');b.type='button';b.addEventListener('click',cb);return b};
const empty=(message)=>txt('p',message,'explicit-admin-empty');
const date=v=>v?new Date(v).toLocaleString('pt-BR'):'—';
const roleName=r=>({owner:'Owner',superadmin:'Superadmin',admin:'Administrador',moderator:'Admin',user:'Usuário'})[r]||r;
const actionError=e=>{const msg=e?.message||'Erro desconhecido';nexoToast('Não foi possível concluir: '+msg,'error');return msg};
// Explicit+ periods are selected in a modal; the server enforces every expiry.
async function explicitPlusPeriodDialog(edit=false){
 const fields=[
  {name:'days',label:'Dias',type:'number',value:edit?'0':'30',required:true},
  {name:'hours',label:'Horas',type:'number',value:'0',required:true},
  {name:'minutes',label:'Minutos',type:'number',value:'0',required:true},
  {name:'seconds',label:'Segundos',type:'number',value:'0',required:true}
 ];
 if(edit)fields.push({name:'mode',label:'Atualização do prazo',options:['extend','replace'],labels:['Acrescentar ao tempo restante','Substituir pelo novo prazo']});
 const values=await nexoForm(edit?'Editar validade do Explicit+':'Definir validade do Explicit+',fields);
 if(!values)return null;
 const units=[['days',86400],['hours',3600],['minutes',60],['seconds',1]];
 let duration=0;
 for(const [key,unit] of units){const v=String(values[key]).trim();if(!/^\d{1,9}$/.test(v)){actionError(new Error('Preencha apenas números inteiros positivos.'));return null}duration+=Number(v)*unit}
 if(!Number.isSafeInteger(duration)||duration<1||duration>315360000){actionError(new Error('Informe um prazo entre 1 segundo e 10 anos.'));return null}
 return {duration_seconds:duration,duration_mode:edit?values.mode:'replace'};
}
function explicitPlusTermText(user){
 if(user.explicit_plus_legacy)return 'Prazo: sem validade definida (concessão anterior).';
 if(user.explicit_plus_expires_at){const future=new Date(user.explicit_plus_expires_at).getTime()>Date.now();return (future?'Válido até ':'Expirado em ')+date(user.explicit_plus_expires_at)}
 return 'Sem Explicit+ ativo.';
}

let activeTab='overview';
let activeReportId='';
let view=null;
let busy=false;
const pane=(title,desc)=>{const section=document.createElement('section');section.className='explicit-admin-pane';section.append(txt('h3',title));if(desc)section.append(txt('p',desc,'explicit-admin-hint'));return section};
const line=(main,detail)=>{const row=document.createElement('div');row.className='explicit-admin-item';const copy=document.createElement('div');copy.className='explicit-admin-item-copy';copy.append(txt('strong',main));if(detail)copy.append(txt('small',detail));row.append(copy);return row};
const controls=(row,...actions)=>{const box=document.createElement('div');box.className='explicit-admin-item-actions';box.append(...actions);row.append(box);return row};
const formField=(form,label,name,{type='text',value='',required=false,choices=[],maxLength=0}={})=>{
 const wrap=document.createElement('label');wrap.className='explicit-admin-field';wrap.append(txt('span',label));
 const field=choices.length?document.createElement('select'):document.createElement('input');field.name=name;field.required=required;
 if(choices.length){for(const [val,label] of choices){const opt=document.createElement('option');opt.value=val;opt.textContent=label;field.append(opt)}}
 else{field.type=type;field.value=String(value);if(maxLength)field.maxLength=maxLength}
 wrap.append(field);form.append(wrap);return field;
};
const confirmation=(button,callback)=>{
 if(button.dataset.confirm!=='1'){button.dataset.confirm='1';button.dataset.old=button.textContent;button.textContent='Clique novamente para confirmar';button.classList.add('is-confirm');return}
 button.disabled=true;Promise.resolve().then(callback).finally(()=>{button.disabled=false;button.textContent=button.dataset.old||'Confirmar';delete button.dataset.confirm;button.classList.remove('is-confirm')});
};
async function mutate(route,payload,{message='Alteração salva',tab=activeTab}={}){
 if(busy)return false;busy=true;
 try{await api(route,'POST',payload);nexoToast(message);if(route==='system-admin'&&payload.action==='set_home_mode')window.dispatchEvent(new Event('explicit:home-mode-updated'));await render(tab);return true}
 catch(e){actionError(e);return false}
 finally{busy=false}
}
function createSpotlightForm(){
 const form=document.createElement('form');form.className='explicit-admin-publish';form.noValidate=false;
 form.append(txt('h4','Publicar divulgação revisada'));
     const fields=document.createElement('div');fields.className='explicit-admin-form-grid';form.append(fields);
 formField(fields,'Título','title',{required:true,maxLength:100});formField(fields,'Link HTTPS do YouTube','video_url',{type:'url',required:true});
 formField(fields,'Criador / autor','author',{maxLength:60});formField(fields,'Duração (horas)','hours',{type:'number',required:true,value:24});
 const helper=txt('small','Publicação manual de teste: confirme autor e conteúdo antes de publicar. Este painel não cobra nem confirma pagamentos.','explicit-admin-hint');form.append(helper);
 const submit=btn('Publicar divulgação',()=>{if(!form.reportValidity())return;const v=Object.fromEntries(new FormData(form));const hours=Number(v.hours);if(!Number.isInteger(hours)||hours<1||hours>48)return actionError(new Error('Duração entre 1 e 48 horas.'));void mutate('spotlight',{action:'add',title:v.title.trim(),video_url:v.video_url.trim(),author:v.author.trim(),hours},{message:'Divulgação publicada na página inicial',tab:'spotlight'})},'explicit-admin-primary');
 form.append(submit);return form;
}

// Explicit v17.9 — editor de comunicados: sem HTML arbitrário, URLs sempre HTTPS.
function createAnnouncementForm(){
 const form=document.createElement('form');form.className='explicit-admin-publish explicit-admin-announcement-form';
 form.append(txt('h4','Novo comunicado da Staff'));
 const fields=document.createElement('div');fields.className='explicit-admin-form-grid';form.append(fields);
 const title=formField(fields,'Título do comunicado','title',{required:true,maxLength:120});
 const wrap=document.createElement('label');wrap.className='explicit-admin-field';wrap.append(txt('span','Corpo do comunicado'));
 const body=document.createElement('textarea');body.name='body';body.required=true;body.minLength=10;body.maxLength=3000;body.rows=7;body.placeholder='Escreva o anúncio. Use **negrito**, *itálico*, parágrafos e listas começando com - ';wrap.append(body);form.append(wrap);
 form.append(txt('small','Formatação: **negrito**, *itálico*, quebras de linha e itens com hífen. O texto é exibido com segurança, sem executar HTML. Até 3 links HTTPS.','explicit-admin-editor-help'));
 const links=[];
 for(let i=0;i<3;i++){
  const line=document.createElement('div');line.className='explicit-admin-announcement-link';
  const label=formField(line,'Link '+(i+1)+' — texto','link_label_'+i,{maxLength:70});
  const url=formField(line,'Link '+(i+1)+' — HTTPS','link_url_'+i,{type:'url',maxLength:500});
  links.push({label,url});form.append(line);
 }
 form.append(btn('Publicar comunicado',()=>{
  if(!form.reportValidity())return;
  if(title.value.trim().length<3||body.value.trim().length<10){actionError(new Error('Informe título e texto válidos.'));return}
  const outgoing=[];
  for(const pair of links){const label=pair.label.value.trim(),url=pair.url.value.trim();
   if(!label&&!url)continue;
   if(!label||!url){actionError(new Error('Preencha nome e endereço de cada link utilizado.'));return}
   try{if(new URL(url).protocol!=='https:')throw new Error('protocol')}catch{actionError(new Error('Links precisam usar HTTPS.'));return}
   outgoing.push({label,url});
  }
  void mutate('announcements',{action:'add',title:title.value.trim(),body:body.value.trim(),links:outgoing},{message:'Comunicado publicado na página Início',tab:'announcements'});
 },'explicit-admin-primary'));
 return form;
}

async function staffAction(payload,message){
 try{const result=await api('staff-control','POST',payload);
  const warnings=result.media_warnings||[];
  if(warnings.length)nexoToast('Ação salva, mas SFU não confirmou: '+warnings.join(' | '),'error');
  else nexoToast(message||'Ação administrativa registrada');
  if(payload.action==='join')await refreshCommunities();
  await render(activeTab);return result;
 }catch(e){actionError(e);return null}
}
const staffControls=(payload,cb)=>{ const b=btn('Executar ação',async()=>{
 const inputs=Object.fromEntries(new FormData(payload));
 if(!inputs.community||!inputs.reason||inputs.reason.trim().length<3)return actionError(new Error('Escolha a comunidade e justifique a ação.'));
 confirmation(b,async()=>{await staffAction({...inputs,reason:inputs.reason.trim()},'Moderação aplicada')});
 },'explicit-admin-primary');payload.append(b);return b};
async function render(tab=activeTab){
 if(!view||!view.isConnected)return;
 activeTab=tab;
 const content=view.querySelector('.explicit-admin-content'),tabs=view.querySelectorAll('[data-admin-tab]');
 tabs.forEach(b=>{const selected=b.dataset.adminTab===tab;b.classList.toggle('active',selected);b.setAttribute('aria-selected',String(selected))});
 content.replaceChildren(txt('p','Carregando informações...','explicit-admin-hint'));
 let data,spotlights=[],requests=[],announcements=[];
 try{data=await api('system-admin');if(tab==='spotlight'){spotlights=await api('spotlight');requests=await api('spotlight?requests=1')}if((['superadmin','owner','admin','moderator'].includes(data.role))&&(tab==='moderation'||tab==='staffaudit'))data.staff=await api('staff-control');if(tab==='announcements')announcements=await api('announcements')}
 catch(e){content.replaceChildren(empty('Não foi possível atualizar o painel: '+(e.message||'rede indisponível')));return}
 if(!view||!view.isConnected)return;
 content.replaceChildren();
 const canManage=['owner','moderator','admin','superadmin'].includes(data.role);
 if(tab==='overview'){
  const p=pane('Visão geral','Estado atual do Explicit. Todos os controles utilizam as permissões reais do servidor.');
  const cards=document.createElement('div');cards.className='explicit-admin-metrics';
  for(const [v,n] of [[data.users?.length||0,'Contas'],[data.communities?.length||0,'Comunidades'],[(data.reports||[]).filter(x=>x.status==='open').length,'Denúncias abertas'],[roleName(data.role),'Seu nível']]){const c=document.createElement('div');c.className='explicit-admin-metric';c.append(txt('strong',v),txt('small',n));cards.append(c)}
  p.append(cards);p.append(txt('h4','Cadastro de novos usuários'));
  p.append(txt('p',data.require_invite?'A chave de convite é obrigatória.':'O cadastro está aberto sem chave.','explicit-admin-hint'));
  if(canManage){const b=btn(data.require_invite?'Desativar exigência de chave':'Exigir chave de convite',()=>confirmation(b,()=>mutate('system-admin',{action:'set_invite_requirement',require_invite:!data.require_invite},{message:'Regra de cadastro atualizada'})));p.append(b)}
  if(canManage&&(data.role==='superadmin'||data.role==='owner')){const limitRow=document.createElement('div');limitRow.className='explicit-invite-global-row';const label=txt('label','Convites por usuário (regra global)');const count=document.createElement('input');count.type='number';count.min='1';count.max='1000';count.value=String(data.invite_limit||5);count.setAttribute('aria-label','Limite global de convites por usuário');const saveLimit=btn('Salvar limite',()=>confirmation(saveLimit,()=>mutate('system-admin',{action:'set_invite_limit',invite_limit:Number(count.value)},{message:'Limite global atualizado'})));limitRow.append(label,count,saveLimit);p.append(limitRow)}
  content.append(p);
 } else if(tab==='spotlight'){
  const p=pane('Conteúdo da página inicial','Escolha o que será mostrado aos usuários: changelog ou anúncios e divulgações.');
  if(canManage){const box=document.createElement('section');box.className='explicit-admin-mode-editor';box.append(txt('h4','Conteúdo principal da página Início'));const modes=document.createElement('select');for(const [value,label] of [['spotlight','Anúncios e divulgações'],['changelog','O que há de novo! · changelog']]){const opt=document.createElement('option');opt.value=value;opt.textContent=label;modes.append(opt)}const notes=document.createElement('textarea');notes.rows=10;notes.maxLength=12000;notes.placeholder='Explicit 18.6.10\nIncluído\n• ...\nCorrigido\n• ...';const changeWrap=txt('label','Changelog (texto simples, até 12 mil caracteres)');changeWrap.append(notes);box.append(modes,changeWrap);p.append(box);api('home-mode').then(current=>{modes.value=current.mode||'changelog';notes.value=current.changelog||'';changeWrap.hidden=modes.value!=='changelog'}).catch(console.warn);modes.onchange=()=>changeWrap.hidden=modes.value!=='changelog';box.append(btn('Salvar modo da página Início',()=>confirmation(box.querySelector('button'),()=>mutate('system-admin',{action:'set_home_mode',role:modes.value,reason:notes.value},{message:'Página inicial atualizada',tab:'spotlight'})),'explicit-admin-primary'))}
  const publicationCount=spotlights.length;
  p.append(txt('p',`${publicationCount} de 5 publicações ativas. O sistema aceita vídeos HTTPS do YouTube, por até 48 horas.`, 'explicit-admin-hint'));
  if(canManage)p.append(createSpotlightForm());
  p.append(txt('h4','Publicações ativas'));
  if(!spotlights.length)p.append(empty('Nenhuma divulgação ativa.'));
  for(const ad of spotlights){const item=line(ad.title,`Por ${ad.author||'Equipe'} · expira ${date(ad.end)}`);
   if(canManage){const remove=btn('Remover',()=>confirmation(remove,()=>mutate('spotlight',{action:'remove',id:ad.id},{message:'Divulgação removida',tab:'spotlight'})),'explicit-admin-danger');controls(item,remove)}p.append(item)}
  p.append(txt('h4','Pedidos recebidos'));
  const pending=requests.filter(r=>r.status==='pending');if(!pending.length)p.append(empty('Nenhuma solicitação aguardando revisão.'));
  for(const req of pending){const item=line(req.title,`@${req.author} · ${req.hours}h · ${date(req.at)}`);
   const actions=[];
   if(/^https:\/\//.test(req.video_url))actions.push(btn('Abrir vídeo',()=>{if(typeof window.explicitOpenExternal==='function')window.explicitOpenExternal(req.video_url);else window.open(req.video_url,'_blank','noopener,noreferrer')}));
   if(canManage){const approve=btn('Aprovar e publicar',()=>confirmation(approve,()=>mutate('spotlight',{action:'approve_request',id:req.id},{message:'Pedido aprovado e publicado',tab:'spotlight'})),'explicit-admin-primary');const reject=btn('Recusar',()=>confirmation(reject,()=>mutate('spotlight',{action:'reject_request',id:req.id},{message:'Solicitação recusada',tab:'spotlight'})),'explicit-admin-danger');actions.push(approve,reject)}
   controls(item,...actions);p.append(item)
  }content.append(p);
 } else if(tab==='announcements'){
  const p=pane('Comunicados da Staff','Publique avisos oficiais no carrossel da página Início. Até 10 comunicados, com título, texto formatado e três links.');
  const canPublish=canManage||data.role==='moderator';
  if(canPublish)p.append(createAnnouncementForm());
  p.append(txt('h4','Comunicados publicados'));
  if(!announcements.length)p.append(empty('Nenhum comunicado publicado.'));
  for(const a of announcements.slice().reverse()){
   const item=line(a.title,`Por @${a.author} · ${date(a.at)} · ${a.body.slice(0,160)}`);
   if(canPublish){const remove=btn('Remover',()=>confirmation(remove,()=>mutate('announcements',{action:'remove',id:a.id},{message:'Comunicado removido',tab:'announcements'})),'explicit-admin-danger');controls(item,remove)}p.append(item)
  }content.append(p);
 } else if(tab==='users'){
  const p=pane('Usuários','Defina badges por conta com um clique. Admin representa um cargo real de moderação; Beta e Explicit+ liberam figurinhas sem poderes administrativos.');
  const search=document.createElement('input');search.type='search';search.placeholder='Buscar usuário por nome ou @';search.className='explicit-admin-search';p.append(search);
  const list=document.createElement('div');p.append(list);
  const populate=()=>{list.replaceChildren();const filter=search.value.trim().toLowerCase();const users=(data.users||[]).filter(u=>(u.name+' '+u.display_name).toLowerCase().includes(filter));
  if(!users.length){list.append(empty('Nenhuma conta encontrada.'));return}
  for(const u of users){const item=line(`${u.display_name||u.name}  @${u.name}`,`${roleName(u.role)}${u.beta?' · Beta':''}${u.explicit_plus?' · Explicit+':''}${u.banned_permanent?' · Banido':u.banned_until?' · Suspenso até '+date(u.banned_until):''}`);
   if(canManage&&(u.role!=='owner'&&(u.role!=='superadmin'||(data.role==='superadmin'&&u.name===document.getElementById('who')?.textContent?.trim()))) && !(data.role==='admin'&&u.role==='admin')){
    const b=btn('Gerenciar',()=>{const old=item.querySelector('.explicit-admin-user-edit');if(old){old.remove();return}const form=document.createElement('div');form.className='explicit-admin-user-edit';form.append(txt('h4','Gerenciar @'+u.name));
  // A maximum of two badges per account, enforced in both client and server.
     if(canManage){
       const badgeBox=document.createElement('section');badgeBox.className='explicit-admin-badge-editor';
       badgeBox.append(txt('h4','Distintivos da conta'));if(data.role==='owner' && u.role!=='owner' && u.role!=='superadmin'){
        const badgeRoleButton=btn(u.role==='moderator'||u.role==='admin'?'Retirar Admin':'Conceder Admin',()=>confirmation(badgeRoleButton,()=>mutate('system-admin',{action:'set_role',target:u.name,role:(u.role==='moderator'||u.role==='admin')?'user':'moderator'},{message:'Cargo Admin atualizado',tab:'users'})),'explicit-admin-primary');
        badgeBox.append(badgeRoleButton);
       }
       const options=[['staff','Admin','Atribui cargo Moderador ao conceder (permissões reais).'],['beta','Beta','Acesso a figurinhas.'],['explicit_plus','Explicit+','Acesso a figurinhas e personalização de nomes por prazo definido pelo staff.']];
       const selected=new Set((u.badges||[...(u.role!=='user'?['staff']:[]),...(u.beta?['beta']:[]),...(u.explicit_plus?['explicit_plus']:[])]).slice(0,2));
       const isOwnerOperator=data.role==='owner';
       const selectedLabel=txt('small','Escolha no máximo dois distintivos.','explicit-admin-hint');badgeBox.append(selectedLabel);
       for(const [id,label,detail] of options){const wrap=document.createElement('label');wrap.className='explicit-admin-badge-choice';const input=document.createElement('input');input.type='checkbox';if(id==='staff'&&!isOwnerOperator){input.disabled=true;input.title='Somente Owner pode conceder ou remover Admin'}input.checked=selected.has(id);input.disabled=id==='staff'&&(!isOwnerOperator||u.role==='admin'||u.role==='superadmin'||u.role==='owner');input.onchange=()=>{if(input.checked&&selected.size>=2){input.checked=false;actionError(new Error('Máximo de dois badges por usuário.'));return}if(input.checked)selected.add(id);else selected.delete(id);selectedLabel.textContent=selected.size+' de 2 badges selecionados.'};const heading=txt('span','', 'explicit-admin-badge-description');heading.append(txt('strong',label,'explicit-badge-'+id),txt('small',detail));const indicator=txt('span','✓','explicit-admin-badge-indicator');wrap.append(input,indicator,heading);badgeBox.append(wrap)}
       badgeBox.append(txt('small',explicitPlusTermText(u),'explicit-admin-hint'));
       const saveBadges=btn('Salvar badges',async()=>{
        const shouldGrant=selected.has('explicit_plus')&&!u.explicit_plus;
        const duration=shouldGrant?await explicitPlusPeriodDialog(false):null;
        if(shouldGrant&&!duration)return;
        if(shouldGrant){await mutate('system-admin',{action:'set_badges',target:u.name,badges:[...selected],...duration},{message:'Explicit+ concedido com validade',tab:'users'});return}
        confirmation(saveBadges,()=>mutate('system-admin',{action:'set_badges',target:u.name,badges:[...selected]},{message:'Badges atualizados',tab:'users'}));
       },'explicit-admin-primary');badgeBox.append(saveBadges);
       if(u.explicit_plus_expires_at||u.explicit_plus_legacy){
        const change=btn('Editar validade do Explicit+',async()=>{
         const duration=await explicitPlusPeriodDialog(true);if(!duration)return;
         await mutate('system-admin',{action:'set_explicit_plus_duration',target:u.name,...duration},{message:'Validade do Explicit+ atualizada',tab:'users'});
        },'explicit-admin-action');badgeBox.append(change);
       }
       form.append(badgeBox);
     }

     const fields=document.createElement('div');fields.className='explicit-admin-form-grid';form.append(fields);
     const action=formField(fields,'Operação','action',{choices:[['set_role','Alterar cargo'],['ban','Suspender / banir'],['unban','Remover banimento'],['set_invite_key','Atualizar chave'],...((data.role==='superadmin'||data.role==='owner')?[['set_beta','Permissão Beta · figurinhas']]:[]),['reset_password','Redefinir senha do usuário']]});
     const role=formField(fields,'Novo cargo','role',{choices:[['user','Usuário'],['moderator','Moderador'],...((data.role==='superadmin'||data.role==='owner')?[['admin','Administrador'],['superadmin','Superadmin (permissão máxima)']]:[])]});role.value=u.role==='superadmin'?'user':u.role;
     const beta=formField(fields,'Acesso Beta','beta',{choices:[['true','Conceder acesso Beta'],['false','Revogar acesso Beta']]});beta.value=String(!!u.beta);
     const hours=formField(fields,'Horas de suspensão (0 = permanente)','hours',{type:'number',value:24});
     const reason=formField(fields,'Motivo da suspensão','reason',{value:''});
     const key=formField(fields,'Nova chave (8–64 caracteres)','invite_key',{value:u.invite_key||''});
     const temp=formField(fields,'Nova senha temporária','new_password',{type:'password',value:''});temp.autocomplete='new-password';
     const forceWrap=document.createElement('label');forceWrap.className='explicit-admin-force';const force=document.createElement('input');force.type='checkbox';force.checked=true;forceWrap.append(force,txt('span','Exigir que o usuário escolha outra senha no próximo acesso.'));fields.append(forceWrap);
     const updateFields=()=>{role.parentElement.hidden=action.value!=='set_role';hours.parentElement.hidden=reason.parentElement.hidden=action.value!=='ban';key.parentElement.hidden=action.value!=='set_invite_key';beta.parentElement.hidden=action.value!=='set_beta';temp.parentElement.hidden=forceWrap.hidden=action.value!=='reset_password'};action.onchange=updateFields;updateFields();
     const confirm=btn('Aplicar alteração',()=>{const hoursValue=Number(hours.value);if(action.value==='ban'&&(!reason.value.trim()||hoursValue<0||!Number.isInteger(hoursValue))){actionError(new Error('Informe motivo e duração válida.'));return}if(action.value==='reset_password'&&(temp.value.length<8||temp.value.length>256)){actionError(new Error('Digite uma senha temporária de 8 a 256 caracteres.'));return}confirmation(confirm,()=>mutate('system-admin',{action:action.value,target:u.name,role:role.value,hours:hoursValue,reason:reason.value.trim(),invite_key:key.value.trim(),beta:beta.value==='true',new_password:temp.value,force_change:force.checked},{message:'Conta atualizada',tab:'users'}))},'explicit-admin-primary');form.append(confirm);item.append(form)});controls(item,b)}list.append(item)
  }};search.addEventListener('input',populate);populate();content.append(p);
  const consent=pane('Aceite obrigatório das regras','Registro de concordância por conta. Apenas usuários com acesso ao painel administrativo podem consultar estes dados.');
  const accepted=(data.users||[]).filter(u=>u.terms_accepted_at).length;
  consent.append(txt('p',accepted+' de '+(data.users||[]).length+' contas com aceite registrado.','explicit-admin-hint'));
  for(const u of data.users||[]){const text=u.terms_accepted_at?'Aceite registrado em '+date(u.terms_accepted_at)+' · versão '+(u.terms_version||'não identificada'):'Pendente — acesso bloqueado até aceitar as regras';consent.append(line('@'+u.name,text))}
  content.append(consent);
 }else if(tab==='reports'){
  const p=pane('Denúncias','Fila de moderação. Resolver remove a denúncia da fila aberta e mantém seu registro.');
  const open=(data.reports||[]).filter(r=>r.status==='open');if(!open.length)p.append(empty('Nenhuma denúncia aberta.'));
  for(const r of open){const item=line(`${r.kind} · ${r.target}`,`Por @${r.reporter} · ${r.reason} · ${date(r.at)}`);const actions=[];
   if(r.kind==='user'){
    actions.push(btn('Investigar DMs e grupos',()=>{activeReportId=r.id;activeTab='privates';render('privates')},'explicit-admin-primary'));
    const reason=txt('input');reason.placeholder='Motivo da sanção (obrigatório)';reason.maxLength=500;reason.className='explicit-admin-sanction-reason';
    const hours=txt('select');for(const [v,label] of [['24','Suspender 24 h'],['168','Suspender 7 dias'],['0','Banimento permanente']]){const o=txt('option',label);o.value=v;hours.append(o)}
    const apply=btn('Aplicar sanção',()=>{
      if(reason.value.trim().length<3)return actionError(new Error('Escreva um motivo com ao menos 3 caracteres.'));
      confirmation(apply,()=>mutate('system-admin',{action:'ban',target:r.target,reason:reason.value.trim(),hours:Number(hours.value),report_id:r.id},{message:'Sanção vinculada à denúncia',tab:'reports'}))
    },'explicit-admin-danger');
    const rowControls=document.createElement('div');rowControls.className='explicit-admin-report-actions';rowControls.append(reason,hours,apply);item.append(rowControls);
   }
   const b=btn('Marcar resolvida',()=>confirmation(b,()=>mutate('system-admin',{action:'resolve_report',report_id:r.id},{message:'Denúncia resolvida',tab:'reports'})));actions.push(b);controls(item,...actions);p.append(item)}content.append(p);
 }else if(tab==='communities'){
  const p=pane('Comunidades','Lista global. Para entrar sem convite e gerenciar canais, utilize a aba Moderação global.');
  for(const c of data.communities||[])p.append(line(c.name,`Criador: @${c.owner} · ${c.members?.length||0} membros · ${c.channels?.length||0} canais`));
  if(!data.communities?.length)p.append(empty('Nenhuma comunidade cadastrada.'));content.append(p);
  }else if(tab==='moderation'){
  const p=pane('Moderação global','Disponível à administração. Identifique usuários pelo @username (não pelo nome de exibição). Tudo fica registrado na auditoria.');
  if(!['owner','superadmin','admin','moderator'].includes(data.role)){p.append(empty('Somente administração pode executar estas ações.'));content.append(p);return}
  const form=document.createElement('form');form.className='explicit-admin-publish';form.onsubmit=e=>e.preventDefault();
  const fields=document.createElement('div');fields.className='explicit-admin-form-grid';form.append(fields);
  const community=formField(fields,'Comunidade','community',{choices:[['','Selecione'],...(data.communities||[]).map(c=>[c.id,c.name+' • '+c.id])]});
  const action=formField(fields,'Ação','action',{choices:[['mute','Mutar'],['join','Entrar sem convite'],['unmute','Desmutar (use lista abaixo)'],['disconnect','Desconectar da voz'],['kick','Expulsar da comunidade'],['community_ban','Banir da comunidade'],['rename_community','Renomear comunidade'],['change_invite','Alterar convite/código da comunidade'],['rename_channel','Renomear canal'],['update_channel','Editar tipo e limite do canal'],['delete_channel','Excluir canal'],['purge_channel','Apagar mensagens do canal']]});
  const channel=formField(fields,'Canal (vazio = comunidade toda)','channel',{choices:[['','Comunidade inteira']]});
  const kind=formField(fields,'Tipo do canal','type',{choices:[['text','Texto'],['voice','Voz']]});const limit=formField(fields,'Limite de participantes (0 = sem limite)','limit',{type:'number',value:0});
  const medium=formField(fields,'Tipo de bloqueio','medium',{choices:[['both','Texto e voz'],['voice','Somente voz'],['text','Somente texto']]});
  const target=formField(fields,'@username (vazio = todos)','target',{value:'',maxLength:80});
  const name=formField(fields,'Novo nome (para renomear)','name',{maxLength:60});
  const reason=formField(fields,'Motivo obrigatório','reason',{maxLength:500,required:true});
  const updateChannels=()=>{const c=(data.communities||[]).find(c=>c.id===community.value);channel.replaceChildren();for(const [value,text] of [['','Comunidade inteira'],...(c?.channels||[]).map(ch=>[ch,ch])]){const o=document.createElement('option');o.value=value;o.textContent=text;channel.append(o)}};
  community.addEventListener('change',updateChannels);updateChannels();
  action.addEventListener('change',()=>{medium.parentElement.hidden=action.value!=='mute';kind.parentElement.hidden=limit.parentElement.hidden=action.value!=='update_channel';name.parentElement.hidden=!['rename_community','rename_channel','change_invite'].includes(action.value);target.parentElement.hidden=!['mute','disconnect','kick','community_ban'].includes(action.value);channel.parentElement.hidden=!['mute','rename_channel','delete_channel','purge_channel','update_channel'].includes(action.value)});action.dispatchEvent(new Event('change'));
  const apply=btn('Aplicar e registrar ação',()=>{if(!form.reportValidity())return;
   if(action.value==='unmute'){actionError(new Error('Desmute pela lista de bloqueios ativos abaixo.'));return}
   confirmation(apply,()=>staffAction({action:action.value,community:community.value,channel:channel.value,target:target.value.trim(),medium:medium.value,name:name.value.trim(),type:kind.value,limit:Number(limit.value),reason:reason.value.trim()},'Ação registrada'));
  },'explicit-admin-primary');form.append(apply);p.append(form);
  p.append(txt('h4','Bloqueios ativos'));
  for(const mute of data.staff?.mutes||[]){const item=line(`${mute.medium} • ${mute.community}${mute.channel?' / '+mute.channel:''}${mute.target?' • @'+mute.target:' • todos os membros'}`,`Por @${mute.actor} • ${mute.reason} • ${date(mute.created)}`);
   const b=btn('Remover bloqueio',()=>confirmation(b,()=>staffAction({action:'unmute',community:mute.community,id:mute.id,reason:'Bloqueio encerrado pela staff'},'Bloqueio removido')),'explicit-admin-danger');controls(item,b);p.append(item)}
  if(!data.staff?.mutes?.length)p.append(empty('Sem bloqueios ativos.'));
  content.append(p);
 }else if(tab==='privates'){
  const p=pane('Investigações de denúncias','Não é possível consultar conversas privadas sem uma denúncia aberta. Toda consulta é registrada na auditoria. A análise não produz aviso individual.');
  const reports=(data.reports||[]).filter(r=>r.status==='open'&&r.kind==='user');
  if(!reports.length){p.append(empty('Não existem denúncias abertas contra usuários. Nenhuma conversa pode ser consultada.'));content.append(p);return}
  const form=document.createElement('div');form.className='explicit-admin-publish';p.append(form);
  const fields=document.createElement('div');fields.className='explicit-admin-form-grid';form.append(fields);
  const report=formField(fields,'Denúncia em análise','report_id',{choices:reports.map(r=>[r.id,'@'+r.target+' · '+r.reason.slice(0,72)+' · '+date(r.at)])});if(reports.some(r=>r.id===activeReportId))report.value=activeReportId;
  const reason=formField(fields,'Justificativa da consulta (mínimo 10 caracteres)','reason',{maxLength:500});
  const list=document.createElement('div');list.className='explicit-admin-dm-history';p.append(list);
  const history=document.createElement('div');history.className='explicit-admin-dm-history';p.append(history);
  const browse=btn('Consultar evidência da denúncia',async()=>{
   list.replaceChildren(txt('p','Verificando denúncia e conversas...'));history.replaceChildren();
   try{
    const result=await api('staff-dm?list=1&report_id='+encodeURIComponent(report.value));
    list.replaceChildren(txt('h4','Denunciado: @'+result.report.target),txt('p','Motivo: '+result.report.reason+' · Por @'+result.report.reporter,'explicit-admin-hint'));
    const chats=result.conversations||[];
    if(!chats.length)list.append(empty('Denúncia sem mensagem privada comprovada: nenhum histórico foi liberado.'));
    for(const chat of chats){
      const row=line((chat.group?'Grupo: ':'DM: ')+(chat.name||chat.users.join(', ')),chat.message_count+' mensagens · '+chat.users.map(u=>'@'+u).join(', '));
      const open=btn('Ver contexto da denúncia',async()=>{
       if((reason.value||'').trim().length<10)return actionError(new Error('Informe justificativa com ao menos 10 caracteres.'));
       history.replaceChildren(txt('p','Consultando conversa...'));
       try{
        const url='staff-dm?chat='+encodeURIComponent(chat.id)+'&report_id='+encodeURIComponent(report.value)+'&reason='+encodeURIComponent(reason.value.trim());
        const data=await api(url);history.replaceChildren(txt('h4','Contexto da mensagem denunciada: '+(chat.name||chat.users.join(', '))));
        for(const m of data.messages||[]){const item=line('@'+m.author+' • '+(m.text||'(anexo)'),date(m.time));
         if(m.file){const fileButton=btn('Ver imagem',async()=>{try{const url='/api/staff-dm?chat='+encodeURIComponent(chat.id)+'&report_id='+encodeURIComponent(report.value)+'&reason='+encodeURIComponent(reason.value.trim())+'&file='+encodeURIComponent(m.file);const resp=await fetch(url,{headers:{Authorization:'Bearer '+session}});if(!resp.ok)throw Error('HTTP '+resp.status);const blob=await resp.blob();const blobUrl=URL.createObjectURL(blob);window.open(blobUrl,'_blank','noopener,noreferrer');setTimeout(()=>URL.revokeObjectURL(blobUrl),60000)}catch(e){actionError(e)}});controls(item,fileButton)}history.append(item)}
       }catch(e){history.replaceChildren();actionError(e)}
      },'explicit-admin-primary');const expand=btn('Solicitar mais contexto',async()=>{
       const justification=await nexoForm('Solicitar ampliação da denúncia',[{name:'reason',label:'Justificativa detalhada (mínimo 15 caracteres)',required:true}]);if(!justification)return;
       try{await api('staff-dm','POST',{action:'request_expand',report_id:report.value,chat:chat.id,reason:justification.reason});nexoToast('Solicitação registrada. Outro Admin deve aprovar.')}catch(e){actionError(e)}
      });
      const approve=btn('Aprovar ampliação',async()=>{try{await api('staff-dm','POST',{action:'approve_expand',report_id:report.value,chat:chat.id,reason:'Revisão independente de escopo do caso'});nexoToast('Ampliação aprovada. Reabra o contexto.')}catch(e){actionError(e)}});
      controls(row,open,expand,approve);list.append(row);
    }
   }catch(e){list.replaceChildren();actionError(e)}
  },'explicit-admin-primary');form.append(browse);
  content.append(p);
 }else if(tab==='staffaudit'){
  const p=pane('Auditoria da Staff','Histórico global somente para leitura. Ações não podem ser excluídas pela interface. Arquivos locais ainda exigem backup externo protegido.');
  if(!['owner','superadmin','admin','moderator'].includes(data.role)){p.append(empty('Acesso restrito.'));content.append(p);return}
  const entries=(data.staff?.audit||[]).slice().reverse();for(const a of entries){p.append(line(`${a.action} • ${a.target}`,`@${a.actor} • ${date(a.at)} • ${a.details} • hash ${String(a.hash||'').slice(0,12)}`))}
  if(!entries.length)p.append(empty('Sem registros.'));content.append(p);
 }else if(tab==='audit'){
  const p=pane('Auditoria','Últimas 50 ações globais registradas pelo backend.');
  const entries=(data.audit||[]).slice(-50).reverse();for(const a of entries)p.append(line(`${a.action} · ${a.target}`,`@${a.actor} · ${date(a.at)}${a.reason?' · '+a.reason:''}`));
  if(!entries.length)p.append(empty('Nenhuma ação registrada.'));content.append(p);
 }
}
window.explicitOpenAdmin=async function(){
 if(view&&view.isConnected){view.closest('.obsidian-modal-backdrop')?.remove();view=null}
 try{await api('system-admin')}catch(e){actionError(e);return}
 const back=document.createElement('div');back.className='obsidian-modal-backdrop explicit-admin-backdrop';
 view=document.createElement('section');view.className='obsidian-modal workspace-modal explicit-admin-console';view.setAttribute('role','dialog');view.setAttribute('aria-modal','true');view.setAttribute('aria-label','Central de administração Explicit');
 const header=document.createElement('header');header.className='explicit-admin-header';const heading=document.createElement('div');heading.append(txt('small','EXPLICIT • CONTROLE GLOBAL'),txt('h2','Central de administração'),txt('p','Gestão de contas, segurança, comunidades e divulgação'));header.append(heading);
 header.append(btn('✕',()=>back.remove(),'explicit-admin-close'));
 const body=document.createElement('div');body.className='explicit-admin-shell';const nav=document.createElement('nav');nav.className='explicit-admin-nav';nav.setAttribute('aria-label','Seções administrativas');
 for(const [tab,label] of [['overview','Visão geral'],['spotlight','Divulgações'],['announcements','Comunicados'],['users','Usuários'],['reports','Denúncias'],['communities','Comunidades'],['moderation','Moderação global'],['privates','Conversas privadas'],['staffaudit','Auditoria Staff'],['audit','Auditoria']]){
  const b=btn(label,()=>{void render(tab)},'explicit-admin-nav-item');b.dataset.adminTab=tab;nav.append(b)
 }
 const content=document.createElement('main');content.className='explicit-admin-content';body.append(nav,content);view.append(header,body);back.append(view);document.body.append(back);
 back.addEventListener('pointerdown',e=>{if(e.target===back)back.remove()});back.addEventListener('keydown',e=>{if(e.key==='Escape'&&e.target===back)back.remove()});
 await render('overview');
};
// Bind global entry point at click time to avoid stale function references.
window.addEventListener('DOMContentLoaded',()=>{const rail=document.getElementById('nexoRail');if(!rail)return;rail.addEventListener('click',e=>{const b=e.target.closest('#explicitAdminNav');if(!b)return;e.stopPropagation();e.preventDefault();void window.explicitOpenAdmin()},true)});
})();
