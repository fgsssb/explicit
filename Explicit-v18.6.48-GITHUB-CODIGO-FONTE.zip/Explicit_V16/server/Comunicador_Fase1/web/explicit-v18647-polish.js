/* Local SVG affordances: no observer, network requests or change to action handlers. */
(()=>{'use strict';
 const icons={attach:'<path d="m8 12 6-6a3 3 0 0 1 4 4l-8 8a5 5 0 0 1-7-7l9-9"/><path d="m7 13 7-7"/>',smile:'<circle cx="12" cy="12" r="9"/><path d="M8 14a4 4 0 0 0 8 0M8 9h.01M16 9h.01"/>',mic:'<rect x="9" y="2" width="6" height="12" rx="3"/><path d="M5 10a7 7 0 0 0 14 0M12 17v5m-4 0h8"/>',headphones:'<path d="M3 14v-3a9 9 0 0 1 18 0v3"/><rect x="3" y="13" width="4" height="8" rx="2"/><rect x="17" y="13" width="4" height="8" rx="2"/>',settings:'<circle cx="12" cy="12" r="4"/><path d="M12 2v3m0 14v3M2 12h3m14 0h3M5 5l2 2m10 10 2 2M5 19l2-2M17 7l2-2"/>',mail:'<rect x="3" y="5" width="18" height="14" rx="2"/><path d="m3 6 9 7 9-7"/>'};
 const svg=key=>'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false">'+icons[key]+'</svg>';
 function apply(){
  for(const [selector,key] of [['#attachImage,#directAttach','attach'],['#explicitEmojiButton','smile'],['.explicit-dm-icon','mail']])for(const node of document.querySelectorAll(selector))node.innerHTML=svg(key);
  for(const button of document.querySelectorAll('.explicit-dm-mini button')){const key=button.title==='Alternar microfone'?'mic':button.title==='Alternar áudio'?'headphones':button.title==='Configurações'?'settings':null;if(key){button.innerHTML=svg(key);button.setAttribute('aria-label',button.title)}}
 }
 apply();
 if(typeof openDirect==='function'){const original=openDirect;openDirect=async function(...args){const result=await original.apply(this,args);apply();return result}}
})();
