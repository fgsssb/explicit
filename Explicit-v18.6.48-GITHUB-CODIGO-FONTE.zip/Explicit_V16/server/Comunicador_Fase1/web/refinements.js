/* Explicit 18.6: channel drag/drop and profile polish. */
(()=>{'use strict';
 const list=document.getElementById('channelList');let dragged='';
 const current=()=>communities.find(c=>c.id===activeCommunity);
 function categoryOf(node){return node?.closest('[data-explicit-category]')?.dataset.explicitCategory||''}
 function target(el){return el.closest('[data-explicit-channel], [data-explicit-category], .voice-label')}
 list.addEventListener('dragstart',e=>{const item=e.target.closest('[data-explicit-channel]');if(!item)return;dragged=item.dataset.explicitChannel;e.dataTransfer.effectAllowed='move';e.dataTransfer.setData('text/plain',dragged);item.classList.add('explicit-dragging')});
 list.addEventListener('dragend',()=>{dragged='';list.querySelectorAll('.explicit-dragging,.explicit-drop-target').forEach(n=>n.classList.remove('explicit-dragging','explicit-drop-target'))});
 list.addEventListener('dragover',e=>{if(!dragged)return;const el=target(e.target);if(!el)return;e.preventDefault();e.dataTransfer.dropEffect='move';list.querySelectorAll('.explicit-drop-target').forEach(n=>n.classList.remove('explicit-drop-target'));el.classList.add('explicit-drop-target')});
 list.addEventListener('drop',async e=>{if(!dragged)return;const dest=target(e.target);if(!dest)return;e.preventDefault();e.stopPropagation();const channel=dragged;dragged='';list.querySelectorAll('.explicit-drop-target,.explicit-dragging').forEach(n=>n.classList.remove('explicit-drop-target','explicit-dragging'));
 let before='',category='';if(dest.dataset.explicitChannel){before=dest.dataset.explicitChannel;category=categoryOf(dest)}else if(dest.dataset.explicitCategory){category=dest.dataset.explicitCategory}else if(dest.classList.contains('voice-label')){category=''}if(before===channel)return;
 const c=current();if(!c)return;const canSync=(adminState?.permissions||[]).some(key=>['MANAGE_ROLES','ADMINISTRATOR'].includes(key));const sync=canSync&&!!category&&c.channel_meta?.[channel]?.category!==category;
 try{await api('channel-permissions','POST',{community:activeCommunity,action:'channel_reorder',channel,before,category,sync});await refreshCommunities();nexoToast('Canal movido'+(sync?' e sincronizado com a categoria.':'.'))}catch(err){nexoToast('Não foi possível mover canal: '+err.message,'error')}
 });
 // Context menu on empty sidebar space. Channel-specific menus are handled by ACL.
 list.addEventListener('contextmenu',e=>{if(!activeCommunity||e.target.closest('.channelButton,.voice-group,.explicit-acl-category-title'))return;e.preventDefault();e.stopPropagation();contextMenu(e,[...((adminState?.permissions||[]).includes('CREATE_CHANNEL')?[['＋ Criar canal',()=>createChannel()]]:[]),...((adminState?.permissions||[]).includes('MANAGE_CHANNELS')?[['＋ Criar categoria',()=>window.explicitCreateCategory?.()]]:[]),['Atualizar canais',()=>refreshCommunities()]])});
 const oldProfile=openExplicitProfile;
 openExplicitProfile=async function(){let u;try{u=await api('status')}catch(e){return nexoToast(e.message,'error')}
 const box=modalWorkspace('Minha conta');box.classList.add('explicit-profile-modal','explicit-profile-redesign');const hero=document.createElement('div');hero.className='explicit-profile-hero';const avatar=document.createElement('div');avatar.className='explicit-profile-circle';avatar.textContent=(u.display_name||u.username||'?').slice(0,1).toUpperCase();if(u.avatar){avatar.style.backgroundImage='url("'+explicitVisualURL('avatar',u.username)+'&v='+Date.now()+'")';avatar.style.backgroundSize='cover';avatar.style.backgroundPosition='center';avatar.style.fontSize='0'}const identity=document.createElement('div');identity.className='explicit-profile-identity';const strong=document.createElement('strong');strong.textContent=u.display_name||u.username;const handle=document.createElement('small');handle.textContent='@'+u.username;identity.append(strong,handle);hero.append(avatar,identity);box.append(hero);const uploadLabel=document.createElement('label');uploadLabel.className='explicit-avatar-upload';uploadLabel.textContent='Alterar foto de perfil';const file=document.createElement('input');file.type='file';file.accept='image/png,image/jpeg,image/gif';uploadLabel.append(file);box.append(uploadLabel);file.onchange=async()=>{const image=file.files?.[0];file.value='';if(!image)return;try{await explicitUploadVisual('avatar',u.username,image);await updateExplicitMini();await refreshMembers();nexoToast('Foto atualizada.');box.closest('.obsidian-modal-backdrop')?.remove();openExplicitProfile()}catch(e){nexoToast(e.message,'error')}};
 const detail=document.createElement('section');detail.className='explicit-profile-section';const title=document.createElement('strong');title.textContent='Informações da conta';const email=document.createElement('small');email.textContent='E-mail cadastrado';const address=document.createElement('span');address.textContent=u.email||'Não cadastrado';detail.append(title,email,address);box.append(detail);
 const plus=document.createElement('section');plus.className='explicit-profile-section explicit-plus-term';
 const plusTitle=document.createElement('strong');plusTitle.textContent='Explicit+';
 const plusTimer=document.createElement('span');plusTimer.className='explicit-plus-countdown';
 const plusSub=document.createElement('small');plusSub.textContent='Validade do acesso';
 plus.append(plusTitle,plusSub,plusTimer);
 const expires=u.explicit_plus_expires_at?Date.parse(u.explicit_plus_expires_at):0;
 const format=(seconds)=>{const d=Math.floor(seconds/86400),h=Math.floor(seconds%86400/3600),m=Math.floor(seconds%3600/60),ss=seconds%60;return `${d}d ${h}h ${m}min ${ss}s`};
 const drawPlus=()=>{
  if(!plus.isConnected)return false;
  if(u.explicit_plus){
   if(expires){const left=Math.max(0,Math.ceil((expires-Date.now())/1000));plusTimer.textContent=left?format(left):'Expirado';plusTimer.dataset.expired=String(!left)}
   else plusTimer.textContent='Ativo — prazo não definido (concessão anterior)';
  }else if(expires){plusTimer.textContent='Expirado em '+new Date(expires).toLocaleString('pt-BR')}
  else plusTimer.textContent='Sem acesso ativo';
  return true;
 };
 box.append(plus);drawPlus();
 if(expires&&u.explicit_plus){const timer=setInterval(()=>{if(!drawPlus())clearInterval(timer)},1000)}

 const invite=document.createElement('section');invite.className='explicit-profile-section';invite.append(Object.assign(document.createElement('strong'),{textContent:'Convites pessoais'}));const help=document.createElement('small');help.textContent='Carregando sua chave de convite…';invite.append(help);box.append(invite);
 api('invite').then(info=>{help.textContent=info.unlimited?'Convites ilimitados':`${info.remaining} convites restantes de ${info.limit}`;const key=document.createElement('code');key.textContent=info.key;invite.append(key);const copy=document.createElement('button');copy.textContent='Copiar código';copy.onclick=()=>{navigator.clipboard?.writeText(info.key).then(()=>nexoToast('Código de convite copiado.')).catch(()=>nexoToast('Falha ao copiar.','error'))};invite.append(copy)}).catch(()=>help.textContent='Não foi possível consultar o convite');
 const actions=document.createElement('div');actions.className='explicit-profile-actions';const rename=document.createElement('button');rename.textContent='Editar nome';rename.onclick=async()=>{const v=await nexoForm('Nome de exibição',[{name:'display_name',label:'Novo nome',value:u.display_name,required:true}]);if(!v)return;try{await api('profile','POST',{action:'display_name',display_name:v.display_name});await updateExplicitMini();box.closest('.obsidian-modal-backdrop')?.remove();openExplicitProfile()}catch(e){nexoToast(e.message,'error')}};const pass=document.createElement('button');pass.textContent='Alterar senha';pass.onclick=async()=>{const v=await nexoForm('Alterar senha',[{name:'current_password',label:'Senha atual',type:'password',required:true},{name:'new_password',label:'Nova senha',type:'password',required:true},{name:'confirm_password',label:'Confirmar senha',type:'password',required:true}]);if(!v)return;try{await api('profile','POST',{action:'password',...v});nexoToast('Senha alterada.')}catch(e){nexoToast(e.message,'error')}};actions.append(rename,pass);box.append(actions)
 };
 // Presentation only: existing server-side sticker authorization remains intact.
 function stickerCopy(){const pane=document.querySelector('.explicit-sticker-locked');if(!pane)return;const title=pane.querySelector('strong');const line=pane.querySelector('p');if(title&&title.textContent!=='Crie suas próprias figurinhas')title.textContent='Crie suas próprias figurinhas';if(line&&line.textContent!=='Envie imagens e use em qualquer comunidade com o Explicit+.')line.textContent='Envie imagens e use em qualquer comunidade com o Explicit+.'}
 const obs=new MutationObserver(stickerCopy);const picker=document.getElementById('explicitEmojiPicker');if(picker)obs.observe(picker,{subtree:true,childList:true});stickerCopy();
})();
