/* Explicit: persistent account preferences, safe notification delivery and mentions. */
(()=>{'use strict';
 const types={message:'Mensagens nos canais',mention:'Menções recebidas',direct:'Mensagens privadas',friend:'Pedidos de amizade',voice_join:'Entrada no canal de voz',voice_leave:'Saída do canal de voz',screen:'Compartilhamento de tela'};
 const baseline=()=>({message_mode:'all',messages:true,mentions:true,direct:true,friends:true,voice_join:true,voice_leave:true,screen:true,sound:true,desktop:true});
 let prefs=baseline(),status='online',cursor=null,account='',loading=false,communityPrefs={},taskbarCount=-1;
 function setTaskbarCount(n){const count=Math.max(0,Math.min(100,Math.floor(Number(n)||0)));if(count===taskbarCount)return;taskbarCount=count;window.explicitDesktopSettings?.setNotificationCount?.(count).catch(()=>{})}
 window.explicitTaskbarBadgeClear=()=>{taskbarCount=-1;setTaskbarCount(0)};
 const currentUser=()=>document.getElementById('who')?.textContent?.trim()||'';
 const channelMode=(p,k)=>k==='message'&&(p.message_mode==='mentions'||!p.messages)?false:k==='mention'?p.mentions:k==='direct'?p.direct:k==='friend'?p.friends:p[k]!==false;
 function notificationMode(value){return value==='busy'?'none':value==='away'||value==='offline'?'sound':'all'}
 let alertContext=null;
 function ensureAudio(){try{const AC=window.AudioContext||window.webkitAudioContext;if(!AC)return null;if(!alertContext)alertContext=new AC();if(alertContext.state==='suspended')void alertContext.resume().catch(()=>{});return alertContext}catch{return null}}
 // Browsers initially suspend audio until a user gesture; activate the shared
 // context on click/key rather than creating a brand-new context on each ping.
 document.addEventListener?.('pointerdown',ensureAudio,{passive:true});
 document.addEventListener?.('keydown',ensureAudio);
 function beep(){try{const ctx=ensureAudio();if(!ctx)return;const start=ctx.currentTime+.015;
  // Três notas originais, suaves e curtas: assinatura sonora do Explicit.
  for(const [frequency,offset,duration] of [[493.88,0,.19],[659.25,.08,.22],[987.77,.17,.31]]){
   const osc=ctx.createOscillator(),filter=ctx.createBiquadFilter(),gain=ctx.createGain();const at=start+offset;osc.type='triangle';osc.frequency.value=frequency;filter.type='lowpass';filter.frequency.value=2250;
   gain.gain.setValueAtTime(.0001,at);gain.gain.exponentialRampToValueAtTime(.045,at+.012);gain.gain.exponentialRampToValueAtTime(.0001,at+duration);
   osc.connect(filter);filter.connect(gain);gain.connect(ctx.destination);osc.start(at);osc.stop(at+duration+.01);osc.onended=()=>{osc.disconnect();filter.disconnect();gain.disconnect()}
  }
 }catch(e){console.debug('Som de notificação indisponível:',e)}}

 const recent=new Set();
 function dispatch(event){if(!event||!event.kind||!channelMode(prefs,event.kind))return;const own=event.community?communityPrefs[event.community]:null;if(own&&(own.muted_until===-1||own.muted_until>Date.now()/1000||own.message_mode==='none'||(own.message_mode==='mentions'&&event.kind==='message')||own.channel_modes?.[event.channel]==='none'||(own.channel_modes?.[event.channel]==='mentions'&&event.kind==='message')))return;if(event.author===currentUser())return;
  const key=event.id||[event.kind,event.author,event.community,event.channel,Date.now()].join('/');if(recent.has(key))return;recent.add(key);if(recent.size>700)recent.clear();
  const mode=notificationMode(status);if(mode==='none')return;if(mode==='sound'){if(prefs.sound)beep();return;}
  const label=types[event.kind]||'Atividade';const author=event.author?'@'+event.author+' · ':'';const title='Explicit · '+label;const body=(author+(event.text||event.channel||'Nova atividade')).slice(0,220);
  if(prefs.desktop){if(window.explicitDesktopSettings?.showNotification){if(prefs.sound)beep();window.explicitDesktopSettings.showNotification({title,body,silent:true}).catch(console.debug);}else if('Notification' in window&&Notification.permission==='granted'){try{new Notification(title,{body,silent:true});if(prefs.sound)beep()}catch{if(prefs.sound)beep()}}else if(prefs.sound)beep();}else if(prefs.sound)beep()
  // Discreet in-app toast; no toast or desktop popup for Away/Offline.
  if(prefs.desktop){if(typeof window.nexoToast==='function')window.nexoToast(label+': '+author+(event.text||''));else if(typeof nexoToast==='function')nexoToast(label+': '+author+(event.text||''));}
 }
 window.explicitNotifyLocal=dispatch;
 window.explicitSetNotificationStatus=(value)=>{status=value};
 window.explicitNotificationPolicy=Object.freeze({notificationMode,channelMode});
 async function poll(){if(typeof session==='undefined'||!session){cursor=null;account='';setTaskbarCount(0);return}const user=currentUser();if(!user)return;if(account!==user){account=user;cursor=null;prefs=baseline();recent.clear();taskbarCount=-1;setTaskbarCount(0)}if(loading)return;loading=true;
  try{const result=await api('notifications'+(cursor?'?after='+encodeURIComponent(cursor):''));if(result.preferences)prefs=result.preferences;communityPrefs=result.community_prefs||{};status=result.status||'online';setTaskbarCount(result.unread_count);if(cursor){const items=result.items||[];for(const item of items.slice(-8))dispatch(item)}cursor=result.cursor||cursor||'0';}
  catch(e){console.debug('Notificações:',e.message)}finally{loading=false}}
 window.explicitRefreshNotifications=poll;
 // Poll even when home, in private chats, or viewing another community.
 setInterval(()=>{void poll()},3000);setTimeout(()=>void poll(),1200);
 function renderMentions(parent,source){const text=String(source||'');const pattern=/@\{[^}\n]{1,64}\}|@[\p{L}\p{N}_.-]{1,64}/gu;let start=0,match;while((match=pattern.exec(text))){if(match.index>start)parent.append(document.createTextNode(text.slice(start,match.index)));const tag=document.createElement('span');tag.className='explicit-mention-highlight';tag.textContent=match[0];parent.append(tag);start=pattern.lastIndex}if(start<text.length)parent.append(document.createTextNode(text.slice(start)));}
 window.explicitRenderMentions=renderMentions;
 window.explicitBuildNotificationSettings=({group,row,button,note})=>{
  const mode=group('Quando você recebe alertas','Online: som e avisos. Ocupado: nenhum aviso. Ausente e Offline: somente som, enquanto o Explicit estiver aberto.');
  note(mode,'As preferências são salvas na sua conta e se aplicam a outros computadores. Notificações do sistema dependem das permissões do Windows.');
  const message=group('Mensagens em canais de texto');
  const select=document.createElement('select');select.className='explicit-notify-select';for(const [value,label] of [['all','Todas as mensagens'],['mentions','Somente quando me mencionarem']]){const option=document.createElement('option');option.value=value;option.textContent=label;select.append(option)}select.value=prefs.message_mode||'all';select.onchange=()=>update({message_mode:select.value});row(message,'Notificar sobre','Escolha quantas mensagens geram avisos.',select);
  const checks=group('Silenciar tipos de notificação','Desative individualmente qualquer categoria. A opção de menções também controla @everyone e menções a cargos.');
  const specs=[['messages','Mensagens comuns','Avisos sobre mensagens dos canais.'],['mentions','Menções','Quando alguém usar @seu usuário, @cargo ou @everyone.'],['direct','Mensagens privadas','Novas mensagens recebidas por DM.'],['friends','Pedidos de amizade','Alguém enviou uma solicitação.'],['voice_join','Entrada em canal de voz','Alguém entrou no canal de voz em que você está.'],['voice_leave','Saída de canal de voz','Alguém saiu do seu canal de voz.'],['screen','Início de transmissão','Alguém começou a compartilhar tela em sua sala.'],['sound','Sons de notificação','Desativar todos os efeitos sonoros de aviso.'],['desktop','Avisos visuais','Desativar banners do Windows e avisos dentro do Explicit.']];
  for(const [key,title,description] of specs){const input=document.createElement('input');input.type='checkbox';input.className='explicit-settings-toggle';input.checked=prefs[key]!==false;input.setAttribute('aria-label',title);input.onchange=()=>update({[key]:input.checked});row(checks,title,description,input)}
  const clear=group('Indicadores não lidos','Zere o contador geral da barra de tarefas e os marcadores de comunidades e conversas privadas.');
  button(clear,'Marcar todas como lidas','Não exclui nenhuma mensagem.','Marcar tudo como lido',async()=>{await api('notifications','POST',{action:'read_all'});setTaskbarCount(0);await window.explicitRefreshCommunityBadges?.();await window.explicitRefreshDirectRail?.();await poll()});
  const test=group('Verificar notificações');button(test,'Tocar aviso de teste','Reproduz um aviso sem enviar mensagens.','Testar som',async()=>beep());button(test,'Testar alerta do Windows','Mostra um alerta local (quando permitido pelo sistema).','Testar aviso',async()=>{const d=window.explicitDesktopSettings;if(!d)throw Error('Teste nativo disponível no aplicativo Windows');const result=await d.testNotification();if(!result.ok)throw Error(result.reason||'Indisponível')});if(!window.explicitDesktopSettings&&'Notification' in window)button(test,'Autorizar notificações no navegador','Necessário para receber avisos em navegadores compatíveis.','Solicitar permissão',async()=>{const value=await Notification.requestPermission();if(value!=='granted')throw Error('Permissão não concedida')});
  async function update(changes){const previous={...prefs};prefs={...prefs,...changes};try{const result=await api('notifications','PUT',prefs);prefs=result.preferences||prefs;}catch(e){prefs=previous;if(typeof nexoToast==='function')nexoToast('Não foi possível salvar as notificações: '+e.message,'error')}}
  void api('notifications').then(data=>{prefs=data.preferences||prefs;status=data.status||'online';if(!checks.isConnected)return;document.querySelectorAll('.explicit-settings-row input.explicit-settings-toggle').forEach(input=>{const found=specs.find(([,name])=>name===input.getAttribute('aria-label'));if(found)input.checked=prefs[found[0]]!==false});select.value=prefs.message_mode||'all'}).catch(()=>{});
 };
})();
