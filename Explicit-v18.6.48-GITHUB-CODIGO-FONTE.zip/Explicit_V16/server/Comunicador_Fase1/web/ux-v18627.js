/* Explicit v18.6.27 — additive UX fixes. Server remains source of permission decisions. */
(()=>{'use strict';
const create=(tag,cls,text)=>{const n=document.createElement(tag);if(cls)n.className=cls;if(text!==undefined)n.textContent=text;return n};
const own=()=>document.getElementById('who')?.textContent?.trim()||'';
const safeToast=(message,error=false)=>{if(typeof nexoToast==='function')nexoToast(message,error?'error':undefined)};
// Invite requirement is public configuration; unknown means keep the safe default visible.
let inviteRequired=true;
let inviteRequestSerial=0;
async function refreshInvite(){
 const serial=++inviteRequestSerial;
 const line=document.getElementById('registerInvite')?.closest('.explicit-register-field');
 // No outdated response may override a newer administrator setting.
 try{
  const response=await fetch('/api/register-config',{method:'GET',cache:'no-store',headers:{'Accept':'application/json'}});
  if(!response.ok)throw Error('HTTP '+response.status);
  const settings=await response.json();if(serial!==inviteRequestSerial)return;
  inviteRequired=settings.require_invite!==false;
 }catch(e){if(serial!==inviteRequestSerial)return;inviteRequired=true;console.warn('Registro: não foi possível consultar a configuração',e)}
 if(line){line.hidden=!inviteRequired;line.style.setProperty('display',inviteRequired?'':'none',inviteRequired?'':'important');line.classList.toggle('explicit-invite-unrequired',!inviteRequired);if(!inviteRequired)document.getElementById('registerInvite').value=''}
}
window.explicitRefreshRegistrationInvite=refreshInvite;
const originalMode=window.setExplicitAuthMode;
window.setExplicitAuthMode=function(mode){originalMode?.(mode);if(mode==='register')void refreshInvite()};
void refreshInvite();document.addEventListener('visibilitychange',()=>{if(!document.hidden&&!session)void refreshInvite()});
window.addEventListener('focus',()=>{if(document.getElementById('auth')?.classList.contains('explicit-auth-register'))void refreshInvite()});
// Profile card chooses status directly. The gear opens the full settings overlay.
const gear=document.getElementById('explicitSettingsGear');if(gear)gear.onclick=ev=>{ev.stopPropagation();document.getElementById('explicitProfileMenu')?.remove();openSettings('Geral')};
const originalMenu=window.toggleExplicitProfileMenu;
window.toggleExplicitProfileMenu=function(e){originalMenu?.(e);const menu=document.getElementById('explicitProfileMenu');if(!menu)return;const status=Array.from(menu.querySelectorAll('button')).find(b=>b.textContent.includes('Alterar status'));const logout=Array.from(menu.querySelectorAll('button')).find(b=>b.textContent.includes('Sair da conta'));menu.querySelector('.explicit-inventory-link')?.remove();if(status){status.click();menu.querySelector('button')?.remove();if(logout)menu.append(logout);const rect=menu.getBoundingClientRect();menu.style.top=Math.max(8,Math.min(rect.top,innerHeight-menu.offsetHeight-8))+'px'}};
// Notifications/ringtone may require the platform to have an unlocked AudioContext.
window.explicitReceivePoke=function(from){
 safeToast('@'+from+' enviou um poke!');
 try{const A=window.AudioContext||window.webkitAudioContext;if(!A)return;const c=new A();void c.resume().then(()=>{for(const [i,f] of [880,660,990].entries()){const o=c.createOscillator(),gain=c.createGain(),start=c.currentTime+i*.19;o.type='sine';o.frequency.setValueAtTime(f,start);gain.gain.setValueAtTime(.0001,start);gain.gain.exponentialRampToValueAtTime(.28,start+.02);gain.gain.exponentialRampToValueAtTime(.0001,start+.16);o.connect(gain);gain.connect(c.destination);o.start(start);o.stop(start+.17)}setTimeout(()=>{void c.close().catch(()=>{})},950)}).catch(()=>{})}catch(e){console.warn('Poke audio:',e)}
};
// Stamp the same actions onto both the immediate and long-poll DM message renderers.
window.explicitDecorateDM=function(row,message,chatId,content){
 if(message.deleted)return;
 row.dataset.explicitDMMessage=message.id;
 if(message.pinned){const badge=create('span','explicit-dm-pinned','📌 Fixada');content.prepend(badge);row.classList.add('explicit-dm-is-pinned')}
 if(message.edited_at){const stamp=create('small','explicit-dm-edited','(editada)');content.querySelector('.explicit-dm-meta')?.append(stamp)}
 if(message.sticker){const image=create('img','explicit-dm-sticker-image');image.alt='Figurinha de '+message.author;image.loading='lazy';content.append(image);void stickerSrc(image,message.sticker)}
 row.addEventListener('contextmenu',event=>{
   if(event.target.closest('a,input,textarea'))return;
   event.preventDefault();event.stopPropagation();if(typeof contextMenu!=='function')return;
   const mine=message.author===own();const items=[];
   const command=async(action)=>{try{let text='';if(action==='edit_message'){text=await nexoPrompt('Editar mensagem privada','Novo texto da mensagem',message.text);if(text===null||!text?.trim())return}if(action==='delete_message'&&!await nexoDialog('Excluir mensagem privada','Deseja realmente excluir esta mensagem?'))return;await api('direct','POST',{id:chatId,action,message_id:message.id,text});safeToast(action==='edit_message'?'Mensagem editada.':action==='delete_message'?'Mensagem excluída.':action==='pin_message'?'Mensagem fixada.':'Mensagem desafixada.');if(activeDirect===chatId)await openDirect(chatId)}catch(e){safeToast('Não foi possível alterar a mensagem: '+e.message,true)}};
   if(mine&&!message.staff_notice){if(!message.file&&!message.sticker)items.push(['Editar mensagem',()=>command('edit_message')]);items.push(['Excluir mensagem',()=>command('delete_message')])}
   if(!message.staff_notice)items.push([message.pinned?'Desafixar mensagem':'Fixar mensagem',()=>command(message.pinned?'unpin_message':'pin_message')]);
   if(items.length)contextMenu(event,items);
 });
};
const ownedURLs=new WeakMap();
async function stickerSrc(image,id){try{const res=await fetch('/api/stickers?id='+encodeURIComponent(id),{headers:{Authorization:'Bearer '+session}});if(!res.ok)throw Error('Indisponível');const src=URL.createObjectURL(await res.blob());if(!image.isConnected){URL.revokeObjectURL(src);return}image.src=src;ownedURLs.set(image,src);image.addEventListener('load',()=>setTimeout(()=>URL.revokeObjectURL(src),3000),{once:true})}catch{image.alt='Figurinha indisponível'}}
function closePicker(){document.querySelector('.explicit-dm-picker')?.remove()}
window.explicitInstallDMCompose=function(root,id){
 const composer=root.querySelector('#directComposer');if(!composer||composer.querySelector('.explicit-dm-emoji-btn'))return;
 const input=composer.elements.text;
 const btn=create('button','explicit-dm-emoji-btn','☺');btn.type='button';btn.title='Emojis e figurinhas';btn.setAttribute('aria-label','Escolher emojis e figurinhas');
 composer.insertBefore(btn,composer.querySelector('button[type=submit]'));
 const choose=async()=>{
 closePicker();const picker=create('section','explicit-dm-picker');picker.setAttribute('role','dialog');picker.setAttribute('aria-label','Emojis e figurinhas');const tabs=create('div','explicit-dm-picker-tabs'),contents=create('div','explicit-dm-picker-grid');
 const emojiBtn=create('button','','Emojis'),stickerBtn=create('button','','Figurinhas');emojiBtn.type=stickerBtn.type='button';tabs.append(emojiBtn,stickerBtn);picker.append(tabs,contents);composer.append(picker);
 const renderEmoji=()=>{contents.replaceChildren();for(const ch of '😀 😁 😂 😍 🥰 😎 😭 😤 🙌 💙 ❤️ 🔥 👍 👏 🎉 🎮 👋 ✨ 😴 🤔 👀 💯 🤝 😇 🤣 🫶'.split(' ')){const b=create('button','',ch);b.type='button';b.onclick=()=>{const a=input.selectionStart??input.value.length,z=input.selectionEnd??a;input.setRangeText(ch,a,z,'end');input.focus();closePicker()};contents.append(b)}};
 emojiBtn.onclick=renderEmoji;stickerBtn.onclick=async()=>{contents.replaceChildren(create('p','','Carregando figurinhas…'));try{const data=await api('stickers');contents.replaceChildren();if(!data.can_send){contents.textContent='Figurinhas disponíveis para Beta, Explicit+ ou Staff.';return}const used=new Set();for(const st of [...(data.owned||[]),...(data.favorites||[])]){if(used.has(st.id))continue;used.add(st.id);const tile=create('button','explicit-dm-sticker-tile');tile.type='button';tile.title='Enviar figurinha';const image=create('img');image.alt='Figurinha';tile.append(image);void stickerSrc(image,st.id);tile.onclick=async()=>{tile.disabled=true;try{await api('direct','POST',{action:'send_sticker',id,sticker:st.id});closePicker();if(activeDirect===id)await openDirect(id)}catch(e){safeToast('Figurinha: '+e.message,true);tile.disabled=false}};contents.append(tile)}if(!used.size)contents.textContent='Nenhuma figurinha em sua biblioteca. Adicione pela área de figurinhas do Explicit.'}catch(e){contents.textContent='Falha ao carregar figurinhas: '+e.message}};
 if(btn.getBoundingClientRect().top<290){picker.style.bottom='auto';picker.style.top='calc(100% + 7px)'}btn.setAttribute('aria-expanded','true');picker.addEventListener('click',ev=>ev.stopPropagation());renderEmoji();
 };
 btn.onclick=e=>{e.stopPropagation();if(composer.querySelector('.explicit-dm-picker'))closePicker();else void choose()};
 
};
document.addEventListener('pointerdown',event=>{if(!event.target.closest('.explicit-dm-picker,.explicit-dm-emoji-btn'))closePicker()});
// Keep account/status controls available on Home and DMs, where the
// community's voice dock is deliberately hidden. This is a compact profile
// dock, not a duplicate "Settings" navigation entry.
const railNav=document.getElementById('nexoRail');
if(railNav){
 const dock=create('div','explicit-rail-account-dock');dock.id='explicitRailAccountDock';
 const avatar=create('button','explicit-rail-account-avatar','E');avatar.type='button';avatar.title='Definir status';avatar.setAttribute('aria-label','Perfil e status');
 const settings=create('button','explicit-rail-account-gear','⚙');settings.type='button';settings.title='Configurações de usuário';settings.setAttribute('aria-label','Configurações de usuário');
 const sync=()=>{avatar.textContent=(own().slice(0,2)||'E').toUpperCase()};
 const nameObserver=new MutationObserver(sync);const who=document.getElementById('who');if(who)nameObserver.observe(who,{childList:true,characterData:true,subtree:true});sync();const statusSource=document.getElementById('explicitMiniStatus');if(statusSource){const updateStatus=()=>{for(const key of ['online','away','busy','offline'])avatar.classList.toggle('explicit-rail-status-'+key,statusSource.classList.contains('explicit-status-'+key))};new MutationObserver(updateStatus).observe(statusSource,{attributes:true,attributeFilter:['class']});updateStatus()}
 avatar.addEventListener('click',event=>{event.stopPropagation();sync();window.toggleExplicitProfileMenu?.(event);const menu=document.getElementById('explicitProfileMenu');if(menu){menu.style.left='68px';menu.style.top=Math.max(8,innerHeight-menu.offsetHeight-12)+'px'}});
 settings.addEventListener('click',event=>{event.stopPropagation();document.getElementById('explicitProfileMenu')?.remove();openSettings('Geral')});
 dock.append(avatar,settings);railNav.append(dock);
}
// Remove the spurious rail overflow introduced by expanded call stages.
const rail=document.getElementById('railDirect');if(rail){rail.style.minHeight='0';rail.style.overflowX='hidden'}
// Resize-to-screen theater control for streams; fullscreen only on user gesture.
document.addEventListener('click',e=>{const video=e.target.closest('.explicit-private-video');if(!video || e.target.closest('button'))return;const media=video.querySelector('video');if(media?.requestFullscreen)void media.requestFullscreen().catch(()=>{});},{capture:false});
})();
