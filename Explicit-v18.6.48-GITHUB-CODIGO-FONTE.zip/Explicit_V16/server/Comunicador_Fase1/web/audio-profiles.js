/* Explicit — lightweight microphone input profiles. No external DSP or network calls.
 * Constraints are browser preferences, not guarantees of hardware processing. */
(function(root){
 'use strict';
 const valid=new Set(['clean','balanced','studio','custom']);
 function normalize(profile){return valid.has(profile)?profile:'clean'}
 function supported(mediaDevices){try{return mediaDevices?.getSupportedConstraints?.()||{}}catch{return {}}}
 function build(prefs={},mediaDevices){
  const mode=normalize(prefs.audioInputProfile);
  let echoCancellation=true,noiseSuppression=false,autoGainControl=false;
  if(mode==='balanced'){noiseSuppression=true;autoGainControl=true;}
  if(mode==='studio')echoCancellation=noiseSuppression=autoGainControl=false;
  if(mode==='custom'){
   echoCancellation=prefs.audioCustomEchoCancellation!==false;
   noiseSuppression=prefs.audioCustomNoiseSuppression!==false;
   autoGainControl=prefs.audioCustomAutoGainControl===true;
  }
  const options={echoCancellation,noiseSuppression,autoGainControl};
  // Experimental; only request when the browser advertises support. It must
  // never be a required constraint or an implicit paid-service dependency.
  if(mode==='custom'&&prefs.audioCustomVoiceIsolation===true&&supported(mediaDevices).voiceIsolation===true)options.voiceIsolation=true;
  const id=String(prefs.audioInputId||'default');
  if(id!=='default')options.deviceId={exact:id};
  return options;
 }
 // All capture devices may reject a newly introduced optional constraint;
 // retry with proven, standard WebRTC constraints without changing profile.
 function withoutExperimental(options){const result={...options};delete result.voiceIsolation;return result}
 root.ExplicitAudioProfiles=Object.freeze({normalize,build,withoutExperimental});
})(typeof globalThis!=='undefined'?globalThis:window);
