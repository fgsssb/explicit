/* Explicit v18.5 — resilient SSE transport using EventEmitter3 (MIT).
 * Never sends tokens to third parties; unchanged HTTP endpoint and auth.
 * Keep offline/fallback polling handled by the existing application.
 */
(function(root){
 'use strict';
 class ExplicitRealtimeEvents {
  constructor({bus,token,fetchFn,delay,setTimeoutFn,clearTimeoutFn}={}) {
   this.bus=bus || (root.EventEmitter3 ? new root.EventEmitter3() : null);
   if(!this.bus)throw Error('EventEmitter3 indisponível');
   this.token=token||(()=>null);
   this.fetchFn=fetchFn||((...args)=>fetch(...args));
   this.delay=delay||(()=>Math.random());
   this.setTimeoutFn=setTimeoutFn||((f,n)=>setTimeout(f,n));
   this.clearTimeoutFn=clearTimeoutFn||((id)=>clearTimeout(id));
   this.running=false;this.abortController=null;this.timer=null;
   this.failures=0;this.malformed=0;this.received=0;this.state='idle';
  }
  diagnostics(){return {state:this.state,reconnections:this.failures,received:this.received,invalidEvents:this.malformed};}
  start(){if(this.running)return;this.running=true;this.connect();}
  stop(){this.running=false;this.state='stopped';if(this.timer!==null)this.clearTimeoutFn(this.timer);this.timer=null;this.abortController?.abort();this.abortController=null;}
  reconnect(){if(!this.running)return;this.state='reconnecting';this.failures++;
   const wait=Math.min(20000,1000*Math.pow(2,Math.min(5,this.failures-1)))+Math.floor(this.delay()*350);
   this.bus.emit('chat:reconnecting',this.diagnostics());
   this.timer=this.setTimeoutFn(()=>{this.timer=null;if(this.running)this.connect()},wait);
  }
  async connect(){
   if(!this.running)return;
   const token=this.token();if(!token){this.stop();return;}
   const ctrl=new AbortController();this.abortController=ctrl;this.state='connecting';
   const active=()=>this.running&&this.abortController===ctrl&&!ctrl.signal.aborted;
   let reader=null;
   try{
    const response=await this.fetchFn('/api/events',{headers:{Authorization:'Bearer '+token},signal:ctrl.signal,cache:'no-store'});
    if(!active()){if(response.body?.cancel)await response.body.cancel().catch(()=>{});return;}
    if(response.status===401||response.status===403){this.bus.emit('chat:unauthorized');this.stop();return;}
    if(!response.ok||!response.body?.getReader)throw Error('Stream HTTP indisponível');
    this.failures=0;this.state='connected';this.bus.emit('chat:connected');
    reader=response.body.getReader();const decoder=new TextDecoder();let pending='';
    while(active()){
     const {value,done}=await reader.read();if(!active())return;if(done)break;
     pending+=decoder.decode(value,{stream:true});
     pending=pending.replace(/\r\n/g,'\n');
     let pos;
     while((pos=pending.indexOf('\n\n'))!==-1){
      if(!active())return;
      if(pos>262144)throw Error('Evento SSE excedeu o limite');
      const packet=pending.slice(0,pos);pending=pending.slice(pos+2);
      const lines=packet.split('\n').filter(line=>line.startsWith('data:'));
      if(!lines.length)continue;const raw=lines.map(line=>line.slice(5).trimStart()).join('\n');
      if(raw.length>131072){this.malformed++;continue;}
      try{const message=JSON.parse(raw);
       if(!message||typeof message!=='object'||typeof message.channel!=='string'||!message.id){this.malformed++;continue;}
       this.received++;this.bus.emit('chat:message',message);
      }catch{this.malformed++;this.bus.emit('chat:invalid');}
     }
     // Bound each unfinished event, independently of network chunk coalescing.
     if(pending.length>262144)throw Error('Evento SSE excedeu o limite');
    }
   }catch(err){if(!active())return;this.bus.emit('chat:transport-error');}
   finally{
    try{await reader?.cancel?.();}catch{}
    try{reader?.releaseLock?.();}catch{}
    if(this.abortController===ctrl)this.abortController=null;
   }
   if(this.running&&!ctrl.signal.aborted)this.reconnect();
  }
 }
 root.ExplicitRealtimeEvents=ExplicitRealtimeEvents;
})(typeof window!=='undefined'?window:globalThis);
