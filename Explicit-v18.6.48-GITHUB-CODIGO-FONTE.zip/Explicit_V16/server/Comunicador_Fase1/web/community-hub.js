/* Explicit • Comunidades: ações no menu, não lidas e gerenciamento centralizado.
   Tudo é validado novamente no servidor; nenhum botão concede permissões. */
(()=>{'use strict';
 const q=s=>document.querySelector(s);
 const E=(tag,cls,text)=>{const x=document.createElement(tag);if(cls)x.className=cls;if(text!==undefined)x.textContent=text;return x};
 const notify=(msg,bad=false)=>nexoToast(msg,bad?'error':undefined);
 const post=(community,action,extra={})=>api('community-hub','POST',{community,action,...extra});
 const can=(info,permission)=>info?.permissions?.includes(permission)||info?.permissions?.includes('ADMINISTRATOR');
 const muted=p=>p?.muted_until===-1||p?.muted_until>Date.now()/1000;
 const cache=new Map();
 let refreshing=false;
 async function refreshBadges(){if(!session||refreshing)return;refreshing=true;
  try{const state=await api('community-hub');cache.clear();for(const [id,v] of Object.entries(state||{}))cache.set(id,v);drawBadges();if(activeCommunity&&!document.body.classList.contains('explicit-home')&&!document.body.classList.contains('explicit-direct-mode'))void markVisibleRead(activeCommunity)}
  catch(err){console.debug('Indicadores de comunidade:',err.message)}finally{refreshing=false}
 }
 window.explicitRefreshCommunityBadges=refreshBadges;
 function drawBadges(){const rail=q('#railCommunities');if(!rail)return;for(const button of rail.querySelectorAll('button.rail-community')){
   const id=button.dataset.communityId;if(!id)continue;button.querySelector('.explicit-unread-badge')?.remove();button.classList.toggle('explicit-community-muted',muted(cache.get(id)?.prefs));
   const unread=Number(cache.get(id)?.unread)||0;if(unread<=0)continue;const badge=E('span','explicit-unread-badge',unread>=100?'99+':String(unread));badge.setAttribute('aria-label',unread>=100?'Mais de 99 notificações':unread+' notificações não lidas');button.append(badge);
 }}
 const markInFlight=new Set();
 async function markVisibleRead(id){
  if(!session||!id||activeCommunity!==id||document.body.classList.contains('explicit-home')||document.body.classList.contains('explicit-direct-mode')||markInFlight.has(id))return;
  if(!cache.has(id))await refreshBadges();
  const state=cache.get(id);if(!state||Number(state.unread)<=0)return;
  markInFlight.add(id);
  try{await post(id,'read');if(cache.has(id))cache.get(id).unread=0;drawBadges();await window.explicitRefreshNotifications?.()}
  catch(e){console.debug('Marcar comunidade como lida:',e.message)}finally{markInFlight.delete(id)}
 }
 window.explicitMarkVisibleCommunityRead=markVisibleRead;
 const prevRail=renderCommunitiesRail;
 renderCommunitiesRail=function(){prevRail();const buttons=q('#railCommunities')?.querySelectorAll('button.rail-community')||[];buttons.forEach((button,i)=>{if(communities[i])button.dataset.communityId=communities[i].id});drawBadges()};
 const prevRefresh=refreshCommunities;
 refreshCommunities=async function(){await prevRefresh();await refreshBadges()};
 const prevLogout=logout;
 logout=async function(){cache.clear();window.explicitTaskbarBadgeClear?.();await prevLogout()};
 async function fetchInfo(c){return api('community-hub?community='+encodeURIComponent(c.id))}
 async function update(c,action,data,success){try{await post(c.id,action,data);await refreshBadges();if(success)notify(success);await refreshCommunities()}catch(err){notify(err.message,true)}}
 async function markRead(c){await update(c,'read',{},'Comunidade marcada como lida.')}
 async function copyInvite(c){try{const info=await fetchInfo(c);if(!can(info,'CREATE_INVITES')&&!can(info,'VIEW_INVITES'))return notify('Você não tem permissão para consultar convites.',true);const code=info.invite_code;
   if(window.explicitDesktopClipboard?.writeText)await window.explicitDesktopClipboard.writeText(code);
   else if(navigator.clipboard?.writeText)await navigator.clipboard.writeText(code);
   else {const field=await nexoPrompt('Copiar convite','Copie o código: '+code);return}
   notify('Código de convite para o servidor copiado.');
  }catch(err){notify('Não foi possível copiar o convite: '+err.message,true)} }
 async function muteMenu(c){const box=modalWorkspace('Silenciar · '+c.name);box.classList.add('explicit-community-dialog');
  box.append(E('p','explicit-community-help','Você continuará recebendo mensagens. Só os avisos desta comunidade serão silenciados.'));
  const actions=E('div','explicit-community-action-grid');for(const [value,label] of [['24h','24 horas'],['48h','48 horas'],['7d','1 semana'],['30d','30 dias'],['forever','Para sempre'],['off','Reativar notificações']]){
    const b=E('button','explicit-community-action',label);b.onclick=async()=>{await update(c,'mute',{mute:value},value==='off'?'Notificações reativadas.':'Comunidade silenciada: '+label);box.closest('.obsidian-modal-backdrop')?.remove()};actions.append(b)}box.append(actions);
 }
 async function notificationSettings(c){let info;try{info=await fetchInfo(c)}catch(err){return notify(err.message,true)}
  const box=modalWorkspace('Notificações · '+c.name);box.classList.add('explicit-community-dialog');box.append(E('p','explicit-community-help','Escolha quais mensagens desta comunidade geram alertas. Sua preferência geral nos Ajustes continua valendo.'));
  const label=E('label','','Avisos de mensagens');const select=E('select');for(const [key,text] of [['all','Todas as mensagens'],['mentions','Apenas menções'],['none','Nenhuma mensagem']]){const opt=E('option','',text);opt.value=key;select.append(opt)}select.value=info.prefs?.message_mode||'all';label.append(select);box.append(label);
  const status=E('p','explicit-community-help',muted(info.prefs)?'O servidor também está silenciado temporariamente ou para sempre.':'Este servidor não está silenciado.');box.append(status);
  const save=E('button','explicit-community-primary','Salvar preferências');save.onclick=async()=>{try{await post(c.id,'preferences',{mode:select.value});box.closest('.obsidian-modal-backdrop')?.remove();notify('Notificações da comunidade atualizadas.');await refreshBadges()}catch(err){notify(err.message,true)}};box.append(save);
 }
 // Invites, roles and audit reuse the existing Explicit administrative APIs.
 async function settings(c,tab='overview'){
   let info;try{info=await fetchInfo(c)}catch(err){return notify(err.message,true)}
   const box=modalWorkspace('Configurações · '+info.name);box.classList.add('explicit-community-dialog','explicit-community-settings');
   const nav=E('div','explicit-community-settings-nav'),content=E('div','explicit-community-settings-content');box.append(nav,content);
   const tabs=[['overview','Visão geral'],['invites','Convites'],['members','Membros'],['roles','Cargos'],['afk','Canal de ausentes'],['bans','Banidos'],['audit','Auditoria'], ...((info.owner===document.getElementById('who')?.textContent?.trim()||info.can_delete===true)?[['danger','Excluir comunidade']]:[])];
   for(const [key,label] of tabs){if(key==='roles'&&!can(info,'MANAGE_ROLES'))continue;if(key==='afk'&&!can(info,'MANAGE_COMMUNITY'))continue;if(key==='bans'&&!can(info,'MANAGE_SANCTIONS'))continue;if(key==='audit'&&!can(info,'VIEW_AUDIT_LOG'))continue;
     const b=E('button',key===tab?'selected':'',label);b.onclick=()=>{for(const node of nav.children)node.classList.remove('selected');b.classList.add('selected');void render(key)};nav.append(b)}
   async function render(key){content.replaceChildren();
    const group=(title,description)=>{const node=E('section','explicit-community-settings-group');node.append(E('h3','',title));if(description)node.append(E('p','explicit-community-help',description));content.append(node);return node};
    const action=(parent,label,fn,cls='')=>{const b=E('button',cls,label);b.onclick=fn;parent.append(b);return b};
    const control=(parent,label,value)=>{const field=E('label','',label),input=E('input');input.value=value??'';field.append(input);parent.append(field);return input};
    if(key==='overview'){
      const g=group('Identidade da comunidade','Alterações ficam registradas na auditoria.');g.append(E('p','','Fundador: @'+info.owner));g.append(E('p','','Identificador interno: '+info.id));if(can(info,'MANAGE_COMMUNITY')){const photo=E('label','explicit-community-cover-upload','Imagem do card da comunidade (PNG, JPG ou GIF · até 4 MB)');const input=E('input');input.type='file';input.accept='image/png,image/jpeg,image/gif';photo.append(input);g.append(photo);input.onchange=async()=>{const f=input.files?.[0];input.value='';if(!f)return;try{await explicitUploadVisual('community',info.id,f);notify('Imagem atualizada.');await refreshCommunities()}catch(e){notify(e.message,true)}}}
      if(can(info,'MANAGE_COMMUNITY')){const name=control(g,'Nome da comunidade',info.name);action(g,'Salvar nome',async()=>{try{await post(c.id,'rename',{name:name.value});notify('Nome atualizado.');await refreshCommunities();info=await fetchInfo(c)}catch(e){notify(e.message,true)}} ,'explicit-community-primary');
      const line=E('label','explicit-community-switch');const check=E('input');check.type='checkbox';check.checked=!info.join_closed;line.append(check,document.createTextNode(' Aceitar novos membros'));g.append(line);check.onchange=async()=>{try{await post(c.id,'toggle_join',{join_closed:!check.checked});info=await fetchInfo(c);notify(check.checked?'Comunidade aberta para novos membros.':'Novos convites foram bloqueados.');await refreshCommunities()}catch(err){check.checked=!check.checked;notify(err.message,true)}};
      }else g.append(E('p','explicit-community-help','Somente administradores autorizados podem alterar estes dados.'));
    }
    if(key==='danger'){
      const g=group('Excluir comunidade','A exclusão é permanente: canais, histórico de mensagens e configuração desta comunidade serão removidos do servidor. Esta ação é exclusiva do fundador ou Superadmin.');
      g.append(E('p','','Comunidade: '+info.name));
      const input=control(g,'Digite exatamente o nome da comunidade para confirmar','');input.placeholder=info.name;input.autocomplete='off';
      const first=action(g,'Confirmar nome e prosseguir',async()=>{
       if(input.value!==info.name)return notify('Digite o nome da comunidade exatamente como aparece acima.',true);
       const second=modalWorkspace('Confirmação final');second.classList.add('explicit-community-dialog');
       const warning=E('section','explicit-community-delete-confirm');
       warning.append(E('h3','','Tem certeza que deseja continuar?'));
       warning.append(E('p','','A comunidade “'+info.name+'” e todos os seus canais e mensagens serão excluídos. Não será possível desfazer.'));
       const choices=E('div','explicit-community-action-grid');
       const no=action(choices,'Não',()=>second.closest('.obsidian-modal-backdrop')?.remove());
       const yes=action(choices,'Sim, excluir definitivamente',async()=>{
        yes.disabled=true;try{await post(c.id,'delete_community',{name:info.name,confirm:true});
          second.closest('.obsidian-modal-backdrop')?.remove();box.closest('.obsidian-modal-backdrop')?.remove();
          if(voiceRoom.startsWith(c.id+':'))await stopVoice({preserveText:true});
          if(activeCommunity===c.id){activeCommunity='';activeChannel='geral';adminState=null;}
          await refreshCommunities();openHome();notify('Comunidade excluída.');
        }catch(err){notify(err.message,true);yes.disabled=false}
       },'explicit-community-delete-danger');choices.append(no,yes);warning.append(choices);second.append(warning);
      },'explicit-community-delete-danger');first.disabled=true;
      input.addEventListener('input',()=>{first.disabled=input.value!==info.name});
    }
    if(key==='invites'){
      const g=group('Código de convite',info.join_closed?'Esta comunidade não aceita novos membros no momento.':'Compartilhe o código com quem deseja convidar.');const code=E('code','explicit-community-invite',info.invite_code);g.append(code);
      if(can(info,'CREATE_INVITES')||can(info,'VIEW_INVITES'))action(g,'Copiar convite',()=>copyInvite(c));
      if(can(info,'MANAGE_COMMUNITY')){const input=control(g,'Alterar código público (4–32 caracteres)',info.invite_code);action(g,'Salvar código',async()=>{try{await post(c.id,'invite',{invite:input.value});info=await fetchInfo(c);code.textContent=info.invite_code;notify('Convite atualizado. O código anterior deixa de funcionar.');await refreshCommunities()}catch(err){notify(err.message,true)}});
       action(g,'Gerar novo código aleatório',async()=>{if(!await nexoDialog('Alterar convite','O convite anterior deixará de funcionar. Confirmar?'))return;try{await post(c.id,'rotate_invite');info=await fetchInfo(c);code.textContent=info.invite_code;input.value=info.invite_code;notify('Novo convite gerado.');await refreshCommunities()}catch(err){notify(err.message,true)}});}
    }
    if(key==='roles'){
      const g=group('Cargos da comunidade','Os cargos e suas permissões são gerenciados no editor já existente.');action(g,'Abrir gerenciamento de cargos',async()=>{await selectCommunity(c.id);box.closest('.obsidian-modal-backdrop')?.remove();showRoles()});
    }
    if(key==='members'){
      const g=group('Membros','Gerencie cargos, expulsões e banimentos pelas ações de cada membro.');if(!info.members){g.append(E('p','explicit-community-help','Sem permissão para gerenciar membros.'));return}
      for(const user of info.members){const line=E('div','explicit-community-member-line');line.append(E('strong','',user===info.owner?'@'+user+' · Fundador':'@'+user));const roles=info.member_roles?.[user]||[];const assigned=(info.roles||[]).filter(r=>roles.includes(r.id)).map(r=>r.name);if(assigned.length)line.append(E('small','',assigned.join(', ')));
       if(user!==info.owner){const actions=E('div');if(can(info,'ASSIGN_ROLES'))action(actions,'Cargos',async()=>{await selectCommunity(c.id);box.closest('.obsidian-modal-backdrop')?.remove();await openMember(user,null)});
        if(can(info,'KICK_MEMBERS'))action(actions,'Expulsar',async()=>{if(!await nexoDialog('Expulsar membro','Expulsar @'+user+' desta comunidade?'))return;try{await api('sanctions','POST',{community:c.id,target:user,action:'kick',reason:'Expulsão pela gestão da comunidade'});notify('Membro expulso.');info=await fetchInfo(c);await render('members');await refreshCommunities()}catch(err){notify(err.message,true)}});
        if(can(info,'BAN_MEMBERS'))action(actions,'Banir',async()=>{if(!await nexoDialog('Banir membro','Banir @'+user+' desta comunidade?'))return;try{await api('sanctions','POST',{community:c.id,target:user,action:'community_ban',unit:'permanent',reason:'Banimento pela gestão da comunidade'});notify('Membro banido.');info=await fetchInfo(c);await render('members');await refreshCommunities()}catch(err){notify(err.message,true)}});
        line.append(actions)}g.append(line)}
    }
    if(key==='afk'){
      const g=group('Canal de ausentes','Utiliza a configuração de ausência automática que já existe no Explicit.');action(g,'Configurar canal de ausentes',async()=>{await selectCommunity(c.id);box.closest('.obsidian-modal-backdrop')?.remove();await configureAFK()});
    }
    if(key==='bans'){
      const g=group('Pessoas banidas','Lista de banimentos da comunidade. Desbanir revoga a sanção existente.');try{const sanctions=await api('sanctions?community='+encodeURIComponent(c.id));const bans=sanctions.filter(s=>s.type==='community_ban'&&!s.revoked_at&&(!s.expires_at||Date.parse(s.expires_at)>Date.now()));if(!bans.length)g.append(E('p','explicit-community-help','Nenhum banimento ativo.'));
        for(const ban of bans){const line=E('div','explicit-community-member-line');line.append(E('strong','','@'+ban.target_user_id));line.append(E('small','',ban.reason||'Sem motivo'));action(line,'Desbanir',async()=>{if(!await nexoDialog('Desbanir','Revogar o banimento de @'+ban.target_user_id+'?'))return;try{await api('sanctions','POST',{community:c.id,action:'revoke',id:ban.id});notify('Banimento revogado.');await render('bans')}catch(err){notify(err.message,true)}});g.append(line)}}catch(err){g.append(E('p','explicit-community-help','Não foi possível carregar: '+err.message))}
    }
    if(key==='audit'){
      const g=group('Auditoria da comunidade','Histórico das ações administrativas registradas pelo servidor.');try{const rows=await api('community-audit?community='+encodeURIComponent(c.id));if(!rows.length)g.append(E('p','explicit-community-help','Nenhuma ação registrada.'));
       for(const item of rows){const line=E('div','explicit-community-audit-line');line.append(E('small','',new Date(item.at).toLocaleString('pt-BR')));line.append(E('div','',(item.actor||'Sistema')+' · '+item.action+(item.details?' · '+item.details:'')));g.append(line)}}catch(err){g.append(E('p','explicit-community-help','Falha na auditoria: '+err.message))}
    }
   }
   const initial=nav.querySelector('button.selected')?tab:'overview';await render(initial);
 }
 // Preserve existing generic context menu and local role/channel editors.
 openCommunityMenu=async function(event,c){
  const coords={clientX:event.clientX,clientY:event.clientY};let info;try{info=await fetchInfo(c)}catch(e){return notify('Permissões indisponíveis: '+e.message,true)}
  const items=[['Marcar como lida',()=>markRead(c)],['Convidar para a comunidade',()=>copyInvite(c)],['Silenciar comunidade  ›',()=>muteMenu(c)],['Config. de notificações  ›',()=>notificationSettings(c)],['Informações',()=>showCommunityInfo(c)]];
  // Fetch permission data on demand; backend enforces any action.
  if(['MANAGE_COMMUNITY','MANAGE_CHANNELS','MANAGE_ROLES','ASSIGN_ROLES','MANAGE_MEMBERS','MANAGE_SANCTIONS','VIEW_AUDIT_LOG'].some(p=>can(info,p)))items.push(['Configurações da comunidade  ›',()=>settings(c)]);
  if(can(info,'CREATE_CHANNEL'))items.push(['Criar canal',async()=>{await selectCommunity(c.id);createChannel()}]);
  if(can(info,'MANAGE_CHANNELS'))items.push(['Criar categoria',async()=>{await selectCommunity(c.id);const name=await nexoPrompt('Criar categoria','Nome da categoria');if(!name)return;try{await api('channel-permissions','POST',{community:c.id,action:'category_create',name:name.trim()});await refreshCommunities();notify('Categoria criada.')}catch(err){notify(err.message,true)}}]);
  contextMenu(coords,items);
  const menu=q('.nexo-context');if(menu){menu.classList.add('explicit-community-context');const bounds=menu.getBoundingClientRect();menu.style.top=Math.max(8,Math.min(coords.clientY,innerHeight-bounds.height-8))+'px';menu.style.left=Math.max(8,Math.min(coords.clientX,innerWidth-bounds.width-8))+'px'}
 };
 showCommunityInfo=function(c){void settings(c,'invites')};
 window.explicitCommunityHub=Object.freeze({refreshBadges,markRead,notificationSettings,settings});
 setInterval(()=>{if(session)void refreshBadges()},5000);
})();
