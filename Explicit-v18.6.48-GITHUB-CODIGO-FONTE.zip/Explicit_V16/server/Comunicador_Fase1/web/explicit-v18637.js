/* Explicit 18.6.37 — progressive UI updates; API remains the authority for access. */
(()=>{'use strict';
const create=(tag,cls,text)=>{const e=document.createElement(tag);if(cls)e.className=cls;if(text!=null)e.textContent=text;return e};
const me=()=>document.getElementById('who')?.textContent?.trim();
const current=()=>communities.find(c=>c.id===activeCommunity);
const can=(permission,c=current())=>!!c&&(c.owner===me()||((adminState?.permissions||[]).includes(permission))||((adminState?.permissions||[]).includes('ADMINISTRATOR')));
const notice=(err)=>nexoToast(err?.message||String(err),'error');
const perform=async(job)=>{try{await job()}catch(e){notice(e)}};
const customMenu=(event,items)=>{event.preventDefault();event.stopPropagation();contextMenu(event,items)};
const inviteCode=async(c,channel='')=>{const invite=await api('community-invite','POST',{community:c.id,channel});return invite.code};
const copy=async(value)=>{await navigator.clipboard.writeText(value);nexoToast('Código de convite copiado')};
async function configureChannelNotifications(community,channel){
 const data=await api('community-hub?community='+encodeURIComponent(community.id));const mode=data.prefs?.channel_modes?.[channel]||'all';
 const form=await nexoForm('Notificações de #'+(channel==='voz'?'Geral':channel),[{name:'mode',label:'Avisos deste canal',options:['all','mentions','none'],labels:['Todas as mensagens','Somente menções','Nenhuma notificação'],value:mode}]);if(!form)return;
 await api('community-hub','POST',{action:'channel_preferences',community:community.id,channel,mode:form.mode});
 window.explicitRefreshNotifications?.();nexoToast('Preferência de notificação salva')
}

async function inviteFriends(c,channel=''){
 const code=await inviteCode(c,channel),box=modalWorkspace('Convidar amigos para '+c.name);
 box.classList.add('explicit-invite-friends');
 box.append(create('p','','Envie o convite diretamente para um amigo ou copie o código abaixo.'));
 const list=create('div','explicit-invite-people');box.append(list);
 try{const social=await api('social');const friends=Array.isArray(social.friends)?social.friends:[];for(const friend of friends){const username=typeof friend==='string'?friend:(friend.username||friend.user||friend.name);if(!username)continue;const row=create('div','explicit-invite-person');row.append(create('span','',friend.display_name||username));const send=create('button','','Enviar convite');send.onclick=()=>perform(async()=>{send.disabled=true;try{const chat=await api('direct','POST',{action:'open',target:username});await api('direct','POST',{action:'send',id:chat.id,text:'Convite para '+c.name+(channel?' · #'+channel:'')+' — código: '+code});send.textContent='Enviado';nexoToast('Convite enviado para @'+username)}finally{send.disabled=false}});row.append(send);list.append(row)}if(!friends.length)list.append(create('p','','Nenhum amigo adicionado. Compartilhe o código abaixo.'))}catch(e){list.append(create('p','','Lista de amigos indisponível: '+e.message))}
 const footer=create('div','explicit-invite-footer');footer.append(create('code','',code));const b=create('button','','Copiar código');b.onclick=()=>perform(()=>copy(code));footer.append(b);box.append(footer)
}
// Community header actions: authoritative permission checks are repeated by server.

function openServerSettings(c){
 document.querySelector('.explicit-server-settings-screen')?.explicitDismiss?.();
 const back=create('div','obsidian-modal-backdrop explicit-server-settings-backdrop');
 const frame=create('section','obsidian-modal workspace-modal explicit-settings-window explicit-server-settings-screen');frame.setAttribute('role','dialog');frame.setAttribute('aria-modal','true');frame.setAttribute('aria-label','Configurações da comunidade '+c.name);
 const heading=create('h2','','Configurações da comunidade');frame.append(heading);
 const layout=create('div','explicit-settings-shell explicit-server-settings-layout');const side=create('nav','explicit-server-settings-side');const content=create('div','explicit-server-settings-content');layout.append(side,content);frame.append(layout);
 const brand=create('div','explicit-server-settings-brand',c.name);brand.title=c.name;side.setAttribute('aria-label','Seções das configurações da comunidade');side.append(brand);
 let restore=()=>{},closed=false,activeSection='Visão geral';
 const dismiss=()=>{if(closed)return;closed=true;if(window.explicitRolesInlineHost===content)window.explicitRolesInlineHost=null;back.remove();restore()};frame.explicitDismiss=dismiss;
 const close=create('button','modal-close explicit-server-settings-close','×');close.type='button';close.title='Fechar configurações';close.setAttribute('aria-label','Fechar configurações da comunidade');close.onclick=dismiss;frame.append(close);
 const help=create('p','','Personalize sua comunidade. As permissões de cada ação são verificadas pelo servidor.');
 const options=[['Visão geral',()=>{content.replaceChildren(create('h2','','Visão geral'),create('p','',c.name),help)}],
 ['Canais',()=>{content.replaceChildren(create('h2','','Canais e categorias'));const list=create('div','explicit-server-settings-channels');const community=current()||c;for(const ch of community.channels||[]){const line=create('div','explicit-server-settings-channel');line.append(create('strong','',(community.channel_meta?.[ch]?.type==='voice'?'◉ ':'# ')+(ch==='voz'?'Geral':ch)));const edit=create('button','','Permissões');edit.onclick=()=>window.explicitManageChannelPermissions?.(ch);line.append(edit);list.append(line)}content.append(list);const add=create('button','explicit-server-settings-action','Criar canal');add.onclick=createChannel;content.append(add)}],
 ['Cargos',async()=>{content.replaceChildren(create('h2','','Cargos'));if(!can('MANAGE_ROLES',c)){content.append(create('p','','Você não tem permissão para gerenciar cargos.'));return}window.explicitRolesInlineHost=content;await refreshMembers();if(!frame.isConnected||activeSection!=='Cargos')return;showRoles()}],
 ['Convites',()=>{dismiss();void perform(()=>inviteFriends(c))}],
 ['Notificações',()=>{dismiss();openSettings('Notificações')}]];
 for(const [label,action] of options){const button=create('button','',label);button.type='button';button.onclick=()=>{activeSection=label;content.scrollTop=0;if(label!=='Cargos'&&window.explicitRolesInlineHost===content)window.explicitRolesInlineHost=null;for(const btn of side.querySelectorAll('button')){btn.classList.toggle('selected',btn===button);if(btn===button)btn.setAttribute('aria-current','page');else btn.removeAttribute('aria-current')}Promise.resolve().then(action).catch(notice)};side.append(button)}
 back.append(frame);explicitMountModal(back);
 back.addEventListener('pointerdown',e=>{if(e.target===back)dismiss()});
 side.querySelector('button')?.click();restore=explicitBindModalFocus(back,frame,dismiss,close);
}

openCommunityMenu=function(e,c){
 const same=c.id===activeCommunity,manager=c.owner===me()||(same&&can('MANAGE_CHANNELS',c));
 const items=[['Convidar para a comunidade',()=>inviteFriends(c)]];
 if(manager){items.push(['Configurações da comunidade',async()=>{await selectCommunity(c.id);openServerSettings(c)}]);items.push(['Criar canal',async()=>{await selectCommunity(c.id);createChannel()}]);items.push(['Criar categoria',async()=>{await selectCommunity(c.id);window.explicitCreateCategory?.()}])}
 items.push(['Configurações de notificação',()=>openSettings('Notificações')]);
 if(c.owner!==me())items.push(['Sair da comunidade',async()=>{if(!await nexoDialog('Sair da comunidade','Deseja sair de '+c.name+'?'))return;if(voiceRoom?.startsWith(c.id+':'))await stopVoice({preserveText:true});await api('communities','POST',{leave:c.id});await refreshCommunities();openHome()}]);
 customMenu(e,items)
};
function updateHeader(){
 const heading=document.getElementById('communityHeading');if(!heading||!activeCommunity)return;
 const c=current();if(!c)return;
 let row=document.getElementById('explicitCommunityHeaderRow');
 if(!row){
  row=create('div','explicit-community-header-row');row.id='explicitCommunityHeaderRow';heading.before(row);row.append(heading);
  const arrow=create('button','explicit-community-chevron');arrow.innerHTML='<svg viewBox="0 0 20 20" width="16" height="16" aria-hidden="true"><path d="m5 7 5 5 5-5" fill="none" stroke="currentColor" stroke-width="1.75" stroke-linecap="round" stroke-linejoin="round"/></svg>';arrow.id='explicitCommunityChevron';arrow.type='button';arrow.title='Opções da comunidade';arrow.setAttribute('aria-label','Abrir opções da comunidade');row.append(arrow);
  const invite=create('button','explicit-community-invite-button');invite.innerHTML='<svg viewBox="0 0 24 24" width="20" height="20" aria-hidden="true" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M19 8v6m-3-3h6"/></svg>';invite.id='explicitCommunityInviteButton';invite.type='button';invite.title='Convidar amigos para a comunidade';invite.setAttribute('aria-label','Convidar amigos para a comunidade');row.append(invite);
 }
 const arrow=document.getElementById('explicitCommunityChevron');const invite=document.getElementById('explicitCommunityInviteButton');
 const show=(ev)=>{
   ev.preventDefault();ev.stopPropagation();
   const visibleMenu=document.querySelector('.nexo-context');
   if(arrow.classList.contains('is-open')&&visibleMenu){
    visibleMenu.explicitClose?.();visibleMenu.remove();
    arrow.classList.remove('is-open');arrow.setAttribute('aria-expanded','false');return;
   }
   const rect=row.getBoundingClientRect();
   openCommunityMenu({preventDefault(){},stopPropagation(){},clientX:Math.max(rect.left+10,rect.right-215),clientY:rect.bottom+3,target:arrow},c);
   const openedMenu=document.querySelector('.nexo-context');
   arrow.classList.toggle('is-open',!!openedMenu);arrow.setAttribute('aria-expanded',String(!!openedMenu));
   if(!openedMenu)return;
   const observer=new MutationObserver(()=>{if(!openedMenu.isConnected){arrow.classList.remove('is-open');arrow.setAttribute('aria-expanded','false');observer.disconnect()}});
   observer.observe(document.body,{childList:true,subtree:true});
  };
 arrow.onpointerdown=e=>e.stopPropagation();heading.onpointerdown=e=>e.stopPropagation();arrow.onclick=show;heading.onclick=show;heading.onkeydown=e=>{if(e.key==='Enter'||e.key===' '){e.preventDefault();show(e)}};heading.tabIndex=0;heading.setAttribute('role','button');heading.setAttribute('aria-label','Opções da comunidade '+c.name);
 heading.oncontextmenu=e=>openCommunityMenu(e,c);invite.onclick=()=>perform(()=>inviteFriends(c));
}
const originalSelect=selectCommunity;selectCommunity=async function(...args){const result=await originalSelect(...args);updateHeader();return result};
const oldRender=renderChannels;renderChannels=function(...args){const ret=oldRender(...args);for(const group of document.querySelectorAll('#channelList .voice-group')){if(group.dataset.explicitChannel==='voz'||group.querySelector('.explicit-sidebar-voice-row')?.dataset.channelName==='voz'){const label=group.querySelector('.explicit-sidebar-name');if(label)label.textContent='Geral'}}updateHeader();return ret};
// Context menus on channels. Mutations are checked by the server even if UI permissions change.
document.addEventListener('contextmenu',e=>{const target=e.target.closest('#channelList .channelButton,#channelList .voice-heading');if(!target||!activeCommunity)return;const c=current();if(!c)return;const raw=target.classList.contains('channelButton')?target.textContent.trim().replace(/^#\s*/,''):target.closest('.voice-group')?.querySelector('.voice-heading button:last-child')?.textContent.trim().replace(/\s*·\s*\d+$/,'');const channel=raw==='Geral'&&target.closest('.voice-group')?'voz':raw;if(!channel||!c.channels.includes(channel))return;
 const manager=can('MANAGE_CHANNELS',c),kind=c.channel_meta?.[channel]?.type||'text';const actions=[['Convidar para '+(kind==='voice'?'a voz':'o canal'),()=>inviteFriends(c,kind==='voice'?'':channel)],['Silenciar canal',async()=>{const info=await api('community-hub?community='+encodeURIComponent(c.id));const muted=info.prefs?.channel_modes?.[channel]==='none';await api('community-hub','POST',{action:'channel_preferences',community:c.id,channel,mode:muted?'all':'none'});window.explicitRefreshNotifications?.();nexoToast(muted?'Notificações do canal reativadas':'Canal silenciado')}],['Configurações de notificação',()=>configureChannelNotifications(c,channel)]];
 if(manager){actions.push(['Mover para categoria',async()=>{const items=[{name:'Sem categoria',id:''},...(c.categories||[]).map(x=>({name:x.name,id:x.id}))];const q=await nexoForm('Mover canal',[{name:'category',label:'Categoria de destino',options:items.map(i=>i.id),labels:items.map(i=>i.name)}]);if(!q)return;await api('channel-permissions','POST',{community:c.id,action:'channel_move',channel,category:q.category});await refreshCommunities();nexoToast('Canal movido')}],['Editar canal',()=>window.explicitManageChannelPermissions?.(channel)],['Duplicar canal',async()=>{const q=await nexoForm('Duplicar canal',[{name:'name',label:'Nome da cópia',value:channel+'-copia',required:true}]);if(!q)return;let meta=c.channel_meta?.[channel]||{};try{const detail=await api('channel-permissions?community='+encodeURIComponent(c.id));meta=detail.channel_meta?.[channel]||meta}catch{}await api('communities','POST',{community:c.id,channel:q.name,type:kind,category:meta.category||'',limit:meta.limit||0,role_permissions:meta.role_permissions||{},member_permissions:meta.member_permissions||{},private:!!meta.private});await refreshCommunities();nexoToast('Canal duplicado com as permissões disponíveis')}],['Excluir canal',async()=>{if(!await nexoDialog('Excluir canal','Excluir '+channel+' permanentemente?'))return;await api('channel-delete','POST',{community:c.id,channel});await refreshCommunities();nexoToast('Canal excluído')}])}
 customMenu(e,actions)
},true);
// Sound input/output arrows: open the existing audio configuration rather than a separate state.
 function installSoundArrows(){
  for(const [id,label] of [['voiceMute','Microfone'],['voiceDeaf','Headset']]){
   const control=document.getElementById(id);
   if(!control||control.parentElement?.querySelector('.explicit-audio-arrow[data-for="'+id+'"]'))continue;
   const arrow=create('button','explicit-audio-arrow');
   arrow.innerHTML='<svg viewBox="0 0 20 20" width="14" height="14" aria-hidden="true"><path d="m5 7 5 5 5-5" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/></svg>';
   arrow.type='button';arrow.dataset.for=id;arrow.title='Configurar '+label;
   arrow.setAttribute('aria-label','Configurar '+label);arrow.setAttribute('aria-expanded','false');
   arrow.onpointerdown=e=>e.stopPropagation();
   arrow.onclick=e=>{
    e.stopPropagation();
    const existing=document.querySelector('.explicit-audio-quick');
    if(existing&&existing.dataset.for===id){existing.explicitClose?.();return}
    existing?.explicitClose?.();existing?.remove();
    const menu=create('div','explicit-audio-quick');menu.dataset.for=id;
    menu.setAttribute('role','dialog');menu.setAttribute('aria-label','Configurações rápidas de '+label);
    const otherArrow=document.querySelector('.explicit-audio-arrow.is-open');
    otherArrow?.classList.remove('is-open');otherArrow?.setAttribute('aria-expanded','false');
    const controller=new AbortController();
    const close=()=>{controller.abort();menu.remove();arrow.classList.remove('is-open');arrow.setAttribute('aria-expanded','false')};
    menu.explicitClose=close;arrow.classList.add('is-open');arrow.setAttribute('aria-expanded','true');
    menu.append(create('strong','',label));
    const row=create('div','explicit-audio-device-list');menu.append(row);
    const type=id==='voiceMute'?'audioinput':'audiooutput';
    const select=create('select','explicit-audio-device-select');select.setAttribute('aria-label','Dispositivo de '+label);row.append(select);
    const fallback=create('option','','Padrão do Windows');fallback.value='default';select.append(fallback);
    const configure=create('button','','Mais configurações de áudio');configure.type='button';
    configure.onclick=()=>{close();openSettings('Voz e áudio')};menu.append(configure);
    navigator.mediaDevices?.enumerateDevices?.().then(devices=>{
     if(!menu.isConnected)return;
     select.replaceChildren();const key=type==='audioinput'?'audioInputId':'audioOutputId';
     const def=create('option','','Padrão do Windows');def.value='default';select.append(def);
     for(const device of devices.filter(d=>d.kind===type&&d.deviceId&&d.deviceId!=='default')){
      const opt=create('option','',device.label||'Dispositivo '+select.length);opt.value=device.deviceId;select.append(opt)
     }
     select.value=getPrefs()[key]||'default';
     select.onchange=()=>perform(async()=>{
      const prefs=getPrefs(),previous=prefs[key];prefs[key]=select.value;savePrefs(prefs);
      try{
       if(type==='audioinput')await changeActiveVoiceInput();
       else await Promise.all([...document.querySelectorAll('#voiceAudios audio')].map(a=>setAudioOutput(a,select.value)));
       nexoToast('Dispositivo alterado')
      }catch(err){prefs[key]=previous;savePrefs(prefs);select.value=previous;throw err}
     })
    }).catch(()=>{row.textContent='Dispositivos indisponíveis. Confira as permissões do Windows.'});
    document.body.append(menu);
    const rect=arrow.getBoundingClientRect();
    menu.style.left=Math.max(8,Math.min(rect.left,innerWidth-menu.offsetWidth-8))+'px';
    menu.style.bottom=(innerHeight-rect.top+5)+'px';
    document.addEventListener('pointerdown',ev=>{if(!menu.contains(ev.target)&&ev.target!==arrow)close()},{signal:controller.signal});
    document.addEventListener('keydown',ev=>{if(ev.key==='Escape')close()},{signal:controller.signal});
   };
   control.after(arrow);
  }
 }
// DM list retained beside conversations, without replacing the functional chat composer.
const oldDirect=openDirect;openDirect=async function(id){const output=await oldDirect(id);const chat=document.getElementById('directMessages');if(!chat)return output;const root=chat.parentElement;if(root.classList.contains('explicit-dm-split'))return output;root.classList.add('explicit-dm-split');const sidebar=create('aside','explicit-dm-sidebar');sidebar.append(create('h3','','Mensagens diretas'));const filter=create('input','explicit-dm-search');filter.type='search';filter.placeholder='Buscar conversa';filter.setAttribute('aria-label','Buscar conversa');sidebar.append(filter);const list=create('div','explicit-dm-side-list');sidebar.append(list);const populate=()=>{list.replaceChildren();for(const c of explicitDirectChats.values()){const title=c.group?c.name:(c.display_name||c.other);if(filter.value&&!title?.toLowerCase().includes(filter.value.toLowerCase()))continue;const b=create('button',c.id===id?'selected':'',title||'Conversa privada');b.onclick=()=>openDirect(c.id);list.append(b)}};filter.oninput=populate;populate();const account=create('div','explicit-dm-mini');const mini=document.getElementById('explicitMiniProfile');if(mini){const name=create('strong','',document.getElementById('explicitMiniName')?.textContent||me());account.append(name);const mic=create('button','','🎙');mic.title='Alternar microfone';mic.onclick=()=>document.getElementById('voiceMute')?.click();const outputButton=create('button','','🎧');outputButton.title='Alternar áudio';outputButton.onclick=()=>document.getElementById('voiceDeaf')?.click();const settings=create('button','','⚙');settings.title='Configurações';settings.onclick=()=>openSettings('Geral');account.append(mic,outputButton,settings)}sidebar.append(account);const pane=create('div','explicit-dm-main');while(root.firstChild)pane.append(root.firstChild);root.append(sidebar,pane);return output};
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',installSoundArrows);else installSoundArrows();
})();

/* v18.6.38: reposition the final-sized profile, not just its empty cover. */
(()=>{
 const originalOpenMember=openMember;
 openMember=async function(user,anchor){
  const result=await originalOpenMember(user,anchor);
  const panel=document.getElementById('memberPopover');
  if(!panel||panel.hidden)return result;
  const rect=anchor?.getBoundingClientRect()||{left:innerWidth-panel.offsetWidth-8,bottom:100};
  const w=panel.offsetWidth,h=panel.offsetHeight;
  panel.style.left=Math.max(8,Math.min(rect.left,innerWidth-w-8))+'px';
  panel.style.top=Math.max(8,Math.min(rect.bottom+7,innerHeight-h-8))+'px';
  return result;
 };
})();
