/* Explicit: user-created display-name styles. Safe typed values, never user HTML or arbitrary CSS. */
(()=>{'use strict';
const fonts={default:'inherit',modern:'Inter,Segoe UI,Arial,sans-serif',rounded:'Trebuchet MS,Arial,sans-serif',serif:'Georgia,serif',mono:'Consolas,monospace',elegant:'Palatino Linotype,Georgia,serif',condensed:'Arial Narrow,Arial,sans-serif'};
const fontLabels={default:'Padrão',modern:'Moderna',rounded:'Arredondada',serif:'Clássica',mono:'Monoespaçada',elegant:'Elegante',condensed:'Condensada'};
const animations=['none'];
const animationLabels={none:'Nenhuma'};
const effectModes=['none'];
const effectLabels={none:'Nenhum'};
const weightLabels={400:'Normal',500:'Média',600:'Seminegrito',700:'Negrito',800:'Extra negrito',900:'Pesada'};
const standard={color:'#8abfff',color2:'#b9a0ff',color3:'#f5aad0',gradient:true,font:'modern',weight:700,spacing:0,shadow_color:'#6da7ff',shadow_blur:4,glow:8,outline_color:'#1c324d',outline:0,animation:'none',speed:5,effect:'none',effect_intensity:62};
const styleShowcases=[
 {label:'Aurora',style:{color:'#8bc7ff',color2:'#c69cff',color3:'#ffe38a',gradient:true,glow:12,shadow_blur:8,shadow_color:'#7baeff',font:'modern',weight:800,animation:'shine',speed:5}},
 {label:'Rubi',style:{color:'#ff97ba',color2:'#ff6b92',color3:'#ffd3e1',gradient:true,glow:10,shadow_blur:7,shadow_color:'#ff77a7',font:'rounded',weight:800,animation:'pulse',speed:4}},
 {label:'Frost',style:{color:'#d8f1ff',color2:'#9dd4ff',color3:'#a7b8ff',gradient:true,glow:14,shadow_blur:10,shadow_color:'#8fd7ff',font:'elegant',weight:700,animation:'shimmer',speed:6}},
 {label:'Dourado',style:{color:'#ffe39a',color2:'#ffcf62',color3:'#fff3c9',gradient:true,glow:15,shadow_blur:8,shadow_color:'#f4c76a',font:'serif',weight:800,animation:'shine',speed:4}},
 {label:'Cyber',style:{color:'#76ffe4',color2:'#73b8ff',color3:'#d58dff',gradient:true,glow:12,shadow_blur:6,shadow_color:'#68dfff',font:'mono',weight:700,animation:'rainbow',speed:7}},
];
const make=(tag,cls,content)=>{const e=document.createElement(tag);if(cls)e.className=cls;if(content!==undefined)e.textContent=content;return e};
const validColor=c=>/^#[0-9a-f]{6}$/i.test(c||'');
const clamp=(n,min,max)=>Math.max(min,Math.min(max,n));
const toInt=(v,def=0)=>Number.isFinite(+v)?Math.round(+v):def;
const currentDisplayName=()=>typeof el==='function'?(el('explicitMiniName')?.textContent?.trim()||el('who')?.textContent?.trim()||'Seu nome'):'Seu nome';
const currentUsername=()=>typeof el==='function'?(el('who')?.textContent?.trim()||'usuario'):'usuario';
const normalize=s=>{s=s||{};const out={...standard};
 for(const k of ['color','color2','color3','shadow_color','outline_color'])if(validColor(s[k]))out[k]=s[k];
 if(Object.hasOwn(fonts,s.font))out.font=s.font;
 if(animations.includes(s.animation))out.animation=s.animation;
 out.gradient=typeof s.gradient==='boolean'?s.gradient:standard.gradient;
 const legacyEffect='none';
 if(effectModes.includes(s.effect))out.effect=s.effect;else out.effect=legacyEffect;
 out.effect_intensity=clamp(toInt(s.effect_intensity??s.flare_intensity,standard.effect_intensity),0,100);
 out.weight=clamp(toInt(s.weight,standard.weight),400,900);out.weight=Math.round(out.weight/100)*100;
 out.spacing=clamp(toInt(s.spacing,standard.spacing),-10,40);
 out.shadow_blur=clamp(toInt(s.shadow_blur,standard.shadow_blur),0,24);
 out.glow=clamp(toInt(s.glow,standard.glow),0,30);
 out.outline=clamp(toInt(s.outline,standard.outline),0,2);
 out.speed=clamp(toInt(s.speed,standard.speed),2,15);
 return out;
};
function paint(elm,s){
 if(!elm)return;
 elm.classList.remove('explicit-name-gradient','explicit-name-effect','explicit-name-effect-ipb_particles','explicit-name-effect-mist','explicit-name-effect-prism','explicit-name-effect-embers',...animations.map(x=>'explicit-name-anim-'+x));
 elm.classList.add('explicit-styled-name');
 for(const k of ['backgroundImage','backgroundSize','backgroundPosition','color','webkitTextFillColor','fontFamily','fontWeight','letterSpacing','textShadow','webkitTextStroke','filter','animation'])elm.style[k]='';
 for(const k of ['--explicit-name-speed','--explicit-effect-color','--explicit-effect-accent','--explicit-effect-opacity','--explicit-effect-blur'])elm.style.removeProperty(k);
 if(!s)return;
 const x=normalize(s);
 elm.style.fontFamily=fonts[x.font];elm.style.fontWeight=String(x.weight);
 elm.style.letterSpacing=(x.spacing/10)+'px';
 const animatedGradient=x.animation==='rainbow'||x.animation==='shine';
 if(x.animation==='rainbow'){
  elm.style.backgroundImage='linear-gradient(90deg,#8fd6ff 0%,#b3a6ff 20%,#ffa6d0 40%,#ffe49d 60%,#9ef0d0 80%,#8fd6ff 100%)';
  elm.classList.add('explicit-name-gradient');
 }else if(x.gradient||x.animation==='shine'){
  // Percentages are strictly increasing: the old shine had 72% followed by 48%,
  // making gradients unexpectedly uneven in Chromium.
  const a=x.color,b=x.gradient?x.color2:x.color,c=x.gradient?x.color3:x.color;
  elm.style.backgroundImage=x.animation==='shine'
   ?`linear-gradient(100deg,${a} 0%,${b} 22%,${c} 36%,#ffffff 47%,${a} 53%,${b} 70%,${c} 100%)`
   :`linear-gradient(100deg,${a} 0%,${b} 48%,${c} 100%)`;
  elm.classList.add('explicit-name-gradient');
 }else elm.style.setProperty('color',x.color,'important');
 elm.style.backgroundSize=animatedGradient?'220% 100%':'100% 100%';
 const shadows=[];
 if(x.shadow_blur>0)shadows.push(`0 1px ${x.shadow_blur}px ${x.shadow_color}`);
 if(x.glow>0){shadows.push(`0 0 ${Math.max(2,Math.round(x.glow/2))}px ${x.shadow_color}`);
  shadows.push(`0 0 ${Math.round(x.glow)}px ${x.shadow_color}`);
 }
 elm.style.textShadow=shadows.join(', ');
 if(x.outline>0)elm.style.webkitTextStroke=`${x.outline}px ${x.outline_color}`;
 if(x.effect!=='none'&&x.effect_intensity>0){
  elm.classList.add('explicit-name-effect','explicit-name-effect-'+x.effect);
  elm.style.setProperty('--explicit-effect-color',x.shadow_color||x.color);
  elm.style.setProperty('--explicit-effect-accent',x.color3||x.color2||x.color);
  elm.style.setProperty('--explicit-effect-opacity',String(Math.max(.12,x.effect_intensity/100)));
  elm.style.setProperty('--explicit-effect-blur',Math.round(4+x.effect_intensity/10)+'px');
 }
 if(x.animation!=='none'){
  elm.classList.add('explicit-name-anim-'+x.animation);
  elm.style.setProperty('--explicit-name-speed',x.speed+'s');
 }
 if(x.effect!=='none')elm.style.setProperty('--explicit-name-speed',x.speed+'s');
}
window.explicitPaintName=paint;

const cache=new Map();let queue=new Set(),pending=false;
function resetStyleCache(){cache.clear();document.querySelectorAll('[data-explicit-name-user]').forEach(node=>paint(node,null));refreshVisible()}

function markName(node,user){if(!node||!user)return;node.dataset.explicitNameUser=user;const hit=cache.get(user);if(hit)paint(node,hit.style);else request([user]);}
function request(users){for(const u of users)if(u&&!cache.has(u))queue.add(u);if(pending||!queue.size||typeof session==='undefined'||!session)return;pending=true;setTimeout(async()=>{pending=false;if(!session||!queue.size)return;const list=[...queue].slice(0,100);list.forEach(u=>queue.delete(u));try{const response=await api('name-presets?users='+encodeURIComponent(list.join(',')));for(const u of list)cache.set(u,{style:response.styles?.[u]||null,at:Date.now()});document.querySelectorAll('[data-explicit-name-user]').forEach(node=>{const entry=cache.get(node.dataset.explicitNameUser);if(entry)paint(node,entry.style)})}catch(e){console.warn('Estilos de nomes:',e.message)}if(queue.size)request([])},30)}
function refreshVisible(){if(!session)return;const names=[...document.querySelectorAll('[data-explicit-name-user]')].map(e=>e.dataset.explicitNameUser);const now=Date.now();for(const u of names){const c=cache.get(u);if(c&&now-c.at>12000)cache.delete(u)}request(names)}
function addMemberMarks(){document.querySelectorAll('#membersList .member-entry:not([data-explicit-prepared])').forEach(b=>{b.dataset.explicitPrepared='1';const user=b.dataset.explicitUser;const text=b.querySelector('.explicit-member-name');if(text&&user)markName(text,user)})}
function addChatMarks(){document.querySelectorAll('.explicit-message-author:not([data-explicit-name-user])').forEach(node=>markName(node,node.dataset.author||node.closest('.message')?.dataset.author))}
function addPopoverMarks(){const pop=document.getElementById('memberPopover');if(pop&&!pop.hidden){const heading=pop.querySelector('.explicit-popover-identity h3');const handle=pop.querySelector('.explicit-popover-handle')?.textContent||pop.querySelector('.explicit-popover-identity small')?.textContent||'';if(heading&&handle.startsWith('@'))markName(heading,handle.slice(1).split(/\s|·/)[0])}}
function scan(){addMemberMarks();addChatMarks();addPopoverMarks()}
const members=document.getElementById('membersList'),messages=document.getElementById('messages'),popover=document.getElementById('memberPopover');
for(const target of [members,messages,popover])if(target)new MutationObserver(()=>scan()).observe(target,{childList:true,subtree:true});
setInterval(refreshVisible,6000);

const $button=(cls,txt,fn)=>{const b=make('button',cls,txt);b.type='button';if(fn)b.addEventListener('click',fn);return b};
const countWord=n=>n===1?'1 estilo':`${n} estilos`;
function presetCard(preset,equipped,handlers){
 const card=make('article','explicit-preset-card'+(equipped?' equipped':''));
 card.style.setProperty('--preset-color',normalize(preset.style).color);
 const visual=make('div','explicit-preset-visual');
 const name=make('strong','explicit-preset-sample-name',currentDisplayName());paint(name,preset.style);visual.append(name);
 const meta=make('div','explicit-preset-card-info');meta.append(make('strong','',preset.name),make('small','',equipped?'Usando agora':animationLabels[normalize(preset.style).animation]));
 const foot=make('div','explicit-preset-card-actions');
 const equip=$button('explicit-preset-primary',equipped?'✓ Equipado':'Equipar',handlers.equip);
 equip.setAttribute('aria-pressed',String(!!equipped));
 const edit=$button('explicit-preset-secondary','Editar',handlers.edit);
 const del=$button('explicit-preset-delete','',handlers.del);del.title='Excluir preset';del.setAttribute('aria-label','Excluir '+preset.name);
 const svg=document.createElementNS('http://www.w3.org/2000/svg','svg');svg.setAttribute('viewBox','0 0 24 24');svg.setAttribute('width','15');svg.setAttribute('height','15');svg.setAttribute('aria-hidden','true');svg.setAttribute('fill','none');svg.setAttribute('stroke','currentColor');svg.setAttribute('stroke-width','1.8');svg.setAttribute('stroke-linecap','round');svg.setAttribute('stroke-linejoin','round');
 for(const path of ['M3 6h18','M8 6V4h8v2','M5 6l1 15h12l1-15','M10 10v7','M14 10v7']){const p=document.createElementNS('http://www.w3.org/2000/svg','path');p.setAttribute('d',path);svg.append(p)}del.append(svg);
 foot.append(equip,edit,del);
 if(equipped)card.append(make('span','explicit-preset-equipped-dot','●'));
 card.append(visual,meta,foot);
 return card;
}
function confirmPresetDelete(preset,anchor){
 const workspace=anchor?.closest('.obsidian-modal-backdrop');
 if(!workspace)return Promise.resolve(false);
 return new Promise(resolve=>{
  const layer=make('div','explicit-preset-confirm-layer');
  const dialog=make('section','explicit-preset-confirm-dialog');
  dialog.setAttribute('role','alertdialog');dialog.setAttribute('aria-modal','true');
  const heading=make('h3','','Excluir preset?');heading.id='explicit-preset-delete-heading';
  const description=make('p','','O preset “'+preset.name+'” será removido permanentemente. Essa ação não poderá ser desfeita.');
  description.id='explicit-preset-delete-description';
  dialog.setAttribute('aria-labelledby',heading.id);dialog.setAttribute('aria-describedby',description.id);
  const actions=make('div','explicit-preset-confirm-actions');
  const cancel=$button('explicit-preset-cancel','Cancelar',()=>finish(false));
  const remove=$button('explicit-preset-confirm-delete','Excluir preset',()=>finish(true));
  actions.append(cancel,remove);dialog.append(make('span','explicit-preset-confirm-icon','!'),heading,description,actions);layer.append(dialog);
  const finish=(value)=>{layer.remove();anchor?.focus?.();resolve(value)};
  layer.addEventListener('pointerdown',e=>{if(e.target===layer)finish(false)});
  layer.addEventListener('keydown',e=>{
   if(e.key==='Escape'){e.preventDefault();e.stopPropagation();finish(false)}
   if(e.key==='Tab'){const order=[cancel,remove];const i=order.indexOf(document.activeElement);if(e.shiftKey&&i<=0){e.preventDefault();remove.focus()}else if(!e.shiftKey&&i===order.length-1){e.preventDefault();cancel.focus()}}
  });
  // Confirmação montada acima do painel de configurações ativo.
  workspace.append(layer);cancel.focus();
 });
}
// A única tela de personalização agora vive dentro de Configurações > Conta.
// O editor abaixo mantém exatamente os campos, paletas e prévia anteriores.
const presetLimit=5;
async function personalization(host){
 if(!host?.isConnected)return;
 host.replaceChildren(make('p','explicit-presets-intro','Carregando seus estilos…'));
 let data;try{data=await api('name-presets')}catch(e){host.replaceChildren(make('p','explicit-presets-intro','Não foi possível carregar a personalização.'));nexoToast(e.message,'error');return}
 if(!host.isConnected)return;
 const panel=make('section','explicit-name-panel explicit-presets-modal');host.replaceChildren(panel);
 panel.append(make('p','explicit-presets-intro','Personalize seu nome, salve até cinco estilos e aplique-os diretamente nesta página.'));
 const editorHost=make('div','explicit-name-inline-editor');panel.append(editorHost);
 const top=make('div','explicit-name-style-toolbar');
 const count=make('strong','',`${data.presets.length} de ${presetLimit} estilos salvos`);
 const add=$button('explicit-presets-cta','+ Novo estilo',()=>editor(null,data,editorHost,()=>personalization(host)));
 add.disabled=!data.enabled||data.presets.length>=presetLimit;
 top.append(count,add);panel.append(top);
 const notice=make('p','explicit-presets-intro','Seus estilos ficam salvos na conta. Use Equipar ou Desequipar sem sair desta tela.');
 panel.append(notice);
 const grid=make('div','explicit-presets-grid explicit-name-style-grid');grid.setAttribute('aria-label','Estilos de nome salvos');panel.append(grid);
 const footer=make('div','explicit-inventory-footer');
 const note=make('span','',data.presets.length>presetLimit?'Você tem estilos legados preservados; exclua os excedentes antes de criar novos.':'O nome em canais de voz permanece sem efeitos.');
 const clear=$button('explicit-presets-secondary','Desequipar estilo',async()=>{clear.disabled=true;try{await api('name-presets','POST',{action:'equip',id:''});resetStyleCache();await personalization(host);nexoToast('Estilo desequipado.')}catch(e){nexoToast(e.message,'error');clear.disabled=false}});
 clear.disabled=!data.enabled||!data.equipped;
 footer.append(note,clear);panel.append(footer);
 const show=()=>{
  grid.replaceChildren();count.textContent=data.presets.length>presetLimit?`${data.presets.length} estilos legados (novo limite: ${presetLimit})`:`${data.presets.length} de ${presetLimit} estilos`;
  for(const preset of data.presets){const equipped=data.equipped===preset.id;
   grid.append(presetCard(preset,equipped,{
    equip:async()=>{try{await api('name-presets','POST',{action:'equip',id:equipped?'':preset.id});resetStyleCache();await personalization(host);nexoToast(equipped?'Estilo desequipado.':'Estilo equipado.')}catch(e){nexoToast(e.message,'error')}},
    edit:()=>editor(preset,data,editorHost,()=>personalization(host)),
    del:async event=>{if(!await confirmPresetDelete(preset,event.currentTarget))return;try{await api('name-presets','POST',{action:'delete',id:preset.id});resetStyleCache();await personalization(host);nexoToast('Estilo excluído.')}catch(e){nexoToast(e.message,'error')}}
   }));
  }
  if(!data.presets.length)grid.append(make('p','explicit-presets-no-results','Você ainda não salvou estilos. Personalize seu nome acima e clique em Salvar estilo.'));
 };
 if(!data.enabled){
  const sample=make('div','explicit-name-locked-sample');sample.setAttribute('aria-hidden','true');
  sample.append(make('div','explicit-name-skeleton-input','Cores · Fonte · Brilho'),make('div','explicit-name-skeleton-preview','Seu nome personalizado'));
  const locked=make('div','explicit-name-locked-overlay');locked.append(make('strong','','Disponível com Explicit+'),make('p','','Ative o Explicit+ para criar, editar e equipar estilos de nome.'));
  const lockedWrap=make('div','explicit-name-locked-wrap');lockedWrap.append(sample,locked);editorHost.append(lockedWrap);
  grid.hidden=true;top.hidden=true;notice.hidden=true;footer.hidden=true;return;
 }
 show();
 const initial=data.presets.find(p=>p.id===data.equipped)|| (data.presets.length>=presetLimit?data.presets[0]:null);
 editor(initial,data,editorHost,()=>personalization(host));
}
function editor(preset,data={enabled:true},host,refresh){
 if(!data.enabled)return;
 const state=normalize(preset?.style);
 const box=host;box.replaceChildren();box.append(make('h3','explicit-name-editor-heading',preset?'Editar estilo: '+preset.name:'Criar estilo de nome'));
 box.append(make('p','explicit-presets-intro','Personalize somente as letras do nome. Teste combinações e veja o resultado em tempo real.'));
 const content=make('div','explicit-editor-shell');box.append(content);
 const left=make('div','explicit-editor-left');const right=make('div','explicit-editor-right');content.append(left,right);
 const nameField=make('label','explicit-editor-name-field');nameField.append(make('span','','Nome do preset'));
 const title=make('input');title.type='text';title.maxLength=48;title.placeholder='Ex.: Aurora azul';title.value=preset?.name||'';title.autocomplete='off';nameField.append(title);left.append(nameField);
 const swatches=make('div','explicit-editor-quick');
 const swTitle=make('span','','Comece com uma paleta');swatches.append(swTitle);
 const choices=make('div','explicit-editor-quick-list');swatches.append(choices);left.append(swatches);
 const tabs=make('div','explicit-editor-tabs');tabs.setAttribute('role','tablist');tabs.setAttribute('aria-label','Categorias de ajustes');left.append(tabs);
 const pages=make('div','explicit-editor-pages');left.append(pages);
 const inputs={};
 const sectionData=[['colors','Cores'],['type','Fonte'],['light','Brilho']];
 const sections={};const tabButtons={};
 function switchPage(id){for(const [k] of sectionData){sections[k].hidden=k!==id;tabButtons[k].classList.toggle('selected',k===id);tabButtons[k].setAttribute('aria-selected',String(k===id))}}
 for(const [key,label] of sectionData){const b=$button('explicit-editor-tab',label,()=>switchPage(key));b.setAttribute('role','tab');tabs.append(b);tabButtons[key]=b;const section=make('section','explicit-editor-page');section.setAttribute('role','tabpanel');pages.append(section);sections[key]=section}
 function group(page,title,desc){const section=make('div','explicit-editor-group');section.append(make('h3','',title));if(desc)section.append(make('p','',desc));page.append(section);return section}
 function field(host,{key,label,type='range',min,max,step=1,options,groupClass=''}){
  const holder=make('label','explicit-editor-field '+groupClass);holder.append(make('span','explicit-editor-field-title',label));
  let input;if(type==='select'){
   input=make('select');for(const [value,text] of options){const opt=make('option','',text);opt.value=value;input.append(opt)}
   holder.append(input);
  }else if(type==='color'){
   const row=make('div','explicit-editor-color-row');input=make('input');input.type='color';const hex=make('span','explicit-editor-hex',state[key]);row.append(input,hex);holder.append(row);
   input.addEventListener('input',()=>hex.textContent=input.value.toUpperCase());
  }else if(type==='checkbox'){
   input=make('input');input.type='checkbox';holder.classList.add('explicit-editor-toggle');holder.append(input);
  }else{
   const row=make('div','explicit-editor-range-row');input=make('input');input.type='range';input.min=String(min);input.max=String(max);input.step=String(step);
   const out=make('output','explicit-editor-range-output');row.append(input,out);holder.append(row);
   input.addEventListener('input',()=>out.textContent=displayValue(key,input.value));
  }
  inputs[key]=input;host.append(holder);input.addEventListener('input',update);input.addEventListener('change',update);
  return input;
 }
 function displayValue(key,value){if(key==='spacing')return (Number(value)/10).toFixed(1)+' px';if(key==='speed')return value+' s';if(key==='glow')return value+' / 30';if(key==='effect_intensity')return value+'%';if(key==='outline')return value+' px';return value+' px'}
 const palette=group(sections.colors,'Paleta','Três tons que se misturam suavemente nas letras.');
 const row=make('div','explicit-editor-color-grid');palette.append(row);
 for(const [key,label] of [['color','Principal'],['color2','Secundária'],['color3','Terceira cor']])field(row,{key,label,type:'color'});
 const gradientRow=group(sections.colors,'Modo de cor');field(gradientRow,{key:'gradient',label:'Ativar degradê',type:'checkbox'});
 const typeGroup=group(sections.type,'Tipografia','Altere a aparência das letras sem afetar outras partes do perfil.');
 field(typeGroup,{key:'font',label:'Fonte',type:'select',options:Object.keys(fonts).map(k=>[k,fontLabels[k]])});
 field(typeGroup,{key:'weight',label:'Peso da fonte',type:'select',options:Object.entries(weightLabels)});
 field(typeGroup,{key:'spacing',label:'Espaçamento entre letras',min:-10,max:40});
 const light=group(sections.light,'Luz e sombra','Efeitos de iluminação discretos e ajustáveis.');
 field(light,{key:'shadow_color',label:'Cor do brilho',type:'color'});
 field(light,{key:'glow',label:'Intensidade do brilho',min:0,max:30});
 field(light,{key:'shadow_blur',label:'Desfoque da sombra',min:0,max:24});
 const outline=group(sections.light,'Contorno');field(outline,{key:'outline_color',label:'Cor do contorno',type:'color'});field(outline,{key:'outline',label:'Espessura do contorno',min:0,max:2});
 for(const item of styleShowcases){const swatch=$button('explicit-editor-swatch',item.label,()=>{Object.assign(state,normalize({...state,...item.style}));syncInputs();update()});
  swatch.style.setProperty('--swatch-a',item.style.color);swatch.style.setProperty('--swatch-b',item.style.color3);choices.append(swatch)}
 const preview=make('section','explicit-editor-preview');right.append(preview);
 const preHeader=make('div','explicit-editor-preview-head');preHeader.append(make('strong','','Prévia ao vivo'),make('small','','Os ajustes aparecem imediatamente.'));preview.append(preHeader);
 const mainPrev=make('div','explicit-editor-main-preview');
 const bigName=make('strong','explicit-editor-main-name',currentDisplayName());mainPrev.append(bigName,make('span','explicit-editor-under-handle','@'+currentUsername()));preview.append(mainPrev);
 const contexts=make('div','explicit-editor-contexts');preview.append(contexts);
 function context(label,name){const row=make('div','explicit-editor-context');const caption=make('small','',label);const text=make('strong','',name);row.append(caption,text);contexts.append(row);return text}
 const chat=context('NO CHAT',currentDisplayName());const member=context('NA LISTA DE MEMBROS',currentDisplayName());const profile=context('NO PERFIL',currentDisplayName());
 const previewNote=make('p','explicit-editor-preview-note','O nome dos canais de voz permanece sem efeitos.');preview.append(previewNote);
 const footer=make('div','explicit-presets-editor-actions');
 const back=$button('explicit-presets-secondary','Descartar alterações',()=>refresh());const save=$button('explicit-presets-cta','Salvar estilo',async()=>{
  const value=title.value.trim();if(!value||[...value].length>48){nexoToast('Informe um nome de até 48 caracteres.','error');title.focus();return}
  if(!preset?.id&&data.presets.length>=presetLimit){nexoToast('Limite de cinco estilos atingido. Edite ou exclua um estilo existente.','error');return}
  save.disabled=true;try{await api('name-presets','POST',{action:'save',id:preset?.id||'',name:value,style:normalize(state)});resetStyleCache();await refresh();nexoToast('Estilo salvo com sucesso.')}catch(e){nexoToast(e.message,'error');save.disabled=false}
 });footer.append(back,save);box.append(footer);
 function syncInputs(){for(const [key,input] of Object.entries(inputs)){
  if(input.type==='checkbox')input.checked=!!state[key];else input.value=String(state[key]);
  if(input.type==='range')input.parentElement.querySelector('output').textContent=displayValue(key,state[key]);
  if(input.type==='color')input.parentElement.querySelector('.explicit-editor-hex').textContent=String(state[key]).toUpperCase();
 }}
 function update(){for(const [key,input] of Object.entries(inputs)){state[key]=input.type==='checkbox'?input.checked:input.type==='range'||key==='weight'?Number(input.value):input.value}
  const prepared=normalize(state);for(const n of [bigName,chat,member,profile])paint(n,prepared);
  for(const input of Object.values(inputs)){if(input.type==='range')input.parentElement.querySelector('output').textContent=displayValue(Object.keys(inputs).find(k=>inputs[k]===input),input.value)}
 }
 syncInputs();switchPage('colors');update();
}
window.explicitRenderNamePersonalization=personalization;
// Compatibilidade com atalhos antigos sem recriar o overlay de inventário.
window.explicitOpenNameInventory=()=>{if(typeof openSettings==='function')openSettings('Conta · Personalização')};
scan();
})();
