"use strict";
class ExplicitLiveKitMedia {
    record(event) {
        this.supportEvents.push({ elapsedMs: Math.max(0, Date.now() - this.supportStarted), event });
        if (this.supportEvents.length > 80)
            this.supportEvents.shift();
        this.supportBus?.emit('media:event', { elapsedMs: Math.max(0, Date.now() - this.supportStarted), event });
    }
    supportReport() {
        return { schema: 'explicit-media-diagnostics-v1', appVersion: '18.6',
            ...this.diagnostics(), connectionQuality: this.lastQuality, screenCapture: this.screenCaptureSettings(), events: this.supportEvents.map(e => ({ ...e })) };
    }
    // Report only technical capture properties: no track identifiers, device labels or participant names.
    screenCaptureSettings() {
        const publication = this.room?.localParticipant.getTrackPublication(this.sdk.Track.Source.ScreenShare);
        const settings = publication?.track?.mediaStreamTrack?.getSettings?.();
        if (!settings)
            return null;
        return { width: Math.max(0, Math.round(Number(settings.width) || 0)), height: Math.max(0, Math.round(Number(settings.height) || 0)), frameRate: Math.max(0, Math.round(Number(settings.frameRate) || 0)) };
    }
    subscribe(eventName, listener) {
        if (!this.supportBus)
            return () => { };
        this.supportBus.on(eventName, listener);
        return () => this.supportBus?.off(eventName, listener);
    }
    constructor(callbacks) {
        this.micOptions = {};
        this.canSpeak = false;
        this.room = null;
        this.stopping = false;
        this.micQueue = Promise.resolve();
        this.audioNodes = new Map();
        this.videoNodes = new Map();
        this.audioGesturePending = false;
        this.mediaState = 'offline';
        this.subscriptionErrors = 0;
        this.lastNetworkWarning = '';
        // Bounded, privacy-preserving, in-memory support log. Never store tokens, URLs, names, track IDs or message content.
        this.supportEvents = [];
        this.supportStarted = Date.now();
        this.lastQuality = 'unknown';
        this.supportBus = null;
        this.onUserGesture = () => { document.removeEventListener('pointerdown', this.onUserGesture); document.removeEventListener('keydown', this.onUserGesture); void this.resumeAudioAfterGesture(); };
        const candidate = window.LivekitClient;
        if (!candidate?.Room || !candidate?.RoomEvent || !candidate?.Track?.Source)
            throw Error('SDK LiveKit indisponível. Execute 03_COMPILAR_CLIENTE.cmd antes do teste.');
        this.sdk = candidate;
        this.callbacks = callbacks;
        const Emitter = window.EventEmitter3;
        if (typeof Emitter === 'function')
            this.supportBus = new Emitter();
    }
    audioKey(name, source) { return name + '\u0000' + source; }
    audioVolumeFor(identity) {
        const master = Math.max(0, Math.min(1, Number(this.callbacks.getVolume()) || 0));
        const individual = this.callbacks.getVolumeForParticipant?.(identity);
        const factor = Number.isFinite(individual) ? Math.max(0, Math.min(1, individual)) : 1;
        return Math.min(1, master * factor);
    }
    setParticipantVolume(identity) {
        for (const [key, node] of this.audioNodes) {
            if (key.startsWith(identity + '\u0000')) node.element.volume = this.audioVolumeFor(identity) * (key === this.audioKey(identity, this.sdk.Track.Source.ScreenShareAudio) ? Math.max(0, Math.min(1, Number(this.callbacks.getScreenVolumeForParticipant?.(identity) ?? 1))) : 1);
        }
    }
    addAudio(track, pub, participant) {
        const key = this.audioKey(participant.identity, pub.source || 'microphone');
        if (this.audioNodes.get(key)?.track === track)
            return;
        this.removeAudio(key);
        const element = document.createElement('audio');
        element.autoplay = true;
        element.setAttribute('playsinline', '');
        element.id = 'voice-' + participant.identity + (pub.source === 'microphone' ? '' : '-' + pub.source);
        element.muted = this.callbacks.isDeaf();
        element.volume = this.audioVolumeFor(participant.identity) * (pub.source === this.sdk.Track.Source.ScreenShareAudio ? Math.max(0, Math.min(1, Number(this.callbacks.getScreenVolumeForParticipant?.(participant.identity) ?? 1))) : 1);
        document.getElementById('voiceAudios')?.appendChild(element);
        try {
            track.attach(element);
        }
        catch (error) {
            element.remove();
            this.callbacks.onStatus('Não foi possível reproduzir uma faixa de áudio');
            return;
        }
        this.audioNodes.set(key, { track, element });
        this.record('audio_subscribed');
        element.play().catch(() => this.requestAudioGesture());
        const output = this.callbacks.getOutputDevice();
        if (output && 'setSinkId' in element)
            element.setSinkId(output).catch((error) => console.warn('[Explicit media] Saída de áudio:', error.message));
    }
    addVideo(track, participant) {
        if (this.videoNodes.get(participant.identity) === track)
            return;
        this.record('video_subscribed');
        this.videoNodes.set(participant.identity, track);
        // MediaStreamTrack can report a browser/network-level pause without LiveKit unsubscribing it.
        // Verify current track identity so an old replaced track cannot affect the new viewer.
        const source = track.mediaStreamTrack, owner = participant.identity;
        if (typeof source?.addEventListener === 'function') {
            source.addEventListener('mute', () => { if (this.videoNodes.get(owner) === track) {
                this.record('screen_track_muted');
                this.callbacks.onStatus('Vídeo remoto temporariamente interrompido');
            } });
            source.addEventListener('unmute', () => { if (this.videoNodes.get(owner) === track) {
                this.record('screen_track_unmuted');
                this.callbacks.onStatus('Vídeo remoto retomado');
            } });
            source.addEventListener('ended', () => { if (this.videoNodes.get(owner) === track)
                this.record('screen_track_ended'); });
        }
        this.callbacks.onVideo(participant.identity, source, new MediaStream([source]));
    }
    removeAudio(key, expected) {
        const node = this.audioNodes.get(key);
        if (!node || (expected && node.track !== expected))
            return;
        try {
            node.track.detach(node.element);
        }
        catch { }
        node.element.remove();
        this.audioNodes.delete(key);
        this.record('audio_removed');
    }
    removeParticipant(name) {
        for (const key of [...this.audioNodes.keys()])
            if (key.startsWith(name + '\u0000'))
                this.removeAudio(key);
        if (this.videoNodes.delete(name)) {
            this.callbacks.onVideoRemoved(name);
            this.record('video_removed');
        }
    }
    restoreSubscribedTracks() {
        // Rebuild actual current subscriptions; never keep ghosts after reconnect.
        const room = this.room;
        if (!room)
            return;
        const expectedAudio = new Map(), expectedVideo = new Map();
        for (const participant of room.remoteParticipants.values()) {
            for (const publication of participant.trackPublications?.values() || []) {
                if (!publication.track || publication.isSubscribed === false)
                    continue;
                if (publication.track.kind === 'audio') {
                    const key = this.audioKey(participant.identity, publication.source || 'microphone');
                    expectedAudio.set(key, publication.track);
                    this.addAudio(publication.track, publication, participant);
                }
                else if (publication.source === this.sdk.Track.Source.ScreenShare) {
                    expectedVideo.set(participant.identity, publication.track);
                    this.addVideo(publication.track, participant);
                }
            }
        }
        for (const [key, node] of this.audioNodes) {
            if (expectedAudio.get(key) !== node.track)
                this.removeAudio(key, node.track);
        }
        for (const [name, track] of this.videoNodes) {
            if (expectedVideo.get(name) !== track) {
                this.videoNodes.delete(name);
                this.callbacks.onVideoRemoved(name);
                this.record('stale_screen_removed');
            }
        }
    }
    async resumeAudioAfterGesture() {
        this.audioGesturePending = false;
        const room = this.room;
        if (!room || this.stopping)
            return;
        try {
            // Invoke BOTH unlock calls before the first await, while the browser still
            // considers this a user activation. A blocked audio track must not prevent video.
            const attempts = [];
            if (room.startAudio)
                attempts.push(room.startAudio());
            if (room.startVideo)
                attempts.push(room.startVideo());
            attempts.push(Promise.all([...this.audioNodes.values()].filter(node => !node.element.muted).map(node => node.element.play())));
            const results = await Promise.allSettled(attempts);
            if (results.some(result => result.status === 'rejected'))
                throw Error('playback still restricted');
            this.record('playback_resumed_by_gesture');
        }
        catch {
            this.requestAudioGesture();
            return;
        }
        this.callbacks.onStatus('Reprodução de áudio liberada');
    }
    requestAudioGesture() {
        if (this.stopping || this.audioGesturePending)
            return;
        this.audioGesturePending = true;
        this.record('playback_gesture_required');
        this.callbacks.onStatus('Clique na janela para liberar áudio e vídeo da chamada');
        document.addEventListener('pointerdown', this.onUserGesture);
        document.addEventListener('keydown', this.onUserGesture);
    }
    async connect(auth, micOptions, startMuted = false) {
        if (!/^wss:\/\/[^/\s]+/.test(auth.url) || !auth.token)
            throw Error('Credenciais de mídia inválidas');
        if (this.room)
            throw Error('Já existe uma sessão de mídia ativa');
        this.micOptions = micOptions;
        this.canSpeak = !!auth.can_speak;
        this.stopping = false;
        this.mediaState = 'connecting';
        this.subscriptionErrors = 0;
        this.lastNetworkWarning = '';
        this.supportStarted = Date.now();
        this.supportEvents = [];
        this.lastQuality = 'unknown';
        this.record('connect_started');
        const sdk = this.sdk, cb = this.callbacks;
        const room = new sdk.Room({ adaptiveStream: true, dynacast: true, stopLocalTrackOnUnpublish: true });
        this.room = room;
        room.on(sdk.RoomEvent.TrackSubscribed, (track, pub, participant) => {
            if (this.stopping || this.room !== room)
                return;
            this.record(track.kind === 'audio' ? 'track_subscribed_audio' : 'track_subscribed_video');
            if (track.kind === 'audio')
                this.addAudio(track, pub, participant);
            else if (pub.source === sdk.Track.Source.ScreenShare)
                this.addVideo(track, participant);
        });
        room.on(sdk.RoomEvent.TrackUnsubscribed, (track, pub, participant) => {
            if (this.room !== room)
                return;
            this.record(track.kind === 'audio' ? 'track_unsubscribed_audio' : 'track_unsubscribed_video');
            if (track.kind === 'audio')
                this.removeAudio(this.audioKey(participant.identity, pub.source || 'microphone'), track);
            else if (pub.source === sdk.Track.Source.ScreenShare && this.videoNodes.get(participant.identity) === track) {
                this.videoNodes.delete(participant.identity);
                cb.onVideoRemoved(participant.identity);
            }
        });
        if (sdk.RoomEvent.ActiveSpeakersChanged)
            room.on(sdk.RoomEvent.ActiveSpeakersChanged, (speakers) => { if (this.room === room && !this.stopping)
                cb.onSpeakers?.((speakers || []).filter(p => p?.identity && p.isMicrophoneEnabled !== false).map(p => p.identity)); });
        room.on(sdk.RoomEvent.ParticipantDisconnected, (participant) => { if (this.room === room) {
            this.record('participant_disconnected');
            this.removeParticipant(participant.identity);
            cb.onSpeakers?.(room.activeSpeakers?.map(p => p.identity) || []);
        } });
        room.on(sdk.RoomEvent.Reconnecting, () => { if (!this.stopping && this.room === room) {
            this.mediaState = 'reconnecting';
            this.record('reconnecting');
            cb.onStatus('Conexão de mídia interrompida: LiveKit tentando recuperar…');
        } });
        if (sdk.RoomEvent.SignalReconnecting)
            room.on(sdk.RoomEvent.SignalReconnecting, () => { if (!this.stopping && this.room === room)
                cb.onStatus('Reconectando sinalização de mídia…'); });
        room.on(sdk.RoomEvent.Reconnected, () => { if (!this.stopping && this.room === room) {
            this.mediaState = 'connected';
            this.record('reconnected');
            this.restoreSubscribedTracks();
            cb.onStatus('Conexão de mídia recuperada');
        } });
        room.on(sdk.RoomEvent.Disconnected, () => { if (this.room !== room)
            return; this.mediaState = 'disconnected'; this.record('disconnected'); if (!this.stopping)
            cb.onDisconnected(); });
        room.on(sdk.RoomEvent.LocalTrackUnpublished, (publication) => { if (!this.stopping && publication.source === sdk.Track.Source.ScreenShare)
            cb.onScreenEnded(); });
        if (sdk.RoomEvent.TrackSubscriptionFailed)
            room.on(sdk.RoomEvent.TrackSubscriptionFailed, (_sid, participant, reason) => {
                if (this.stopping)
                    return;
                this.subscriptionErrors++;
                this.record('subscription_failed');
                // Do not print identities, token-bearing errors or server URLs to console logs.
                console.warn('[Explicit media] Inscrição em mídia falhou');
                cb.onStatus('Falha ao receber mídia de outro participante (verifique sua rede)');
            });
        if (sdk.RoomEvent.TrackStreamStateChanged)
            room.on(sdk.RoomEvent.TrackStreamStateChanged, (publication, state) => {
                if (this.stopping || publication.source !== sdk.Track.Source.ScreenShare)
                    return;
                if (String(state).toLowerCase().includes('paused')) {
                    this.record('screen_stream_paused');
                    cb.onStatus('Transmissão pausada pelo servidor devido à rede');
                }
                else if (String(state).toLowerCase().includes('active')) {
                    this.record('screen_stream_active');
                    cb.onStatus('Transmissão de tela retomada');
                }
                ;
            });
        if (sdk.RoomEvent.ConnectionQualityChanged)
            room.on(sdk.RoomEvent.ConnectionQualityChanged, (quality, participant) => {
                if (this.stopping || participant !== room.localParticipant)
                    return;
                const q = String(quality).toLowerCase();
                if (['excellent', 'good', 'poor', 'lost'].includes(q) && q !== this.lastQuality) {
                    this.lastQuality = q;
                    this.record('quality_' + q);
                }
                if ((q === 'poor' || q === 'lost') && this.lastNetworkWarning !== q) {
                    this.lastNetworkWarning = q;
                    cb.onStatus('Sua conexão de mídia está instável');
                }
                else if (q === 'excellent' || q === 'good')
                    this.lastNetworkWarning = '';
            });
        if (sdk.RoomEvent.AudioPlaybackStatusChanged)
            room.on(sdk.RoomEvent.AudioPlaybackStatusChanged, (canPlay) => { if (!canPlay)
                this.requestAudioGesture(); });
        if (sdk.RoomEvent.VideoPlaybackStatusChanged)
            room.on(sdk.RoomEvent.VideoPlaybackStatusChanged, (canPlay) => { if (!canPlay)
                this.requestAudioGesture(); });
        try {
            await room.connect(auth.url, auth.token);
            this.mediaState = 'connected';
            this.record('connected');
            this.restoreSubscribedTracks();
        }
        catch (error) {
            this.record('connect_failed');
            this.stopping = true;
            this.mediaState = 'failed';
            await room.disconnect().catch(() => { });
            this.room = null;
            throw error;
        }
        if (auth.can_speak && !startMuted) {
            try {
                await this.enableMicrophone();
            }
            catch {
                this.record('microphone_unavailable');
                cb.onStatus('Conectado para ouvir. Microfone indisponível; confira a permissão e tente ativá-lo novamente.');
            }
        }
    }
    setRemoteScreenFPS(identity, fps) {
        const person = this.room?.remoteParticipants.get(identity);
        const pub = person?.getTrackPublication(this.sdk.Track.Source.ScreenShare);
        if (!pub || typeof pub.setVideoFPS !== 'function') return false;
        pub.setVideoFPS(Math.max(30, Math.min(60, Math.round(Number(fps) || 60))));
        return true;
    }
    setScreenAudioVolume(identity, factor) {
        const safe = Math.max(0, Math.min(1, Number(factor) || 0));
        for (const [key, node] of this.audioNodes) {
            if (key === this.audioKey(identity, this.sdk.Track.Source.ScreenShareAudio)) node.element.volume = Math.min(1, this.audioVolumeFor(identity) * safe);
        }
    }
    remoteCount() { return this.room?.remoteParticipants.size || 0; }
    diagnostics() {
        return { state: this.mediaState, remoteParticipants: this.remoteCount(), audioTracks: this.audioNodes.size, screenTracks: this.videoNodes.size, subscriptionErrors: this.subscriptionErrors };
    }
    setMicActive(enabled) {
        // Keep PTT events ordered, including when the user presses/releases very quickly.
        this.micQueue = this.micQueue.catch(() => { }).then(async () => {
            const pub = this.room?.localParticipant.getTrackPublication(this.sdk.Track.Source.Microphone);
            if (!pub) {
                if (enabled && this.room && this.canSpeak)
                    await this.enableMicrophone();
                return;
            }
            // The state poll can run every ~1.2 seconds. Do not send mute
            // commands to LiveKit when the publication already matches.
            if (typeof pub.isMuted === 'boolean' && pub.isMuted === !enabled) return;
            if (enabled) await pub.unmute();
            else await pub.mute();
        });
        return this.micQueue;
    }
    // When a previously selected microphone is unplugged, first try the default
    // device before sending the caller into a needless leave/rejoin loop.
    async enableMicrophone() {
        const local = this.room?.localParticipant;
        if (!local || !this.canSpeak) return;
        try {
            await local.setMicrophoneEnabled(true, this.micOptions);
        } catch (error) {
            const options = this.micOptions || {};
            if (!options.deviceId && !options.voiceIsolation) throw error;
            // Optional voice isolation is experimental; an unplugged input
            // also deserves a fallback before abandoning the voice session.
            const fallback = { ...options };
            delete fallback.deviceId;
            delete fallback.voiceIsolation;
            await local.setMicrophoneEnabled(true, fallback);
            this.micOptions = fallback;
            this.record('microphone_default_fallback');
            this.callbacks.onStatus(options.deviceId ? 'Microfone selecionado indisponível; usando o dispositivo padrão.' : 'Processamento de microfone simplificado para manter a chamada.');
        }
    }
    async updateInputProfile(options) {
        const next = { ...options };
        const pub = this.room?.localParticipant?.getTrackPublication(this.sdk.Track.Source.Microphone);
        const track = pub?.track;
        // Muted or not-yet-created tracks must stay muted. Only update saved
        // options, which will be used at the next actual microphone capture.
        if (!track?.applyConstraints) { this.micOptions = next; return; }
        const constraints = {echoCancellation:next.echoCancellation,noiseSuppression:next.noiseSuppression,autoGainControl:next.autoGainControl};
        if (next.voiceIsolation) constraints.voiceIsolation = true;
        try { await track.applyConstraints(constraints); }
        catch(error) {
            if (!constraints.voiceIsolation) throw error;
            delete constraints.voiceIsolation;
            await track.applyConstraints(constraints);
            delete next.voiceIsolation;
            this.callbacks.onStatus('Seu sistema não oferece isolamento avançado; usando supressão padrão.');
        }
        this.micOptions = next;
        this.record('microphone_profile_updated');
    }
    async setInputDevice(id, options) {
        if (!this.room) return;
        const nextOptions = { ...(options || this.micOptions) };
        try {
            await this.room.switchActiveDevice('audioinput', id || 'default');
        } catch (error) {
            if (!id || id === 'default') throw error;
            await this.room.switchActiveDevice('audioinput', 'default');
            delete nextOptions.deviceId;
            this.record('microphone_default_fallback');
            this.callbacks.onStatus('O microfone escolhido foi desconectado. Voltamos ao dispositivo padrão.');
        }
        await this.updateInputProfile(nextOptions);
    }
    async shareScreen(fps) {
        const local = this.room?.localParticipant;
        if (!local || this.mediaState !== 'connected')
            throw Error('Sem conexão de mídia estável');
        const safeFPS = Math.min(60, Math.max(30, Math.round(Number(fps) || 30)));
        this.record('screen_publish_started');
        await local.setScreenShareEnabled(true, { frameRate: safeFPS, audio: false });
        const pub = local.getTrackPublication(this.sdk.Track.Source.ScreenShare);
        if (!pub?.track?.mediaStreamTrack) {
            await local.setScreenShareEnabled(false).catch(() => { });
            throw Error('LiveKit não publicou a tela');
        }
        this.record('screen_published');
        return new MediaStream([pub.track.mediaStreamTrack]);
    }
    async stopScreen() { if (this.room) {
        await this.room.localParticipant.setScreenShareEnabled(false);
        this.record('screen_stopped');
    } }
    syncAudio(deaf, volume, outputId) {
        for (const [key, node] of this.audioNodes) {
            node.element.muted = deaf;
            const identity = key.split('\u0000')[0];
            const factor = this.callbacks.getVolumeForParticipant?.(identity);
            node.element.volume = Math.min(1, Math.max(0, volume) * (Number.isFinite(factor) ? Math.max(0, Math.min(1, factor)) : 1) * (key.endsWith('\u0000' + this.sdk.Track.Source.ScreenShareAudio) ? Math.max(0, Math.min(1, Number(this.callbacks.getScreenVolumeForParticipant?.(key.split('\u0000')[0]) ?? 1))) : 1));
            // Polling runs frequently while gaming. Avoid reselecting the
            // same device every cycle, which can disrupt audio on Windows.
            if (outputId && 'setSinkId' in node.element && node.element.sinkId !== outputId)
                node.element.setSinkId(outputId).catch(() => this.record('output_device_failed'));
        }
    }
    async disconnect() {
        this.stopping = true;
        this.mediaState = 'stopped';
        this.record('manual_disconnect');
        document.removeEventListener('pointerdown', this.onUserGesture);
        document.removeEventListener('keydown', this.onUserGesture);
        this.audioGesturePending = false;
        for (const key of [...this.audioNodes.keys()])
            this.removeAudio(key);
        for (const name of this.videoNodes.keys())
            this.callbacks.onVideoRemoved(name);
        this.videoNodes.clear();
        this.callbacks.onSpeakers?.([]);
        const room = this.room;
        this.room = null;
        if (room)
            await room.disconnect().catch(() => { });
    }
}
window.ExplicitLiveKitMedia = ExplicitLiveKitMedia;
