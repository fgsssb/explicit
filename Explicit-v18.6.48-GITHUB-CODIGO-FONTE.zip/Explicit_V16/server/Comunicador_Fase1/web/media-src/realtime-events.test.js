const test=require('node:test');
const assert=require('node:assert/strict');
const path=require('node:path');
const fs=require('node:fs');
const vm=require('node:vm');
const zlib=require('node:zlib');
const web=path.join(__dirname,'..');
const emitter=require('../vendor/eventemitter3-4.0.7.min.js');
function create(fn,{delay=()=>0}={}){
 const context={window:{EventEmitter3:emitter},AbortController,TextDecoder,Error,JSON,console};
 vm.runInNewContext(fs.readFileSync(path.join(web,'realtime-events.js'),'utf8'),context);
 const timers=[];const bus=new emitter();const observed=[];
 for(const name of ['chat:message','chat:connected','chat:reconnecting','chat:invalid','chat:unauthorized'])bus.on(name,m=>observed.push([name,m]));
 const transport=new context.window.ExplicitRealtimeEvents({bus,token:()=> 'local-test-token',fetchFn:fn,delay,setTimeoutFn:(fn,n)=>{timers.push({fn,n});return timers.length;},clearTimeoutFn:id=>{timers[id-1]=null;}});
 return {transport,observed,timers};
}
function stream(chunks){let i=0;const enc=new TextEncoder();return {ok:true,status:200,body:{getReader(){return {async read(){return i<chunks.length?{value:enc.encode(chunks[i++]),done:false}:{done:true}}}}}};}
const tick=()=>new Promise(resolve=>setImmediate(resolve));
test('SSE parser survives fragmented JSON, CRLF and ping and ignores malformed events',async()=>{
 const message={id:'abc',channel:'community:geral',text:'Olá 🎯'};
 const data=': ping\r\n\r\ndata: '+JSON.stringify(message)+'\r\n\r\ndata: not-json\r\n\r\n';
 const parts=[data.slice(0,11),data.slice(11,23),data.slice(23,47),data.slice(47,61),data.slice(61)];
 const f=create(async()=>stream(parts));f.transport.start();await tick();await tick();
 assert.equal(f.observed.filter(x=>x[0]==='chat:message').length,1);
 assert.equal(f.observed.find(x=>x[0]==='chat:message')[1].text,'Olá 🎯');
 assert.equal(f.transport.diagnostics().invalidEvents,1);
 assert.equal(f.observed.filter(x=>x[0]==='chat:reconnecting').length,1,'clean EOF should reconnect');
 f.transport.stop();
});
test('clean EOF triggers a bounded reconnect that delivers subsequent messages',async()=>{
 let count=0;const f=create(async()=>stream(['data: '+JSON.stringify({id:'m'+(++count),channel:'geral'})+'\n\n']));
 f.transport.start();await tick();await tick();assert.equal(count,1);
 assert.ok(f.timers[0].n>=1000 && f.timers[0].n<20000);
 f.timers[0].fn();await tick();await tick();assert.equal(count,2);
 assert.equal(f.observed.filter(x=>x[0]==='chat:message').length,2);
 f.transport.stop();
});
test('401/403 stop the stream; no automatic reconnect or token exposure',async()=>{
 let hits=0;const f=create(async()=>{hits++;return {ok:false,status:401}});
 f.transport.start();await tick();await tick();
 assert.equal(hits,1);assert.equal(f.transport.running,false);
 assert.equal(f.observed.filter(x=>x[0]==='chat:unauthorized').length,1);
 assert.equal(f.timers.length,0);
 assert.ok(!JSON.stringify(f.observed).includes('local-test-token'));
});
test('oversized SSE blocks are rejected and reconnect is scheduled safely',async()=>{
 const f=create(async()=>stream(['x'.repeat(270000)]));f.transport.start();await tick();await tick();
 assert.equal(f.observed.filter(x=>x[0]==='chat:message').length,0);
 assert.equal(f.observed.filter(x=>x[0]==='chat:reconnecting').length,1);
 f.transport.stop();
});
test('EventEmitter3 library bundle provides a real browser global',()=>{
 const ctx={window:{}};ctx.self=ctx.window;ctx.globalThis=ctx.window;
 vm.runInNewContext(fs.readFileSync(path.join(web,'vendor/eventemitter3-4.0.7.min.js'),'utf8'),ctx);
 assert.equal(typeof ctx.window.EventEmitter3,'function');
 const emitter=new ctx.window.EventEmitter3();let calls=0;emitter.on('voice:connected',()=>calls++);emitter.emit('voice:connected');assert.equal(calls,1);
});
test('Pako browser bundle creates valid gzip JSON without server calls',()=>{
 const ctx={window:{}};ctx.self=ctx.window;ctx.globalThis=ctx.window;
 vm.runInNewContext(fs.readFileSync(path.join(web,'vendor/pako-1.0.11.min.js'),'utf8'),ctx);
 assert.equal(typeof ctx.window.pako?.gzip,'function');
 const source=JSON.stringify({schema:'diagnostic',events:Array(80).fill({event:'media:reconnecting'})});
 const bytes=ctx.window.pako.gzip(source);
 assert.equal(zlib.gunzipSync(bytes).toString(),source);
 assert.ok(bytes.length<Buffer.byteLength(source),'compression must reduce repeated event metadata');
});

test('a stopped connection never dispatches the read that was already pending',async()=>{
 let finish;let cancelled=0,released=0;
 const reader={read:()=>new Promise(resolve=>{finish=resolve}),cancel:async()=>{cancelled++},releaseLock:()=>{released++}};
 const f=create(async()=>({ok:true,status:200,body:{getReader:()=>reader}}));
 f.transport.start();await tick();f.transport.stop();
 finish({done:false,value:new TextEncoder().encode('data: '+JSON.stringify({id:'old',channel:'geral'})+'\n\n')});
 await tick();
 assert.equal(f.observed.filter(x=>x[0]==='chat:message').length,0,'old read delivered after stop');
 assert.equal(cancelled,1);assert.equal(released,1);
});

test('an obsolete unauthorized response cannot stop a new connection',async()=>{
 let completeOld;let calls=0;
 const f=create(()=>++calls===1?new Promise(resolve=>{completeOld=resolve}):Promise.resolve({ok:true,status:200,body:{getReader:()=>({read:()=>new Promise(()=>{})})}}));
 f.transport.start();f.transport.stop();f.transport.start();await tick();
 completeOld({ok:false,status:401});await tick();
 assert.equal(f.transport.running,true);assert.equal(f.transport.state,'connected');
 assert.equal(f.observed.filter(x=>x[0]==='chat:unauthorized').length,0);
 f.transport.stop();
});

test('many valid SSE events coalesced into a large network chunk are delivered',async()=>{
 const packets=Array.from({length:400},(_,i)=>'data: '+JSON.stringify({id:'batch-'+i,channel:'geral',text:'x'.repeat(800)})+'\n\n').join('');
 assert.ok(Buffer.byteLength(packets)>262144);
 const f=create(async()=>stream([packets]));f.transport.start();await tick();await tick();
 assert.equal(f.observed.filter(x=>x[0]==='chat:message').length,400);
 f.transport.stop();
});

test('stop from an event subscriber also discards the remainder of that chunk',async()=>{
 const packet=i=>'data: '+JSON.stringify({id:'m'+i,channel:'geral'})+'\n\n';
 const f=create(async()=>stream([packet(1)+packet(2)]));
 f.transport.bus.on('chat:message',()=>f.transport.stop());
 f.transport.start();await tick();await tick();
 assert.equal(f.observed.filter(x=>x[0]==='chat:message').length,1);
});
