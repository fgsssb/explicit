// Simulated SDK tests — cannot replace LiveKit Cloud or multi-operator testing.
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const vm=require('node:vm');
const test=require('node:test');
function fixture({existingScreens=false,autoplayBlocked=false,missingMicPublication=false,micStartFails=false,micSpecificFails=false}={}){
 const handlers=new Map(),status=[],video=[],removed=[],disconnected=[],speakerEvents=[];
 let roomRef=null;
 const pub={source:'microphone',muted:false,muteCount:0,unmuteCount:0,get isMuted(){return this.muted},track:{applied:[],async applyConstraints(options){this.applied.push({...options})}},async mute(){this.muteCount++;this.muted=true},async unmute(){this.unmuteCount++;this.muted=false}};
 const local={identity:'local',getTrackPublication(source){return source==='microphone'?(missingMicPublication&&!this.micStarted?undefined:pub):this.screenPublication},async setMicrophoneEnabled(_enabled,options){if(micStartFails||micSpecificFails&&options?.deviceId)throw Error('NotFoundError');this.micStarted=true;this.lastMicOptions=options},async setScreenShareEnabled(enabled,options){this.lastCapture=options;this.screenPublication=enabled?{source:'screen_share',track:{mediaStreamTrack:{kind:'video',id:'screen-local'}}}:undefined}};
 const sources={Microphone:'microphone',ScreenShare:'screen_share',ScreenShareAudio:'screen_share_audio'};
 const events={TrackSubscribed:'subscribed',TrackUnsubscribed:'unsubscribed',ParticipantDisconnected:'participantleft',Reconnecting:'reconnecting',SignalReconnecting:'signalreconnecting',Reconnected:'reconnected',Disconnected:'disconnected',LocalTrackUnpublished:'unpublished',TrackSubscriptionFailed:'subscriptionfailed',TrackStreamStateChanged:'streamstate',ConnectionQualityChanged:'quality',AudioPlaybackStatusChanged:'audioplayback',VideoPlaybackStatusChanged:'videoplayback',ActiveSpeakersChanged:'speakerschanged'};
 const track=(kind,id)=>({kind,mediaStreamTrack:{kind,id},attach(el){el.attached=this;return el},detach(el){el.detached=true;return [el]}});
 const screenTrack=track('video','preexisting-screen');
 const existingParticipant={identity:'ana',trackPublications:new Map([['screen',{source:'screen_share',track:screenTrack,isSubscribed:true}]])};
 class MockRoom {
  constructor(){this.localParticipant=local;this.remoteParticipants=new Map(existingScreens?[['ana',existingParticipant]]:[]);this.audioStarts=0;roomRef=this}
  on(name,fn){if(!handlers.has(name))handlers.set(name,[]);handlers.get(name).push(fn);return this}
  emit(name,...args){for(const fn of handlers.get(name)||[])fn(...args)}
  async connect(){this.connected=true}
  async disconnect(){this.connected=false;this.emit('disconnected')}
  async switchActiveDevice(){return true}
  async startAudio(){this.audioStarts++}
  async startVideo(){this.videoStarts=(this.videoStarts||0)+1}
 }
 const audioParent={appendChild(el){this.items.push(el)},items:[]};
 const listeners=new Map();
 const doc={getElementById(){return audioParent},createElement(){return {id:'',muted:false,volume:1,autoplay:false,remove(){this.removed=true},setAttribute(){},async play(){if(autoplayBlocked && !this.unblocked)throw Error('autoplay denied');this.played=true}}},addEventListener(n,cb){listeners.set(n,cb)},removeEventListener(n,cb){if(listeners.get(n)===cb)listeners.delete(n)}};
 const emitterContext={window:{}};
 vm.runInNewContext(fs.readFileSync(path.join(__dirname,'../vendor/eventemitter3-4.0.7.min.js'),'utf8'),emitterContext);
 const context={window:{EventEmitter3:emitterContext.window.EventEmitter3,LivekitClient:{Room:MockRoom,RoomEvent:events,Track:{Source:sources}}},document:doc,MediaStream:class{constructor(tracks){this.tracks=tracks}getVideoTracks(){return this.tracks.filter(t=>t.kind==='video')}},console};
 const source=fs.readFileSync(path.join(__dirname,'../livekit-adapter.js'),'utf8');
 vm.runInNewContext(source,context);
 const adapter=new context.window.ExplicitLiveKitMedia({onVideo:(...args)=>video.push(args),onVideoRemoved:n=>removed.push(n),onStatus:m=>status.push(m),onSpeakers:n=>speakerEvents.push([...n]),onDisconnected:()=>disconnected.push(true),onScreenEnded(){},getVolume:()=>.8,getOutputDevice:()=>'',isDeaf:()=>false});
 return {adapter,video,removed,status,disconnected,speakerEvents,pub,local,audioParent,doc,listeners,track,sources,events,room:()=>roomRef,existingParticipant};
}
const AUTH={url:'wss://media.test',token:'test',can_speak:true};
test('two independent simulated viewers can subscribe to one screen',async()=>{
 const first=fixture(),second=fixture();
 await first.adapter.connect(AUTH,{});await second.adapter.connect({...AUTH,can_speak:false},{});
 const t=first.track('video','ana-screen');const participant={identity:'ana'};
 first.room().emit(first.events.TrackSubscribed,t,{source:'screen_share'},participant);
 second.room().emit(second.events.TrackSubscribed,t,{source:'screen_share'},participant);
 assert.equal(first.video.length,1);assert.equal(second.video.length,1);
 assert.equal(first.video[0][0],'ana');assert.equal(second.video[0][0],'ana');
 await first.adapter.disconnect();await second.adapter.disconnect();
});
test('new viewer receives preexisting published screen after joining',async()=>{
 const f=fixture({existingScreens:true});await f.adapter.connect(AUTH,{});
 assert.equal(f.video.length,1);assert.equal(f.video[0][0],'ana');
 f.room().emit(f.events.TrackSubscribed,f.existingParticipant.trackPublications.get('screen').track,{source:'screen_share'},f.existingParticipant);
 assert.equal(f.video.length,1,'late subscription must not create a duplicate');
 await f.adapter.disconnect();
});
test('reconnection reconciles screen, ignores stale unsubscriptions and cleans participant',async()=>{
 const f=fixture({existingScreens:true});await f.adapter.connect(AUTH,{});
 const old=f.existingParticipant.trackPublications.get('screen').track;
 const fresh=f.track('video','new-screen');f.existingParticipant.trackPublications.set('screen',{source:'screen_share',track:fresh,isSubscribed:true});
 f.room().emit(f.events.Reconnecting);f.room().emit(f.events.Reconnected);
 assert.equal(f.adapter.diagnostics().state,'connected');assert.equal(f.video.length,2);
 f.room().emit(f.events.TrackUnsubscribed,old,{source:'screen_share'},f.existingParticipant);
 assert.equal(f.removed.length,0,'old track must not remove replacement');
 f.room().emit(f.events.ParticipantDisconnected,f.existingParticipant);
 assert.deepEqual(f.removed,['ana']);assert.equal(f.adapter.diagnostics().screenTracks,0);
 await f.adapter.disconnect();assert.equal(f.disconnected.length,0,'manual exit must not be reported as a crash');
});
test('audio track replacement removes stale player; PTT serializes mute/unmute',async()=>{
 const f=fixture();await f.adapter.connect(AUTH,{});
 const a=f.track('audio','mic1'),b=f.track('audio','mic2'),who={identity:'ana'};
 f.room().emit(f.events.TrackSubscribed,a,{source:'microphone'},who);
 f.room().emit(f.events.TrackSubscribed,b,{source:'microphone'},who);
 assert.equal(f.adapter.diagnostics().audioTracks,1);
 assert.equal(f.audioParent.items[0].removed,true);
 f.room().emit(f.events.TrackUnsubscribed,a,{source:'microphone'},who);
 assert.equal(f.adapter.diagnostics().audioTracks,1);
 await f.adapter.setMicActive(false);assert.equal(f.pub.muted,true);
 await f.adapter.setMicActive(true);assert.equal(f.pub.muted,false);
 await f.adapter.disconnect();assert.equal(f.adapter.diagnostics().audioTracks,0);
});
test('subscription errors are countable but no JWT/secret is exposed',async()=>{
 const f=fixture();await f.adapter.connect(AUTH,{});
 f.room().emit(f.events.TrackSubscriptionFailed,'sid',{identity:'ana'},'timeout');
 assert.equal(f.adapter.diagnostics().subscriptionErrors,1);
 assert.match(f.status.join(' '),/Falha ao receber/);
 assert.ok(!JSON.stringify(f.adapter.diagnostics()).includes('test'));
 await f.adapter.disconnect();
});
test('screen sharing FPS is bounded and inactive session cannot start capture',async()=>{
 const f=fixture();await f.adapter.connect(AUTH,{});
 assert.equal((await f.adapter.shareScreen(999)).getVideoTracks().length,1);
 assert.equal(f.local.lastCapture.frameRate,60);
 await f.adapter.stopScreen();await f.adapter.disconnect();
 await assert.rejects(()=>f.adapter.shareScreen(20),/conexão de mídia/);
});
test('missing SDK refuses voice rather than silently downgrading to mesh',()=>{
 const source=fs.readFileSync(path.join(__dirname,'../livekit-adapter.js'),'utf8');
 const context={window:{}};vm.runInNewContext(source,context);
 assert.throws(()=>new context.window.ExplicitLiveKitMedia({}),/SDK LiveKit indisponível/);
});
test('blocked audio offers user gesture recovery and removes listeners on exit',async()=>{
 const f=fixture({autoplayBlocked:true});await f.adapter.connect(AUTH,{});
 const t=f.track('audio','blocked');f.room().emit(f.events.TrackSubscribed,t,{source:'microphone'},{identity:'bia'});
 await new Promise(resolve=>setImmediate(resolve));
 assert.equal(f.listeners.has('pointerdown'),true);
 f.audioParent.items[0].unblocked=true;
 f.listeners.get('pointerdown')();
 await new Promise(resolve=>setImmediate(resolve));
 assert.equal(f.audioParent.items[0].played,true);
 assert.equal(f.listeners.has('pointerdown'),false);
 await f.adapter.disconnect();assert.equal(f.listeners.has('keydown'),false);
});
test('network pause and signal recovery expose readable status, not a false disconnect',async()=>{
 const f=fixture();await f.adapter.connect(AUTH,{});
 f.room().emit(f.events.TrackStreamStateChanged,{source:'screen_share'},'paused');
 f.room().emit(f.events.SignalReconnecting);f.room().emit(f.events.Reconnected);
 assert.match(f.status.join(' '),/pausada/);
 assert.match(f.status.join(' '),/recuperada/);
 assert.equal(f.disconnected.length,0);
 await f.adapter.disconnect();
});

test('joining already muted does not publish microphone and unmuting can publish it',async()=>{
 const f=fixture({missingMicPublication:true});
 await f.adapter.connect(AUTH,{echoCancellation:true},true);
 assert.equal(!!f.local.micStarted,false,'pre-muted participant must not publish audio even briefly');
 await f.adapter.setMicActive(false);
 assert.equal(!!f.local.micStarted,false);
 await f.adapter.setMicActive(true);
 assert.equal(f.local.micStarted,true,'mic is published only when participant explicitly unmutes');
 await f.adapter.disconnect();
});

test('blocked video playback actually starts video after user gesture',async()=>{
 const f=fixture();await f.adapter.connect(AUTH,{});
 f.room().emit(f.events.VideoPlaybackStatusChanged,false);
 assert.equal(f.listeners.has('pointerdown'),true);
 f.listeners.get('pointerdown')();
 await new Promise(resolve=>setImmediate(resolve));
 assert.equal(f.room().videoStarts,1,'room.startVideo() is required to recover blocked video playback');
 assert.equal(f.listeners.has('pointerdown'),false);
 await f.adapter.disconnect();
});
test('support diagnostics are bounded, anonymized and contain state changes',async()=>{
 const f=fixture();await f.adapter.connect({...AUTH,token:'SECRET_JWT_DO_NOT_LEAK'},{});
 for(let i=0;i<100;i++)f.room().emit(f.events.ConnectionQualityChanged,i%2?'good':'poor',f.room().localParticipant);
 f.room().emit(f.events.TrackSubscriptionFailed,'SID_SECRET',{identity:'user_private'},'AUTH_SECRET');
 f.room().emit(f.events.Reconnecting);f.room().emit(f.events.Reconnected);
 const report=f.adapter.supportReport();
 assert.ok(report.events.length<=80);
 assert.equal(report.state,'connected');
 assert.equal(report.subscriptionErrors,1);
 assert.ok(report.events.some(e=>e.event==='reconnecting'));
 assert.ok(report.events.some(e=>e.event==='reconnected'));
 const serialized=JSON.stringify(report);
 for(const secret of ['SECRET_JWT','SID_SECRET','user_private','AUTH_SECRET','wss://media.test'])assert.ok(!serialized.includes(secret),secret+' leaked');
 await f.adapter.disconnect();
});

test('EventEmitter3-backed media diagnostics emit anonymous transitions and screen settings',async()=>{
 const f=fixture();const events=[];
 const unsubscribe=f.adapter.subscribe('media:event',ev=>events.push(ev));
 await f.adapter.connect(AUTH,{});
 await f.adapter.shareScreen(30);
 f.local.screenPublication.track.mediaStreamTrack.getSettings=()=>({width:1920,height:1080,frameRate:24,deviceId:'not-shareable'});
 f.room().emit(f.events.Reconnecting);f.room().emit(f.events.Reconnected);
 const report=f.adapter.supportReport();
 assert.equal(report.appVersion,'18.6');
 assert.deepEqual(JSON.parse(JSON.stringify(report.screenCapture)),{width:1920,height:1080,frameRate:24});
 assert.ok(events.some(ev=>ev.event==='reconnecting'));
 assert.ok(!JSON.stringify(report).includes('deviceId'));
 assert.ok(!JSON.stringify(events).includes('not-shareable'));
 unsubscribe();const count=events.length;f.room().emit(f.events.Reconnecting);assert.equal(events.length,count);
 await f.adapter.disconnect();
});
test('track interruption is reported only for currently displayed video track',async()=>{
 const f=fixture();await f.adapter.connect(AUTH,{});
 const handlers={};const media={kind:'video',addEventListener(name,fn){handlers[name]=fn}};
 const remote={kind:'video',mediaStreamTrack:media,attach(){},detach(){return []}};
 const person={identity:'ana'};
 f.room().emit(f.events.TrackSubscribed,remote,{source:'screen_share'},person);
 handlers.mute();handlers.unmute();handlers.ended();
 assert.ok(f.status.some(text=>text.includes('interrompido')));
 assert.ok(f.status.some(text=>text.includes('retomado')));
 const report=f.adapter.supportReport();
 assert.ok(report.events.some(ev=>ev.event==='screen_track_muted'));
 assert.ok(report.events.some(ev=>ev.event==='screen_track_unmuted'));
 await f.adapter.disconnect();
});

test('mic permission failure keeps the member in the voice room as listener',async()=>{
 const f=fixture({micStartFails:true});await f.adapter.connect(AUTH,{});
 assert.equal(f.adapter.diagnostics().state,'connected');
 assert.match(f.status.join(' '),/Conectado para ouvir/);
 assert.ok(f.room().connected);
 await f.adapter.disconnect();
});
test('reconnect removes stale audio and video that the SFU no longer publishes',async()=>{
 const f=fixture({existingScreens:true});await f.adapter.connect(AUTH,{});
 const who=f.existingParticipant;const a=f.track('audio','audio-1');
 who.trackPublications.set('mic',{source:'microphone',track:a,isSubscribed:true});
 f.room().emit(f.events.TrackSubscribed,a,{source:'microphone'},who);
 assert.equal(f.adapter.diagnostics().audioTracks,1);assert.equal(f.adapter.diagnostics().screenTracks,1);
 who.trackPublications.clear();f.room().emit(f.events.Reconnecting);f.room().emit(f.events.Reconnected);
 assert.equal(f.adapter.diagnostics().audioTracks,0);assert.equal(f.adapter.diagnostics().screenTracks,0);
 assert.deepEqual(f.removed,['ana']);
 await f.adapter.disconnect();
});

test('unplugged selected microphone falls back to default while keeping LiveKit room',async()=>{
 const f=fixture({micSpecificFails:true});
 await f.adapter.connect(AUTH,{deviceId:{exact:'missing'},echoCancellation:true});
 assert.equal(f.adapter.diagnostics().state,'connected');
 assert.equal(f.local.micStarted,true);
 assert.equal(f.local.lastMicOptions.echoCancellation,true);
 assert.equal(f.local.lastMicOptions.deviceId,undefined);
 assert.match(f.status.join(' '),/dispositivo padrão/);
 await f.adapter.disconnect();
});

test('individual audio volume applies only to the selected participant and persists through global sync',async()=>{
 const f=fixture();await f.adapter.connect(AUTH,{});
 let factor=.4;f.adapter.callbacks.getVolumeForParticipant=(identity)=>identity==='ana'?factor:1;
 const a=f.track('audio','a'), b=f.track('audio','b');
 f.room().emit(f.events.TrackSubscribed,a,{source:'microphone'},{identity:'ana'});
 f.room().emit(f.events.TrackSubscribed,b,{source:'microphone'},{identity:'bia'});
 assert.ok(Math.abs(f.audioParent.items[0].volume-.32)<1e-8);
 assert.equal(f.audioParent.items[1].volume,.8);
 factor=.5;f.adapter.setParticipantVolume('ana');
 assert.equal(f.audioParent.items[0].volume,.4);
 assert.equal(f.audioParent.items[1].volume,.8);
 f.adapter.syncAudio(false,.6,'');
 assert.equal(f.audioParent.items[0].volume,.3);
 assert.equal(f.audioParent.items[1].volume,.6);
 await f.adapter.disconnect();
});

test('audio profile applies to an active LiveKit mic without republishing, unmuting or restarting',async()=>{
 const f=fixture();await f.adapter.connect(AUTH,{autoGainControl:true});
 const callsBefore=f.local.lastMicOptions;
 await f.adapter.updateInputProfile({echoCancellation:true,noiseSuppression:true,autoGainControl:false,voiceIsolation:true});
 assert.equal(f.pub.track.applied.length,1);
 assert.equal(f.pub.track.applied[0].autoGainControl,false);
 assert.equal(f.pub.track.applied[0].voiceIsolation,true);
 assert.equal(f.local.lastMicOptions,callsBefore,'no microphone republish on profile change');
 assert.equal(f.pub.isMuted,false);
 await f.adapter.setMicActive(false);
 await f.adapter.updateInputProfile({echoCancellation:false,noiseSuppression:false,autoGainControl:false});
 assert.equal(f.pub.isMuted,true,'updating audio must not unmute participants');
 await f.adapter.disconnect();
});
test('voice polling avoids redundant LiveKit mute/unmute commands',async()=>{
 const f=fixture();await f.adapter.connect(AUTH,{});
 await f.adapter.setMicActive(true);await f.adapter.setMicActive(true);
 assert.equal(f.pub.unmuteCount,0);
 await f.adapter.setMicActive(false);await f.adapter.setMicActive(false);
 assert.equal(f.pub.muteCount,1);
 await f.adapter.disconnect();
});
test('repeated voice polls do not reselect a working speaker device',async()=>{
 const f=fixture();await f.adapter.connect(AUTH,{});
 let count=0;
 f.adapter.audioNodes.set('ana\u0000microphone',{element:{muted:false,volume:1,sinkId:'default',setSinkId(){count++},remove(){}},track:{}});
 for(let i=0;i<10;i++)f.adapter.syncAudio(false,1,'default');
 assert.equal(count,0);
 await f.adapter.disconnect();
});

test('active speakers distinguish speaking identities, ignore muted and clear after leaving',async()=>{
 const f=fixture();await f.adapter.connect(AUTH,{});
 f.room().emit(f.events.ActiveSpeakersChanged,[{identity:'ana',isMicrophoneEnabled:true},{identity:'bia',isMicrophoneEnabled:false},{identity:'local',isMicrophoneEnabled:true}]);
 assert.deepEqual(f.speakerEvents.at(-1),['ana','local']);
 f.room().emit(f.events.ActiveSpeakersChanged,[]);
 assert.deepEqual(f.speakerEvents.at(-1),[]);
 await f.adapter.disconnect();assert.deepEqual(f.speakerEvents.at(-1),[]);
});

test('preferred screen FPS is applied only to existing screen publication and constrained to 30–60',async()=>{
 const f=fixture({existingScreens:true});await f.adapter.connect(AUTH,{});
 const screen=f.existingParticipant.trackPublications.get('screen');
 let chosen=0;screen.setVideoFPS=n=>chosen=n;
 f.existingParticipant.getTrackPublication=source=>source==='screen_share'?screen:undefined;
 assert.equal(f.adapter.setRemoteScreenFPS('ana',999),true);assert.equal(chosen,60);
 assert.equal(f.adapter.setRemoteScreenFPS('ana',1),true);assert.equal(chosen,30);
 assert.equal(f.adapter.setRemoteScreenFPS('unknown',45),false);
 await f.adapter.disconnect();
});
