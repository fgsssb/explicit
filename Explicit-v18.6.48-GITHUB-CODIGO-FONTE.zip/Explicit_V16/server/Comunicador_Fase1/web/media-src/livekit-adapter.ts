/* Explicit media adapter — independently implemented with the public LiveKit SDK.
   No code/binaries from Discord. API secrets are only used by the Go backend. */
interface LKTrack { kind: string; mediaStreamTrack: MediaStreamTrack; attach(element: HTMLMediaElement): HTMLMediaElement; detach(element?: HTMLMediaElement): HTMLMediaElement[]; }
interface LKPublication { source: string; kind?: string; isSubscribed?: boolean; track?: LKTrack; mute(): Promise<void>; unmute(): Promise<void>; setVideoFPS?(fps:number):void; }
interface LKParticipant {
 identity: string; trackPublications?: Map<string,LKPublication>;isMicrophoneEnabled?:boolean;
 getTrackPublication(source: string): LKPublication | undefined;
 setMicrophoneEnabled(enabled: boolean, options?: object): Promise<unknown>;
 setScreenShareEnabled(enabled: boolean, options?: object): Promise<unknown>;
}
interface LKRoom {
 on(name: string, callback: (...args: any[]) => void): LKRoom;
 connect(url: string, token: string): Promise<void>;
 disconnect(): Promise<void>;
 startAudio?(): Promise<void>;
 startVideo?(): Promise<void>;
 localParticipant: LKParticipant;
 remoteParticipants: Map<string,LKParticipant>;activeSpeakers?:LKParticipant[];
 switchActiveDevice(kind: string, id: string): Promise<boolean>;
}
interface LKSDK {
 Room: new (options: object) => LKRoom;
 RoomEvent: Record<string,string>;
 Track: { Source: { Microphone:string; ScreenShare:string; ScreenShareAudio:string } };
}
interface AuthData { url:string; token:string; can_speak:boolean; can_screen:boolean; }
interface Callbacks {
 onVideo(name:string, track:MediaStreamTrack, stream:MediaStream):void;
 onVideoRemoved(name:string):void;
 onStatus(text:string):void;
 onSpeakers?(participants:string[]):void;
 onDisconnected():void;
 onScreenEnded():void;
 getVolume():number;
 getVolumeForParticipant?(identity:string):number;
 getScreenVolumeForParticipant?(identity:string):number;
 getOutputDevice():string;
 isDeaf():boolean;
}
class ExplicitLiveKitMedia {
 private micOptions:object={};private canSpeak=false;
 private room: LKRoom | null = null;
 private sdk: LKSDK;
 private stopping = false;
 private micQueue: Promise<void> = Promise.resolve();
 private audioNodes: Map<string,{track:LKTrack,element:HTMLAudioElement}> = new Map();
 private videoNodes: Map<string,LKTrack> = new Map();
 private callbacks: Callbacks;
 private audioGesturePending = false;
 private mediaState = 'offline';
 private subscriptionErrors = 0;
 private lastNetworkWarning = '';
 // Bounded, privacy-preserving, in-memory support log. Never store tokens, URLs, names, track IDs or message content.
 private supportEvents:{elapsedMs:number;event:string}[]=[];
 private supportStarted=Date.now();
 private lastQuality='unknown';
 private supportBus:{emit:(name:string,event:object)=>void;on:(name:string,fn:(event:object)=>void)=>void;off:(name:string,fn:(event:object)=>void)=>void}|null=null;
 private record(event:string):void {
  this.supportEvents.push({elapsedMs:Math.max(0,Date.now()-this.supportStarted),event});
  if(this.supportEvents.length>80)this.supportEvents.shift();
  this.supportBus?.emit('media:event',{elapsedMs:Math.max(0,Date.now()-this.supportStarted),event});
 }
 supportReport():object {
  return {schema:'explicit-media-diagnostics-v1',appVersion:'18.6',
   ...this.diagnostics(),connectionQuality:this.lastQuality,screenCapture:this.screenCaptureSettings(),events:this.supportEvents.map(e=>({...e}))};
 }
 // Report only technical capture properties: no track identifiers, device labels or participant names.
 screenCaptureSettings():{width:number,height:number,frameRate:number}|null {
  const publication=this.room?.localParticipant.getTrackPublication(this.sdk.Track.Source.ScreenShare);
  const settings=publication?.track?.mediaStreamTrack?.getSettings?.();
  if(!settings)return null;
  return {width:Math.max(0,Math.round(Number(settings.width)||0)),height:Math.max(0,Math.round(Number(settings.height)||0)),frameRate:Math.max(0,Math.round(Number(settings.frameRate)||0))};
 }
 subscribe(eventName:string,listener:(event:object)=>void):()=>void {
  if(!this.supportBus)return ()=>{};
  this.supportBus.on(eventName,listener);
  return ()=>this.supportBus?.off(eventName,listener);
 }
 constructor(callbacks:Callbacks) {
  const candidate=(window as any).LivekitClient as LKSDK | undefined;
  if(!candidate?.Room || !candidate?.RoomEvent || !candidate?.Track?.Source)throw Error('SDK LiveKit indisponível. Execute 03_COMPILAR_CLIENTE.cmd antes do teste.');
  this.sdk=candidate;this.callbacks=callbacks;
  const Emitter=(window as any).EventEmitter3;if(typeof Emitter==='function')this.supportBus=new Emitter();
 }
 private audioKey(name:string,source:string):string{return name+'\u0000'+source;}
 private audioVolumeFor(identity:string):number {
  const master=Math.max(0,Math.min(1,Number(this.callbacks.getVolume())||0));
  const factor=this.callbacks.getVolumeForParticipant?.(identity);
  return Math.min(1,master*(Number.isFinite(factor)?Math.max(0,Math.min(1,factor!)):1));
 }
 setParticipantVolume(identity:string):void{
  for(const [key,node] of this.audioNodes)if(key.startsWith(identity+'\u0000'))node.element.volume=this.audioVolumeFor(identity)*(key===this.audioKey(identity,this.sdk.Track.Source.ScreenShareAudio)?Math.max(0,Math.min(1,Number(this.callbacks.getScreenVolumeForParticipant?.(identity)??1))):1);
 }
 private addAudio(track:LKTrack, pub:LKPublication, participant:LKParticipant):void {
  const key=this.audioKey(participant.identity,pub.source||'microphone');
  if(this.audioNodes.get(key)?.track===track)return;
  this.removeAudio(key);
  const element=document.createElement('audio');element.autoplay=true;element.setAttribute('playsinline','');
  element.id='voice-'+participant.identity+(pub.source==='microphone'?'':'-'+pub.source);
  element.muted=this.callbacks.isDeaf();
  element.volume=this.audioVolumeFor(participant.identity)*(pub.source===this.sdk.Track.Source.ScreenShareAudio?Math.max(0,Math.min(1,Number(this.callbacks.getScreenVolumeForParticipant?.(participant.identity)??1))):1);
  document.getElementById('voiceAudios')?.appendChild(element);
  try {track.attach(element)}catch(error){element.remove();this.callbacks.onStatus('Não foi possível reproduzir uma faixa de áudio');return}
  this.audioNodes.set(key,{track,element});
  this.record('audio_subscribed');
  element.play().catch(()=>this.requestAudioGesture());
  const output=this.callbacks.getOutputDevice();
  if(output&&'setSinkId' in element)(element as any).setSinkId(output).catch((error:Error)=>console.warn('[Explicit media] Saída de áudio:',error.message));
 }
 private addVideo(track:LKTrack, participant:LKParticipant):void {
  if(this.videoNodes.get(participant.identity)===track)return;
  this.record('video_subscribed');
  this.videoNodes.set(participant.identity,track);
  // MediaStreamTrack can report a browser/network-level pause without LiveKit unsubscribing it.
  // Verify current track identity so an old replaced track cannot affect the new viewer.
  const source=track.mediaStreamTrack, owner=participant.identity;
  if(typeof source?.addEventListener==='function'){
   source.addEventListener('mute',()=>{if(this.videoNodes.get(owner)===track){this.record('screen_track_muted');this.callbacks.onStatus('Vídeo remoto temporariamente interrompido')}});
   source.addEventListener('unmute',()=>{if(this.videoNodes.get(owner)===track){this.record('screen_track_unmuted');this.callbacks.onStatus('Vídeo remoto retomado')}});
   source.addEventListener('ended',()=>{if(this.videoNodes.get(owner)===track)this.record('screen_track_ended')});
  }
  this.callbacks.onVideo(participant.identity,source,new MediaStream([source]));
 }
 private removeAudio(key:string, expected?:LKTrack):void {
  const node=this.audioNodes.get(key);if(!node||(expected&&node.track!==expected))return;
  try{node.track.detach(node.element)}catch{}
  node.element.remove();this.audioNodes.delete(key);this.record('audio_removed');
 }
 private removeParticipant(name:string):void {
  for(const key of [...this.audioNodes.keys()])if(key.startsWith(name+'\u0000'))this.removeAudio(key);
  if(this.videoNodes.delete(name)){this.callbacks.onVideoRemoved(name);this.record('video_removed');}
 }
 private restoreSubscribedTracks():void {
  // Rebuild actual current subscriptions; never keep ghosts after reconnect.
  const room=this.room;if(!room)return;
  const expectedAudio=new Map<string,LKTrack>(),expectedVideo=new Map<string,LKTrack>();
  for(const participant of room.remoteParticipants.values()){
   for(const publication of participant.trackPublications?.values()||[]){
    if(!publication.track||publication.isSubscribed===false)continue;
    if(publication.track.kind==='audio'){
     const key=this.audioKey(participant.identity,publication.source||'microphone');
     expectedAudio.set(key,publication.track);this.addAudio(publication.track,publication,participant);
    }else if(publication.source===this.sdk.Track.Source.ScreenShare){
     expectedVideo.set(participant.identity,publication.track);this.addVideo(publication.track,participant);
    }
   }
  }
  for(const [key,node] of this.audioNodes){if(expectedAudio.get(key)!==node.track)this.removeAudio(key,node.track)}
  for(const [name,track] of this.videoNodes){
   if(expectedVideo.get(name)!==track){this.videoNodes.delete(name);this.callbacks.onVideoRemoved(name);this.record('stale_screen_removed')}
  }
 }
 private async resumeAudioAfterGesture():Promise<void> {
  this.audioGesturePending=false;
  const room=this.room;
  if(!room||this.stopping)return;
  try{
   // Invoke BOTH unlock calls before the first await, while the browser still
   // considers this a user activation. A blocked audio track must not prevent video.
   const attempts:Promise<unknown>[]=[];
   if(room.startAudio)attempts.push(room.startAudio());
   if(room.startVideo)attempts.push(room.startVideo());
   attempts.push(Promise.all([...this.audioNodes.values()].filter(node=>!node.element.muted).map(node=>node.element.play())));
   const results=await Promise.allSettled(attempts);
   if(results.some(result=>result.status==='rejected'))throw Error('playback still restricted');
   this.record('playback_resumed_by_gesture');
  }catch{this.requestAudioGesture();return}
  this.callbacks.onStatus('Reprodução de áudio liberada');
 }
 private onUserGesture = ():void => {document.removeEventListener('pointerdown',this.onUserGesture);document.removeEventListener('keydown',this.onUserGesture);void this.resumeAudioAfterGesture()};
 private requestAudioGesture():void {
  if(this.stopping||this.audioGesturePending)return;
  this.audioGesturePending=true;
  this.record('playback_gesture_required');
  this.callbacks.onStatus('Clique na janela para liberar áudio e vídeo da chamada');
  document.addEventListener('pointerdown',this.onUserGesture);
  document.addEventListener('keydown',this.onUserGesture);
 }
 async connect(auth:AuthData, micOptions:object, startMuted:boolean=false):Promise<void> {
  if(!/^wss:\/\/[^/\s]+/.test(auth.url)||!auth.token)throw Error('Credenciais de mídia inválidas');
  if(this.room)throw Error('Já existe uma sessão de mídia ativa');
  this.micOptions=micOptions;this.canSpeak=!!auth.can_speak;
  this.stopping=false;this.mediaState='connecting';this.subscriptionErrors=0;this.lastNetworkWarning='';
  this.supportStarted=Date.now();this.supportEvents=[];this.lastQuality='unknown';this.record('connect_started');
  const sdk=this.sdk,cb=this.callbacks;
  const room=new sdk.Room({adaptiveStream:true,dynacast:true,stopLocalTrackOnUnpublish:true});
  this.room=room;
  room.on(sdk.RoomEvent.TrackSubscribed,(track:LKTrack,pub:LKPublication,participant:LKParticipant)=>{
   if(this.stopping||this.room!==room)return;
   this.record(track.kind==='audio'?'track_subscribed_audio':'track_subscribed_video');
   if(track.kind==='audio')this.addAudio(track,pub,participant);
   else if(pub.source===sdk.Track.Source.ScreenShare)this.addVideo(track,participant);
  });
  room.on(sdk.RoomEvent.TrackUnsubscribed,(track:LKTrack,pub:LKPublication,participant:LKParticipant)=>{
   if(this.room!==room)return;
   this.record(track.kind==='audio'?'track_unsubscribed_audio':'track_unsubscribed_video');
   if(track.kind==='audio')this.removeAudio(this.audioKey(participant.identity,pub.source||'microphone'),track);
   else if(pub.source===sdk.Track.Source.ScreenShare&&this.videoNodes.get(participant.identity)===track){this.videoNodes.delete(participant.identity);cb.onVideoRemoved(participant.identity)}
  });
  if(sdk.RoomEvent.ActiveSpeakersChanged)room.on(sdk.RoomEvent.ActiveSpeakersChanged,(speakers:LKParticipant[])=>{if(this.room===room&&!this.stopping)cb.onSpeakers?.((speakers||[]).filter(p=>p?.identity&&p.isMicrophoneEnabled!==false).map(p=>p.identity))});
  room.on(sdk.RoomEvent.ParticipantDisconnected,(participant:LKParticipant)=>{if(this.room===room){this.record('participant_disconnected');this.removeParticipant(participant.identity);cb.onSpeakers?.(room.activeSpeakers?.map(p=>p.identity)||[])}});
  room.on(sdk.RoomEvent.Reconnecting,()=>{if(!this.stopping&&this.room===room){this.mediaState='reconnecting';this.record('reconnecting');cb.onStatus('Conexão de mídia interrompida: LiveKit tentando recuperar…')}});
  if(sdk.RoomEvent.SignalReconnecting)room.on(sdk.RoomEvent.SignalReconnecting,()=>{if(!this.stopping&&this.room===room)cb.onStatus('Reconectando sinalização de mídia…')});
  room.on(sdk.RoomEvent.Reconnected,()=>{if(!this.stopping&&this.room===room){this.mediaState='connected';this.record('reconnected');this.restoreSubscribedTracks();cb.onStatus('Conexão de mídia recuperada')}});
  room.on(sdk.RoomEvent.Disconnected,()=>{if(this.room!==room)return;this.mediaState='disconnected';this.record('disconnected');if(!this.stopping)cb.onDisconnected()});
  room.on(sdk.RoomEvent.LocalTrackUnpublished,(publication:LKPublication)=>{if(!this.stopping&&publication.source===sdk.Track.Source.ScreenShare)cb.onScreenEnded()});
  if(sdk.RoomEvent.TrackSubscriptionFailed)room.on(sdk.RoomEvent.TrackSubscriptionFailed,(_sid:string,participant:LKParticipant,reason:unknown)=>{
   if(this.stopping)return;this.subscriptionErrors++;this.record('subscription_failed');
   // Do not print identities, token-bearing errors or server URLs to console logs.
   console.warn('[Explicit media] Inscrição em mídia falhou');
   cb.onStatus('Falha ao receber mídia de outro participante (verifique sua rede)');
  });
  if(sdk.RoomEvent.TrackStreamStateChanged)room.on(sdk.RoomEvent.TrackStreamStateChanged,(publication:LKPublication,state:string)=>{
   if(this.stopping||publication.source!==sdk.Track.Source.ScreenShare)return;
   if(String(state).toLowerCase().includes('paused')){this.record('screen_stream_paused');cb.onStatus('Transmissão pausada pelo servidor devido à rede')}
   else if(String(state).toLowerCase().includes('active')){this.record('screen_stream_active');cb.onStatus('Transmissão de tela retomada')};
  });
  if(sdk.RoomEvent.ConnectionQualityChanged)room.on(sdk.RoomEvent.ConnectionQualityChanged,(quality:string,participant:LKParticipant)=>{
   if(this.stopping||participant!==room.localParticipant)return;
   const q=String(quality).toLowerCase();
   if(['excellent','good','poor','lost'].includes(q)&&q!==this.lastQuality){this.lastQuality=q;this.record('quality_'+q)}
   if((q==='poor'||q==='lost')&&this.lastNetworkWarning!==q){this.lastNetworkWarning=q;cb.onStatus('Sua conexão de mídia está instável')}
   else if(q==='excellent'||q==='good')this.lastNetworkWarning='';
  });
  if(sdk.RoomEvent.AudioPlaybackStatusChanged)room.on(sdk.RoomEvent.AudioPlaybackStatusChanged,(canPlay:boolean)=>{if(!canPlay)this.requestAudioGesture()});
  if(sdk.RoomEvent.VideoPlaybackStatusChanged)room.on(sdk.RoomEvent.VideoPlaybackStatusChanged,(canPlay:boolean)=>{if(!canPlay)this.requestAudioGesture()});
  try {
   await room.connect(auth.url,auth.token);
   this.mediaState='connected';this.record('connected');this.restoreSubscribedTracks();
  } catch(error) {this.record('connect_failed');this.stopping=true;this.mediaState='failed';await room.disconnect().catch(()=>{});this.room=null;throw error}
  if(auth.can_speak&&!startMuted){
   try{await this.enableMicrophone()}
   catch{this.record('microphone_unavailable');cb.onStatus('Conectado para ouvir. Microfone indisponível; confira a permissão e tente ativá-lo novamente.');}
  }
 }
 setRemoteScreenFPS(identity:string,fps:number):boolean{
  const pub=this.room?.remoteParticipants.get(identity)?.getTrackPublication(this.sdk.Track.Source.ScreenShare);
  if(!pub||typeof pub.setVideoFPS!=='function')return false;
  pub.setVideoFPS(Math.max(30,Math.min(60,Math.round(Number(fps)||60))));return true;
 }
 setScreenAudioVolume(identity:string,factor:number):void{
  const safe=Math.max(0,Math.min(1,Number(factor)||0));
  for(const [key,node] of this.audioNodes)if(key===this.audioKey(identity,this.sdk.Track.Source.ScreenShareAudio))node.element.volume=Math.min(1,this.audioVolumeFor(identity)*safe);
 }
 remoteCount():number {return this.room?.remoteParticipants.size||0}
 diagnostics():{state:string,remoteParticipants:number,audioTracks:number,screenTracks:number,subscriptionErrors:number}{
  return {state:this.mediaState,remoteParticipants:this.remoteCount(),audioTracks:this.audioNodes.size,screenTracks:this.videoNodes.size,subscriptionErrors:this.subscriptionErrors};
 }
 setMicActive(enabled:boolean):Promise<void> {
  // Keep PTT events ordered, including when the user presses/releases very quickly.
  this.micQueue=this.micQueue.catch(()=>{}).then(async()=>{
   const pub=this.room?.localParticipant.getTrackPublication(this.sdk.Track.Source.Microphone);
   if(!pub){if(enabled&&this.room&&this.canSpeak)await this.enableMicrophone();return;}
   if(enabled)await pub.unmute();else await pub.mute();
  });return this.micQueue;
 }
 // When a previously selected microphone is unplugged, first try the default
 // device before sending the caller into a needless leave/rejoin loop.
 private async enableMicrophone():Promise<void>{
  const local=this.room?.localParticipant;if(!local||!this.canSpeak)return;
  try{await local.setMicrophoneEnabled(true,this.micOptions)}
  catch(error){
   const options=this.micOptions as Record<string,unknown>;
   if(!options.deviceId)throw error;
   const fallback={...options};delete fallback.deviceId;
   await local.setMicrophoneEnabled(true,fallback);
   this.micOptions=fallback;this.record('microphone_default_fallback');
   this.callbacks.onStatus('Microfone anterior indisponível; usando o dispositivo padrão.');
  }
 }
 async setInputDevice(id:string):Promise<void>{
  if(!this.room)return;
  try{await this.room.switchActiveDevice('audioinput',id||'default')}
  catch(error){
   if(!id||id==='default')throw error;
   await this.room.switchActiveDevice('audioinput','default');
   this.record('microphone_default_fallback');
   this.callbacks.onStatus('O microfone escolhido foi desconectado. Voltamos ao dispositivo padrão.');
  }
 }
 async shareScreen(fps:number):Promise<MediaStream> {
  const local=this.room?.localParticipant;if(!local||this.mediaState!=='connected')throw Error('Sem conexão de mídia estável');
  const safeFPS=Math.min(60,Math.max(30,Math.round(Number(fps)||30)));
  this.record('screen_publish_started');
  await local.setScreenShareEnabled(true,{frameRate:safeFPS,audio:false});
  const pub=local.getTrackPublication(this.sdk.Track.Source.ScreenShare);
  if(!pub?.track?.mediaStreamTrack){await local.setScreenShareEnabled(false).catch(()=>{});throw Error('LiveKit não publicou a tela')}
  this.record('screen_published');return new MediaStream([pub.track.mediaStreamTrack]);
 }
 async stopScreen():Promise<void>{if(this.room){await this.room.localParticipant.setScreenShareEnabled(false);this.record('screen_stopped')}}
 syncAudio(deaf:boolean,volume:number,outputId:string):void{
  for(const [key,node] of this.audioNodes){
   const factor=this.callbacks.getVolumeForParticipant?.(key.split('\u0000')[0]);
   node.element.muted=deaf;node.element.volume=Math.min(1,Math.max(0,volume)*(Number.isFinite(factor)?Math.max(0,Math.min(1,factor!)):1)*(key.endsWith("\u0000"+this.sdk.Track.Source.ScreenShareAudio)?Math.max(0,Math.min(1,Number(this.callbacks.getScreenVolumeForParticipant?.(key.split("\u0000")[0])??1))):1));
   if(outputId&&'setSinkId' in node.element)(node.element as any).setSinkId(outputId).catch((error:Error)=>console.warn('[Explicit media] Saída de áudio:',error.message));
  }
 }
 async disconnect():Promise<void>{
  this.stopping=true;this.mediaState='stopped';this.record('manual_disconnect');
  document.removeEventListener('pointerdown',this.onUserGesture);document.removeEventListener('keydown',this.onUserGesture);this.audioGesturePending=false;
  for(const key of [...this.audioNodes.keys()])this.removeAudio(key);
  for(const name of this.videoNodes.keys())this.callbacks.onVideoRemoved(name);
  this.videoNodes.clear();this.callbacks.onSpeakers?.([]);const room=this.room;this.room=null;if(room)await room.disconnect().catch(()=>{});
 }
}
(window as any).ExplicitLiveKitMedia=ExplicitLiveKitMedia;
