const assert=require('node:assert/strict');
const test=require('node:test');
const vm=require('node:vm');
const fs=require('node:fs');
const path=require('node:path');
function factory(fetchFn){
 const ctx={window:{crypto:{randomUUID:()=> '11111111-1111-4111-8111-000000000001'}},JSON,Promise,Uint8Array,Error,Set};
 vm.runInNewContext(fs.readFileSync(path.resolve(__dirname,'../reliable-chat.js'),'utf8'),ctx);
 return new ctx.window.ExplicitReliableChat({fetchFn,token:()=> 'secret-token',sleep:async()=>{}});
}
test('retry after a dropped response uses the exact same persisted nonce',async()=>{
 const attempts=[];let first=true;
 const chat=factory(async(url,init)=>{
  const sent=JSON.parse(init.body);attempts.push(sent);
  assert.equal(url,'/api/channel-messages?community=x&channel=geral');
  if(first){first=false;throw Error('network disconnected after server saved');}
  return {ok:true,json:async()=>({id:'server-id',text:sent.text,client_id:sent.client_id})};
 });
 const response=await chat.send('channel-messages?community=x&channel=geral','olá');
 assert.equal(response.id,'server-id');assert.equal(attempts.length,2);
 assert.equal(attempts[0].client_id,attempts[1].client_id);
 assert.equal(attempts[0].text,'olá');
});
test('invalid permission does not retry even once',async()=>{
 let count=0;const chat=factory(async()=>{count++;return {ok:false,status:403,text:async()=>'{"error":"forbidden"}'};});
 await assert.rejects(()=>chat.send('messages','no'),/forbidden/);assert.equal(count,1);
});
test('transient overload retries only three times then reports ambiguity',async()=>{
 let count=0;const chat=factory(async()=>{count++;return {ok:false,status:503,text:async()=>'{"error":"overload"}'};});
 await assert.rejects(()=>chat.send('messages','no'),/não confirmado/);assert.equal(count,3);
});
test('unauthenticated send is rejected before any transport',async()=>{
 const chat=factory(()=>{throw Error('should not request')});chat.token=()=>'';
 await assert.rejects(()=>chat.send('messages','no'),/Sessão encerrada/);
});
