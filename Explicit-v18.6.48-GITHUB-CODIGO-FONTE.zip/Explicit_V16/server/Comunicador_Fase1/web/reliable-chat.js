/* Explicit reliability v18.6: one stable request ID across network retries.
 * No third-party network requests and no persistent plaintext message queue.
 */
(function(root){
 'use strict';
 const RETRYABLE=new Set([408,425,429,502,503,504]);
 function id(cryptoObject){
  if(cryptoObject?.randomUUID)return cryptoObject.randomUUID().toLowerCase();
  const b=new Uint8Array(16);
  if(!cryptoObject?.getRandomValues)throw Error('Gerador seguro de identificadores indisponível');
  cryptoObject.getRandomValues(b);
  return Array.from(b,x=>x.toString(16).padStart(2,'0')).join('');
 }
 class ReliableChat {
  constructor({fetchFn,token,cryptoObject,sleep}={}){
   this.fetchFn=fetchFn||((...args)=>fetch(...args));
   this.token=token||(()=>null);
   this.cryptoObject=cryptoObject||root.crypto;
   this.sleep=sleep||((ms)=>new Promise(resolve=>setTimeout(resolve,ms)));
  }
  async send(path,text,options={}) {
   const client_id=options.clientID||id(this.cryptoObject);
   const token=this.token();if(!token)throw Error('Sessão encerrada');
   const payload=JSON.stringify({text,client_id});
   let failure;
   const maxAttempts=/^\/ban(?:\s|$)/i.test(text)?1:3;
   for(let attempt=0;attempt<maxAttempts;attempt++) {
    try{
     const response=await this.fetchFn('/api/'+path,{method:'POST',headers:{'Content-Type':'application/json',Authorization:'Bearer '+token},body:payload});
     if(!response.ok){
      const raw=await response.text();let data;try{data=JSON.parse(raw)}catch{}
      const message=(data?.error||raw||'Falha HTTP '+response.status).slice(0,180);
      const error=new Error(message);error.status=response.status;
      if(!RETRYABLE.has(response.status))throw error;
      failure=error;
     } else return await response.json();
    } catch(error){
     if(error?.status && !RETRYABLE.has(error.status))throw error;
     failure=error;
    }
    if(attempt<maxAttempts-1)await this.sleep((attempt+1)*450);
   }
   throw new Error('Envio não confirmado. Verifique o canal antes de tentar de novo. '+(failure?.message||''));
  }
 }
 root.ExplicitReliableChat=ReliableChat;
})(typeof window!=='undefined'?window:globalThis);
