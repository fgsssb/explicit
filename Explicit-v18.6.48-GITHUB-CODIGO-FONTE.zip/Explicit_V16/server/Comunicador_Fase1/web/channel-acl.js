/* Explicit channel/category permissions — tri-state editor. Existing features only. */
(()=>{
 'use strict';
 const spec={
 text:[['VIEW_CHANNEL','Ver canal','Define quem pode visualizar o canal.'],['SEND_MESSAGES','Enviar mensagens','Permite escrever no canal.'],['ATTACH_FILES','Anexar arquivos','Permite enviar imagens e arquivos.'],['USE_STICKERS','Enviar figurinhas próprias','O usuário ainda precisa ser Staff ou Beta para ter acesso ao recurso.'],['EDIT_OWN_MESSAGES','Editar próprias mensagens','Permite editar mensagens enviadas pelo próprio usuário.'],['DELETE_OWN_MESSAGES','Excluir próprias mensagens','Permite excluir mensagens próprias.'],['EDIT_ANY_MESSAGES','Editar mensagens','Permite editar mensagens de outros usuários.'],['DELETE_ANY_MESSAGES','Excluir mensagens','Permite remover mensagens de outros usuários.'],['CREATE_INVITES','Criar convite','Permite criar convites para a comunidade a partir deste canal.'],['PIN_MESSAGES','Fixar mensagens','Permite fixar e desafixar mensagens.']],
 voice:[['VIEW_CHANNEL','Ver canal','Define quem pode visualizar o canal.'],['CONNECT_VOICE','Conectar','Permite entrar no canal de voz.'],['SPEAK','Falar','Permite transmitir áudio.'],['SCREEN_SHARE','Compartilhar tela','Permite publicar a transmissão de tela.'],['USE_PTT','Usar push-to-talk','Permite utilizar apertar para falar.'],['MUTE_MEMBERS','Silenciar membros','Permissão de moderação de voz.'],['DEAFEN_MEMBERS','Desativar áudio de membros','Permissão de moderação de voz.'],['MOVE_MEMBERS','Mover membros','Permite mover pessoas entre canais.'],['DISCONNECT_VOICE','Desconectar membros','Permite desconectar outras pessoas.'],['POKE_MEMBERS','Enviar poke','Permite enviar um alerta sonoro a participantes do mesmo canal.'],['CREATE_INVITES','Criar convite','Permite criar convites para a comunidade a partir deste canal.']]
 };
 const E=(tag,cls,text)=>{const el=document.createElement(tag);if(cls)el.className=cls;if(text!==undefined)el.textContent=text;return el};
 const notice=(message,error=false)=>{if(typeof nexoToast==='function')nexoToast(message,error?'error':undefined)};
 const ownCommunity=()=>typeof communities==='undefined'?null:communities.find(c=>c.id===activeCommunity);
 const canManage=()=>!!(adminState?.permissions?.includes('MANAGE_CHANNELS')||adminState?.permissions?.includes('ADMINISTRATOR'));
 const safe=async(action,payload)=>api('channel-permissions','POST',{community:activeCommunity,action,...payload});
 async function fetchACL(){return api('channel-permissions?community='+encodeURIComponent(activeCommunity))}
 const state=(obj,id,p)=>obj?.[id]?.[p]===true?'allow':obj?.[id]?.[p]===false?'deny':'inherit';
 const titleRole=(r)=>r.id==='everyone'?'@everyone':r.name;
 // One source of truth for permissions: used both in creation and in channel settings.
 function buildPermissionEditor({roles=[],members=[],kind='text',rolePermissions={},memberPermissions={}}={}){
  const host=E('div','explicit-acl-editor'),intro=E('p','explicit-acl-hint','Escolha @everyone, um cargo ou usuário. Em cada opção use Negar, Herdar ou Permitir.');host.append(intro);
  const choose=E('select','explicit-acl-picker');choose.setAttribute('aria-label','Cargo ou membro');
  for(const item of [{value:'role:everyone',label:'@everyone'},...roles.filter(x=>x.id!=='everyone').map(x=>({value:'role:'+x.id,label:'Cargo: '+x.name})),...members.slice().sort().map(x=>({value:'member:'+x,label:'Usuário: @'+x}))]){const opt=E('option','',item.label);opt.value=item.value;choose.append(opt)}
  const selectionBar=E('div','explicit-acl-selection');selectionBar.append(E('span','','Cargo / membro'),choose);host.append(selectionBar);
  const rows=E('div','explicit-acl-rows');host.append(rows);
  let selectedType='role',selected='everyone',currentKind=kind;
  const source=()=>selectedType==='role'?rolePermissions:memberPermissions;
  const perms=()=>currentKind==='category'?[...spec.text,...spec.voice.filter(x=>!spec.text.some(y=>y[0]===x[0]))]:spec[currentKind]||spec.text;
  function render(){rows.replaceChildren();for(const [key,label,description] of perms()){
   const row=E('div','explicit-acl-row'),copy=E('div','explicit-acl-copy'),options=E('div','explicit-acl-switch');copy.append(E('strong','',label),E('small','',description));options.setAttribute('role','group');options.setAttribute('aria-label',label);
   for(const [val,glyph,title] of [['deny','×','Negar'],['inherit','／','Herdar'],['allow','✓','Permitir']]){
    const b=E('button','',glyph);b.type='button';b.title=title;b.setAttribute('aria-label',title+' '+label);b.dataset.value=val;b.setAttribute('aria-pressed',String(state(source(),selected,key)===val));b.classList.toggle('current',state(source(),selected,key)===val);
    b.onclick=()=>{const data=source();if(val==='inherit'){if(data[selected])delete data[selected][key];if(data[selected]&&!Object.keys(data[selected]).length)delete data[selected]}else{(data[selected]??={})[key]=val==='allow'}render()};options.append(b);
   }row.append(copy,options);rows.append(row)
  }}
  choose.onchange=()=>{const [type,...parts]=choose.value.split(':');selectedType=type;selected=parts.join(':');render()};render();
  return {host,roles:rolePermissions,members:memberPermissions,setKind(next){currentKind=next;render()},render};
 }
 async function manage(kind,id){
  if(!activeCommunity)return;
  let info;try{info=await fetchACL()}catch(e){return notice(e.message,true)}
  const cat=info.categories?.find(c=>c.id===id),meta=info.channel_meta?.[id],category=kind==='category';
  if(!category&&!meta)return notice('Canal indisponível.',true);
  const roleOverrides=JSON.parse(JSON.stringify((category?cat:meta)?.role_permissions||{}));
  const memberOverrides=JSON.parse(JSON.stringify((category?cat:meta)?.member_permissions||{}));
  const title=category?'Categoria '+(cat?.name||''):'# '+id;
  const back=E('div','explicit-acl-backdrop'),modal=E('section','explicit-acl-modal');modal.setAttribute('role','dialog');modal.setAttribute('aria-modal','true');modal.setAttribute('aria-label','Permissões de '+title);
  const header=E('div','explicit-acl-header');const intro=E('div');intro.append(E('small','explicit-acl-overline','EXPLICIT  /  PERMISSÕES'),E('h2','',title));header.append(intro);
  const close=E('button','explicit-acl-close','×');close.title='Fechar';close.onclick=()=>back.remove();header.append(close);modal.append(header);
  const shell=E('div','explicit-acl-shell'),left=E('aside','explicit-acl-left'),right=E('div','explicit-acl-right');shell.append(left,right);modal.append(shell);
  const editor=buildPermissionEditor({roles:info.roles||[],members:info.members||[],kind:category?'category':meta?.type||'text',rolePermissions:roleOverrides,memberPermissions:memberOverrides});right.append(editor.host);
  if(!category){const description=E('p','explicit-acl-hint',meta.synced?'Este canal está sincronizado com a categoria. Se salvar permissões diferentes, ele se tornará independente.':meta.category?'As permissões deste canal são independentes da categoria.':'Canal sem categoria.');right.insertBefore(description,editor.host)}
  const footer=E('div','explicit-acl-footer');const cancel=E('button','','Cancelar');cancel.onclick=()=>back.remove();const save=E('button','explicit-acl-primary','Salvar permissões');save.onclick=async()=>{save.disabled=true;try{await safe(category?'category_update':'channel_update',{category:category?id:undefined,channel:category?undefined:id,name:category?cat.name:undefined,role_permissions:roleOverrides,member_permissions:memberOverrides});back.remove();await refreshCommunities();notice('Permissões atualizadas.')}catch(e){notice(e.message,true)}finally{save.disabled=false}};footer.append(cancel,save);
  if(!category&&meta.category){const sync=E('button','','Sincronizar com categoria');sync.title='Substitui as regras do canal pelas da categoria';sync.onclick=async()=>{if(!await nexoDialog('Sincronizar permissões','As permissões específicas deste canal serão substituídas pelas regras da categoria. Confirmar?'))return;try{await safe('channel_sync',{channel:id});back.remove();await refreshCommunities();notice('Permissões sincronizadas.')}catch(e){notice(e.message,true)}};footer.prepend(sync)}
  if(category){const syncAll=E('button','','Sincronizar todos os canais');syncAll.onclick=async()=>{if(!await nexoDialog('Sincronizar toda a categoria','Todas as permissões individuais dos canais desta categoria serão substituídas pelas permissões atuais da categoria. Confirmar?'))return;try{await safe('category_sync_all',{category:id});back.remove();await refreshCommunities();notice('Todos os canais da categoria foram sincronizados.')}catch(e){notice(e.message,true)}};footer.prepend(syncAll)}
  modal.append(footer);back.append(modal);document.body.append(back);back.addEventListener('pointerdown',e=>{if(e.target===back)back.remove()});back.addEventListener('keydown',e=>{if(e.key==='Escape')back.remove()});close.focus();
 }
 async function createCategory(){
  if(!canManage())return notice('Sem permissão para criar categorias.',true);
  const name=await nexoPrompt('Criar categoria','Nome da nova categoria');if(!name)return;
  try{await safe('category_create',{name:name.trim()});await refreshCommunities();notice('Categoria criada. Clique com botão direito para configurar permissões.')}catch(e){notice(e.message,true)}
 }
 async function moveChannel(ch){const c=ownCommunity();if(!c)return;const choices=[{id:'',name:'Sem categoria'},...(c.categories||[])];const back=E('div','explicit-acl-backdrop'),modal=E('section','explicit-acl-small');modal.append(E('h2','','Mover #'+ch));const select=E('select');for(const cat of choices){const opt=E('option','',cat.name);opt.value=cat.id;select.append(opt)}select.value=c.channel_meta?.[ch]?.category||'';modal.append(select);const action=E('button','explicit-acl-primary','Mover canal');action.onclick=async()=>{try{await safe('channel_move',{channel:ch,category:select.value});back.remove();await refreshCommunities();notice('Canal movido. Para herdar as regras da categoria, sincronize as permissões.')}catch(e){notice(e.message,true)}};const cancel=E('button','','Cancelar');cancel.onclick=()=>back.remove();modal.append(action,cancel);back.append(modal);document.body.append(back);back.onclick=e=>{if(e.target===back)back.remove()}}
 async function removeCategory(id){if(!await nexoDialog('Excluir categoria','Os canais serão preservados, mas ficarão sem categoria. Continuar?'))return;try{await safe('category_delete',{category:id});await refreshCommunities();notice('Categoria removida; canais preservados.')}catch(e){notice(e.message,true)}}
 // Channel creation/layout has one owner: the original renderer produces flat nodes,
 // and this ACL adapter groups them, retaining every channel and its listeners.
 const collapsedCategories=new Set();
 const previous=renderChannels;
 renderChannels=function(){
  previous();
  const c=ownCommunity(),list=document.getElementById('channelList');
  if(!c||!list)return;
  const map=new Map();
  for(const item of [...list.children]){
   if(item.classList.contains('channelButton')){
    const name=item.textContent.replace(/^#\s*/,'');
    if(name)map.set(name,item);
   }else if(item.classList.contains('voice-group')){
    const name=item.dataset.explicitChannel;
    if(name)map.set(name,item);
   }
  }
  const categorized=new Set(),sections=[];
  const addCategory=(name,id,channels,virtual=false)=>{
   const group=E('section','explicit-acl-category');
   const key=virtual?'virtual:'+name:'real:'+id;
   if(!virtual)group.dataset.explicitCategory=id;
   group.classList.toggle('collapsed',collapsedCategories.has(key));
   const title=E('button','explicit-acl-category-title');
   title.type='button';title.title='Categoria '+name;
   const update=()=>{
    const closed=group.classList.contains('collapsed');
    title.textContent=(closed?'▸  ':'⌄  ')+name;
    title.setAttribute('aria-expanded',String(!closed));
   };
   title.onclick=()=>{
    group.classList.toggle('collapsed');
    if(group.classList.contains('collapsed'))collapsedCategories.add(key);
    else collapsedCategories.delete(key);
    update();
   };
   update();
   if(!virtual){
    title.addEventListener('contextmenu',e=>{
     e.preventDefault();e.stopPropagation();
     if(!canManage())return;
     contextMenu(e,[['Permissões da categoria',()=>manage('category',id)],['Excluir categoria',()=>removeCategory(id)]]);
    });
   }
   group.append(title);
   for(const ch of channels){
    const item=map.get(ch);
    if(!item)continue;
    item.classList.add('explicit-acl-nested');
    group.append(item);
    categorized.add(ch);
   }
   sections.push(group);
  };
  for(const cat of c.categories||[]){
   const members=(c.channels||[]).filter(ch=>c.channel_meta?.[ch]?.category===cat.id&&map.has(ch));
   if(members.length||canManage())addCategory(cat.name,cat.id,members);
  }
  const uncategorized=(c.channels||[]).filter(ch=>!categorized.has(ch)&&map.has(ch));
  const texts=uncategorized.filter(ch=>(c.channel_meta?.[ch]?.type||'text')==='text');
  const voices=uncategorized.filter(ch=>c.channel_meta?.[ch]?.type==='voice');
  // Fallback visual grouping only for existing communities with legacy channels.
  // These virtual headings are deliberately not assigned a server category ID.
  if(texts.length)addCategory('TEXTO','',texts,true);
  if(voices.length)addCategory('VOZ','',voices,true);
  list.replaceChildren(...sections);
  // Keep the existing channel context actions, drag and drop, and live voice members.
  for(const [ch,item] of map){
   item.dataset.explicitChannel=ch;
   if(!canManage())continue;
   item.draggable=true;
   item.addEventListener('contextmenu',e=>{
    e.preventDefault();e.stopImmediatePropagation();
    contextMenu(e,[
     ['Permissões do canal',()=>manage('channel',ch)],
     ['Mover para categoria',()=>moveChannel(ch)],
     ['Excluir canal',async()=>{
      if(!await nexoDialog('Excluir canal','Excluir o canal '+ch+'?'))return;
      try{await api('channel-delete','POST',{community:activeCommunity,channel:ch});
       if(activeChannel===ch)activeChannel='geral';await refreshCommunities();notice('Canal excluído')}
      catch(error){notice(error.message,true)}
     }]
    ]);
   },true);
  }
 };
 // Existing settings screen and shared channel-creation permissions are preserved.
 window.explicitManageChannelPermissions=ch=>manage('channel',ch);
 window.explicitMoveChannelCategory=moveChannel;
 window.explicitCreateCategory=createCategory;
 // Creation reuses the very same ACL rows/picker/tri-state controls as editing.
 window.explicitManageChannelPermissions=ch=>manage('channel',ch);
 window.explicitMoveChannelCategory=moveChannel;
 window.explicitCreateCategory=createCategory;
 const prevCreate=createChannel;
 createChannel=function(){prevCreate();const modal=document.querySelector('.explicit-channel-create');if(!modal)return;
  const existing=modal.querySelector('.explicit-channel-fields'),save=modal.querySelector('.explicit-channel-save');if(!existing||!save)return;
  const community=ownCommunity(),canEdit=(adminState?.permissions||[]).some(key=>['MANAGE_ROLES','ADMINISTRATOR'].includes(key));
  const panel=E('div','explicit-acl-create-controls');const category=E('select');
  for(const item of [{id:'',name:'Sem categoria'},...(community?.categories||[])]){const opt=E('option','',item.name);opt.value=item.id;category.append(opt)}
  const categoryLabel=E('label','','Categoria (opcional)');categoryLabel.append(category);panel.append(categoryLabel);
  function checkRow(title,detail){const line=E('label','explicit-acl-check');const text=E('span','explicit-acl-check-copy');text.append(E('strong','',title),E('small','',detail));const input=E('input');input.type='checkbox';line.append(text,input);panel.append(line);return {line,input}}
  const {line:syncLabel,input:sync}=checkRow('Sincronizar com a categoria','Herdar as configurações de acesso da categoria selecionada.');
  const {input:privateCheck}=checkRow('Canal privado','Ocultar o canal de @everyone; conceda acesso a cargos ou usuários no painel abaixo.');
  const alert=E('p','explicit-acl-hint','Defina permissões específicas para cargos e usuários. O acesso privado exige permitir “Ver canal” para ao menos um deles.');
  const editor=buildPermissionEditor({roles:community?.roles||[],members:community?.members||[],kind:'text'});
  const editorPanel=E('div','explicit-acl-inline-editor');const heading=E('div','explicit-acl-inline-header');heading.append(E('span','explicit-acl-overline','EXPLICIT / PERMISSÕES'),E('strong','','Permissões avançadas'));editorPanel.append(heading,alert,editor.host);panel.append(editorPanel);
  const originalHeader=modal.querySelector('.explicit-channel-perm-header'),originalRows=modal.querySelector('.explicit-channel-permissions');originalHeader?.remove();originalRows?.remove();existing.after(panel);
  const type=existing.querySelector('select'),limit=existing.querySelector('input[type=number]');
  const existingTypeHandler=type?.onchange;type.onchange=()=>{existingTypeHandler?.();editor.setKind(type.value)};editor.setKind(type.value);
  const refresh=()=>{syncLabel.hidden=!category.value;if(!category.value)sync.checked=false;if(privateCheck.checked)sync.checked=false;if(sync.checked)privateCheck.checked=false;editor.host.classList.toggle('explicit-acl-disabled',sync.checked||!canEdit);privateCheck.disabled=!canEdit;sync.disabled=!canEdit&&!!category.value};
  category.onchange=()=>{if(category.value&&!privateCheck.checked&&canEdit)sync.checked=true;refresh()};sync.onchange=refresh;privateCheck.onchange=refresh;refresh();
  if(!canEdit){const warning=E('p','explicit-acl-hint','Você pode criar canais, mas não possui Gerenciar cargos para definir exceções de acesso.');editorPanel.prepend(warning)}
  save.addEventListener('click',event=>{event.stopImmediatePropagation();event.preventDefault();if(save.disabled)return;
   const field=existing.querySelector('input:not([type=number])');const channel=field?.value.trim();if(!channel){field?.focus();return notice('Informe o nome do canal.',true)}
   const roles=JSON.parse(JSON.stringify(editor.roles)),members=JSON.parse(JSON.stringify(editor.members));
   const privateMode=privateCheck.checked;
   if(privateMode){(roles.everyone??={}).VIEW_CHANNEL=false;
    if(!Object.entries(roles).some(([id,p])=>id!=='everyone'&&p.VIEW_CHANNEL===true)&&!Object.values(members).some(p=>p.VIEW_CHANNEL===true))return notice('Para um canal privado, permita “Ver canal” a pelo menos um cargo ou usuário no editor.',true);
   }
   save.disabled=true;
   api('communities','POST',{community:activeCommunity,channel,type:type.value,limit:type.value==='voice'?Number(limit.value):0,category:category.value,sync:sync.checked&&!privateMode,private:privateCheck.checked,role_permissions:sync.checked||!canEdit?{}:roles,member_permissions:sync.checked||!canEdit?{}:members})
    .then(async()=>{modal.closest('.obsidian-modal-backdrop')?.remove();await refreshCommunities();if(type.value==='text')await selectChannel(channel);notice('Canal criado.')})
    .catch(error=>notice(error.message,true)).finally(()=>save.disabled=false);
  },true);
 };

})();
