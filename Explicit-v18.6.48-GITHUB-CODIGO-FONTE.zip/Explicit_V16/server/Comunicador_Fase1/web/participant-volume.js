/* Local per-listener participant volume; this does not change the speaker's published audio. */
function explicitParticipantVolumeKey(user){
 return ['explicit-participant-volume-v1',document.getElementById('who')?.textContent?.trim()||'',activeCommunity||'',user||''].join(':');
}
function explicitParticipantVolume(user){
 try{const raw=localStorage.getItem(explicitParticipantVolumeKey(user));
  if(raw===null)return 1;const n=Number(raw);return Number.isFinite(n)?Math.max(0,Math.min(1,n)):1;
 }catch{return 1}
}
function explicitSetParticipantVolume(user,factor){
 const safe=Math.max(0,Math.min(1,Number(factor)||0));
 try{localStorage.setItem(explicitParticipantVolumeKey(user),String(safe))}catch{}
 livekitClient?.setParticipantVolume?.(user);
 const audio=document.getElementById('voice-'+user);
 if(audio)audio.volume=Math.min(1,(Number(getPrefs().volume)/100)*safe);
}
function explicitParticipantVolumeControl(user){
 const box=document.createElement('section');box.className='explicit-member-volume';
 const top=document.createElement('div');top.className='explicit-member-volume-top';
 const name=document.createElement('strong');name.textContent='Volume individual';
 const value=document.createElement('output');value.setAttribute('aria-live','off');
 const input=document.createElement('input');input.type='range';input.min='0';input.max='100';input.step='5';
 input.value=String(Math.round(explicitParticipantVolume(user)*100));
 input.setAttribute('aria-label','Volume de @'+user);input.title='Apenas você ouvirá este participante neste volume';
 value.textContent=input.value+'%';
 input.addEventListener('input',()=>{value.textContent=input.value+'%';explicitSetParticipantVolume(user,Number(input.value)/100)});
 top.append(name,value);box.append(top,input);return box;
}
