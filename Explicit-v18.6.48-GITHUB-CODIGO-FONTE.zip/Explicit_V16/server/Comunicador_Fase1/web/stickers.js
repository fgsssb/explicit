'use strict';
/* Explicit v18.3 - biblioteca pessoal de figurinhas estáticas. Permissões reais no Go. */
(()=>{
 const picker=document.getElementById('explicitEmojiPicker');
 if(!picker)return;
 const $=(tag,cls,txt)=>{const x=document.createElement(tag);if(cls)x.className=cls;if(txt!==undefined)x.textContent=txt;return x};
 const switcher=$('div','explicit-sticker-switch');
 const emojiBtn=$('button','is-active','Emojis');emojiBtn.type='button';
 const stickerBtn=$('button','','Figurinhas');stickerBtn.type='button';
 switcher.append(emojiBtn,stickerBtn);picker.prepend(switcher);
 const pane=$('section','explicit-sticker-pane');const tools=$('div','explicit-sticker-tools');
 const desc=$('span','','Biblioteca pessoal');const upload=$('button','explicit-sticker-upload','+ Adicionar');upload.type='button';
 const uploadInput=$('input');uploadInput.type='file';uploadInput.accept='.png,.jpg,.jpeg,image/png,image/jpeg';uploadInput.hidden=true;
 tools.append(desc,upload,uploadInput);pane.append(tools);
 const body=$('div','explicit-sticker-grid');pane.append(body);picker.append(pane);
 let state={can_upload:false,can_send:false,owned:[],favorites:[]},refreshing=false;
 const encoded=id=>'/api/stickers?id='+encodeURIComponent(id);
 let cache=new Map();
 const loadImage=async(img,id)=>{
  if(!/^[a-f0-9]{32}\.(png|jpg)$/.test(id))return;
  if(cache.has(id)){img.src=cache.get(id);return}
  const res=await fetch(encoded(id),{headers:{Authorization:'Bearer '+session}});
  if(!res.ok)throw Error('Figurinha indisponível');
  const blob=await res.blob();if(!['image/png','image/jpeg'].includes(blob.type))throw Error('Formato inválido');
  const url=URL.createObjectURL(blob);cache.set(id,url);
  if(cache.size>120){const [first,url]=cache.entries().next().value;cache.delete(first);URL.revokeObjectURL(url)}
  img.src=url;
 };
 const closeMenu=()=>document.querySelector('.explicit-sticker-context')?.remove();
 const menu=(event,id,owner=false,favorite=false)=>{
  event.preventDefault();event.stopPropagation();closeMenu();
  const panel=$('div','explicit-sticker-context');
  const action=(label,fn)=>{const b=$('button','',label);b.type='button';b.onclick=async()=>{closeMenu();try{await fn();await refresh()}catch(e){nexoToast(e.message,'error')}};panel.append(b)};
  if(owner)action('Excluir minha figurinha',async()=>{if(!await nexoDialog('Excluir figurinha','Remover da sua biblioteca? Mensagens antigas continuarão exibindo a imagem.'))return;await api('stickers','POST',{action:'delete',id})});
  else if(favorite)action('Remover dos favoritos',()=>api('stickers','POST',{action:'unfavorite',id}));
  else action('Salvar nos favoritos',async()=>{await api('stickers','POST',{action:'favorite',id});nexoToast('Figurinha adicionada aos favoritos')});
  if(!panel.childNodes.length)return;
  document.body.append(panel);panel.style.left=Math.max(5,Math.min(event.clientX,window.innerWidth-200))+'px';panel.style.top=Math.max(5,Math.min(event.clientY,window.innerHeight-80))+'px';
  const dismiss=e=>{if(!panel.contains(e.target)){closeMenu();document.removeEventListener('pointerdown',dismiss,true)}};setTimeout(()=>document.addEventListener('pointerdown',dismiss,true),0);
 };
 window.explicitRenderSticker=(box,id)=>{
  if(!/^[a-f0-9]{32}\.(png|jpg)$/.test(id))return;
  const img=$('img','explicit-sticker-message');img.alt='Figurinha';img.title='Botão direito: salvar nos favoritos';img.loading='lazy';
  box.append(img);loadImage(img,id).catch(()=>{img.alt='Figurinha indisponível'});
  img.addEventListener('contextmenu',async e=>{e.preventDefault();try{const library=await api('stickers');const own=library.owned?.some(st=>st.id===id);const saved=library.favorites?.some(st=>st.id===id);menu(e,id,!!own,!!saved)}catch{menu(e,id,false,false)}});
 };
 const render=()=>{
  body.replaceChildren();pane.classList.toggle('is-sticker-locked',!state.can_send);tools.hidden=!state.can_upload;upload.disabled=!state.can_upload;
  if(!state.can_send){
   const backdrop=$('div','explicit-sticker-locked-back');const sample=$('div','explicit-sticker-grid');
   for(let i=0;i<6;i++){const b=$('div','explicit-sticker-tile');b.textContent=['✦','✿','♡','☻','★','☺'][i];b.style.fontSize='30px';sample.append(b)}
   backdrop.append(sample);body.append(backdrop);
   const lock=$('div','explicit-sticker-locked');lock.innerHTML='<svg viewBox="0 0 24 24" aria-hidden="true"><rect x="5" y="10" width="14" height="11" rx="2"/><path d="M8 10V7a4 4 0 0 1 8 0v3"/></svg>';
   lock.append($('strong','','Figurinhas indisponíveis'),$('p','','Disponível para contas Admin, Beta ou Explicit+.'));
   pane.querySelector('.explicit-sticker-locked')?.remove();pane.append(lock);return;
  }
  pane.querySelector('.explicit-sticker-locked')?.remove();
  const owned=state.owned||[],fav=(state.favorites||[]).filter(st=>!owned.some(x=>x.id===st.id));
  const section=(name,items,source)=>{
   if(!items.length)return;
   const h=$('div','explicit-sticker-heading',name+' · '+items.length);h.style.gridColumn='1 / -1';body.append(h);
   for(const st of items){const b=$('button','explicit-sticker-tile');b.type='button';b.title='Enviar figurinha · botão direito para opções';const img=$('img');img.alt='Figurinha de @'+st.owner;img.loading='lazy';b.append(img);loadImage(img,st.id).catch(()=>{img.alt='Indisponível'});
    b.onclick=async()=>{if(!activeCommunity||document.body.classList.contains('explicit-screen-view'))return nexoToast('Abra um canal de texto para enviar figurinhas','error');b.disabled=true;try{const m=await api('stickers','POST',{action:'send',id:st.id,community:activeCommunity,channel:activeChannel});add(m);picker.hidden=true;document.getElementById('explicitEmojiButton')?.setAttribute('aria-expanded','false')}catch(e){nexoToast(e.message,'error')}finally{b.disabled=false}};
    b.oncontextmenu=e=>menu(e,st.id,source==='owned',source==='favorites');body.append(b)}
  };
  section('Suas figurinhas',owned,'owned');section('Favoritas',fav,'favorites');
  if(!owned.length&&!fav.length)body.append($('p','explicit-sticker-empty','Sua biblioteca está vazia. Adicione um PNG ou JPEG para começar.'));
 };
 async function refresh(){if(refreshing||!session)return;refreshing=true;try{state=await api('stickers');render()}catch(e){body.replaceChildren($('p','explicit-sticker-empty','Não foi possível carregar as figurinhas: '+e.message))}finally{refreshing=false}}
 render();
 const setMode=async(stickers)=>{
  picker.classList.toggle('explicit-sticker-mode',stickers);emojiBtn.classList.toggle('is-active',!stickers);stickerBtn.classList.toggle('is-active',stickers);
  if(stickers)await refresh();
 };
 emojiBtn.onclick=()=>setMode(false);stickerBtn.onclick=()=>setMode(true);
 const mainBtn=document.getElementById('explicitEmojiButton');mainBtn?.addEventListener('click',()=>{if(!picker.hidden&&picker.classList.contains('explicit-sticker-mode'))refresh()},false);
 upload.onclick=()=>{if(!state.can_upload||!state.can_send)return;uploadInput.click()};
 uploadInput.onchange=async()=>{
  const file=uploadInput.files?.[0];uploadInput.value='';if(!file)return;if(!state.can_upload||!state.can_send)return nexoToast('Figurinhas indisponíveis para esta conta','error');
  if(!['image/png','image/jpeg'].includes(file.type)||file.size>5*1024*1024)return nexoToast('Selecione PNG ou JPEG de até 5 MB','error');
  const form=new FormData();form.append('image',file,file.name);
  upload.disabled=true;
  try{const response=await fetch('/api/stickers',{method:'POST',headers:{Authorization:'Bearer '+session},body:form});if(!response.ok)throw Error((await response.text()).slice(0,180));nexoToast('Figurinha otimizada e adicionada');await refresh()}
  catch(e){nexoToast('Figurinha: '+e.message,'error')}finally{upload.disabled=false}
 };
})();
