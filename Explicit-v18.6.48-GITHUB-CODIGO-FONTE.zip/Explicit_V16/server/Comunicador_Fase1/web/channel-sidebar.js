/* Explicit 18.6.19 — compact channel navigation, preserving existing actions. */
(()=>{
 'use strict';
 const E=(tag,cls,value)=>{const n=document.createElement(tag);if(cls)n.className=cls;if(value!==undefined)n.textContent=value;return n};
 const icon=(kind)=>{
  const ns='http://www.w3.org/2000/svg';const svg=document.createElementNS(ns,'svg');
  svg.setAttribute('viewBox','0 0 24 24');svg.setAttribute('width','19');svg.setAttribute('height','19');
  svg.setAttribute('fill','none');svg.setAttribute('stroke','currentColor');svg.setAttribute('stroke-width','1.9');
  svg.setAttribute('stroke-linecap','round');svg.setAttribute('stroke-linejoin','round');svg.setAttribute('aria-hidden','true');
  const paths=kind==='voice'?[
   ['path',{d:'M4 13.5V11a8 8 0 0 1 16 0v2.5'}],['rect',{x:3,y:12,width:4,height:8,rx:1.5}],['rect',{x:17,y:12,width:4,height:8,rx:1.5}]
  ]:[
   ['path',{d:'M5 3 3 21M13 3l-2 18M2 9h17M1 15h17'}]
  ];
  for(const [tag,attrs] of paths){const part=document.createElementNS(ns,tag);for(const [k,v]of Object.entries(attrs))part.setAttribute(k,String(v));svg.append(part)}
  return svg;
 };
 const lockIcon=()=>{
  const ns='http://www.w3.org/2000/svg';const svg=document.createElementNS(ns,'svg');
  svg.setAttribute('viewBox','0 0 16 16');svg.setAttribute('aria-hidden','true');svg.setAttribute('width','12');svg.setAttribute('height','12');
  svg.setAttribute('fill','none');svg.setAttribute('stroke','currentColor');svg.setAttribute('stroke-width','1.9');
  svg.setAttribute('stroke-linecap','round');svg.setAttribute('stroke-linejoin','round');
  const p=document.createElementNS(ns,'path');p.setAttribute('d','M4.5 7V4.8a3.5 3.5 0 1 1 7 0V7M4.2 7.2h7.6a1.1 1.1 0 0 1 1.1 1.1v5a1.1 1.1 0 0 1-1.1 1.1H4.2a1.1 1.1 0 0 1-1.1-1.1v-5a1.1 1.1 0 0 1 1.1-1.1z');svg.append(p);return svg;
 };
 const iconWrap=(kind,restricted)=>{
  const wrap=E('span','explicit-sidebar-channel-icon');wrap.append(icon(kind));
  if(restricted){wrap.append((()=>{const small=E('span','explicit-sidebar-lock');small.append(lockIcon());return small})())}
  return wrap;
 };
 function decorate(){
  const list=document.getElementById('channelList');
  const community=typeof communities!=='undefined'&&typeof activeCommunity!=='undefined'
    ? communities.find(c=>c.id===activeCommunity) : null;
  if(!list||!community)return;
  list.classList.add('explicit-sidebar-channels');
  for(const button of list.querySelectorAll('button.channelButton')){
   const name=button.closest('[data-explicit-channel]')?.dataset.explicitChannel||button.textContent.trim().replace(/^#\s*/,'');
   if(!name)continue;
   const restricted=community.channel_meta?.[name]?.private===true;
   button.classList.add('explicit-sidebar-text-row');
   button.dataset.channelName=name;
   button.classList.toggle('active',typeof activeChannel!=='undefined'&&activeChannel===name);
   button.setAttribute('aria-label',(restricted?'Canal privado de texto ':'Canal de texto ')+name);
   button.replaceChildren(iconWrap('text',restricted),E('span','explicit-sidebar-name',name));
  }
  for(const group of list.querySelectorAll('.voice-group')){
   const name=group.dataset.explicitChannel||group.querySelector('.voice-heading button:not(.toggle)')?.textContent.trim().replace(/\s*·\s*\d+$/,'');
   if(!name)continue;
   const join=group.querySelector('.voice-heading button:not(.toggle)');
   if(!join)continue;
   const restricted=community.channel_meta?.[name]?.private===true;
   const limit=community.channel_meta?.[name]?.limit;
   join.classList.add('explicit-sidebar-voice-row');
   join.dataset.channelName=name;
   join.setAttribute('aria-label',(restricted?'Canal privado de voz ':'Canal de voz ')+name);
   join.replaceChildren(iconWrap('voice',restricted),E('span','explicit-sidebar-name',name));
   if(limit){join.append(E('span','explicit-sidebar-limit',String(limit)))}
   group.classList.add('explicit-sidebar-voice-group');
   const arrow=group.querySelector('.voice-heading button.toggle');if(arrow){arrow.setAttribute('aria-label','Expandir ou recolher participantes de '+name)}
  }
  for(const label of list.querySelectorAll('.voice-label'))label.classList.add('explicit-sidebar-section-label');
  for(const title of list.querySelectorAll('.explicit-acl-category-title'))title.classList.add('explicit-sidebar-category-title');
  for(const section of list.querySelectorAll('.explicit-acl-category'))section.classList.add('explicit-sidebar-category');
 }
 if(typeof renderChannels!=='function')return;
 const original=renderChannels;
 renderChannels=function(){const result=original.apply(this,arguments);decorate();return result};
 decorate();
})();
