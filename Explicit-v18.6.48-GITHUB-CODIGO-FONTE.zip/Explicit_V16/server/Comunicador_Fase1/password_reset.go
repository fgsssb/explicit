package main

import (
	"net/http"
	"strings"
)

const defaultExplicitChangelog = `Explicit 18.6.11
Adicionado
• Inventário de efeitos personalizados de nome para Beta e Explicit+.
• Editor de cores, fontes, degradês, sombras, contornos e animações.
• Presets equipáveis nos nomes do chat e dos perfis.

Explicit 18.6.10
Corrigido
• Ausência sem limite de tempo e saída explícita na presença online.

Explicit 18.6.9
Adicionado
• Novidades exibidas diretamente na página inicial.
• Alternância entre changelog e divulgações no painel administrativo.
Corrigido
• Status ausente ao deixar o navegador em segundo plano.
• Apresentação e rolagem do changelog.

Explicit 18.6.8
Adicionado
• Solicitações de amizade pelo perfil de membros.
Corrigido
• Avisos de amizade, identificação das conversas privadas e opções conforme permissões.
• Presença ao navegar pelo aplicativo.

Explicit 18.6.7
Atualizado
• Sincronização das mensagens, conversas privadas e presença.
Corrigido
• Contadores de notificações após a leitura.

Explicit 18.6.6
Adicionado
• Fotos dos membros nas mensagens e na lista lateral.
• Imagens das comunidades.
Atualizado
• Cadastro mais compacto e status sobreposto aos avatares.

Explicit 18.6.5
Corrigido
• Rolagem e seleção de badges no painel administrativo.

Explicit 18.6.4
Adicionado
• Navegação Voltar e Avançar e barra superior personalizada.
Atualizado
• Botões de criação e entrada em comunidades.

Explicit 18.6.3
Corrigido
• Botão de cadastro acessível mesmo com CAPTCHA.

Explicit 18.6.2
Adicionado
• CAPTCHA, upload de vídeos, avatares e imagens de comunidades.
• Redefinição de senha com troca obrigatória.
• Novos sons de notificações e controles de voz.
Atualizado
• Perfil de membros, badges e atalhos.

Explicit 18.6.1
Adicionado
• Movimento de usuários entre salas de voz.
• Créditos e QR Pix no Início.
Atualizado
• Permissões de canais e aparência dos controles.`

// Complete a staff-issued temporary-password reset without minting a session.
// Credentials are checked server-side; a temporary password cannot access APIs.
func (s *Server) completePasswordReset(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		http.Error(w, "method", 405)
		return
	}
	if !s.allowLogin(r.RemoteAddr) {
		http.Error(w, "too many attempts", 429)
		return
	}
	var q struct {
		Name              string `json:"name"`
		TemporaryPassword string `json:"temporary_password"`
		NewPassword       string `json:"new_password"`
		ConfirmPassword   string `json:"confirm_password"`
		CaptchaID         string `json:"captcha_id"`
		CaptchaAnswer     string `json:"captcha_answer"`
	}
	if parse(r, &q) != nil {
		http.Error(w, "invalid request", 400)
		return
	}
	if len(q.NewPassword) < 8 || len(q.NewPassword) > 256 || q.NewPassword != q.ConfirmPassword || strings.TrimSpace(q.Name) != q.Name {
		reply(w, 400, map[string]string{"error": "Nova senha inválida"})
		return
	}
	if !s.verifyCaptcha(q.CaptchaID, q.CaptchaAnswer) {
		reply(w, 403, map[string]string{"error": "CAPTCHA inválido ou expirado"})
		return
	}
	s.mu.Lock()
	defer s.mu.Unlock()
	u, ok := s.db.Users[q.Name]
	if !ok || !u.RequirePasswordChange || !checkPassword(u, q.TemporaryPassword) {
		reply(w, 401, map[string]string{"error": "Credenciais temporárias inválidas"})
		return
	}
	old := u
	u.Salt = token()
	u.Hash = secureHash(u.Salt, q.NewPassword)
	u.RequirePasswordChange = false
	s.db.Users[q.Name] = u
	if e := s.save(); e != nil {
		s.db.Users[q.Name] = old
		reply(w, 500, map[string]string{"error": "Falha ao salvar"})
		return
	}
	reply(w, 200, map[string]bool{"ok": true})
}

func (s *Server) homeModeAPI(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodGet {
		http.Error(w, "method", 405)
		return
	}
	s.mu.Lock()
	defer s.mu.Unlock()
	mode := s.db.HomeMode
	if mode != "spotlight" || !s.db.HomeModeConfiguredV1869 { // One-time upgrade to news; admin selection remains persistent afterwards.
		mode = "changelog"
	}
	changelog := s.db.Changelog
	if strings.TrimSpace(changelog) == "" {
		changelog = defaultExplicitChangelog
	}
	w.Header().Set("Cache-Control", "no-store")
	reply(w, 200, map[string]string{"mode": mode, "changelog": changelog})
}

// registrationConfigAPI exposes only whether the invite field is required.
func (s *Server) registrationConfigAPI(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodGet {
		http.Error(w, "method", 405)
		return
	}
	s.mu.Lock()
	required := s.db.RequireInvite
	s.mu.Unlock()
	w.Header().Set("Cache-Control", "no-store")
	reply(w, 200, map[string]bool{"require_invite": required})
}
