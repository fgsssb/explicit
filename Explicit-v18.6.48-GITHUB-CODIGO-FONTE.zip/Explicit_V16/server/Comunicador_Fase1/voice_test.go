package main

import (
	"bytes"
	"encoding/json"
	"net/http/httptest"
	"path/filepath"
	"testing"
)

func TestVoiceRoomAuthorizationAndSignaling(t *testing.T) {
	s := newServer(filepath.Join(t.TempDir(), "db.json"))
	s.db.Users["ana"] = User{Name: "ana"}
	s.db.Users["bia"] = User{Name: "bia"}
	s.db.Users["intruso"] = User{Name: "intruso"}
	s.db.Communities = []Community{{ID: "room", Name: "Room", Owner: "ana", Members: []string{"ana", "bia"}, Channels: []string{"geral"}, ChannelMeta: map[string]ChannelMeta{"geral": {Type: "voice"}}}}

	s.db.Users["ana"] = User{Name: "ana"}
	s.db.Users["bia"] = User{Name: "bia"}
	s.db.Users["intruso"] = User{Name: "intruso"}
	s.sessions["ta"] = "ana"
	s.sessions["tb"] = "bia"
	s.sessions["tx"] = "intruso"
	call := func(tok, action, to, kind string) (int, map[string]any) {
		t.Helper()
		b, _ := json.Marshal(map[string]string{"community": "room", "channel": "geral", "action": action, "to": to, "kind": kind, "data": "test"})
		r := httptest.NewRequest("POST", "/api/voice", bytes.NewReader(b))
		r.Header.Set("Authorization", "Bearer "+tok)
		w := httptest.NewRecorder()
		s.voiceAPI(w, r)
		var v map[string]any
		_ = json.Unmarshal(w.Body.Bytes(), &v)
		return w.Code, v
	}
	if code, _ := call("tx", "join", "", ""); code != 403 {
		t.Fatalf("intruder join: %d", code)
	}
	if code, _ := call("ta", "join", "", ""); code != 200 {
		t.Fatalf("ana join: %d", code)
	}
	if code, _ := call("tb", "join", "", ""); code != 200 {
		t.Fatalf("bia join: %d", code)
	}
	if code, _ := call("ta", "signal", "bia", "offer"); code != 200 {
		t.Fatalf("signal: %d", code)
	}
	if code, v := call("tb", "poll", "", ""); code != 200 || len(v["events"].([]any)) != 1 {
		t.Fatalf("poll: %d %v", code, v)
	}
	if code, v := call("tb", "poll", "", ""); code != 200 || len(v["events"].([]any)) != 0 {
		t.Fatalf("poll again: %d %v", code, v)
	}
	_, _ = call("ta", "leave", "", "")
	_, _ = call("tb", "leave", "", "")
}
