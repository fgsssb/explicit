package main

import (
	"net/http"
	"net/http/httptest"
	"strings"
	"testing"
)

func TestV18637GlobalInviteLimitAndAuthorization(t *testing.T) {
	s := newServer(t.TempDir() + "/data.json")
	s.mu.Lock()
	s.db.Users["owner"] = User{Name: "owner", AccountID: "account-owner", SystemRole: "owner", InviteKey: "OWNER-KEY"}
	s.db.Users["admin"] = User{Name: "admin", AccountID: "account-admin", SystemRole: "admin", InviteKey: "ADMIN-KEY"}
	s.db.Users["alice"] = User{Name: "alice", AccountID: "account-alice", InviteKey: "ALICE-KEY"}
	s.db.OwnerAccountID = "account-owner"
	s.sessions["token-owner"] = "owner"
	s.sessions["token-admin"] = "admin"
	s.sessions["token-alice"] = "alice"
	s.db.RequireInvite = true
	s.db.Invites = []InviteRedemption{{Inviter: "alice", Invitee: "first"}, {Inviter: "alice", Invitee: "second"}}
	s.mu.Unlock()
	request := func(token, method, path, payload string) *httptest.ResponseRecorder {
		r := httptest.NewRequest(method, path, strings.NewReader(payload))
		r.Header.Set("Authorization", "Bearer "+token)
		w := httptest.NewRecorder()
		s.routes().ServeHTTP(w, r)
		return w
	}
	if w := request("token-admin", "POST", "/api/system-admin", `{"action":"set_invite_limit","invite_limit":12}`); w.Code != http.StatusForbidden {
		t.Fatalf("admin can change global limit: %d %s", w.Code, w.Body.String())
	}
	if w := request("token-owner", "POST", "/api/system-admin", `{"action":"set_invite_limit","invite_limit":0}`); w.Code != http.StatusBadRequest {
		t.Fatalf("zero allowed: %d", w.Code)
	}
	if w := request("token-owner", "POST", "/api/system-admin", `{"action":"set_invite_limit","invite_limit":1001}`); w.Code != http.StatusBadRequest {
		t.Fatalf("excess allowed: %d", w.Code)
	}
	if w := request("token-owner", "POST", "/api/system-admin", `{"action":"set_invite_limit","invite_limit":12}`); w.Code != http.StatusOK {
		t.Fatalf("owner limit update: %d %s", w.Code, w.Body.String())
	}
	if w := request("token-alice", "GET", "/api/invite", ""); w.Code != http.StatusOK || !strings.Contains(w.Body.String(), `"limit":12`) || !strings.Contains(w.Body.String(), `"remaining":10`) {
		t.Fatalf("invite status: %d %s", w.Code, w.Body.String())
	}
	s.mu.Lock()
	s.db.InviteLimit = 2
	_, accepted := s.validateInviteLocked("ALICE-KEY")
	s.mu.Unlock()
	if accepted {
		t.Fatal("allowed invitation over configured limit")
	}
	loaded := newServer(s.file)
	loaded.mu.Lock()
	persisted := loaded.db.InviteLimit
	loaded.mu.Unlock()
	if persisted != 12 {
		t.Fatalf("limit did not persist: %d", persisted)
	}
}
