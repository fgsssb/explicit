package main

import (
	"bytes"
	"encoding/json"
	"net/http/httptest"
	"path/filepath"
	"testing"
)

func TestOwnerAndAdminHaveSameModerationLevelAndOnlyOwnerGrantsAdmin(t *testing.T) {
	s := newServer(filepath.Join(t.TempDir(), "store.json"))
	for _, name := range []string{"creator", "staff", "normal", "observer"} {
		s.db.Users[name] = User{Name: name, AccountID: token()}
		s.sessions[name+"-token"] = name
	}
	if err := s.bootstrapOwner("creator"); err != nil {
		t.Fatal(err)
	}
	if err := s.bootstrapOwner("staff"); err == nil {
		t.Fatal("second owner accepted")
	}
	if !s.isOwner("creator") || s.isSuperadmin("creator") {
		t.Fatal("Owner incorrectly elevated to bypass level")
	}
	if systemLevel("owner") != systemLevel("moderator") {
		t.Fatal("Owner/Admin levels differ")
	}
	call := func(actor, action, target, role string) int {
		t.Helper()
		b, _ := json.Marshal(map[string]any{"action": action, "target": target, "role": role})
		req := httptest.NewRequest("POST", "/api/system-admin", bytes.NewReader(b))
		req.Header.Set("Authorization", "Bearer "+actor+"-token")
		rec := httptest.NewRecorder()
		s.routes().ServeHTTP(rec, req)
		return rec.Code
	}
	if got := call("staff", "set_role", "normal", "moderator"); got != 403 {
		t.Fatalf("Admin could grant Admin: %d", got)
	}
	if got := call("creator", "set_role", "staff", "moderator"); got != 200 {
		t.Fatalf("Owner grant failed: %d", got)
	}
	if got := call("observer", "set_role", "normal", "moderator"); got != 403 {
		t.Fatalf("Admin could grant another Admin: %d", got)
	}
	if got := call("creator", "set_role", "staff", "user"); got != 200 {
		t.Fatalf("Owner revoke failed: %d", got)
	}
	if !newServer(s.file).isOwner("creator") {
		t.Fatal("Owner identity did not persist")
	}
}
func TestOwnerHasNoPrivateChannelBypassOrMuteImmunity(t *testing.T) {
	s := newServer(filepath.Join(t.TempDir(), "store.json"))
	s.db.Users["creator"] = User{Name: "creator", AccountID: token()}
	s.db.Users["moderator"] = User{Name: "moderator", AccountID: token()}
	if err := s.bootstrapOwner("creator"); err != nil {
		t.Fatal(err)
	}
	c := Community{ID: "closed", Owner: "moderator", Members: []string{"moderator"}, Channels: []string{"secret"}, ChannelMeta: map[string]ChannelMeta{"secret": {Type: "text", RolePermissions: map[string]map[string]bool{"everyone": {"VIEW_CHANNEL": false}}}}}
	s.db.Communities = []Community{c}
	if s.channelPermission(c, "creator", "secret", "VIEW_CHANNEL") {
		t.Fatal("Owner bypassed private channel")
	}
	s.db.StaffMutes = append(s.db.StaffMutes, StaffMute{Community: "closed", Channel: "secret", Target: "creator", Medium: "text"})
	if !s.isStaffMuted("closed", "secret", "creator", "text") {
		t.Fatal("Owner immune to mute")
	}
}
