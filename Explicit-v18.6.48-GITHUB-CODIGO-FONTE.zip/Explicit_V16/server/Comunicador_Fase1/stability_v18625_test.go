package main

import (
	"bytes"
	"encoding/json"
	"fmt"
	"io"
	"mime/multipart"
	"net/http"
	"net/http/httptest"
	"os"
	"path/filepath"
	"strings"
	"sync"
	"sync/atomic"
	"testing"
	"time"
)

func stableRequest(s *Server, who, method, url string, payload any) *httptest.ResponseRecorder {
	data, _ := json.Marshal(payload)
	req := httptest.NewRequest(method, url, bytes.NewReader(data))
	req.Header.Set("Authorization", "Bearer "+who+"-token")
	w := httptest.NewRecorder()
	s.routes().ServeHTTP(w, req)
	return w
}
func TestStorageQuotaConcurrentDirectUploadsAndRestart(t *testing.T) {
	t.Setenv("EXPLICIT_STORAGE_USER_BYTES", "800")
	t.Setenv("EXPLICIT_STORAGE_GLOBAL_BYTES", "1600")
	s := newServer(filepath.Join(t.TempDir(), "store.json"))
	for _, u := range []string{"ana", "bia"} {
		s.db.Users[u] = User{Name: u}
		s.sessions[u+"-token"] = u
	}
	s.db.Friends = []FriendRequest{{From: "ana", To: "bia", Status: "accepted"}}
	s.db.DirectChats = []DirectChat{{ID: "dm", Users: []string{"ana", "bia"}, Visible: map[string]bool{"ana": true, "bia": true}}}
	// Both uploads are individually valid but exceed the account quota together.
	var wg sync.WaitGroup
	var accepted, denied atomic.Int32
	send := func() {
		defer wg.Done()
		var body bytes.Buffer
		form := multipart.NewWriter(&body)
		_ = form.WriteField("chat", "dm")
		file, _ := form.CreateFormFile("file", "relatorio.txt")
		_, _ = io.WriteString(file, strings.Repeat("a", 600))
		_ = form.Close()
		req := httptest.NewRequest("POST", "/api/direct-file", bytes.NewReader(body.Bytes()))
		req.Header.Set("Authorization", "Bearer ana-token")
		req.Header.Set("Content-Type", form.FormDataContentType())
		w := httptest.NewRecorder()
		s.routes().ServeHTTP(w, req)
		switch w.Code {
		case 201:
			accepted.Add(1)
		case http.StatusRequestEntityTooLarge:
			denied.Add(1)
		default:
			t.Errorf("unexpected upload response %d: %s", w.Code, w.Body.String())
		}
	}
	wg.Add(2)
	go send()
	go send()
	wg.Wait()
	if accepted.Load() != 1 || denied.Load() != 1 {
		t.Fatalf("quota bypass: accepted=%d rejected=%d", accepted.Load(), denied.Load())
	}
	if len(s.db.DirectChats[0].Messages) != 1 {
		t.Fatalf("bad persisted messages: %d", len(s.db.DirectChats[0].Messages))
	}
	restored := newServer(s.file)
	restored.mu.Lock()
	used := restored.storageSnapshotLocked().UserBytes["ana"]
	restored.mu.Unlock()
	if used != 600 {
		t.Fatalf("quota not recovered after restart: %d", used)
	}
}
func TestStorageOrphansDryRunReferencesAndSymlink(t *testing.T) {
	root := t.TempDir()
	s := newServer(filepath.Join(root, "store.json"))
	s.db.Users["ana"] = User{Name: "ana"}
	dir := filepath.Join(root, "images")
	if err := os.MkdirAll(dir, 0700); err != nil {
		t.Fatal(err)
	}
	valid := strings.Repeat("a", 32) + ".png"
	orphan := strings.Repeat("b", 32) + ".png"
	recent := strings.Repeat("c", 32) + ".png"
	for _, f := range []string{valid, orphan, recent} {
		if err := os.WriteFile(filepath.Join(dir, f), []byte("sample"), 0600); err != nil {
			t.Fatal(err)
		}
	}
	s.db.Messages = []Message{{ID: "m", Author: "ana", Image: valid}}
	old := time.Now().Add(-100 * time.Hour)
	for _, f := range []string{valid, orphan} {
		_ = os.Chtimes(filepath.Join(dir, f), old, old)
	}
	dry := s.cleanOrphansLocked(true, time.Now())
	if dry.Candidates != 1 || dry.Deleted != 0 {
		t.Fatalf("dry-run incorrect: %+v", dry)
	}
	if _, err := os.Stat(filepath.Join(dir, orphan)); err != nil {
		t.Fatal("dry-run deleted file", err)
	}
	real := s.cleanOrphansLocked(false, time.Now())
	if real.Deleted != 1 {
		t.Fatalf("cleanup incorrect: %+v", real)
	}
	for _, f := range []string{valid, recent} {
		if _, err := os.Stat(filepath.Join(dir, f)); err != nil {
			t.Fatalf("live file removed: %s: %v", f, err)
		}
	}
	// A storage folder replaced by a symlink must not traverse outside the root.
	external := t.TempDir()
	victim := strings.Repeat("d", 32) + ".png"
	_ = os.WriteFile(filepath.Join(external, victim), []byte("private"), 0600)
	_ = os.Chtimes(filepath.Join(external, victim), old, old)
	if err := os.RemoveAll(dir); err != nil {
		t.Fatal(err)
	}
	if err := os.Symlink(external, dir); err == nil {
		s.cleanOrphansLocked(false, time.Now())
		if _, err := os.Stat(filepath.Join(external, victim)); err != nil {
			t.Fatal("followed directory symlink", err)
		}
	}
}
func TestReportNarrowEvidenceAndTwoStaffExpansion(t *testing.T) {
	s := newServer(filepath.Join(t.TempDir(), "store.json"))
	for _, u := range []string{"root", "second", "reporter", "accused", "visitor"} {
		role := "user"
		if u == "root" || u == "second" {
			role = "moderator"
		}
		s.db.Users[u] = User{Name: u, SystemRole: role}
		s.sessions[u+"-token"] = u
	}
	messages := []DirectMessage{}
	for i := 0; i < 32; i++ {
		messages = append(messages, DirectMessage{ID: fmt.Sprintf("m%d", i), Author: "accused", Text: fmt.Sprintf("text %d", i)})
	}
	s.db.DirectChats = []DirectChat{
		{ID: "linked", Users: []string{"reporter", "accused"}, Messages: messages},
		{ID: "unrelated", Users: []string{"accused", "visitor"}, Messages: []DirectMessage{{ID: "private", Author: "accused", Text: "hidden"}}},
	}
	generic := stableRequest(s, "reporter", "POST", "/api/report", map[string]string{"kind": "user", "target": "accused", "reason": "Perfil preocupante"})
	if generic.Code != 201 {
		t.Fatal(generic.Body.String())
	}
	var data struct {
		ID string `json:"id"`
	}
	_ = json.Unmarshal(generic.Body.Bytes(), &data)
	list := stableRequest(s, "root", "GET", "/api/staff-dm?list=1&report_id="+data.ID, nil)
	if list.Code != 200 || !strings.Contains(list.Body.String(), `"conversations":[]`) {
		t.Fatalf("generic report exposed DM: %d %s", list.Code, list.Body)
	}
	if got := stableRequest(s, "root", "GET", "/api/staff-dm?chat=linked&report_id="+data.ID+"&reason=investigacao", nil).Code; got != 403 {
		t.Fatalf("generic report read %d", got)
	}
	invalid := stableRequest(s, "reporter", "POST", "/api/report", map[string]string{"kind": "user", "target": "accused", "reason": "Mensagem inapropriada", "chat_id": "unrelated", "message_id": "private"})
	if invalid.Code != 403 {
		t.Fatalf("reporter fabricated evidence: %d", invalid.Code)
	}
	evidence := stableRequest(s, "reporter", "POST", "/api/report", map[string]string{"kind": "user", "target": "accused", "reason": "Mensagem inapropriada", "chat_id": "linked", "message_id": "m15"})
	if evidence.Code != 201 {
		t.Fatalf("evidence report refused: %d %s", evidence.Code, evidence.Body)
	}
	_ = json.Unmarshal(evidence.Body.Bytes(), &data)
	query := "/api/staff-dm?chat=linked&report_id=" + data.ID + "&reason=Investigacao%20necessaria"
	denied := stableRequest(s, "root", "GET", "/api/staff-dm?chat=unrelated&report_id="+data.ID+"&reason=Investigacao%20necessaria", nil)
	if denied.Code != 403 {
		t.Fatalf("unrelated conversation exposed: %d", denied.Code)
	}
	result := stableRequest(s, "root", "GET", query, nil)
	if result.Code != 200 {
		t.Fatalf("evidence denied: %d %s", result.Code, result.Body)
	}
	var scoped struct {
		Messages []DirectMessage `json:"messages"`
	}
	if err := json.Unmarshal(result.Body.Bytes(), &scoped); err != nil || len(scoped.Messages) != 13 {
		t.Fatalf("context size: %d %v", len(scoped.Messages), err)
	}
	if strings.Contains(result.Body.String(), "text 0") || strings.Contains(result.Body.String(), "hidden") {
		t.Fatal("unrelated content leaked")
	}
	request := stableRequest(s, "root", "POST", "/api/staff-dm", map[string]string{"action": "request_expand", "report_id": data.ID, "chat": "linked", "reason": "Abuso repetido em mensagens próximas"})
	if request.Code != 200 {
		t.Fatalf("expand request: %d %s", request.Code, request.Body)
	}
	if got := stableRequest(s, "root", "POST", "/api/staff-dm", map[string]string{"action": "approve_expand", "report_id": data.ID, "chat": "linked", "reason": "Revisao por outro moderador"}).Code; got != 403 {
		t.Fatalf("self approval: %d", got)
	}
	approve := stableRequest(s, "second", "POST", "/api/staff-dm", map[string]string{"action": "approve_expand", "report_id": data.ID, "chat": "linked", "reason": "Concordo com ampliacao no mesmo chat"})
	if approve.Code != 200 {
		t.Fatalf("two person approval: %d %s", approve.Code, approve.Body)
	}
	result = stableRequest(s, "root", "GET", query, nil)
	_ = json.Unmarshal(result.Body.Bytes(), &scoped)
	if len(scoped.Messages) != 32 {
		t.Fatalf("expanded scope missing: %d", len(scoped.Messages))
	}
	if strings.Contains(result.Body.String(), "hidden") {
		t.Fatal("expanded to unrelated DM")
	}
	if got := stableRequest(s, "root", "POST", "/api/system-admin", map[string]any{"action": "resolve_report", "report_id": data.ID}).Code; got != 200 {
		t.Fatalf("could not close report: %d", got)
	}
	if got := stableRequest(s, "root", "GET", query, nil).Code; got != 403 {
		t.Fatalf("closed report still grants access: %d", got)
	}
}
func TestOperationRateConcurrentAndIndependentAccounts(t *testing.T) {
	t.Setenv("EXPLICIT_RATE_PRESET_BURST", "3")
	t.Setenv("EXPLICIT_RATE_PRESET_WINDOW_SECONDS", "120")
	guard := newResourceGuard()
	var passed atomic.Int32
	var wg sync.WaitGroup
	for i := 0; i < 20; i++ {
		wg.Add(1)
		go func() {
			defer wg.Done()
			if guard.allow("ana", "preset", time.Now()) {
				passed.Add(1)
			}
		}()
	}
	wg.Wait()
	if passed.Load() != 3 {
		t.Fatalf("concurrent burst bypass: %d", passed.Load())
	}
	if !guard.allow("bia", "preset", time.Now()) {
		t.Fatal("one user affected another")
	}
	s := newServer(filepath.Join(t.TempDir(), "store.json"))
	s.db.Users["ana"] = User{Name: "ana", Beta: true}
	s.sessions["ana-token"] = "ana"
	for i := 0; i < 4; i++ {
		res := stableRequest(s, "ana", "POST", "/api/name-presets", map[string]any{"action": "save", "name": "Preset", "style": exampleNameStyle()})
		if i < 3 && res.Code != 200 {
			t.Fatalf("premature limit %d %s", res.Code, res.Body)
		}
		if i == 3 && res.Code != 429 {
			t.Fatalf("limit not applied: %d", res.Code)
		}
	}
}
func TestNotificationRetentionPerAccountAndReload(t *testing.T) {
	s := newServer(filepath.Join(t.TempDir(), "store.json"))
	for _, u := range []string{"ana", "bia", "sender"} {
		s.db.Users[u] = User{Name: u}
	}
	s.enqueueNotificationLocked("bia", "direct", "sender", "", "", "Private notification")
	for i := 0; i < 1200; i++ {
		s.enqueueNotificationLocked("ana", "direct", "sender", "", "", fmt.Sprintf("event %d", i))
	}
	a, b := 0, 0
	for _, n := range s.db.Notifications {
		if n.User == "ana" {
			a++
		}
		if n.User == "bia" {
			b++
		}
	}
	if a != maxNotificationsPerUser || b != 1 {
		t.Fatalf("global eviction: ana=%d bia=%d", a, b)
	}
	if err := s.save(); err != nil {
		t.Fatal(err)
	}
	restored := newServer(s.file)
	got := 0
	for _, n := range restored.db.Notifications {
		if n.User == "bia" && n.Text == "Private notification" {
			got++
		}
	}
	if got != 1 {
		t.Fatal("unread notification lost on restart")
	}
}
