package main

import (
	"bytes"
	"encoding/json"
	"fmt"
	"net/http"
	"net/http/httptest"
	"path/filepath"
	"runtime"
	"strings"
	"sync"
	"testing"
	"time"
)

func TestResourceGuardPerAccountAndBurst(t *testing.T) {
	g := newResourceGuard()
	at := time.Date(2026, 10, 31, 0, 0, 0, 0, time.UTC)
	for i := 0; i < messageBurst; i++ {
		if !g.allow("a", "message", at) {
			t.Fatalf("blocked legitimate burst at %d", i)
		}
	}
	if g.allow("a", "message", at) {
		t.Fatal("did not stop burst")
	}
	if !g.allow("b", "message", at) {
		t.Fatal("one account throttled another")
	}
	if !g.allow("a", "upload", at) {
		t.Fatal("message burst blocked unrelated upload")
	}
	if !g.allow("a", "message", at.Add(messageWindow)) {
		t.Fatal("window did not recover")
	}
	for i := 1; i < uploadBurst; i++ {
		if !g.allow("a", "upload", at) {
			t.Fatal("premature upload limit")
		}
	}
	if g.allow("a", "upload", at) {
		t.Fatal("upload limit not enforced")
	}
}

func TestHeavyWriteGuardThrottlesWithoutBlockingOthers(t *testing.T) {
	s := newServer(filepath.Join(t.TempDir(), "store.json"))
	for _, u := range []string{"alice", "bob"} {
		s.db.Users[u] = User{Name: u, DisplayName: u, AccountID: u}
		s.sessions[u+"-token"] = u
	}
	h := s.routes()
	for i := 0; i < messageBurst+1; i++ {
		data, _ := json.Marshal(map[string]string{"text": fmt.Sprintf("hello %d", i)})
		req := httptest.NewRequest("POST", "/api/messages", bytes.NewReader(data))
		req.Header.Set("Authorization", "Bearer alice-token")
		rec := httptest.NewRecorder()
		h.ServeHTTP(rec, req)
		if i == messageBurst && rec.Code != 429 {
			t.Fatalf("limit returned %d", rec.Code)
		}
		if i < messageBurst && rec.Code == 429 {
			t.Fatalf("early 429 on %d", i)
		}
	}
	req := httptest.NewRequest("POST", "/api/messages", strings.NewReader(`{"text":"other"}`))
	req.Header.Set("Authorization", "Bearer bob-token")
	rec := httptest.NewRecorder()
	h.ServeHTTP(rec, req)
	if rec.Code != 201 {
		t.Fatalf("second user blocked: %d %s", rec.Code, rec.Body.String())
	}
}

func TestThirtyConcurrentUsersLocalStorage(t *testing.T) {
	if testing.Short() {
		t.Skip("local storage concurrency check")
	}
	s := newServer(filepath.Join(t.TempDir(), "store.json"))
	for i := 0; i < 30; i++ {
		u := fmt.Sprintf("user%02d", i)
		s.db.Users[u] = User{Name: u, DisplayName: u, AccountID: u}
		s.sessions[u+"-token"] = u
	}
	h := s.routes()
	var wg sync.WaitGroup
	failures := make(chan string, 30)
	start := time.Now()
	for i := 0; i < 30; i++ {
		wg.Add(1)
		go func(i int) {
			defer wg.Done()
			req := httptest.NewRequest("POST", "/api/messages", strings.NewReader(fmt.Sprintf(`{"text":"hello from user %d"}`, i)))
			req.Header.Set("Authorization", fmt.Sprintf("Bearer user%02d-token", i))
			rec := httptest.NewRecorder()
			h.ServeHTTP(rec, req)
			if rec.Code != 201 {
				failures <- fmt.Sprintf("client %d: %d %s", i, rec.Code, rec.Body.String())
			}
		}(i)
	}
	wg.Wait()
	close(failures)
	for err := range failures {
		t.Error(err)
	}
	if len(s.db.Messages) != 30 {
		t.Fatalf("persisted messages=%d", len(s.db.Messages))
	}
	var memory runtime.MemStats
	runtime.ReadMemStats(&memory)
	t.Logf("30 users, 30 concurrent writes (local JSON file): elapsed=%s, allocated_memory=%d MiB; not a VPS/PostgreSQL benchmark", time.Since(start), memory.Alloc>>20)
}

func TestRecentChannelHistoryRespectsLimitAndOrder(t *testing.T) {
	s := newServer(filepath.Join(t.TempDir(), "store.json"))
	s.db.Users["a"] = User{Name: "a"}
	s.sessions["token"] = "a"
	c := Community{ID: "c", Name: "C", Owner: "a", Members: []string{"a"}, Channels: []string{"geral"}, ChannelMeta: map[string]ChannelMeta{"geral": {Type: "text"}}}
	s.db.Communities = []Community{c}
	for i := 0; i < 260; i++ {
		s.db.Messages = append(s.db.Messages, Message{ID: fmt.Sprintf("%d", i), Author: "a", Channel: "c:geral", Text: fmt.Sprintf("msg%d", i)})
	}
	req := httptest.NewRequest(http.MethodGet, "/api/channel-messages?community=c&channel=geral", nil)
	req.Header.Set("Authorization", "Bearer token")
	rec := httptest.NewRecorder()
	s.channelMessages(rec, req)
	if rec.Code != 200 {
		t.Fatalf("status %d: %s", rec.Code, rec.Body.String())
	}
	var out []Message
	if err := json.Unmarshal(rec.Body.Bytes(), &out); err != nil {
		t.Fatal(err)
	}
	if len(out) != 100 || out[0].Text != "msg160" || out[99].Text != "msg259" {
		t.Fatalf("unexpected page: count=%d first=%s last=%s", len(out), out[0].Text, out[len(out)-1].Text)
	}
}

func TestEventStreamBounded(t *testing.T) {
	s := newServer(filepath.Join(t.TempDir(), "store.json"))
	s.db.Users["a"] = User{Name: "a"}
	s.sessions["a-token"] = "a"
	for i := 0; i < 150; i++ {
		s.listeners[make(chan string, 1)] = "a"
	}
	req := httptest.NewRequest(http.MethodGet, "/api/events", nil)
	req.Header.Set("Authorization", "Bearer a-token")
	rec := httptest.NewRecorder()
	s.events(rec, req)
	if rec.Code != 503 {
		t.Fatalf("unbounded SSE streams: %d", rec.Code)
	}
}
