@echo off
setlocal EnableExtensions EnableDelayedExpansion
cd /d "%~dp0"
echo.
echo === EXPLICIT - PRIMEIRA ATIVACAO DO OWNER ===
echo Este procedimento vincula UMA CONTA EXISTENTE ao Owner permanentemente.
echo Use a mesma configuracao de banco de dados do servidor principal.
echo Antes de continuar, faca backup e DESLIGUE o servidor antigo.
echo.
set /p "OWNER_NAME=Nome de usuario EXATO que sera Owner (ex: usuario_owner): "
if not defined OWNER_NAME (echo Nome obrigatorio. & exit /b 1)
echo(!OWNER_NAME!| findstr /R /C:"^[a-zA-Z0-9_.-][a-zA-Z0-9_.-]*$" >nul
if errorlevel 1 (echo Nome deve usar apenas letras, numeros, ponto, hifen ou underline. & exit /b 1)
set /p "CONFIRM_OWNER=Digite VINCULAR para confirmar: "
if /I not "!CONFIRM_OWNER!"=="VINCULAR" (echo Cancelado. & exit /b 1)
set "EXPLICIT_BOOTSTRAP_OWNER=!OWNER_NAME!"
call "%~dp0INICIAR_RADMIN_POSTGRES.cmd"
set "EXPLICIT_BOOTSTRAP_OWNER="
echo.
echo Verifique o log do servidor. Se foi ativado, reinicie NORMALMENTE sem esta rotina.
endlocal
