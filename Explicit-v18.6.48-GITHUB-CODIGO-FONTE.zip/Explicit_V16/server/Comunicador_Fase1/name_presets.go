package main

import (
	"net/http"
	"regexp"
	"strings"
	"unicode/utf8"
)

// Names are rendered as plain text. Only whitelisted presentation data reaches the client.
type NameStyle struct {
	Color           string `json:"color"`
	Color2          string `json:"color2"`
	Color3          string `json:"color3"`
	Gradient        bool   `json:"gradient"`
	Font            string `json:"font"`
	Weight          int    `json:"weight"`
	Spacing         int    `json:"spacing"` // tenths of px
	ShadowColor     string `json:"shadow_color"`
	ShadowBlur      int    `json:"shadow_blur"`
	Glow            int    `json:"glow"`
	OutlineColor    string `json:"outline_color"`
	Outline         int    `json:"outline"` // integer px
	Animation       string `json:"animation"`
	Speed           int    `json:"speed"` // seconds
	Effect          string `json:"effect,omitempty"`
	EffectIntensity int    `json:"effect_intensity,omitempty"` // 0..100
	Flare           bool   `json:"flare,omitempty"`
	FlareColor      string `json:"flare_color,omitempty"`
	FlareIntensity  int    `json:"flare_intensity,omitempty"` // legacy 0..100
}

const maxSavedNamePresets = 5

type NamePreset struct {
	ID    string    `json:"id"`
	Name  string    `json:"name"`
	Style NameStyle `json:"style"`
}

var nameColorRe = regexp.MustCompile(`^#[0-9a-fA-F]{6}$`)

func validNameStyle(v NameStyle) bool {
	for _, c := range []string{v.Color, v.Color2, v.Color3, v.ShadowColor, v.OutlineColor} {
		if !nameColorRe.MatchString(c) {
			return false
		}
	}
	fonts := map[string]bool{"default": true, "modern": true, "rounded": true, "serif": true, "mono": true, "elegant": true, "condensed": true}
	animations := map[string]bool{"none": true}
	effects := map[string]bool{"": true, "none": true}
	effect := v.Effect
	effectIntensity := v.EffectIntensity
	if effect == "" && v.Flare {
		effect = "none"
		effectIntensity = 0
	}
	legacyFlareOK := !v.Flare || (nameColorRe.MatchString(v.FlareColor) && v.FlareIntensity >= 0 && v.FlareIntensity <= 100)
	return legacyFlareOK && effects[effect] && effectIntensity >= 0 && effectIntensity <= 100 && fonts[v.Font] && animations[v.Animation] && v.Weight >= 400 && v.Weight <= 900 && v.Weight%100 == 0 && v.Spacing >= -10 && v.Spacing <= 40 && v.ShadowBlur >= 0 && v.ShadowBlur <= 24 && v.Glow >= 0 && v.Glow <= 30 && v.Outline >= 0 && v.Outline <= 2 && v.Speed >= 2 && v.Speed <= 15
}
func hasNameStyles(u User) bool {
	return u.Beta || explicitPlusActive(u) || systemLevel(systemRole(u)) >= 2
}
func activeNameStyle(u User) *NameStyle {
	if !hasNameStyles(u) {
		return nil
	}
	for _, p := range u.NamePresets {
		if p.ID == u.EquippedNamePreset {
			style := p.Style
			return &style
		}
	}
	return nil
}
func (s *Server) namePresetsAPI(w http.ResponseWriter, r *http.Request) {
	user, err := s.auth(r)
	if err != nil {
		http.Error(w, "unauthorized", 401)
		return
	}
	s.mu.Lock()
	defer s.mu.Unlock()
	u := s.db.Users[user]
	if r.Method == http.MethodGet {
		if r.URL.Query().Has("users") {
			names := strings.Split(r.URL.Query().Get("users"), ",")
			if len(names) > 100 {
				http.Error(w, "too many names", 400)
				return
			}
			styles := map[string]*NameStyle{}
			for _, name := range names {
				name = strings.TrimSpace(name)
				if len(name) > 64 || name == "" {
					continue
				}
				if other, ok := s.db.Users[name]; ok {
					styles[name] = activeNameStyle(other)
				}
			}
			reply(w, 200, map[string]any{"styles": styles})
			return
		}
		presets := u.NamePresets
		if presets == nil {
			presets = []NamePreset{}
		}
		reply(w, 200, map[string]any{"enabled": hasNameStyles(u), "presets": presets, "equipped": u.EquippedNamePreset})
		return
	}
	if r.Method != http.MethodPost {
		http.Error(w, "method", 405)
		return
	}
	if !hasNameStyles(u) {
		http.Error(w, "Explicit+ ou Beta necessário", 403)
		return
	}
	var q struct {
		Action string    `json:"action"`
		ID     string    `json:"id"`
		Name   string    `json:"name"`
		Style  NameStyle `json:"style"`
	}
	if r.ContentLength > 8192 {
		http.Error(w, "request too large", 413)
		return
	}
	r.Body = http.MaxBytesReader(w, r.Body, 8192)
	if parse(r, &q) != nil {
		http.Error(w, "invalid", 400)
		return
	}
	old := u
	u.NamePresets = append([]NamePreset(nil), u.NamePresets...)
	switch q.Action {
	case "save":
		q.Name = strings.TrimSpace(q.Name)
		if q.Name == "" || utf8.RuneCountInString(q.Name) > 48 || !validNameStyle(q.Style) {
			http.Error(w, "invalid name or style", 400)
			return
		}
		if q.ID != "" {
			found := false
			for i := range u.NamePresets {
				if u.NamePresets[i].ID == q.ID {
					u.NamePresets[i].Name = q.Name
					u.NamePresets[i].Style = q.Style
					found = true
					break
				}
			}
			if !found {
				http.Error(w, "preset not found", 404)
				return
			}
		} else {
			if len(u.NamePresets) >= maxSavedNamePresets {
				http.Error(w, "Limite de cinco estilos atingido", http.StatusConflict)
				return
			}
			u.NamePresets = append(u.NamePresets, NamePreset{ID: token()[:16], Name: q.Name, Style: q.Style})
		}
	case "equip":
		if q.ID != "" {
			found := false
			for _, p := range u.NamePresets {
				if p.ID == q.ID {
					found = true
					break
				}
			}
			if !found {
				http.Error(w, "preset not found", 404)
				return
			}
		}
		u.EquippedNamePreset = q.ID
	case "delete":
		found := false
		for i, p := range u.NamePresets {
			if p.ID == q.ID {
				u.NamePresets = append(u.NamePresets[:i:i], u.NamePresets[i+1:]...)
				found = true
				break
			}
		}
		if !found {
			http.Error(w, "preset not found", 404)
			return
		}
		if u.EquippedNamePreset == q.ID {
			u.EquippedNamePreset = ""
		}
	default:
		http.Error(w, "invalid action", 400)
		return
	}
	s.db.Users[user] = u
	if err := s.save(); err != nil {
		s.db.Users[user] = old
		http.Error(w, "storage failure", 500)
		return
	}
	reply(w, 200, map[string]any{"ok": true, "equipped": u.EquippedNamePreset})
}
