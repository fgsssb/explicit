package main

import "time"

// Legacy grants without an expiry remain active until an administrator sets a term.
// The deadline, not the client badge, is authoritative across all endpoints.
func explicitPlusActive(u User) bool {
	return u.ExplicitPlus && (u.ExplicitPlusExpiresAt == nil || time.Now().Before(*u.ExplicitPlusExpiresAt))
}

func explicitPlusExpiry(u User) any {
	if u.ExplicitPlusExpiresAt == nil {
		return nil
	}
	return u.ExplicitPlusExpiresAt
}

// Badge names are a fixed server-side allowlist; client badges never convey authority.
// Admin denotes an actual global moderation role, not a cosmetic grant.
func userBadges(u User) []string {
	badges := make([]string, 0, 3)
	if systemRole(u) == "owner" {
		badges = append(badges, "owner")
	} else if systemLevel(systemRole(u)) > 0 {
		badges = append(badges, "staff")
	}
	if u.Beta && len(badges) < 2 {
		badges = append(badges, "beta")
	}
	if explicitPlusActive(u) && len(badges) < 2 {
		badges = append(badges, "explicit_plus")
	}
	return badges
}

func parseBadgeSelection(badges []string) (staff, beta, plus bool, ok bool) {
	if len(badges) > 2 {
		return false, false, false, false
	}
	seen := map[string]bool{}
	for _, b := range badges {
		if seen[b] {
			return false, false, false, false
		}
		seen[b] = true
		switch b {
		case "staff":
			staff = true
		case "beta":
			beta = true
		case "explicit_plus":
			plus = true
		default:
			return false, false, false, false
		}
	}
	return staff, beta, plus, true
}
