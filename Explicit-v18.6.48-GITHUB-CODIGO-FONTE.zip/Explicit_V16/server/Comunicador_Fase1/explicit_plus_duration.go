package main

// Explicit+ uses a bounded staff-specified lease. Client times never decide entitlement.
// Ten years is an operational safety cap, not a subscription restriction.
func validExplicitPlusDuration(seconds int64) bool {
	return seconds >= 1 && seconds <= 10*365*24*60*60
}
