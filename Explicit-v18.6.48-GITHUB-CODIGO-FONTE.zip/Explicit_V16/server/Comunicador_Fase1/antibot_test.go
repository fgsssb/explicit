package main

import (
	"os"
	"path/filepath"
	"testing"
)

func TestExplicitCaptchaAndRegistrationLimits(t *testing.T) {
	s := newServer(filepath.Join(t.TempDir(), "store.json"))
	// Production response verification: invalid challenges must never be accepted.
	old := os.Getenv("EXPLICIT_TEST_SKIP_ANTIBOT")
	os.Unsetenv("EXPLICIT_TEST_SKIP_ANTIBOT")
	defer os.Setenv("EXPLICIT_TEST_SKIP_ANTIBOT", old)
	if s.verifyCaptcha("nonexistent", "AAAAA") {
		t.Fatal("missing captcha accepted")
	}
	if validDeviceID("short") {
		t.Fatal("bad device accepted")
	}
}
