package main

import (
	"regexp"
	"time"
)

// A client-supplied, per-message nonce makes retrying after an ambiguous
// network timeout safe. Stored alongside each message, so process restarts
// do not create duplicates. Old clients can omit it.
var chatClientIDPattern = regexp.MustCompile(`^[a-f0-9-]{16,64}$`)

func validChatClientID(v string) bool { return v == "" || chatClientIDPattern.MatchString(v) }

// Caller holds s.mu. Limit the deduplication window to 24 hours; this also
// avoids scanning arbitrarily old history on busy instances.
func findChatRetry(messages []Message, author, channel, clientID string) *Message {
	if clientID == "" {
		return nil
	}
	cutoff := time.Now().Add(-24 * time.Hour)
	for i := len(messages) - 1; i >= 0; i-- {
		m := &messages[i]
		if m.Time.Before(cutoff) {
			break
		}
		if m.ClientID == clientID && m.Author == author && m.Channel == channel {
			return m
		}
	}
	return nil
}
