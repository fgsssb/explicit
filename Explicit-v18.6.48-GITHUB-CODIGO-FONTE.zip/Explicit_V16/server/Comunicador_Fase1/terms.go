package main

import (
	"net/http"
	"time"
)

// Version is stored alongside an auditable, server-created acceptance timestamp.
const currentTermsVersion = "2026-10-30-1"

func (s *Server) termsAPI(w http.ResponseWriter, r *http.Request) {
	name, err := s.auth(r)
	if err != nil {
		http.Error(w, "unauthorized", 401)
		return
	}
	switch r.Method {
	case http.MethodGet:
		s.mu.Lock()
		u := s.db.Users[name]
		s.mu.Unlock()
		reply(w, 200, map[string]any{"version": currentTermsVersion, "accepted": u.TermsAcceptedAt != nil && u.TermsVersion == currentTermsVersion, "accepted_at": u.TermsAcceptedAt})
	case http.MethodPost:
		var q struct {
			Accept  bool   `json:"accept"`
			Version string `json:"version"`
		}
		if parse(r, &q) != nil || !q.Accept || q.Version != currentTermsVersion {
			http.Error(w, "Confirme a versão integral das regras", 400)
			return
		}
		s.mu.Lock()
		defer s.mu.Unlock()
		u := s.db.Users[name]
		prior := u
		if u.TermsAcceptedAt == nil || u.TermsVersion != currentTermsVersion {
			now := time.Now().UTC()
			u.TermsAcceptedAt = &now
			u.TermsVersion = currentTermsVersion
			s.db.Users[name] = u
			if err := s.save(); err != nil {
				s.db.Users[name] = prior
				http.Error(w, "storage error", 500)
				return
			}
		}
		for key, owner := range s.sessions {
			if owner == name {
				delete(s.termsPending, key)
			}
		}
		reply(w, 200, map[string]any{"accepted": true, "version": currentTermsVersion, "accepted_at": u.TermsAcceptedAt})
	default:
		http.Error(w, "method", 405)
	}
}
