package main

import (
	"encoding/json"
	"net/http/httptest"
	"strings"
	"testing"
)

func TestNewCommunityDefaultVoiceAndLegacyUnchanged(t *testing.T) {
	s := newServer(t.TempDir() + "/data.json")
	s.mu.Lock()
	s.sessions["voice-test"] = "ana"
	s.db.Users["ana"] = User{Name: "ana"}
	s.db.Communities = []Community{{ID: "legacy", Name: "Antiga", Owner: "ana", Members: []string{"ana"}, Channels: []string{"geral"}, ChannelMeta: map[string]ChannelMeta{"geral": {Type: "text"}}}}
	if err := s.save(); err != nil {
		s.mu.Unlock()
		t.Fatal(err)
	}
	s.mu.Unlock()
	r := httptest.NewRequest("POST", "/api/communities", strings.NewReader(`{"name":"Nova comunidade"}`))
	r.Header.Set("Authorization", "Bearer voice-test")
	w := httptest.NewRecorder()
	s.routes().ServeHTTP(w, r)
	if w.Code != 201 {
		t.Fatalf("criar comunidade: HTTP %d: %s", w.Code, w.Body.String())
	}
	var created Community
	if err := json.Unmarshal(w.Body.Bytes(), &created); err != nil {
		t.Fatal(err)
	}
	if len(created.Channels) != 2 || created.Channels[0] != "geral" || created.Channels[1] != "voz" {
		t.Fatalf("canais iniciais: %v", created.Channels)
	}
	if created.channelType("voz") != "voice" || created.channelType("geral") != "text" {
		t.Fatalf("metadados incorretos: %+v", created.ChannelMeta)
	}
	if len(created.Categories) != 2 || created.Categories[0].Name != "TEXTO" || created.Categories[1].Name != "VOZ" {
		t.Fatalf("categorias iniciais incorretas: %+v", created.Categories)
	}
	if created.ChannelMeta["geral"].Category != "texto" || created.ChannelMeta["voz"].Category != "voz" {
		t.Fatalf("vinculo inicial com categorias incorreto: %+v", created.ChannelMeta)
	}
	loaded := newServer(s.file)
	if len(loaded.db.Communities) != 2 {
		t.Fatalf("comunidades gravadas: %d", len(loaded.db.Communities))
	}
	if len(loaded.db.Communities[0].Channels) != 1 || loaded.db.Communities[0].Channels[0] != "geral" {
		t.Fatalf("comunidade anterior alterada: %+v", loaded.db.Communities[0].Channels)
	}
	if loaded.db.Communities[1].channelType("voz") != "voice" {
		t.Fatal("nova sala nao persistiu como voz")
	}
	if len(loaded.db.Communities[1].Categories) != 2 || loaded.db.Communities[1].ChannelMeta["geral"].Category != "texto" || loaded.db.Communities[1].ChannelMeta["voz"].Category != "voz" {
		t.Fatalf("categorias iniciais nao persistiram: %+v %+v", loaded.db.Communities[1].Categories, loaded.db.Communities[1].ChannelMeta)
	}
}
