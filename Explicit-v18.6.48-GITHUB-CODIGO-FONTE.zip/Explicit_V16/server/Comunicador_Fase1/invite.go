package main

import (
	"net/http"
	"os"
	"strings"
	"time"
)

const defaultInviteLimit = 5

func (s *Server) inviteLimitLocked() int {
	if s.db.InviteLimit <= 0 {
		return defaultInviteLimit
	}
	return s.db.InviteLimit
}

type InviteRedemption struct {
	Inviter string    `json:"inviter"`
	Invitee string    `json:"invitee"`
	At      time.Time `json:"at"`
}

func (s *Server) uniqueInviteKeyLocked() string {
	for {
		key := strings.ToUpper(token()[:20])
		found := false
		for _, u := range s.db.Users {
			if u.InviteKey == key {
				found = true
				break
			}
		}
		if !found {
			return key
		}
	}
}

// validateInviteLocked is the authoritative database validation for registration.
// Caller must hold s.mu; check and consume occur under the same lock.
// The local JSON store is authoritative today and can be replaced by a DB transaction later.
func (s *Server) validateInviteLocked(key string) (string, bool) {
	key = strings.ToUpper(strings.TrimSpace(key))
	if key == "" {
		return "", false
	}
	// Explicitly configured bootstrap key is limited to the initial account only.
	// It is never returned by the API and cannot be used after an account exists.
	if len(s.db.Users) == 0 && key == strings.ToUpper(strings.TrimSpace(os.Getenv("EXPLICIT_INITIAL_INVITE_KEY"))) && os.Getenv("EXPLICIT_INITIAL_INVITE_KEY") != "" {
		return "__bootstrap__", true
	}
	for name, u := range s.db.Users {
		if u.InviteKey != key {
			continue
		}
		if u.BannedPermanent || (u.BannedUntil != nil && time.Now().Before(*u.BannedUntil)) {
			return "", false
		}
		if systemRole(u) == "admin" || systemRole(u) == "superadmin" {
			return name, true
		}
		used := 0
		for _, entry := range s.db.Invites {
			if entry.Inviter == name {
				used++
			}
		}
		return name, used < s.inviteLimitLocked()
	}
	return "", false
}

func (s *Server) inviteAPI(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodGet {
		http.Error(w, "method", 405)
		return
	}
	name, err := s.auth(r)
	if err != nil {
		http.Error(w, "unauthorized", 401)
		return
	}
	s.mu.Lock()
	defer s.mu.Unlock()
	u := s.db.Users[name]
	used := 0
	for _, entry := range s.db.Invites {
		if entry.Inviter == name {
			used++
		}
	}
	unlimited := systemRole(u) == "admin" || systemRole(u) == "superadmin"
	limit := s.inviteLimitLocked()
	remaining := limit - used
	if remaining < 0 {
		remaining = 0
	}
	reply(w, 200, map[string]any{"key": u.InviteKey, "used": used, "limit": limit, "remaining": remaining, "unlimited": unlimited})
}
