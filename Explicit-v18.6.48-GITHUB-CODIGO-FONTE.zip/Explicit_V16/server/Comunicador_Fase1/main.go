package main

import (
	"crypto/hmac"
	"crypto/rand"
	"crypto/sha256"
	"crypto/subtle"
	"encoding/binary"
	"encoding/hex"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"log"
	"log/slog"
	"net"
	"net/http"
	"net/mail"
	"os"
	"path/filepath"
	"runtime"
	"strings"
	"sync"
	"time"
	"unicode"
	"unicode/utf8"
)

type User struct {
	Name                   string             `json:"name"`
	AccountID              string             `json:"account_id,omitempty"`
	DisplayName            string             `json:"display_name,omitempty"`
	Email                  string             `json:"email,omitempty"`
	Avatar                 string             `json:"avatar,omitempty"`
	NamePresets            []NamePreset       `json:"name_presets,omitempty"`
	EquippedNamePreset     string             `json:"equipped_name_preset,omitempty"`
	InviteKey              string             `json:"invite_key,omitempty"`
	InvitedBy              string             `json:"invited_by,omitempty"`
	SystemRole             string             `json:"system_role,omitempty"`
	TermsAcceptedAt        *time.Time         `json:"terms_accepted_at,omitempty"`
	TermsVersion           string             `json:"terms_version,omitempty"`
	Beta                   bool               `json:"beta,omitempty"`
	ExplicitPlus           bool               `json:"explicit_plus,omitempty"`
	ExplicitPlusExpiresAt  *time.Time         `json:"explicit_plus_expires_at,omitempty"`
	OtherNoticesRead       int64              `json:"other_notices_read,omitempty"`
	DirectNoticesRead      map[string]int64   `json:"direct_notices_read,omitempty"`
	BannedUntil            *time.Time         `json:"banned_until,omitempty"`
	BannedPermanent        bool               `json:"banned_permanent,omitempty"`
	PreferredStatus        string             `json:"preferred_status,omitempty"`
	NotificationPrefs      *NotifyPreferences `json:"notification_prefs,omitempty"`
	Salt                   string             `json:"salt"`
	Hash                   string             `json:"hash"`
	RequirePasswordChange  bool               `json:"require_password_change,omitempty"`
	RegistrationIPHash     string             `json:"registration_ip_hash,omitempty"`
	RegistrationDeviceHash string             `json:"registration_device_hash,omitempty"`
}
type Message struct {
	ID       string     `json:"id"`
	ClientID string     `json:"client_id,omitempty"`
	Channel  string     `json:"channel"`
	Author   string     `json:"author"`
	Text     string     `json:"text"`
	Image    string     `json:"image,omitempty"`
	Video    string     `json:"video,omitempty"`
	Sticker  string     `json:"sticker,omitempty"`
	Time     time.Time  `json:"time"`
	EditedAt *time.Time `json:"edited_at,omitempty"`
	EditedBy string     `json:"edited_by,omitempty"`
	Deleted  bool       `json:"deleted,omitempty"`
	Pinned   bool       `json:"pinned,omitempty"`
}
type Community struct {
	ID          string                 `json:"id"`
	Name        string                 `json:"name"`
	Owner       string                 `json:"owner"`
	CardImage   string                 `json:"card_image,omitempty"`
	Members     []string               `json:"members"`
	Channels    []string               `json:"channels"`
	ChannelMeta map[string]ChannelMeta `json:"channel_meta,omitempty"`
	Roles       []Role                 `json:"roles,omitempty"`
	MemberRoles map[string][]string    `json:"member_roles,omitempty"`
	Categories  []ChannelCategory      `json:"categories,omitempty"`
	AFKChannel  string                 `json:"afk_channel_id,omitempty"`
	AFKTimeout  int                    `json:"afk_timeout_seconds,omitempty"`
	AFKEnabled  bool                   `json:"afk_enabled,omitempty"`
	InviteCode  string                 `json:"invite_code,omitempty"`
	JoinClosed  bool                   `json:"join_closed,omitempty"`
}
type ChannelMeta struct {
	// Private is a derived, display-only marker in visible community responses.
	Private           bool                       `json:"private,omitempty"`
	Type              string                     `json:"type"`
	Limit             int                        `json:"limit,omitempty"`
	RolePermissions   map[string]map[string]bool `json:"role_permissions,omitempty"`
	MemberPermissions map[string]map[string]bool `json:"member_permissions,omitempty"`
	Category          string                     `json:"category,omitempty"`
	Synced            bool                       `json:"synced,omitempty"`
}
type ChannelCategory struct {
	ID                string                     `json:"id"`
	Name              string                     `json:"name"`
	RolePermissions   map[string]map[string]bool `json:"role_permissions,omitempty"`
	MemberPermissions map[string]map[string]bool `json:"member_permissions,omitempty"`
}
type Role struct {
	ID          string   `json:"id"`
	Name        string   `json:"name"`
	Color       string   `json:"color"`
	Priority    int      `json:"priority"`
	Permissions []string `json:"permissions"`
}
type StaffMute struct {
	ID        string    `json:"id"`
	Community string    `json:"community"`
	Channel   string    `json:"channel,omitempty"`
	Target    string    `json:"target,omitempty"`
	Medium    string    `json:"medium"`
	Actor     string    `json:"actor"`
	Reason    string    `json:"reason"`
	Created   time.Time `json:"created"`
}
type StaffAuditEntry struct {
	At       time.Time `json:"at"`
	Actor    string    `json:"actor"`
	Action   string    `json:"action"`
	Target   string    `json:"target"`
	Details  string    `json:"details"`
	PrevHash string    `json:"prev_hash"`
	Hash     string    `json:"hash"`
}
type CommunityVoiceRestriction struct {
	Muted bool `json:"muted"`
	Deaf  bool `json:"deaf"`
}

type Store struct {
	VoiceRestrictions       map[string]map[string]CommunityVoiceRestriction `json:"voice_restrictions,omitempty"`
	OwnerAccountID          string                                          `json:"owner_account_id,omitempty"`
	StaffMutes              []StaffMute                                     `json:"staff_mutes,omitempty"`
	StaffAudit              []StaffAuditEntry                               `json:"staff_audit,omitempty"`
	Communities             []Community                                     `json:"communities"`
	Users                   map[string]User                                 `json:"users"`
	Messages                []Message                                       `json:"messages"`
	Sanctions               []Sanction                                      `json:"sanctions,omitempty"`
	Friends                 []FriendRequest                                 `json:"friends,omitempty"`
	DirectChats             []DirectChat                                    `json:"direct_chats,omitempty"`
	SystemAudit             []SystemAuditEntry                              `json:"system_audit,omitempty"`
	Reports                 []SystemReport                                  `json:"system_reports,omitempty"`
	Invites                 []InviteRedemption                              `json:"invite_redemptions"`
	CommunityInvites        []CommunityInvite                               `json:"community_invites,omitempty"`
	RequireInvite           bool                                            `json:"require_invite"`
	InviteLimit             int                                             `json:"invite_limit,omitempty"`
	Spotlights              []Spotlight                                     `json:"spotlights,omitempty"`
	SpotlightRequests       []SpotlightRequest                              `json:"spotlight_requests,omitempty"`
	RegistrationSecret      string                                          `json:"registration_secret,omitempty"`
	HomeMode                string                                          `json:"home_mode,omitempty"`
	HomeModeConfiguredV1869 bool                                            `json:"home_mode_configured_v1869,omitempty"`
	Changelog               string                                          `json:"changelog,omitempty"`
	Announcements           []StaffAnnouncement                             `json:"announcements,omitempty"`
	Stickers                []Sticker                                       `json:"stickers,omitempty"`
	Notifications           []AppNotification                               `json:"notifications,omitempty"`
	CommunityPrefs          map[string]CommunityUserPrefs                   `json:"community_prefs,omitempty"`
	StickerFavorites        map[string][]string                             `json:"sticker_favorites,omitempty"`
}
type Server struct {
	mu            sync.Mutex
	db            Store
	file          string
	sessions      map[string]string
	sessionExpiry map[string]time.Time
	listeners     map[chan string]string
	loginAttempts map[string][]time.Time
	captchaMu     sync.Mutex
	captchas      map[string]explicitCaptcha
	captchaIssued map[string][]time.Time
	privateReadAt map[string]time.Time
	termsPending  map[string]bool
	resources     *resourceGuard
}

func token() string {
	b := make([]byte, 32)
	if _, err := rand.Read(b); err != nil {
		panic(err)
	}
	return hex.EncodeToString(b)
}
func hash(salt, password string) string {
	h := sha256.Sum256([]byte(salt + password))
	return hex.EncodeToString(h[:])
}

// PBKDF2-HMAC-SHA256 (120,000 rounds), encoded with a version prefix.
// Legacy salted SHA-256 hashes are upgraded on successful authentication.
func secureHash(salt, password string) string {
	key := []byte(password)
	saltBytes := []byte(salt)
	var block [4]byte
	binary.BigEndian.PutUint32(block[:], 1)
	mac := hmac.New(sha256.New, key)
	mac.Write(saltBytes)
	mac.Write(block[:])
	u := mac.Sum(nil)
	out := append([]byte(nil), u...)
	for i := 1; i < 120000; i++ {
		mac.Reset()
		mac.Write(u)
		u = mac.Sum(nil)
		for j := range out {
			out[j] ^= u[j]
		}
	}
	return "pbkdf2-sha256$120000$" + hex.EncodeToString(out)
}
func checkPassword(u User, password string) bool {
	var expected string
	if strings.HasPrefix(u.Hash, "pbkdf2-sha256$120000$") {
		expected = secureHash(u.Salt, password)
	} else {
		expected = hash(u.Salt, password)
	}
	return subtle.ConstantTimeCompare([]byte(u.Hash), []byte(expected)) == 1
}
func validDisplayName(v string) bool {
	n := utf8.RuneCountInString(v)
	if n < 2 || n > 40 || len(v) > 160 {
		return false
	}
	for _, r := range v {
		if unicode.IsControl(r) {
			return false
		}
	}
	return true
}
func newServer(path string) *Server {
	s := &Server{file: path, sessions: map[string]string{}, sessionExpiry: map[string]time.Time{}, listeners: map[chan string]string{}, loginAttempts: map[string][]time.Time{}, privateReadAt: map[string]time.Time{}, resources: newResourceGuard(), db: Store{Users: map[string]User{}, Messages: []Message{}}}
	var b []byte
	var e error
	if path == "data/store.json" && os.Getenv("EXPLICIT_MYSQL_CONFIG") != "" {
		b, e = mysqlLoad()
		if e != nil {
			log.Fatalf("MySQL initialization failed: %v", e)
		}
	} else if path == "data/store.json" && os.Getenv("PGDATABASE") != "" {
		b, e = postgresLoad()
		if e != nil {
			log.Fatalf("PostgreSQL initialization failed: %v", e)
		}
	} else {
		b, e = os.ReadFile(path)
	}
	// Nunca inicializar um banco vazio se o existente estiver ilegível ou corrompido.
	if e != nil && !os.IsNotExist(e) {
		log.Fatalf("STORAGE ERROR opening %q: %v; database not overwritten", path, e)
	}
	if e == nil && len(b) > 0 {
		if e = json.Unmarshal(b, &s.db); e != nil {
			log.Fatalf("STORAGE ERROR invalid database %q: %v; database not overwritten", path, e)
		}
	}
	if s.db.StaffAudit == nil {
		s.db.StaffAudit = []StaffAuditEntry{}
	}
	if s.db.Users == nil {
		s.db.Users = map[string]User{}
	}
	migratedIdentity := false
	for id, u := range s.db.Users {
		if u.AccountID == "" {
			u.AccountID = token()
			migratedIdentity = true
		}
		if u.SystemRole == "owner" && (s.db.OwnerAccountID == "" || u.AccountID != s.db.OwnerAccountID) {
			u.SystemRole = "superadmin" // Never trust a disconnected badge/role as owner.
		}
		if s.db.OwnerAccountID != "" && u.AccountID == s.db.OwnerAccountID {
			u.SystemRole = "owner"
		} else if s.db.OwnerAccountID != "" && u.SystemRole == "superadmin" {
			// Previous versions used a superadmin tier. With an Owner bound,
			// those grants become regular Admin roles; the Owner is the only
			// account able to grant/revoke Admin now.
			u.SystemRole = "moderator"
			migratedIdentity = true
		}
		if u.InviteKey == "" {
			u.InviteKey = s.uniqueInviteKeyLocked()
		}
		if u.DisplayName == "" {
			u.DisplayName = id
		}
		s.db.Users[id] = u
	}
	// IDs are immutable and must be unique; two accounts must never share Owner authority.
	ids := make(map[string]string, len(s.db.Users))
	ownerMatches := 0
	for username, u := range s.db.Users {
		if other, exists := ids[u.AccountID]; exists {
			log.Fatalf("DUPLICATE ACCOUNT ID for %q and %q: refuse startup", other, username)
		}
		ids[u.AccountID] = username
		if s.db.OwnerAccountID != "" && u.AccountID == s.db.OwnerAccountID {
			ownerMatches++
		}
	}
	if s.db.OwnerAccountID != "" && ownerMatches != 1 {
		log.Fatalf("OWNER ID MISSING OR AMBIGUOUS: refuse startup, restore backup offline")
	}
	if migratedIdentity {
		if err := s.save(); err != nil {
			log.Fatalf("ACCOUNT ID MIGRATION FAILED: %v", err)
		}
	}
	return s
}
func (s *Server) save() error {
	b, err := json.Marshal(s.db)
	if err != nil {
		log.Printf("STORAGE ERROR encoding database: %v", err)
		return err
	}
	if s.file == "data/store.json" && os.Getenv("EXPLICIT_MYSQL_CONFIG") != "" {
		err = mysqlSave(b)
	} else if s.file == "data/store.json" && os.Getenv("PGDATABASE") != "" {
		err = postgresSave(b)
	} else {
		err = persistLocalStore(s.file, b)
	}
	if err != nil {
		log.Printf("STORAGE ERROR saving %q: %v (verifique permissoes, espaco, antivirus e outros processos que usam o arquivo)", s.file, err)
	}
	return err
}

// Atomicidade e recuperação: gravação em arquivo temporário único; o arquivo
// existente continua intacto até a substituição. No Windows, antivírus pode
// momentaneamente impedir renomear arquivos; três tentativas curtas.
func persistLocalStore(path string, b []byte) error {
	if err := os.MkdirAll(filepath.Dir(path), 0700); err != nil {
		return fmt.Errorf("create data directory: %w", err)
	}
	f, err := os.CreateTemp(filepath.Dir(path), ".explicit-store-*.tmp")
	if err != nil {
		return fmt.Errorf("create temporary file: %w", err)
	}
	tmp := f.Name()
	defer os.Remove(tmp)
	if err = f.Chmod(0600); err == nil {
		_, err = f.Write(b)
	}
	if err == nil {
		err = f.Sync()
	}
	closeErr := f.Close()
	if err != nil {
		return fmt.Errorf("write/sync temporary file: %w", err)
	}
	if closeErr != nil {
		return fmt.Errorf("close temporary file: %w", closeErr)
	}
	for attempt := 0; attempt < 3; attempt++ {
		err = os.Rename(tmp, path)
		if err == nil {
			return nil
		}
		time.Sleep(time.Duration(attempt+1) * 80 * time.Millisecond)
	}
	// Algumas instalações Windows não permitem substituir arquivos existentes
	// por rename. Mover o banco anterior para backup antes de renomear o novo
	// preserva a versão anterior e permite reverter se a segunda etapa falhar.
	if runtime.GOOS == "windows" {
		if _, statErr := os.Stat(path); statErr == nil {
			backup := path + ".backup-" + time.Now().UTC().Format("20060102T150405.000000000")
			if backupErr := os.Rename(path, backup); backupErr == nil {
				if swapErr := os.Rename(tmp, path); swapErr == nil {
					log.Printf("STORAGE recovered Windows replacement; previous database saved in %q", backup)
					return nil
				} else {
					if restoreErr := os.Rename(backup, path); restoreErr != nil {
						return fmt.Errorf("CRITICAL storage replacement failed: %v; restore %q manually to %q: %w", swapErr, backup, path, restoreErr)
					}
					return fmt.Errorf("replace failed but previous database restored: %w", swapErr)
				}
			} else {
				return fmt.Errorf("Windows database file is locked or read-only: %w (initial replacement: %v)", backupErr, err)
			}
		}
	}
	return fmt.Errorf("replace previous database (previous file preserved): %w", err)
}
func reply(w http.ResponseWriter, status int, v any) {
	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(status)
	_ = json.NewEncoder(w).Encode(v)
}
func parse(r *http.Request, v any) error {
	r.Body = http.MaxBytesReader(nil, r.Body, 8192)
	decoder := json.NewDecoder(r.Body)
	if err := decoder.Decode(v); err != nil {
		return err
	}
	var trailing any
	if err := decoder.Decode(&trailing); err != io.EOF {
		if err == nil {
			return errors.New("unexpected trailing JSON")
		}
		return err
	}
	return nil
}
func (s *Server) auth(r *http.Request) (string, error) {
	t := strings.TrimPrefix(r.Header.Get("Authorization"), "Bearer ")
	s.mu.Lock()
	defer s.mu.Unlock()
	u, ok := s.sessions[t]
	if expiry, tracked := s.sessionExpiry[t]; tracked && !time.Now().Before(expiry) {
		delete(s.sessions, t)
		delete(s.sessionExpiry, t)
		return "", errors.New("session expired")
	}
	if !ok || t == "" {
		return "", errors.New("unauthorized")
	}
	account, exists := s.db.Users[u]
	if !exists || (account.BannedPermanent || (account.BannedUntil != nil && time.Now().Before(*account.BannedUntil))) {
		return "", errors.New("account suspended")
	}
	return u, nil
}
func (s *Server) register(w http.ResponseWriter, r *http.Request) {
	if r.Method != "POST" {
		http.Error(w, "method", 405)
		return
	}
	if !s.allowLogin("register:" + registrationRemoteIP(r)) {
		http.Error(w, "too many registrations", 429)
		return
	}
	var q struct {
		Name          string `json:"name"`
		Password      string `json:"password"`
		DisplayName   string `json:"display_name"`
		Email         string `json:"email"`
		InviteKey     string `json:"invite_key"`
		CaptchaID     string `json:"captcha_id"`
		CaptchaAnswer string `json:"captcha_answer"`
		DeviceID      string `json:"device_id"`
	}
	q.DisplayName = strings.TrimSpace(q.DisplayName)
	if parseErr := parse(r, &q); parseErr != nil {
		reply(w, 400, map[string]string{"error": "Dados inválidos"})
		return
	}
	q.DisplayName = strings.TrimSpace(q.DisplayName)
	if !s.verifyCaptcha(q.CaptchaID, q.CaptchaAnswer) {
		reply(w, 403, map[string]string{"error": "CAPTCHA inválido ou expirado. Atualize e tente novamente."})
		return
	}
	q.Email = strings.ToLower(strings.TrimSpace(q.Email))
	if q.Email != "" {
		if _, err := mail.ParseAddress(q.Email); err != nil || !strings.Contains(q.Email, "@") || len(q.Email) > 254 || len(q.Email) < 5 {
			reply(w, 400, map[string]string{"error": "E-mail inválido"})
			return
		}
	}
	if len(q.Name) < 3 || len(q.Name) > 32 || strings.TrimSpace(q.Name) != q.Name || !validDisplayName(q.DisplayName) || len(q.Password) < 8 || len(q.Password) > 256 {
		reply(w, 400, map[string]string{"error": "Nome 3-32 caracteres; senha 8-256"})
		return
	}
	s.mu.Lock()
	defer s.mu.Unlock()
	inviter, valid := "", true
	if s.db.RequireInvite {
		inviter, valid = s.validateInviteLocked(q.InviteKey)
	}
	if !valid {
		reply(w, 403, map[string]string{"error": "Chave de convite inválida ou sem cadastros disponíveis"})
		return
	}
	if _, ok := s.db.Users[q.Name]; ok {
		reply(w, 409, map[string]string{"error": "Usuário existente"})
		return
	}
	for _, existing := range s.db.Users {
		if q.Email != "" && strings.EqualFold(existing.Email, q.Email) {
			reply(w, 409, map[string]string{"error": "E-mail já cadastrado"})
			return
		}
	}
	if s.db.RegistrationSecret == "" {
		s.db.RegistrationSecret = token()
	}
	ipHash := registrationHash(s.db.RegistrationSecret, registrationRemoteIP(r))
	deviceHash := ""
	if validDeviceID(q.DeviceID) {
		deviceHash = registrationHash(s.db.RegistrationSecret, q.DeviceID)
	}
	ipCount, deviceCount := 0, 0
	for _, u := range s.db.Users {
		if u.RegistrationIPHash != "" && u.RegistrationIPHash == ipHash {
			ipCount++
		}
		if deviceHash != "" && u.RegistrationDeviceHash == deviceHash {
			deviceCount++
		}
	}
	if ipCount >= 2 || deviceCount >= 2 {
		reply(w, 429, map[string]string{"error": "Limite de duas contas por IP ou dispositivo atingido."})
		return
	}
	salt := token()
	inviteKey := s.uniqueInviteKeyLocked()
	s.db.Users[q.Name] = User{Name: q.Name, DisplayName: q.DisplayName, Email: q.Email, InviteKey: inviteKey, InvitedBy: inviter, SystemRole: "user", AccountID: token(), Salt: salt, Hash: secureHash(salt, q.Password), RegistrationIPHash: ipHash, RegistrationDeviceHash: deviceHash}
	if inviter != "" {
		s.db.Invites = append(s.db.Invites, InviteRedemption{Inviter: inviter, Invitee: q.Name, At: time.Now().UTC()})
	}
	if e := s.save(); e != nil {
		delete(s.db.Users, q.Name)
		if inviter != "" {
			s.db.Invites = s.db.Invites[:len(s.db.Invites)-1]
		}
		reply(w, 500, map[string]string{"error": "Falha de armazenamento"})
		return
	}
	reply(w, 201, map[string]string{"status": "created"})
}

// allowLogin bounds PBKDF2 workload and periodically removes expired buckets.
func (s *Server) allowLogin(remote string) bool {
	host, _, err := net.SplitHostPort(remote)
	if err != nil {
		host = remote
	}
	now := time.Now()
	s.mu.Lock()
	defer s.mu.Unlock()
	if s.loginAttempts == nil {
		s.loginAttempts = make(map[string][]time.Time)
	}
	for ip, attempts := range s.loginAttempts {
		kept := attempts[:0]
		for _, t := range attempts {
			if now.Sub(t) < time.Minute {
				kept = append(kept, t)
			}
		}
		if len(kept) == 0 {
			delete(s.loginAttempts, ip)
		} else {
			s.loginAttempts[ip] = kept
		}
	}
	if len(s.loginAttempts[host]) >= 10 {
		return false
	}
	s.loginAttempts[host] = append(s.loginAttempts[host], now)
	return true
}
func (s *Server) login(w http.ResponseWriter, r *http.Request) {
	if r.Method != "POST" {
		http.Error(w, "method", 405)
		return
	}
	// Bound expensive password hashing attempts per source IP.
	if !s.allowLogin(registrationRemoteIP(r)) {
		w.Header().Set("Retry-After", "60")
		http.Error(w, "too many login attempts", http.StatusTooManyRequests)
		return
	}
	var q struct {
		Name          string `json:"name"`
		Password      string `json:"password"`
		CaptchaID     string `json:"captcha_id"`
		CaptchaAnswer string `json:"captcha_answer"`
	}
	if parse(r, &q) != nil || len(q.Password) > 256 {
		http.Error(w, "bad request", 400)
		return
	}
	if !s.verifyCaptcha(q.CaptchaID, q.CaptchaAnswer) {
		reply(w, 403, map[string]string{"error": "CAPTCHA inválido ou expirado."})
		return
	}
	// Snapshot credentials only; PBKDF2 must never hold the shared store mutex.
	s.mu.Lock()
	u, ok := s.db.Users[q.Name]
	s.mu.Unlock()
	if !ok || !checkPassword(u, q.Password) {
		reply(w, 401, map[string]string{"error": "Credenciais inválidas"})
		return
	}
	upgradedHash := ""
	if !strings.HasPrefix(u.Hash, "pbkdf2-sha256$") {
		upgradedHash = secureHash(u.Salt, q.Password)
	}
	s.mu.Lock()
	defer s.mu.Unlock()
	current, exists := s.db.Users[q.Name]
	if !exists || current.Hash != u.Hash || current.Salt != u.Salt {
		reply(w, 401, map[string]string{"error": "Credenciais alteradas; entre novamente"})
		return
	}
	u = current // Recheck current suspension/reset state after the expensive work.
	if u.BannedPermanent || (u.BannedUntil != nil && time.Now().Before(*u.BannedUntil)) {
		reply(w, 403, map[string]string{"error": "Conta suspensa no Explicit"})
		return
	}
	if u.RequirePasswordChange {
		reply(w, 200, map[string]any{"password_reset_required": true, "name": q.Name})
		return
	}
	if !strings.HasPrefix(u.Hash, "pbkdf2-sha256$") {
		old := u
		u.Hash = upgradedHash
		s.db.Users[q.Name] = u
		if err := s.save(); err != nil {
			s.db.Users[q.Name] = old
			reply(w, 500, map[string]string{"error": "Falha ao atualizar credenciais"})
			return
		}
	}
	t := token()
	s.sessions[t] = q.Name
	if s.termsPending == nil {
		s.termsPending = make(map[string]bool)
	}
	s.termsPending[t] = u.TermsAcceptedAt == nil || u.TermsVersion != currentTermsVersion
	if s.sessionExpiry == nil {
		s.sessionExpiry = make(map[string]time.Time)
	}
	s.sessionExpiry[t] = time.Now().Add(24 * time.Hour)
	reply(w, 200, map[string]string{"token": t, "name": q.Name, "display_name": s.displayName(q.Name)})
}
func (s *Server) messages(w http.ResponseWriter, r *http.Request) {
	name, e := s.auth(r)
	if e != nil {
		http.Error(w, "unauthorized", 401)
		return
	}
	switch r.Method {
	case "GET":
		s.mu.Lock()
		out := make([]Message, 0)
		for i := len(s.db.Messages) - 1; i >= 0 && len(out) < 100; i-- {
			if s.db.Messages[i].Channel == "geral" && !s.db.Messages[i].Deleted {
				out = append(out, s.db.Messages[i])
			}
		}
		for i, j := 0, len(out)-1; i < j; i, j = i+1, j-1 {
			out[i], out[j] = out[j], out[i]
		}
		s.mu.Unlock()
		reply(w, 200, out)
	case "POST":
		var q struct {
			Text     string `json:"text"`
			ClientID string `json:"client_id"`
		}
		if parse(r, &q) != nil || len(strings.TrimSpace(q.Text)) == 0 || len(q.Text) > 2000 || !validChatClientID(q.ClientID) {
			http.Error(w, "invalid message", 400)
			return
		}
		s.mu.Lock()
		if previous := findChatRetry(s.db.Messages, name, "geral", q.ClientID); previous != nil {
			s.mu.Unlock()
			if previous.Text != q.Text {
				http.Error(w, "client_id reused with different message", http.StatusConflict)
				return
			}
			reply(w, 200, previous)
			return
		}
		if abusiveMessageText(q.Text) || s.resources.excessiveRepeat(name, q.Text, time.Now()) {
			s.mu.Unlock()
			http.Error(w, "message flood rejected", http.StatusTooManyRequests)
			return
		}
		m := Message{ID: token()[:16], ClientID: q.ClientID, Channel: "geral", Author: name, Text: q.Text, Time: time.Now().UTC()}
		s.db.Messages = append(s.db.Messages, m)
		if e = s.save(); e != nil {
			s.db.Messages = s.db.Messages[:len(s.db.Messages)-1]
			s.mu.Unlock()
			http.Error(w, "storage failure", 500)
			return
		}
		b, _ := json.Marshal(m)
		for c := range s.listeners {
			select {
			case c <- string(b):
			default:
			}
		}
		s.mu.Unlock()
		reply(w, 201, m)
	default:
		http.Error(w, "method", 405)
	}
}
func (s *Server) events(w http.ResponseWriter, r *http.Request) {
	name, e := s.auth(r)
	if e != nil {
		http.Error(w, "unauthorized", 401)
		return
	}
	f, ok := w.(http.Flusher)
	if !ok {
		http.Error(w, "stream unsupported", 500)
		return
	}
	w.Header().Set("Content-Type", "text/event-stream")
	w.Header().Set("Cache-Control", "no-cache")
	w.Header().Set("X-Accel-Buffering", "no")
	c := make(chan string, 32)
	s.mu.Lock()
	// Bound long-lived SSE connections. Thirty users can each open multiple
	// clients/tabs, but thousands of leaked streams must not exhaust the host.
	perUserStreams := 0
	for _, u := range s.listeners {
		if u == name {
			perUserStreams++
		}
	}
	if len(s.listeners) >= 150 || perUserStreams >= 5 {
		s.mu.Unlock()
		w.Header().Set("Retry-After", "10")
		http.Error(w, "event stream busy", http.StatusServiceUnavailable)
		return
	}
	s.listeners[c] = name
	s.mu.Unlock()
	defer func() { s.mu.Lock(); delete(s.listeners, c); s.mu.Unlock() }()
	fmt.Fprint(w, ": connected\n\n")
	f.Flush()
	ticker := time.NewTicker(20 * time.Second)
	defer ticker.Stop()
	for {
		select {
		case m := <-c:
			// Revalidate before data delivery, not only on the heartbeat.
			if verified, err := s.auth(r); err != nil || verified != name {
				return
			}
			fmt.Fprintf(w, "data: %s\n\n", m)
			f.Flush()
		case <-ticker.C:
			// A stream must not survive a revoked or expired session.
			if verified, err := s.auth(r); err != nil || verified != name {
				return
			}
			fmt.Fprint(w, ": ping\n\n")
			f.Flush()
		case <-r.Context().Done():
			return
		}
	}
}
func (s *Server) routes() http.Handler {
	m := http.NewServeMux()
	m.HandleFunc("/api/register", s.register)
	m.HandleFunc("/api/invite", s.inviteAPI)
	m.HandleFunc("/api/community-invite", s.communityInviteAPI)
	m.HandleFunc("/api/system-admin", s.systemAdminAPI)
	m.HandleFunc("/api/staff-control", s.staffControlAPI)
	m.HandleFunc("/api/staff-dm", s.staffDMAPI)
	m.HandleFunc("/api/spotlight", s.spotlightAPI)
	m.HandleFunc("/api/announcements", s.announcementsAPI)
	m.HandleFunc("/api/report", s.reportAPI)
	m.HandleFunc("/api/login", s.login)
	m.HandleFunc("/api/password-reset/complete", s.completePasswordReset)
	m.HandleFunc("/api/captcha", s.captchaAPI)
	m.HandleFunc("/api/home-mode", s.homeModeAPI)
	m.HandleFunc("/api/register-config", s.registrationConfigAPI)
	m.HandleFunc("/api/terms", s.termsAPI)
	m.HandleFunc("/api/messages", s.messages)
	m.HandleFunc("/api/image", s.imageAPI)
	m.HandleFunc("/api/video", s.videoAPI)
	m.HandleFunc("/api/visual", s.visualAPI)
	m.HandleFunc("/api/stickers", s.stickerAPI)
	m.HandleFunc("/api/events", s.events)
	m.HandleFunc("/api/communities", s.communities)
	m.HandleFunc("/api/channel-delete", s.deleteChannel)
	m.HandleFunc("/api/channel-permissions", s.channelPermissionsAPI)
	m.HandleFunc("/api/channel-messages", s.channelMessages)
	m.HandleFunc("/api/logout", s.logout)
	m.HandleFunc("/api/profile", s.profileAPI)
	m.HandleFunc("/api/name-presets", s.namePresetsAPI)
	m.HandleFunc("/api/voice-moderation", s.voiceModeration)
	m.HandleFunc("/api/voice", s.voiceAPI)
	m.HandleFunc("/api/media-config", s.mediaConfig)
	m.HandleFunc("/api/livekit-token", s.liveKitToken)
	m.HandleFunc("/api/voice-presence", s.voicePresence)
	m.HandleFunc("/api/community-admin", s.communityAdmin)
	m.HandleFunc("/api/community-audit", s.communityAudit)
	m.HandleFunc("/api/presence", s.presenceAPI)
	m.HandleFunc("/api/presence-heartbeat", s.presenceHeartbeatAPI)
	m.HandleFunc("/api/sanctions", s.sanctionsAPI)
	m.HandleFunc("/api/sanction-notices", s.sanctionNotices)
	m.HandleFunc("/api/status", s.statusAPI)
	m.HandleFunc("/api/notifications", s.notificationsAPI)
	m.HandleFunc("/api/community-hub", s.communityHubAPI)
	m.HandleFunc("/api/afk", s.afkAPI)
	m.HandleFunc("/api/social", s.socialAPI)
	m.HandleFunc("/api/direct", s.directAPI)
	m.HandleFunc("/api/direct-call", s.directCallAPI)
	m.HandleFunc("/api/direct-file", s.directFileAPI)
	m.HandleFunc("/api/storage", s.storageAPI)
	m.HandleFunc("/api/message-actions", s.messageActions)
	m.HandleFunc("/api/channel-search", s.channelSearch)
	m.HandleFunc("/api/ping", func(w http.ResponseWriter, r *http.Request) {
		if _, err := s.auth(r); err != nil {
			http.Error(w, "unauthorized", 401)
			return
		}
		reply(w, 200, map[string]bool{"ok": true})
	})
	m.Handle("/", secureWebAssets("web"))
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("X-Content-Type-Options", "nosniff")
		w.Header().Set("Cache-Control", "no-store")
		w.Header().Set("Content-Security-Policy", "default-src 'self'; script-src 'self' 'unsafe-inline'; style-src 'self' 'unsafe-inline'; img-src 'self' data: blob:; media-src 'self' blob:; connect-src 'self' https: wss:; object-src 'none'; base-uri 'none'; frame-ancestors 'none'; form-action 'self'")
		w.Header().Set("Referrer-Policy", "no-referrer")
		w.Header().Set("X-Frame-Options", "DENY")
		w.Header().Set("Cross-Origin-Resource-Policy", "same-origin")
		w.Header().Set("X-DNS-Prefetch-Control", "off")
		w.Header().Set("X-Permitted-Cross-Domain-Policies", "none")
		w.Header().Set("Permissions-Policy", "camera=(), microphone=(self), display-capture=(self)")
		// Requests carrying a foreign Origin are never accepted. Authorization is
		// still validated separately on every protected endpoint; this is defense
		// in depth against browser-driven cross-origin requests and local abuse.
		if strings.HasPrefix(r.URL.Path, "/api/") && !sameOriginRequest(r) {
			http.Error(w, "origin denied", http.StatusForbidden)
			return
		}
		// Only sessions issued by successful login are marked as terms-pending.
		// All normal application endpoints are blocked before consent; direct requests
		// to the backend cannot bypass the first-login overlay.
		if strings.HasPrefix(r.URL.Path, "/api/") && r.URL.Path != "/api/terms" && r.URL.Path != "/api/login" && r.URL.Path != "/api/password-reset/complete" && r.URL.Path != "/api/home-mode" && r.URL.Path != "/api/register-config" && r.URL.Path != "/api/captcha" && r.URL.Path != "/api/register" && r.URL.Path != "/api/logout" && !(r.URL.Path == "/api/status" && r.Method == http.MethodGet) {
			bearer := strings.TrimPrefix(r.Header.Get("Authorization"), "Bearer ")
			s.mu.Lock()
			pending := s.termsPending[bearer] && s.sessions[bearer] != ""
			s.mu.Unlock()
			if pending {
				reply(w, http.StatusForbidden, map[string]string{"error": "Aceite as regras do Explicit antes de continuar.", "code": "terms_required"})
				return
			}
		}
		release, ok := s.protectExpensiveWrites(w, r)
		if !ok {
			return
		}
		defer release()
		m.ServeHTTP(w, r)
	})
}
func main() {
	addr := os.Getenv("LISTEN_ADDR")
	if addr == "" {
		addr = "127.0.0.1:8080"
	}
	s := newServer("data/store.json")
	s.startStorageMaintenance()
	if requested := strings.TrimSpace(os.Getenv("EXPLICIT_BOOTSTRAP_OWNER")); requested != "" {
		if err := s.bootstrapOwner(requested); err != nil {
			log.Fatal("Owner activation refused: ", err)
		}
		slog.Info("system.owner.bootstrapped", "user", requested)
	}
	// One-time, local operator bootstrap. Never exposed over HTTP.
	if first := strings.TrimSpace(os.Getenv("EXPLICIT_BOOTSTRAP_SUPERADMIN")); first != "" {
		s.mu.Lock()
		hasRoot := false
		for _, u := range s.db.Users {
			if systemRole(u) == "superadmin" || systemRole(u) == "owner" {
				hasRoot = true
				break
			}
		}
		if !hasRoot {
			if u, ok := s.db.Users[first]; ok {
				u.SystemRole = "superadmin"
				s.db.Users[first] = u
				if err := s.save(); err != nil {
					log.Fatal("bootstrap failed: ", err)
				}
				slog.Info("system.superadmin.bootstrapped", "user", first)
			} else {
				slog.Warn("bootstrap user does not exist", "user", first)
			}
		}
		s.mu.Unlock()
	}
	slog.Info("explicit.started", "address", addr)
	go s.afkWorker()
	httpServer := &http.Server{Addr: addr, Handler: withHTTPDiagnostics(s.routes()), ReadHeaderTimeout: 10 * time.Second, ReadTimeout: 90 * time.Second, IdleTimeout: 90 * time.Second, MaxHeaderBytes: 32 << 10}
	log.Fatal(httpServer.ListenAndServe())
}
