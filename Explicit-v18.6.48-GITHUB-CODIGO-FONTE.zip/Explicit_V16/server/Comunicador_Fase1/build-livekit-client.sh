#!/usr/bin/env bash
# Compile TypeScript and install the pinned official LiveKit browser SDK.
set -Eeuo pipefail
HERE=$(cd "$(dirname "$0")" && pwd)
if ! command -v tsc >/dev/null 2>&1; then
 echo 'TypeScript não encontrado. Execute: npm install -g typescript@5.8.3' >&2; exit 1
fi
mkdir -p "$HERE/web/vendor"
tsc --target ES2020 --lib ES2020,DOM --skipLibCheck --strict --outFile "$HERE/web/livekit-adapter.js" "$HERE/web/media-src/livekit-adapter.ts"
if [[ "${1:-}" == '--sdk' ]]; then
 command -v npm >/dev/null || { echo 'npm necessário para instalar o SDK'; exit 1; }
 temp=$(mktemp -d); trap 'rm -rf "$temp"' EXIT
 printf '{"name":"explicit-sdk-pack","private":true,"version":"1.0.0"}\n' > "$temp/package.json"
 (cd "$temp" && npm install --no-audit --no-fund --save-exact livekit-client@2.23.0)
 package="$temp/node_modules/livekit-client"
 sdk=''
 for candidate in "$package/dist/livekit-client.umd.js" "$package/dist/livekit-client.umd.min.js"; do
  if [[ -s "$candidate" && $(wc -c < "$candidate") -gt 100000 ]]; then sdk="$candidate"; break; fi
 done
 [[ -n "$sdk" ]] || { echo 'Bundle UMD oficial nao encontrado; nao iniciar testes de voz.' >&2; exit 1; }
 install -m 644 "$sdk" "$HERE/web/vendor/livekit-client.umd.min.js"
fi
