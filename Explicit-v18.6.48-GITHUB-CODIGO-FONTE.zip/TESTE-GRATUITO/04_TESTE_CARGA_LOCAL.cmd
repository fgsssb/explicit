@echo off
setlocal
set "ROOT=%~dp0..\Explicit_V16\server\Comunicador_Fase1"
if not exist "%ROOT%\go.mod" (
  echo Servidor nao encontrado em "%ROOT%".
  pause
  exit /b 1
)
where go >nul 2>&1
if errorlevel 1 (
  echo Go nao encontrado. Instale Go para executar os testes locais.
  pause
  exit /b 1
)
pushd "%ROOT%"
echo === Explicit v18.6.22 - teste local de 30 contas concorrentes ===
echo Nao cria usuarios no seu servidor nem envia mensagens para a VPS.
go test -run "TestThirtyConcurrentUsersLocalStorage|TestResourceGuard|TestHeavyWriteGuard|TestRecentChannelHistoryRespectsLimitAndOrder|TestEventStreamBounded" -v -count=1
set "EXIT=%ERRORLEVEL%"
popd
pause
exit /b %EXIT%
