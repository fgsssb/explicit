﻿**ATUALIZAÇÃO 18.6.8:** veja `../LEIA-EXPLICIT-v18.6.8-PERFIS-AVATARES.md` para as melhorias de perfis, emblemas, chat e cadastro. Os scripts do cliente usam a versão 18.6.8.

## v17.5.2 — Correção do erro -105 no Electron portátil

O pacote portátil gerado por electron-builder inicia o processo Electron a partir de uma pasta temporária. Na v17.5.1, o cliente buscava `explicit-endpoint.json` nessa pasta errada, depois carregava `config.json` com `api.SEUDOMINIO.com`, provocando erro -105. Na v17.5.2, usa `PORTABLE_EXECUTABLE_FILE`/`PORTABLE_EXECUTABLE_DIR` para localizar o JSON ao lado do EXE externo. Se o JSON estiver ausente, a inicialização avisa claramente sem tentar um domínio de exemplo.

**Ordem de uso (Windows):** feche todas as instâncias do Explicit (inclusive da bandeja perto do relógio), execute `03_COMPILAR_CLIENTE.cmd`, depois `04_CONFIGURAR_CLIENTE.cmd` informando a URL atual do túnel, depois `06_VERIFICAR_PREPARACAO.cmd`. Abra o arquivo `Explicit_V16\desktop\dist\Explicit-18.6.8-x64.exe`. Mantenha `01_INICIAR_SERVIDOR.cmd` e `02_INICIAR_TUNEL.cmd` abertos. Só depois gere o ZIP dos amigos com `05_GERAR_ZIP_AMIGOS.cmd`.

Para teste sem recompile, o login no navegador pelo endereço do túnel confirma apenas backend e HTTPS; não valida mídia no Electron.

# EXPLICIT — PILOTO GRATUITO CLOUD, sem Radmin e sem VPS

**Abra o arquivo `TUTORIAL-COMPLETO-EXPLICIT-CLOUD.md` na raiz do ZIP.**

Em resumo: seu PC executa a API Go e grava contas/mensagens em `data/store.json` (sem PostgreSQL); um **Cloudflare Quick Tunnel** oferece HTTPS para seus amigos; o **LiveKit Cloud Build** transporta voz e compartilhamento de tela. Três computadores, três contas, internet normal, nenhum Radmin. **O IPv4 26.x.x.x não é utilizado.**

Arquivos para Windows na pasta `TESTE-GRATUITO`:

1. `01_INICIAR_SERVIDOR.cmd` — execute DEPOIS do 03; pergunta Project URL, API Key e API Secret do LiveKit, inicia Go local com polling de mensagens. Não grava os segredos em arquivo.
2. `02_INICIAR_TUNEL.cmd` — depende do `cloudflared`, mostra a URL HTTPS temporária `https://...trycloudflare.com`.
3. `03_COMPILAR_CLIENTE.cmd` — depende do Node.js/npm, baixa **obrigatoriamente** `livekit-client@2.23.0` da npm e compila o Electron portátil no Windows. Execute ANTES de iniciar o servidor.
4. `04_CONFIGURAR_CLIENTE.cmd` — grava somente a URL pública no `explicit-endpoint.json` ao lado do executável.
5. `05_GERAR_ZIP_AMIGOS.cmd` — gera um ZIP com **apenas o cliente + URL** para os amigos.

IMPORTANTE: não iniciar os scripts Radmin/PostgreSQL antigos; não ativar o servidor de mídia Docker/KingHost; não instalar o `Development token server` no LiveKit. O segredo do projeto LiveKit fica SOMENTE com o host.

Este teste não garante resultado na rede: exige validação real. Dados e contas criados aqui são **separados** do banco PostgreSQL anterior. A publicação temporária pela Cloudflare expõe a API Go ao público que conhece o link; use contas de teste, senha exclusiva e não divulgue o endereço fora do grupo.

## v17.5 — mudanças para estabilidade

O adaptador LiveKit foi atualizado para reconhecer streams já assinados ao entrar, tratar reconexões sem apagar o vídeo substituto, recuperar áudio bloqueado e informar problemas da rede. Novo script `06_VERIFICAR_PREPARACAO.cmd`: execute após configurar o cliente e antes de enviar o ZIP aos amigos. Consulte `RELATORIO-DISCORD-EXPLICIT-v17.5.md` na raiz para detalhes. Nenhuma biblioteca do Discord foi incluída.
