$ErrorActionPreference='Stop'
$base=Split-Path (Split-Path $PSScriptRoot -Parent) -Parent
$dist=Join-Path $base 'Explicit_V16\desktop\dist'
$manifestPath = Join-Path $base 'Explicit_V16\desktop\package.json'
if (!(Test-Path -LiteralPath $manifestPath)) { throw 'package.json do cliente nao encontrado.' }
$version = [string]((Get-Content -Raw -LiteralPath $manifestPath | ConvertFrom-Json).version)
if ($version -notmatch '^\d+\.\d+\.\d+$') { throw 'Versao invalida no package.json do cliente.' }
$exe=Join-Path $dist ('Explicit-' + $version + '-x64.exe')
if(!(Test-Path $exe)){throw 'Executavel nao encontrado. Primeiro execute 03_COMPILAR_CLIENTE.cmd.'}
Write-Host '=== CONFIGURAR ENDERECO PUBLICO DO CLIENTE ===' -ForegroundColor Cyan
Write-Host 'O tunel da Cloudflare muda de endereco cada vez que e iniciado.'
$url=(Read-Host 'Cole a URL COMPLETA https://...trycloudflare.com').Trim().TrimEnd('/')
if($url -notmatch '^https://[a-zA-Z0-9-]+\.trycloudflare\.com$'){Write-Host 'URL invalida. Copie a URL exibida pelo cloudflared.' -ForegroundColor Red;exit 2}
New-Item -ItemType Directory -Force -Path $dist | Out-Null
$dest=Join-Path $dist 'explicit-endpoint.json'
# Windows PowerShell 5.1 Set-Content -Encoding UTF8 gera BOM, que quebra JSON.parse no Electron.
$json=@{serverUrl=$url}|ConvertTo-Json -Compress
[System.IO.File]::WriteAllText($dest,$json,(New-Object System.Text.UTF8Encoding($false)))
Write-Host "Arquivo criado: $dest" -ForegroundColor Green
Write-Host ('Este arquivo deve ficar AO LADO do Explicit-' + $version + '-x64.exe. Sem recompilar ao mudar o endereco.') -ForegroundColor Yellow

Write-Host 'IMPORTANTE: abra o EXE que esta NESTA MESMA PASTA. Versoes antigas de outro local nao receberam a correcao.' -ForegroundColor Yellow
