$ErrorActionPreference='Stop'
$base=Split-Path (Split-Path $PSScriptRoot -Parent) -Parent
$dist=Join-Path $base 'Explicit_V16\desktop\dist'
$manifestPath = Join-Path $base 'Explicit_V16\desktop\package.json'
if (!(Test-Path -LiteralPath $manifestPath)) { throw 'package.json do cliente nao encontrado.' }
$version = [string]((Get-Content -Raw -LiteralPath $manifestPath | ConvertFrom-Json).version)
if ($version -notmatch '^\d+\.\d+\.\d+$') { throw 'Versao invalida no package.json do cliente.' }
$exe=Join-Path $dist ('Explicit-' + $version + '-x64.exe')
$config=Join-Path $dist 'explicit-endpoint.json'
if(!(Test-Path $exe)){Write-Host 'ERRO: Primeiro execute 03_COMPILAR_CLIENTE.cmd' -ForegroundColor Red;exit 1}
if(!(Test-Path $config)){Write-Host 'ERRO: Primeiro execute 04_CONFIGURAR_CLIENTE.cmd' -ForegroundColor Red;exit 1}
$folder=Join-Path $PSScriptRoot '..\PARA_OS_AMIGOS'
New-Item -ItemType Directory -Path $folder -Force|Out-Null
Copy-Item $exe $folder -Force; Copy-Item $config $folder -Force
$zip=Join-Path $PSScriptRoot '..\Explicit-CLIENTE-AMIGOS.zip'
if(Test-Path $zip){Remove-Item $zip -Force}
Compress-Archive -Path (Join-Path $folder '*') -DestinationPath $zip
Write-Host "PRONTO. Envie APENAS este arquivo aos amigos: $zip" -ForegroundColor Green
Write-Host 'NUNCA envie o projeto completo e NUNCA envie sua API Secret.' -ForegroundColor Yellow
