$ErrorActionPreference='Continue'
$base=Split-Path (Split-Path $PSScriptRoot -Parent) -Parent
$manifestPath = Join-Path $base 'Explicit_V16\desktop\package.json'
if (!(Test-Path -LiteralPath $manifestPath)) { throw 'package.json do cliente nao encontrado.' }
$version = [string]((Get-Content -Raw -LiteralPath $manifestPath | ConvertFrom-Json).version)
if ($version -notmatch '^\d+\.\d+\.\d+$') { throw 'Versao invalida no package.json do cliente.' }
$exe=Join-Path $base ('Explicit_V16\desktop\dist\Explicit-' + $version + '-x64.exe')
$endpoint=Join-Path $base 'Explicit_V16\desktop\dist\explicit-endpoint.json'
$sdk=Join-Path $base 'Explicit_V16\server\Comunicador_Fase1\web\vendor\livekit-client.umd.min.js'
$goExe=Join-Path $base 'Explicit_V16\server\Comunicador_Fase1\ExplicitServer-Teste-Cloud.exe'
function Check($desc,$ok,$hint){
 if($ok){Write-Host ('[OK] '+$desc) -ForegroundColor Green}
 else{Write-Host ('[FALTA] '+$desc) -ForegroundColor Yellow;Write-Host ('  '+$hint) -ForegroundColor DarkGray}
}
Write-Host '=== EXPLICIT - CONFERENCIA SEGURA DO PILOTO ===' -ForegroundColor Cyan
Write-Host 'Este script NAO pede nem imprime API Key, API Secret ou tokens.'
Check 'Servidor Go Windows compilado' (Test-Path $goExe) 'Execute Explicit_V16\BUILD_SERVER.bat.'
$adminJs=Join-Path $base 'Explicit_V16\server\Comunicador_Fase1\web\admin-console.js'
Check 'Painel administrativo instalado' ((Test-Path $adminJs) -and ((Get-Item $adminJs).Length -gt 10000)) 'Extraia o pacote mais recente na MESMA pasta do servidor.'
$html=Join-Path $base 'Explicit_V16\server\Comunicador_Fase1\web\index.html'
$htmlText=if(Test-Path $html){Get-Content -Raw -LiteralPath $html}else{''}
Check 'Painel novo ligado ao botao Admin' ($htmlText -match 'admin-console\.js\?v=1800' -and $htmlText -notmatch 'modalWorkspace\(''Painel Admin''\)') 'Atualize o index.html e reinicie o servidor Go.'
Check 'Botao de comunidade e canal da transmissao corrigidos' ($htmlText -match 'add\.onclick=openCommunityChoice' -and $htmlText -match 'explicitJoinTransmission\(user,voice\.channel\)') 'Atualize o index.html com a versão 18.3.'

$stickerJs=Join-Path $base 'Explicit_V16\server\Comunicador_Fase1\web\stickers.js'
Check 'Modulo Figurinhas v18.3 instalado' ((Test-Path $stickerJs) -and ($htmlText -match 'stickers\.js\?v=1830')) 'Extraia o ZIP v18.3 na pasta correta, mantendo web/stickers.js.'
Check 'SDK LiveKit real instalado' ((Test-Path $sdk) -and ((Get-Item $sdk).Length -gt 100000)) 'Execute 03_COMPILAR_CLIENTE.cmd com internet.'
Check 'Electron portátil gerado' (Test-Path $exe) 'Execute 03_COMPILAR_CLIENTE.cmd e verifique erros no terminal.'
Check 'Cloudflared instalado' ([bool](Get-Command cloudflared -ErrorAction SilentlyContinue)) 'Execute winget install -e --id Cloudflare.cloudflared; abra outro terminal.'
$url=''
if(Test-Path $endpoint){try {$url=(Get-Content -Raw -Path $endpoint|ConvertFrom-Json).serverUrl }catch{}}
Check 'Endereço público configurado' ([bool]($url -match '^https://[a-zA-Z0-9-]+\.trycloudflare\.com$')) 'Execute 02_INICIAR_TUNEL.cmd e depois 04_CONFIGURAR_CLIENTE.cmd.'
try{
 $r=Invoke-WebRequest -Uri 'http://127.0.0.1:8080/api/ping' -UseBasicParsing -TimeoutSec 4
 Check 'Servidor local responde' ($r.StatusCode -eq 200) 'Execute 01_INICIAR_SERVIDOR.cmd.'

 try{
  $adminResponse=Invoke-WebRequest -Uri 'http://127.0.0.1:8080/admin-console.js' -UseBasicParsing -TimeoutSec 4
  $adminOk=($adminResponse.StatusCode -eq 200) -and ($adminResponse.Content -match 'window\.explicitOpenAdmin=async function')
  Check 'Servidor entrega o NOVO painel administrativo' $adminOk 'Reinicie 01_INICIAR_SERVIDOR.cmd a partir da pasta corrigida; confira /admin-console.js no navegador.'
 }catch{Check 'Servidor entrega o NOVO painel administrativo' $false 'Arquivo ausente ou o servidor esta usando outra pasta. Use o ZIP v17.6.1.'}

}catch{Check 'Servidor local responde' $false 'Execute 01_INICIAR_SERVIDOR.cmd e deixe a janela aberta.'}
if($url){
 try{
  $r=Invoke-WebRequest -Uri ($url+'/api/ping') -UseBasicParsing -TimeoutSec 7
  Check 'Túnel público responde' ($r.StatusCode -eq 200) 'Confira a janela 02_INICIAR_TUNEL.cmd e a URL.'
 }catch{Check 'Túnel público responde' $false 'Pode estar offline, ter mudado de endereço ou bloqueado por rede.'}
}
Write-Host '\nNenhum desses testes garante voz e tela. Para isso é preciso entrar com três PCs.' -ForegroundColor Cyan
