$ErrorActionPreference = 'Stop'
$base = Split-Path (Split-Path $PSScriptRoot -Parent) -Parent
$desktop = Join-Path $base 'Explicit_V16\desktop'
$server = Join-Path $base 'Explicit_V16\server\Comunicador_Fase1'
$vendor = Join-Path $server 'web\vendor\livekit-client.umd.min.js'
$manifestPath = Join-Path $desktop 'package.json'
if (!(Test-Path -LiteralPath $manifestPath)) { throw 'package.json do cliente nao encontrado.' }
$version = [string]((Get-Content -Raw -LiteralPath $manifestPath | ConvertFrom-Json).version)
if ($version -notmatch '^\d+\.\d+\.\d+$') { throw 'Versao invalida no package.json do cliente.' }
Write-Host ('=== EXPLICIT v' + $version + ' - COMPILAR WINDOWS + INSTALAR LIVEKIT ===') -ForegroundColor Cyan
if (!(Get-Command npm.cmd -ErrorAction SilentlyContinue)) {
    throw 'Node.js/npm nao encontrado. Instale o Node.js LTS e abra novamente o terminal.'
}
if (!(Test-Path $desktop) -or !(Test-Path $server)) {
    throw 'Pastas do projeto nao encontradas. Extraia o ZIP inteiro, mantendo a estrutura das pastas.'
}
# O livekit-client@2.23.0 publica dist/livekit-client.umd.js como bundle principal.
# Alguns CDNs oferecem um nome minificado; nao devemos exigir esse arquivo no pacote npm.
# O aplicativo usa a URL local /vendor/livekit-client.umd.min.js: o nome do DESTINO
# e mantido para preservar compatibilidade, independentemente do nome do bundle de ORIGEM.
$tmp = Join-Path $env:TEMP ('explicit-livekit-sdk-' + [guid]::NewGuid().ToString('N'))
New-Item -ItemType Directory -Force -Path $tmp | Out-Null
try {
    [System.IO.File]::WriteAllText((Join-Path $tmp 'package.json'), '{"name":"explicit-pilot-sdk","version":"1.0.0","private":true}', (New-Object System.Text.UTF8Encoding($false)))
    Push-Location $tmp
    try {
        npm.cmd install --no-audit --no-fund --save-exact 'livekit-client@2.23.0'
        if ($LASTEXITCODE -ne 0) { throw 'Falha no npm install livekit-client@2.23.0. Confira internet e npm.' }
    } finally { Pop-Location }
    $packageRoot = Join-Path $tmp 'node_modules\livekit-client'
    $manifest = Join-Path $packageRoot 'package.json'
    if (!(Test-Path $manifest)) { throw 'npm terminou, mas a pasta node_modules/livekit-client nao foi criada.' }
    $metadata = Get-Content -Raw -LiteralPath $manifest | ConvertFrom-Json
    if ($metadata.version -ne '2.23.0') { throw ('Versao inesperada do LiveKit: ' + $metadata.version) }

    $sdk = $null
    foreach ($name in @('dist\livekit-client.umd.js', 'dist\livekit-client.umd.min.js')) {
        $candidate = Join-Path $packageRoot $name
        if ((Test-Path -LiteralPath $candidate) -and ((Get-Item -LiteralPath $candidate).Length -gt 100000)) {
            $sdk = $candidate
            break
        }
    }
    if (!$sdk) {
        $available = @(Get-ChildItem -Path (Join-Path $packageRoot 'dist') -ErrorAction SilentlyContinue | Select-Object -ExpandProperty Name) -join ', '
        throw ('Bundle UMD nao encontrado na distribuicao oficial. Arquivos em dist: ' + $available)
    }
    New-Item -ItemType Directory -Force -Path (Split-Path $vendor -Parent) | Out-Null
    Copy-Item -LiteralPath $sdk -Destination $vendor -Force
    if ((Get-Item -LiteralPath $vendor).Length -le 100000) { throw 'Arquivo copiado, mas tamanho invalido. Nao inicie o teste de voz.' }
    Write-Host ('[OK] LiveKit ' + $metadata.version + ' instalado: ' + (Split-Path $sdk -Leaf) + ' (' + [math]::Round((Get-Item $vendor).Length / 1024) + ' KB).') -ForegroundColor Green
} finally {
    Remove-Item $tmp -Recurse -Force -ErrorAction SilentlyContinue
}
Write-Host '[INFO] Compilando cliente Electron Windows...' -ForegroundColor Cyan
Push-Location $desktop
try {
    npm.cmd install --no-audit --no-fund
    if ($LASTEXITCODE -ne 0) { throw 'npm install Electron falhou.' }
    npm.cmd run build:portable
    if ($LASTEXITCODE -ne 0) { throw 'build:portable falhou. Confira o erro acima.' }
    $exe = Join-Path $desktop ('dist\Explicit-' + $version + '-x64.exe')
    if (!(Test-Path -LiteralPath $exe)) { throw ('Compilacao terminou sem gerar o executavel esperado: ' + $exe) }
    Write-Host ('[OK] Compilacao concluida: ' + $exe) -ForegroundColor Green
} finally {
    Pop-Location
}
