﻿$ErrorActionPreference='Stop'
$base=Split-Path (Split-Path $PSScriptRoot -Parent) -Parent
$dir=Join-Path $base 'Explicit_V16\server\Comunicador_Fase1'
$server=Join-Path $dir 'ExplicitServer-Teste-Cloud.exe'
if (!(Test-Path $server)) { Write-Host 'ERRO: Executavel Go ausente. Execute Explicit_V16\BUILD_SERVER.bat primeiro.' -ForegroundColor Red; exit 1 }
$sdk=Join-Path $dir 'web\vendor\livekit-client.umd.min.js'
if(!(Test-Path $sdk) -or (Get-Item $sdk).Length -lt 100000){
 Write-Host 'ERRO: SDK LiveKit REAL ainda nao instalado. Execute primeiro 03_COMPILAR_CLIENTE.cmd (com internet).' -ForegroundColor Red
 exit 1
}
Write-Host '=== EXPLICIT - SERVIDOR DE TESTE GRATUITO ===' -ForegroundColor Cyan
Write-Host 'Nao precisa PostgreSQL, VPS nem Radmin. Este piloto usa JSON local.'
Write-Host 'Os campos abaixo ficam apenas na MEMORIA deste processo; nao sao salvos.'
Write-Host 'Nao compartilhe a CHAVE SECRET com amigos ou em prints.'
$url=(Read-Host 'Cole a Project URL do LiveKit Cloud (wss://...livekit.cloud)').Trim()
$key=(Read-Host 'Cole a API Key do LiveKit Cloud').Trim()
$secretSecure=Read-Host 'Cole a API Secret do LiveKit Cloud (entrada oculta)' -AsSecureString
$bstr=[Runtime.InteropServices.Marshal]::SecureStringToBSTR($secretSecure)
try{$secret=[Runtime.InteropServices.Marshal]::PtrToStringBSTR($bstr).Trim()}
finally{[Runtime.InteropServices.Marshal]::ZeroFreeBSTR($bstr)}
if ($url -notmatch '^wss://[a-zA-Z0-9.-]+\.livekit\.cloud/?$') {Write-Host 'URL invalida. Use wss://SEUPROJETO.livekit.cloud' -ForegroundColor Red;exit 2}
$url=$url.TrimEnd('/')
if($key.Length -lt 12 -or $secret.Length -lt 32){Write-Host 'Chave ou segredo muito curtos. Veja Settings > Keys.' -ForegroundColor Red;exit 2}
$env:LIVEKIT_WS_URL=$url
$env:LIVEKIT_API_KEY=$key
$env:LIVEKIT_API_SECRET=$secret
$env:LISTEN_ADDR='127.0.0.1:8080'
$env:EXPLICIT_PILOT_POLLING='1'
$env:PGDATABASE=''
$env:EXPLICIT_MYSQL_CONFIG=''
# Garante que um script antigo Radmin nao injete endereco/vinculo PostgreSQL.
Write-Host 'Servidor local: http://127.0.0.1:8080' -ForegroundColor Green
Write-Host 'Teste: http://127.0.0.1:8080/api/media-config (401 e NORMAL sem login)' -ForegroundColor Gray
Write-Host 'Nao feche esta janela durante os testes.' -ForegroundColor Yellow
try {Set-Location $dir; & $server; if($LASTEXITCODE -ne 0){exit $LASTEXITCODE}}
finally{ $env:LIVEKIT_API_SECRET=''; $env:LIVEKIT_API_KEY=''; $env:LIVEKIT_WS_URL=''; }
