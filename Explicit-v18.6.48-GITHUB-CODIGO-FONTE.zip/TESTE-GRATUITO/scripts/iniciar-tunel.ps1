﻿$ErrorActionPreference='Stop'
Write-Host '=== EXPLICIT - TUNEL HTTPS DE TESTE ===' -ForegroundColor Cyan
$cmd=Get-Command cloudflared -ErrorAction SilentlyContinue
if(!$cmd){Write-Host 'ERRO: cloudflared nao encontrado. Instale pelo comando: winget install -e --id Cloudflare.cloudflared' -ForegroundColor Red;exit 1}
try{$response=Invoke-WebRequest -Uri 'http://127.0.0.1:8080/' -UseBasicParsing -TimeoutSec 6}catch{Write-Host 'ERRO: Primeiro abra 01_INICIAR_SERVIDOR.cmd. Nao existe servidor na porta 8080.' -ForegroundColor Red;exit 1}
Write-Host 'Servidor respondeu. Criando URL https temporaria...' -ForegroundColor Green
Write-Host 'COPIE a URL do formato https://...trycloudflare.com. Nao feche esta janela.' -ForegroundColor Yellow
& $cmd.Source tunnel --url http://127.0.0.1:8080
