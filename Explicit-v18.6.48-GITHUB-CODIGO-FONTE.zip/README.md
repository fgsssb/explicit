# Explicit

Aplicativo de comunidades, mensagens, voz e compartilhamento de tela. Base: **18.6.48, auditoria rodada 4**.

Este pacote contém o código-fonte, os testes e os recursos necessários ao projeto. Executáveis, dados reais, credenciais LiveKit, capturas antigas e documentação histórica repetida foram retirados para preparar o primeiro envio ao GitHub.

## Estrutura

```text
Explicit_V16/
  desktop/                      # Electron, recursos e testes Node
  server/Comunicador_Fase1/      # Backend Go, frontend web e testes
  BUILD_SERVER.bat               # Compilação do servidor no Windows
  BUILD_PORTABLE.bat             # Compilação do cliente portátil
TESTE-GRATUITO/                  # Ferramentas opcionais de teste local
kinghost/                       # Scripts e templates de implantação Linux
docs/                           # Auditoria atual e referências selecionadas
```

Os nomes antigos das pastas foram mantidos para preservar caminhos nos testes e scripts. Não são versões diferentes do código atual.

## Requisitos

- Go **1.22 ou superior**; esta preparação foi validada com Go 1.23.12 em Linux.
- Node.js e npm; os testes foram executados com Node 24.22.1.
- Windows para executar o cliente e validar o empacotamento Windows.
- LiveKit configurado para chamadas privadas e para usar o transporte SFU. Sem ele, não se deve considerar voz/tela validadas.

## Executar o backend local

Na raiz do repositório:

```sh
cd Explicit_V16/server/Comunicador_Fase1
go run .
```

O endereço padrão é `http://127.0.0.1:8080`. A interface web é servida pelo backend; mantenha a pasta `web/` junto do servidor. O armazenamento local é criado em `data/`, ignorado pelo Git.

Para executar um binário Linux compilado, faça `go build -trimpath -o explicit-server .` nessa pasta e execute `./explicit-server`. Não versione esse binário. Configure `LISTEN_ADDR` explicitamente se precisar mudar o endereço.

Para gerar os dois nomes de servidor usados pelos atalhos Windows, execute `Explicit_V16/BUILD_SERVER.bat`. O servidor Radmin/PostgreSQL é opcional e requer configuração local própria.

## Executar o desktop

Com o backend aberto, em outro terminal:

```sh
cd Explicit_V16/desktop
npm install
npm start
```

O `config.json` versionado aponta para localhost. `config.example.json` mostra o formato para um servidor HTTPS remoto. Antes de produzir uma Release, configure a URL correta. Não coloque tokens ou senhas nesses arquivos: o endpoint é uma URL pública.

Não existia `package-lock.json` na entrada original. Não foi inventado um lockfile nesta limpeza. A primeira instalação gera um; revise e versione-o para fixar também as dependências transitivas. Instalações futuras com lockfile podem usar `npm ci`.

## Credenciais de mídia

O `web/vendor/livekit-client.umd.min.js` recebido no ZIP original é um **marcador de 159 bytes**, não o SDK completo. Foi preservado sem alterar o código do app. No Windows, `TESTE-GRATUITO/03_COMPILAR_CLIENTE.cmd` baixa o SDK oficial fixado em `2.23.0` antes de compilar o desktop. Não considere voz/tela prontas apenas por executar `npm start`.

Em Linux, `build-livekit-client.sh --sdk` é o caminho existente para reconstruir o adapter e obter o SDK; ele exige `tsc` (TypeScript 5.8.3 indicado pelo próprio script) e npm. O acesso ao npm e o download do SDK não foram executados nesta limpeza.

Os scripts opcionais `TESTE-GRATUITO/01_INICIAR_SERVIDOR.cmd` e `01_INICIAR_SERVIDOR_LIVEKIT_CONFIGURADO.cmd` agora usam o mesmo fluxo interativo: URL, API Key e API Secret são solicitados em tempo de execução; a entrada do segredo é oculta. Compile primeiro o servidor com `BUILD_SERVER.bat`.

Também é possível definir `LIVEKIT_WS_URL`, `LIVEKIT_API_KEY` e `LIVEKIT_API_SECRET` no ambiente antes de iniciar o backend. `.env.example` é só referência: o Go **não carrega `.env` automaticamente**. Segredos ficam somente no backend/ambiente, nunca no renderer ou no repositório.

**O ZIP original continha credenciais em um iniciador LiveKit. Elas foram removidas desta entrega. Se eram reais ou ainda estão em uso, rotacione a chave e o segredo no provedor. A limpeza não revoga credenciais nem remove cópias antigas já compartilhadas.**

## Testes

```sh
cd Explicit_V16/server/Comunicador_Fase1
go test ./...
go test -race ./...
go vet ./...
node --test web/media-src/*.test.js
```

```sh
cd Explicit_V16/desktop
npm test
npm run check
```

O detector de corridas requer uma toolchain/plataforma compatível. Os testes usam fixtures; não aponte testes para banco ou serviços de produção.

## Compilar e distribuir

No Windows, execute `Explicit_V16/BUILD_PORTABLE.bat`, ou na pasta `desktop` use `npm run build:portable` depois de instalar as dependências. O nome é obtido da versão do `package.json`; não está mais preso a `18.6.5`.

O resultado fica em `desktop/dist/`. Executáveis e ZIPs de distribuição podem ser publicados separadamente em **Releases**, após validação Windows. O código-fonte não precisa conter esses arquivos. A compilação/execução do cliente Windows não foi realizada nesta preparação.

Os scripts `kinghost/` são opcionais, alteram infraestrutura e não foram executados. Examine-os antes de usar. A preparação do GitHub não autoriza nem executa implantação.

## Primeiro envio ao GitHub

1. Extraia este ZIP inteiro, incluindo `.gitignore` e `.gitattributes`.
2. No GitHub Desktop, adicione esta pasta, revise os arquivos e faça o primeiro commit.
3. Publique em um repositório **privado** inicialmente. Nenhum repositório foi criado ou publicado por esta preparação.
4. Não arraste o próprio ZIP para dentro do repositório: envie os arquivos extraídos.

Se preferir Git pela linha de comando, execute na raiz:

```sh
git init
git add .
git diff --cached --stat
git commit -m "Base Explicit 18.6.48 auditada e preparada para GitHub"
```

Antes de publicar, revise o primeiro commit. `.gitignore` não remove segredos que já entraram no histórico de um repositório existente.

## Estado e documentação

- Auditoria mais recente: [docs/auditoria-rodada-4/relatorio.md](docs/auditoria-rodada-4/relatorio.md).
- Preparação e validação deste pacote: [docs/PREPARACAO-GITHUB.md](docs/PREPARACAO-GITHUB.md).
- Pendências VPS: [docs/PENDENCIAS-FUTURA-IMPLANTACAO.md](docs/PENDENCIAS-FUTURA-IMPLANTACAO.md).

Os relatórios antigos preservados em `docs/` descrevem o pacote auditado antes desta limpeza; nomes de executáveis e caminhos históricos podem se referir ao ZIP original. Não são instruções para atualizar ou implantar produção automaticamente.

Os testes automatizados não comprovam áudio/tela reais, NAT/TURN ou funcionamento Windows. LGPD, retenção/exclusão de dados e condições de uso exigem trabalho próprio antes de abrir o serviço ao público.

## Licenças

Preservados os avisos de licença das fontes e bibliotecas distribuídas. Não foi atribuída uma licença pública nova ao código do Explicit. Defina a licença do projeto antes de autorizar redistribuição pública; tornar um repositório público não substitui essa decisão.
