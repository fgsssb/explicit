# Matriz de permissões — Explicit v18.6.41

## Regras verificadas no código

Fonte: `Explicit_V16/server/Comunicador_Fase1/admin.go` (`hasPermission`, `channelPermission`, `validPermissions`), `channel_permissions.go` (`maySetOverrides`, `validateOverrides`). Referência conceitual: documentação oficial das permissões do Discord; o Explicit possui nomes e regras próprios.

- Conta global autorizada pelo backend (`isSuperadmin`) e proprietário da comunidade possuem privilégios elevados segundo as regras existentes.
- Um cargo `ADMINISTRATOR` da comunidade ultrapassa as sobrescritas de canal. Essa autoridade depende de atribuição legítima do cargo, também protegida por hierarquia.
- Para membros comuns: permissões básicas da comunidade → sobrescrita `@everyone` do canal → união das permissões de cargos, com **allow prevalecendo sobre deny entre os cargos** → sobrescrita individual do membro.
- `VIEW_CHANNEL` é verificada na leitura de canal e em operações selecionadas; o novo teste exige também visibilidade ao emitir convite direcionado.
- As alterações de cargos agora voltam ao estado anterior quando a persistência falha.

## Inventário de chaves de permissões

| Grupo | Chaves existentes | Evidência disponível |
|---|---|---|
| Visualização e chat | `VIEW_CHANNEL`, `SEND_MESSAGES`, `ATTACH_FILES`, `USE_STICKERS`, `EDIT_OWN_MESSAGES`, `DELETE_OWN_MESSAGES`, `EDIT_ANY_MESSAGES`, `DELETE_ANY_MESSAGES`, `PIN_MESSAGES` | `channel_permissions_test.go`, `channel_visibility_marker_v18619_test.go`, testes de mensagens, stickers e regressão |
| Voz | `CONNECT_VOICE`, `SPEAK`, `USE_PTT`, `SCREEN_SHARE`, `POKE_MEMBERS`, `MUTE_MEMBERS`, `DEAFEN_MEMBERS`, `MOVE_MEMBERS`, `DISCONNECT_VOICE` | `voice_test.go`, `voice_move_permissions_v1861_test.go`, `voice_poke_permissions_v18635_test.go`, `livekit_test.go` |
| Convites | `CREATE_INVITES`, `VIEW_INVITES` | `invite_test.go`, `community_invite_codes.go`, `TestAuditInviteToHiddenChannelRequiresVisibility` |
| Gerenciamento de canais | `CREATE_CHANNEL`, `MANAGE_CHANNELS` | `channel_permissions_test.go`, `channel_reorder_test.go` |
| Gerenciamento da comunidade | `MANAGE_COMMUNITY`, `MANAGE_ROLES`, `ASSIGN_ROLES`, `MANAGE_MEMBERS`, `ADMINISTRATOR` | `admin_test.go`, `channel_permissions_test.go`, `TestAuditRoleWritesRollBackPermissionsOnStorageFailure` |
| Moderação | `KICK_MEMBERS`, `BAN_MEMBERS`, `BAN_CHANNEL_MEMBERS`, `MANAGE_SANCTIONS`, `VIEW_AUDIT_LOG` | `sanctions_test.go`, `moderation_cases_v18624_test.go`, `staff_control_test.go` |

**Atenção:** a existência de testes relacionados não significa que **todas** as permutações de cargos, hierarquia e negações tenham sido examinadas. A cobertura da matriz completa com as oito posições de usuário solicitadas é uma pendência de homologação, não um item concluído.

## Testes de autorização recomendados para cada operação

1. Anônimo deve receber 401 e não alterar estado.
2. Membro sem permissão deve receber 403 e não alterar estado.
3. Membro com permissão efetiva deve executar a operação permitida.
4. Membro com múltiplos cargos deve seguir a precedência documentada de allow/deny.
5. Negação de canal deve prevalecer quando não há permissão superior legítima.
6. Administrador e proprietário devem respeitar as regras específicas de sua autoridade.
7. Revogação de cargo ou canal durante sessão ativa deve impedir novas operações no servidor.
8. Cliente adulterado enviando requisição direta deve ser tratado como qualquer outro cliente, sem confiar na UI.
9. Falha de persistência deve reverter operações sensíveis, evitando privilégios transitórios.

## Casos acrescentados neste ciclo

| Caso | Negado | Permitido | Falha de gravação | Resultado |
|---|---:|---:|---:|---|
| Convite direcionado a canal oculto | Sim | Sim, quando visível | — | Aprovado |
| Entrada em comunidade | — | Fluxos existentes | Sim | Aprovado |
| Criação de cargo | Autorização anterior preservada | Fluxos existentes | Sim | Aprovado |
| Atualização/reordenação de cargo | Autorização anterior preservada | Fluxos existentes | Sim | Aprovado |
| Atribuição/remoção de cargo | Autorização anterior preservada | Fluxos existentes | Sim | Aprovado |
| Exclusão de cargo | Autorização anterior preservada | Fluxos existentes | Sim | Aprovado |
| Tokens e requisições de voz | — | Rajadas legítimas admitidas | Limite por usuário | Aprovado |

Não foi alterada a ordem global de precedência das permissões existentes, pois isso seria mudança de comportamento abrangente que exigiria homologação completa das comunidades já criadas.
