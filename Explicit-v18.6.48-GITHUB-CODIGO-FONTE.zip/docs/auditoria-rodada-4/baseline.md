# Estado inicial e continuidade

| Check inicial | Resultado | Evidência |
|---|---|---|
| Integridade da entrada | aprovada, 693 arquivos/CRC | mapa.md |
| go test -count=1 ./... | exit 0; 7,001 s | logs/go-baseline.txt |
| npm test no desktop | 181/181, exit 0 | logs/desktop-baseline.txt |
| node --test web/media-src/*.test.js | 37/37, exit 0 | logs/media-baseline.txt |
| Novos testes de saída/exclusão antes do patch | 4 variantes falharam, controles de erro de disco/ator inválido passaram | logs/media-revoke-before.txt |

As suítes iniciais incluem as regressões anteriores: rollback/nil de DM; guard de captura; continuidade/limite de SSE; sessão revogada no SSE; ACL herdada em criação/reordenação; arraste coerente. Elas passaram antes de qualquer alteração desta rodada.

Falha reproduzida: com participante ativo em audit-community:voice, sair/excluir retornava sucesso e removia presença local, mas o serviço de mídia simulado não recebia RemoveParticipant. Simular erro da SFU também retornava 200 em vez de informar falha parcial. Não se tratou ausência de teste como aprovação de mídia real.
