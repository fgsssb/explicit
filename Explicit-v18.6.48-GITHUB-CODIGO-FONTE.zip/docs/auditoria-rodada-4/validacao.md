# Validação e evidências

| Teste/comando | Resultado | Evidência |
|---|---|---|
| go test -count=1 ./... | passou, exit 0; 9,165 s | logs/go-after.txt |
| go test -race -count=1 ./... | passou, exit 0; 25,288 s | logs/go-race-after.txt |
| go test -run TestAuditRound4 -count=1 -v | passou, exit 0 | logs/round4-final.txt |
| go test -race -run TestAuditRound4 -count=1 | passou, exit 0 | logs/round4-race-final.txt |
| TestAuditRound4MultiAccountHTTPIsolation | passou; rede HTTP loopback e 4 logins reais | logs/multiaccount-http.txt |
| Testes novos antes/depois | falha original → aprovação | logs/media-revoke-before.txt / media-revoke-after.txt |
| npm test no desktop | 181/181, exit 0 | logs/desktop-after.txt |
| npm run check no desktop | exit 0 | logs/desktop-check.txt |
| node --test web/media-src/*.test.js | 37/37, exit 0 | logs/media-after.txt |
| go vet ./... | exit 0 | logs/builds-and-vet.txt |
| go build Windows x64 e Linux amd64 | exit 0 | logs/builds-and-vet.txt |
| smoke do binário Linux isolado | register-config=200, SSE sem token=401 | logs/server-smoke.txt |

A última alteração após a suíte completa foi somente acrescentar asserts de recarga no teste de R4-01; todos os testes R4 finais foram repetidos com e sem race. Código de produção não mudou depois da suíte completa. Patch e hashes-alterados.json identificam a revisão.

## Cenário HTTP executado
1. Quatro contas sintéticas, hashes de senha reais e termos atuais; verificação de CAPTCHA ativa com desafios sintéticos conhecidos pelo fixture. Senha incorreta retorna 401; cada conta faz login e recebe sua própria sessão (tokens não registrados).
2. A publica em canal privado, B autorizado lê; C sem ACL e D de outra comunidade recebem 403.
3. A cria grupo com B/C, envia DM; B recebe ao consultar a API; D recebe 404.
4. A envia TXT, B/C baixam conteúdo correto; D não baixa nem envia; PNG disfarçado e arquivo acima de 8 MiB são rejeitados.
5. A/C entram em chamada, grants têm identidade e sala canônicas; D não obtém grant. C sai: requisição RemoveParticipant aponta à sala correta; C perde acesso à DM, arquivo e novo grant.
6. Recarga do armazenamento mantém mensagens e saída de C. B faz logout e sua sessão anterior recebe 401 na API.

Não há navegador, áudio, tela real ou LiveKit ativo nesse cenário: a aplicação usa TCP/HTTP local real; somente o HTTP administrativo da SFU é simulado. Não se testou latência/NAT/TURN, captura real ou qualidade de mídia.

Reprodução:
```
cd Explicit_V16/server/Comunicador_Fase1
go test -run TestAuditRound4 -count=1 -v
go test -race -run TestAuditRound4 -count=1
go test -count=1 ./...
go test -race -count=1 ./...
go vet ./...
node --test web/media-src/*.test.js
cd ../../desktop
npm test
npm run check
```
Executar em fixtures sem configuração SQL de produção. Testes usam Go >=1.22 e Node com node:test.
