# Achado confirmado

| ID | Área / severidade | Confirmação | Implementação | Validação |
|---|---|---|---|---|
| R4-01 | backend/comunicação/autorização — média | ausência da chamada de revogação reproduzida em handlers; prova estática do fluxo | implementada | passou com SFU simulado; mídia real pendente |

## R4-01 — Saída/exclusão de comunidade não revoga transporte de mídia ativo
Referências da entrada: communities.go:104–142 (q.Leave); community_hub.go:178–251 (delete_community); voice.go:61–81 (leave com remoção correta como controle); livekit.go:108–163 (grant por room); staff_control.go:483–558 (RoomService).

Pré-condição: membro já conectado a uma sala de voz LiveKit. Ator pode usar cliente modificado que mantenha o transporte aberto; exclusão é restrita ao proprietário/administrador conforme proteção existente. Entrada → autenticação → permissão/participação → save → exclusão do voice.members → resposta 200. Não havia solicitação RemoveParticipant nos dois caminhos, embora voiceAPI.leave já a fizesse. Deletar presença do aplicativo não executa por si só uma ação no SFU.

Impacto: a revogação no aplicativo não solicitava o encerramento da participação no serviço externo. Isso abre possibilidade de continuidade de voz/tela por transporte já estabelecido; não foi capturado áudio real nem demonstrado replay de token contra um LiveKit real. Severidade média pelo alcance em participantes previamente autorizados e pela necessidade de transporte já aberto; não é emissão anônima de credenciais ou quebra de criptografia.

Confirmação: os testes recebem 200 e zero chamadas à SFU no original. Depois do patch, esperam RemoveParticipant na sala canônica e identidade corretas; simulam SFU 503 e recebem 502 com membership_removed/community_deleted; erro de persistência continua 500 sem remoção local nem chamada SFU. O mock exige que mutexes de store/voz/directCalls estejam livres no HTTP. Confiança alta na falha de integração; encerramento externo real permanece não validado.

Correção: serialização com mediaControlMu, snapshot das presenças da comunidade após save, remoção local e chamada SFU fora dos locks de dados/voz. Saída afeta somente o ator; exclusão afeta todos os participantes conhecidos na comunidade; participantes de outras comunidades ficam intactos. Chamadas concorrentes por participante usam o timeout HTTP já existente e todas são tentadas, mesmo quando uma falha. Sem alteração de endpoint, persistência ou layout.

Regressões: audit_round4_media_test.go — leave/delete × sucesso/falha SFU/falha save; ator externo negado; tentativa de todos os participantes; recarga do arquivo comprova remoção persistida. Logs before/after/round4-final. Teste adicional de grupo/DM/call valida remoção na sala real do grupo, preservando correção anterior.

Limites/resíduos: cleanup cobre participantes presentes no cache local. Não comprova remoção de transporte que já desapareceu desse cache. Não há retry durável após SFU indisponível: 502 informa a alteração já persistida; não restaura acesso. O helper existente faz revogação de token específica de LiveKit Cloud, mas replay em self-hosted/Cloud e reconexão real exigem ensaio externo. Esses pontos não foram marcados como corrigidos.

## Resultados sem novos achados confirmados
O cenário HTTP de quatro contas passou para: senha errada negada; quatro sessões distintas; canal privado por ACL; isolamento entre comunidades/DMs; anexo acessível a membros e negado a estranho/ex-membro; upload por estranho, arquivo disfarçado e tamanho excessivo negados; JWT de chamada limitado à identidade/sala; saída do grupo revoga a sala canônica; estado preservado na recarga; logout impede reutilizar a sessão na API.
Esses resultados cobrem as entradas exercitadas, não a segurança integral de todos os endpoints. Não se fabricou uma quantidade mínima de vulnerabilidades.
