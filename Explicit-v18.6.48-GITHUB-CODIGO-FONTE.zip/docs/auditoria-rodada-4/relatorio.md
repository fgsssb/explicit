# Explicit 18.6.48 — quarta rodada

As correções anteriores passaram nas suítes iniciais. Esta rodada aprofundou testes funcionais de API com quatro contas, autenticação real, isolamento de comunidades/DMs, anexos, grants de chamadas, saída de grupo, recarga da persistência e logout.

Corrigida uma família de falhas em dois caminhos: saída e exclusão de comunidade removiam presença local sem solicitar remoção do participante no LiveKit. Agora participantes conhecidos são removidos do cache e há solicitação de revogação à SFU, com erro parcial explícito se o serviço externo falhar. A gravação falha não provoca desconexão. A interface foi preservada.

Passaram: suíte Go, detector de corridas, go vet, cenário HTTP com quatro contas, 181 testes desktop e 37 testes JavaScript. Achados, reprodução antes/depois, logs e limites estão nesta pasta. Não é auditoria exaustiva nem certificação de segurança.

| Área | Cobertura desta rodada | Limites |
|---|---|---|
| Electron | suíte/pre-build e guard anterior | sem runtime/instalador Windows |
| Frontend | regressões existentes, sem mudança visual | sem navegador, DPI/teclado/screenshots novos |
| Backend | handlers de saída/exclusão; 4 logins por HTTP; suíte completa | não cobre todo endpoint/combinação |
| Dados | falha de save, rollback anterior, recarga de membros/mensagens | PostgreSQL/MySQL reais não executados |
| Segurança | isolamento de canal/DM/arquivo/grants; logout API | sem scanner atual de advisories ou pentest amplo |
| Desempenho | HTTP SFU fora de locks, timeout existente e tentativa de todos | sem benchmark ou 20 ciclos reais |
| Comunicação | revogação da sala canônica e regressões SSE | SFU simulado; sem áudio/tela/NAT/TURN real |

Três servidores foram recompilados do fonte final: ExplicitServer-Teste-Cloud.exe, ExplicitServer-Radmin-Postgres.exe e kinghost/explicit-server-linux-amd64. Linux passou smoke isolado; Windows foi compilado, não executado. Cliente Electron não foi recompilado/empacotado; não há instalador desktop novo. A versão declarada foi preservada.

Os relatórios das rodadas anteriores são históricos. O atual é AUDITORIA-RODADA-4. Nenhum serviço de produção, banco real ou conta externa foi utilizado; nenhum commit/push/deploy. 2FA Owner/Admin, verificação de e-mail e modernização PostgreSQL continuam adiados para a VPS.

## Próximos testes prioritários
1. LiveKit real + PCs distintos: sair/excluir comunidade com voz e tela abertas; cliente que não fecha o transporte; reconexão com token antigo em Cloud e self-hosted; testar participante ausente do cache e SFU indisponível/recuperada.
2. Logout e banimento durante call de comunidade e DM com várias sessões; confirmar limpeza de mídia e política de reconexão em runtime. O teste desta rodada valida logout na API, não encerramento real de toda mídia.
3. Electron Windows: permissão de microfone, iniciar/cancelar tela, minimizar/restaurar/fechar, troca de conta, reconexão e paridade web.
4. Falhas de disco/SQL e acessos concorrentes de UI, incluindo upload com FFprobe lento, sem dados de produção.
5. Revisão de dependências com advisories atuais e lockfile revisado; sem atualizar tudo automaticamente.

Limitações da correção: presenças conhecidas no cache; sem retry durável em falha SFU; replay externo de tokens ainda não verificado. Ver achados.md. Não foram marcadas como resolvidas as etapas que exigem infraestrutura real.

Rollback em cópia: inverter correcoes.patch; remover community_media_cleanup.go, audit_round4_media_test.go e audit_round4_http_test.go; restaurar os três binários da entrada identificada em mapa.md. Não há migração de dados.
