# Quarta rodada — mapa e identidade
Data: 04/11/2026. Entrada exclusiva: `Explicit-v18.6.48-AUDITADO-RODADA-3-COMPLETO(1).zip`.
SHA-256: `fe88ce2578fefeda978c904aeb8542cc09aa01f65a0fe096080f86cd1e46cb62`. Tamanho 32695929 bytes; 693 entradas; índice/CRC do ZIP aprovados. Extração isolada em round4. Nenhuma reconstrução ou mistura de versões foi necessária.

Lidos os registros anteriores: AUDITORIA-2026-11-04, AUDITORIA-RODADA-2 e AUDITORIA-RODADA-3. Correções anteriores preservadas. Não há histórico git utilizável do ZIP.
Stack observada: Go 1.22 no go.mod, sem dependências declaradas; Electron 43.0.0/electron-builder 26.18.0; frontend HTML/CSS/JS; HTTP/SSE; LiveKit; armazenamento JSON e adaptadores SQL opcionais. Nenhuma mudança de dependências/manifest/tema/esquema de dados. Toolchain de validação: Go 1.23.12 isolado, Node v24.22.1, Linux. Hash oficial da toolchain já conferido na rodada 2; não se afirma que seja a versão atual mais recente.

Arquivos aprofundados: communities.go, community_hub.go, direct_calls.go, social.go, direct_files.go, voice.go, livekit.go, staff_control.go (RoomService), main.go (auth/login/events/routes), captcha.go, terms.go, resource_guard.go; testes e manifests desktop. Referências da auditoria e matriz de cenários das rodadas anteriores reutilizadas.

Fronteiras: cliente A/B/C/D → HTTP real loopback → Bearer/CAPTCHA/senha → autorização de canal/DM/anexo/call → persistência; revogação de participação → cache de voz → chamada administrativa ao SFU. Invariantes: sucesso de gravação precede desconexão; erro de gravação mantém acesso/presença anteriores; HTTP de mídia não segura mutex de dados/voz; grants de mídia serializados com saída/exclusão; usuários de outras comunidades não são removidos.

Fixtures: quatro usuários com senhas sintéticas, CAPTCHA sintético com verificador real e sessões de login independentes. O teste NÃO usa o bypass de CAPTCHA. SFU é simulado; rede HTTP da aplicação usa httptest.NewServer com cliente/transport próprios. Nenhuma conta externa, DM privada real ou banco de produção foi utilizado.
