# Itens adiados — futura implantação

Este documento **não é instrução para executar as ações agora**. Nenhum desses trabalhos foi implementado na auditoria atual.

## Requisitos adiados explicitamente

- Autenticação em duas etapas para Owner/Admin.
- Verificação obrigatória de e-mail no cadastro.
- Modernização da camada de armazenamento e da conexão PostgreSQL.

## Requisitos de infraestrutura/produção fora do escopo

- Preparação de VPS, isolamento de processos, firewall, administração de sistema e endurecimento do host.
- DNS, proxy reverso, TLS público, certificados, Cloudflare, TURN/SFU adicionais, redes e balanceamento.
- Secret management externo, credenciais de produção e rotação operacional de chaves.
- Backups de produção, exercícios de restauração, retenção, monitoramento e alertas da VPS.
- Pipelines CI/CD e atualização remota.
- Testes de carga controlados contra a infraestrutura futura, incluindo WebRTC com vários usuários e diferentes redes.

## Riscos de código para uma auditoria posterior

- Reduzir dependência de `unsafe-inline` na CSP sem comprometer os controles e componentes existentes.
- Comprovar a revogação real de tracks LiveKit quando um usuário perde permissão ou deixa uma comunidade.
- Testar o comportamento de sessões Windows Electron reais e de múltiplos dispositivos de áudio/vídeo.
- Repetir detector de corrida Go com ambiente instrumentado e tempo suficiente.
- Executar inventário de CVEs e auditoria externa de dependências em ambiente com acesso online.
- Reforçar testes de cobertura RBAC com todos os papéis e combinações de permissões.
- Dimensionar crescimento do estado JSON e custo das gravações em cargas sustentadas antes da migração planejada.

**Não modificar arquivos, servidores ou serviços externos até a etapa correspondente ser autorizada.**
