# Moldura personalizada — Explicit 18.6.48

Alterações limitadas a desktop/main.js e desktop/preload.js: barra preta com azul-bebê, ícone oficial embutido em resolução reduzida, botão Maximizar/Restaurar sincronizado com eventos da janela e solicitação de cantos nativos no Windows 11. Navegação, dimensões e compensação de 34 px já existentes preservadas. Fechar continua chamando win.close(), respeitando a bandeja. A validação de remetente, frame principal e origem também protege a consulta de estado. O listener do preload é removido ao sair da página.

Interface web, backend, conteúdo interno, dependências, versão, splash e configuração de build mantidos byte a byte. O teste de navegação foi atualizado para reconhecer a opção roundedCorners.

Validação: node --check, scripts/check.js e npm test. Não foi possível executar Chromium/Electron neste ambiente. Nenhuma compilação Windows ou comparação visual de login/chat/overlays foi realizada. A prévia é ilustrativa.

No Windows, validar: minimizar/restaurar pela barra de tarefas, maximizar/restaurar e duplo clique, arrastar e redimensionar, Snap, Alt+F4, bandeja, múltiplos monitores e escalas 100/125/150%. Comparar login, chat e overlay antes/depois. Cantos dependem do Windows 11 e do compositor; não há transparência ou máscara CSS. O botão HTML não promete o menu Snap ao passar o mouse.

Uso: substituir a pasta anterior pela fonte completa deste ZIP e seguir os scripts de compilação existentes. Não é um executável pronto. A versão interna foi mantida para evitar alterações fora do escopo.

Reversão: restaurar desktop/main.js, desktop/preload.js e desktop/tests/explicit-1864-navigation.test.js do ZIP original Explicit-v18.6.48-CORRIGIDO(1).zip e recompilar.
