# Explicit — contrato visual v18.6.47

Este contrato substitui as restrições pontuais de apresentação da v18.6.46. Base exclusiva: ZIP v18.6.46 recebido nesta solicitação. Refinar o produto existente, preservando arquitetura, navegação, ações, identidade e o preto com azul-bebê. A referência de acabamento é a legibilidade e a previsibilidade de um aplicativo de comunicação desktop; não copiar marca, paleta ou ativos do Discord.

## Objetos e tarefas

Comunidades, canais de texto e voz, conversas privadas, participantes, mensagens, perfis e preferências. Sessões longas em desktop; abrir conversa e enviar mensagem são as ações mais frequentes. Comunidade: qual canal está ativo e quem está disponível? DM: com quem converso e como respondo? Início: onde encontro amigos e comunidades? Configurações: qual preferência estou alterando? Menu/modal: qual ação será executada e como cancelar?

Manter estrela oficial, avatares circulares, marca Explicit, fotos, estilos individuais de nomes, badges, cores dos cargos, estados de presença, indicador de fala verde, ping e ações destrutivas. Dados nas capturas são fictícios; nenhum número de demonstração é injetado no produto.

## Cores

| Papel | Token | Valor |
| --- | --- | --- |
| Fundo | --ex-bg | #08090b |
| Navegação | --ex-sidebar | #0d0f12 |
| Superfície | --ex-surface | #121519 |
| Superfície elevada | --ex-raised | #191d23 |
| Hover | --ex-hover | #20262e |
| Seleção | --ex-selected | #192e40 |
| Separação estrutural | --ex-line | #292e35 |
| Borda de controle | --ex-control-line | #626d7a |
| Texto principal | --ex-text | #edf1f5 |
| Texto secundário | --ex-secondary | #b8c0ca |
| Metadados | --ex-muted | #9da8b5 |
| Azul-bebê | --ex-blue | #a8d5f7 |
| Hover primário | --ex-blue-hover | #c1e2fb |
| Texto sobre azul | --ex-on-blue | #0b1823 |

Arquivo de origem: web/ui-tokens.css. A cópia desktop/ui-tokens.css contém os mesmos tokens, com URL de fonte relativa à janela local. Cores neutras nas grandes superfícies; azul em seleção, foco e ação principal. Sombras apenas em menus, popovers e modais. Não mudar cores semânticas ou personalizações.

## Tipografia e espaços

Inter variável incluída localmente, SIL OFL 1.1, com fallback Segoe UI/Arial/sans-serif; sem CDN. Base 14px; mensagens 15px/1.6; navegação 13–14px; metadados 12px; títulos 18–24px. Fontes próprias dos presets continuam válidas. Ícones de interface alterados são SVG locais com traço 1.7, sem pacote novo.

Escala de espaços 4/8/12/16/24px. Controles 34–42px conforme contexto. Raio 8px nos controles, 10px nas superfícies pequenas e menus, 14px nos modais. Lista de canais permanece compacta; lista de DMs e conversa usam as colunas já previstas no projeto, corrigindo o conflito de flex/grid.

## Estados e comportamento

Foco visível de 2px em azul-bebê; ação primária azul com texto escuro, cancelar neutro. Menus com linhas legíveis, seleção perceptível e rolagem própria quando necessário. Modal sobre scrim sem blur, mantendo a barra nativa acessível. Tab, Shift+Tab, Escape e retorno de foco respeitam os mecanismos existentes. Sem nova animação decorativa; redução de movimento continua respeitada.

## Integração e validação

Styles finais carregados após as camadas legadas. O ID explicitApp delimita a prioridade de cascata sem mexer nas permissões ou endpoints. Fonte web na raiz para cumprir publicWebPath existente; fonte e tokens desktop listados no empacotamento e no check de pré-build. Não acrescentar conteúdo demonstrativo ao servidor real.

Validar no Electron 43 o renderer e preload isolados. Não interpretar capturas e mocks como validação do backend Go, SFU, bandeja, lock de instância, barra Windows ou instalador. A matriz e as evidências estão em REVISAO-v18.6.47.

## Correção v18.6.48 — configurações da comunidade

Janela central no mesmo padrão dos Ajustes: largura máxima 1120px, altura máxima 800px e folga ao viewport; título e fechar dentro do modal, sidebar 240px e conteúdo rolável. Reutilizar os tokens existentes para fundo, seleção, campos e botões. Em janelas estreitas, navegação horizontal para manter todas as seções acessíveis. Editor de cargos integrado ao conteúdo, sem scroll ou altura de main global. Montagem, empilhamento e foco usam os helpers compartilhados dos modais. Convites e Notificações preservam os destinos especializados já existentes.
