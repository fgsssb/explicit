# Preparação para GitHub — 05/11/2026

Base exclusiva: Explicit-v18.6.48-AUDITADO-RODADA-4-COMPLETO(1).zip. SHA-256 da entrada: 15582ef007e0595b7744754c6a31446e91688d474ce551c1fae0ad493c2cc891. Integridade de todas as entradas aprovada antes da extração.

## Alterações

- Retirados executáveis Windows/Linux, binários duplicados, arquivo temporário de transferência, capturas e documentação histórica repetitiva. Consulte ARQUIVOS-REMOVIDOS.json (somente caminhos/tamanhos).
- Preservados todos os arquivos de código Go/JS/TS/HTML/CSS, testes e recursos PNG/ICO/WOFF2 dentro de Explicit_V16: comparação byte a byte com o ZIP original aprovada. Inclui web/vendor e avisos de licença.
- Mantidos em docs/ a auditoria da rodada 4, matriz de permissões, pendências VPS, referência da moldura e design system. Histórico retirado não é necessário à execução; a documentação preservada pode mencionar arquivos do pacote original.
- Acrescentados README.md, .gitignore, .gitattributes e .env.example. Pastas do código mantidas para não romper caminhos. Não foi atribuída licença nova ao código do projeto.
- Iniciador que continha API Key e API Secret LiveKit substituído por alias do fluxo interativo já existente. URL privada de projeto removida desse script. As literais originais da chave/segredo foram procuradas em TODOS os arquivos entregues: zero ocorrências, inclusive UTF-16LE. Nenhum valor foi gravado neste relatório.
- Rotacione credenciais se forem reais/ainda ativas. Não houve acesso ao provedor, teste dessas credenciais ou revogação automática. Cópias antigas continuam contendo o que já possuíam.
- Configuração desktop versionada passou a localhost, com exemplo HTTPS separado; overrides de endpoint e segredos são ignorados no Git. Senhas e chaves permanecem no backend/ambiente. .env.example não é carregado automaticamente pelo Go.
- BUILD_PORTABLE.bat passou a obter a versão do package.json; removida a verificação obsoleta 18.6.5. Acrescentado BUILD_SERVER.bat para produzir os dois nomes esperados pelos atalhos Windows. Mensagens de ferramentas de teste ajustadas à entrega sem binários.
- Iniciador Radmin/PostgreSQL solicita endereço local em vez de fixar IP pessoal. Launcher portátil Radmin procura um único executável pelo padrão de nome, sem fixar versão antiga.

## Validação executada

| Verificação | Resultado |
|---|---|
| go test -buildvcs=false -count=1 ./... | passou, exit 0; 8,128 s |
| npm test no desktop | 181/181, exit 0 |
| node --test web/media-src/*.test.js | 37/37, exit 0 |
| npm run check no desktop | passou, exit 0 |
| go build -trimpath, Linux amd64 e Windows amd64, CGO=0 | ambos passaram; resultados ficaram fora do pacote |
| bash -n em todos os scripts shell mantidos | passou; nenhum instalador foi executado |
| Comparação de código/testes/recursos com a entrada | idênticos nos tipos conferidos |
| Busca das literais LiveKit removidas | zero ocorrências |
| Busca adicional por padrões de credenciais fora de fixtures | somente placeholders explícitos de .env.example |
| git check-ignore | dados, .env, endpoint local, dependências e dist ignorados; código/testes/vendor/licenças não ignorados |

Os testes foram executados em Linux com Go 1.23.12 e Node 24.22.1. Não foram instaladas dependências npm nesta preparação. Não havia package-lock.json no original. Os arquivos gerados pelas verificações ficaram fora do ZIP final; logs detalhados das auditorias anteriores foram mantidos em docs/auditoria-rodada-4/.

Limites: scripts batch e PowerShell não foram executados no Windows; cliente Electron não foi empacotado. Compilar o servidor para Windows não comprova execução nesse sistema. Nenhuma implantação/serviço real foi acionado. A revisão de padrões de segredos não é prova de ausência de todo dado identificável; mantidos fixtures e endereços de compatibilidade presentes no código, sem alterar lógica do app.

O bundle LiveKit original contém somente um marcador de 159 bytes. Foi mantido byte a byte, e o README explica como os scripts existentes instalam o SDK oficial 2.23.0 antes de usar voz/tela. Não se declarou esse marcador um SDK funcional; testes unitários não validam a instalação do SDK nem mídia real.

Nenhum repositório remoto foi criado, commit publicado ou upload para GitHub feito. O ZIP final exclui metadados .git usados somente na conferência local, dependências, builds e dados de usuários. A integridade final é verificada por CRC de todas as entradas e pelo conteúdo do pacote.
